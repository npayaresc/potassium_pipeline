"""
Concentration-Range Feature Engineering Module

This module adds concentration-aware features that help AutoGluon learn
patterns specific to different potassium concentration ranges, replacing
the need for manual sample weighting.
"""
import logging
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class TargetAwareTransformer(BaseEstimator, TransformerMixin):
    """
    Wrapper that allows a transformer to store target values from fit() 
    and use them during transform() for concentration features.
    """
    
    def __init__(self, transformer):
        self.transformer = transformer
        self.y_fit_ = None
        
    def fit(self, X, y=None):
        """Fit the wrapped transformer and store target values."""
        self.y_fit_ = y
        self.transformer.fit(X, y)
        return self
        
    def transform(self, X):
        """Transform using the wrapped transformer."""
        return self.transformer.transform(X)
        
    def get_feature_names_out(self, input_features=None):
        """Pass through feature names from wrapped transformer."""
        return self.transformer.get_feature_names_out(input_features)


class MinimalConcentrationFeatures(BaseEstimator, TransformerMixin):
    """
    Lightweight concentration-aware features for raw spectral mode.
    
    This transformer adds essential distribution-aware features to help models
    handle the uneven target distribution while maintaining the raw spectral philosophy.
    It focuses only on the most impactful concentration features without full
    feature engineering.
    """
    
    def __init__(self, 
                 use_target_percentiles: bool = True,
                 low_percentile: float = 25.0,
                 high_percentile: float = 75.0,
                 potassium_wavelength: float = 766.49):
        """
        Initialize minimal concentration features.
        
        Args:
            use_target_percentiles: Calculate thresholds from target distribution
            low_percentile: Percentile for low concentration threshold
            high_percentile: Percentile for high concentration threshold
            potassium_wavelength: Primary potassium wavelength for intensity features
        """
        self.use_target_percentiles = use_target_percentiles
        self.low_percentile = low_percentile
        self.high_percentile = high_percentile
        self.potassium_wavelength = potassium_wavelength
        
        # Will be learned during fit
        self.low_threshold_ = None
        self.high_threshold_ = None
        self.k_intensity_percentiles_ = None
        self.feature_names_out_ = []
        
    def fit(self, X, y=None):
        """
        Fit the transformer by learning distribution statistics.
        
        Args:
            X: Raw spectral features [n_samples, n_wavelengths]
            y: Target concentrations (required for threshold calculation)
        """
        if y is None:
            raise ValueError("Target values (y) are required for MinimalConcentrationFeatures.fit()")
            
        X = self._validate_input(X)
        y_array = np.array(y)
        
        # Calculate concentration thresholds from target distribution
        if self.use_target_percentiles:
            self.low_threshold_ = np.percentile(y_array, self.low_percentile)
            self.high_threshold_ = np.percentile(y_array, self.high_percentile)
            logger.info(f"Learned concentration thresholds: low={self.low_threshold_:.3f}, high={self.high_threshold_:.3f}")
        else:
            # Use fixed thresholds based on typical potassium ranges
            self.low_threshold_ = 0.25
            self.high_threshold_ = 0.40
            
        # Calculate K intensity statistics if we can find the wavelength
        self.k_intensity_percentiles_ = self._calculate_k_intensity_percentiles(X)
        
        # Define feature names
        self.feature_names_out_ = [
            'concentration_range_low',      # Binary: is in low concentration range
            'concentration_range_high',     # Binary: is in high concentration range
            'concentration_range_mid',      # Binary: is in mid concentration range
            'k_intensity_weight',          # Concentration-based weighting feature
            'distribution_emphasis'         # Feature to emphasize rare concentration ranges
        ]
        
        logger.info(f"MinimalConcentrationFeatures fitted. Will generate {len(self.feature_names_out_)} features.")
        return self
        
    def transform(self, X):
        """
        Transform raw spectral data by adding minimal concentration features.
        
        Args:
            X: Raw spectral features [n_samples, n_wavelengths]
            
        Returns:
            X_enhanced: [n_samples, n_wavelengths + n_concentration_features]
        """
        X = self._validate_input(X)
        
        if self.low_threshold_ is None:
            raise ValueError("Transformer not fitted. Call fit() first.")
            
        X_df = pd.DataFrame(X) if not isinstance(X, pd.DataFrame) else X.copy()
        
        # Extract potassium intensity estimate (best available proxy)
        k_intensity = self._extract_k_intensity_proxy(X_df)
        
        # Normalize k_intensity to a 0-1 scale based on fitted statistics
        if self.k_intensity_percentiles_ is not None:
            k_min = self.k_intensity_percentiles_['values'][0]
            k_max = self.k_intensity_percentiles_['values'][-1]
            # Handle edge cases to prevent divide by zero warnings
            k_range = k_max - k_min
            if k_range > 1e-8 and not np.isnan(k_range) and not np.isinf(k_range):
                k_intensity_norm = np.clip((k_intensity - k_min) / k_range, 0, 1)
            else:
                # If range is too small or invalid, use uniform values
                k_intensity_norm = np.full_like(k_intensity, 0.5)
        else:
            # Fallback normalization with better edge case handling
            k_min = k_intensity.min()
            k_max = k_intensity.max()
            k_range = k_max - k_min
            if k_range > 1e-8 and not np.isnan(k_range) and not np.isinf(k_range):
                k_intensity_norm = (k_intensity - k_min) / k_range
            else:
                # If all values are the same or invalid, use uniform values
                k_intensity_norm = np.full_like(k_intensity, 0.5)
        
        # Use normalized intensity for threshold comparisons
        # Map target thresholds to intensity scale
        low_intensity_threshold = 0.3  # Assume low concentrations have lower relative intensities
        high_intensity_threshold = 0.7  # Assume high concentrations have higher relative intensities
        
        # Add concentration range indicators
        # These help models learn different behaviors for different concentration ranges
        X_df['concentration_range_low'] = (k_intensity_norm <= low_intensity_threshold).astype(float)
        X_df['concentration_range_high'] = (k_intensity_norm >= high_intensity_threshold).astype(float)
        X_df['concentration_range_mid'] = ((k_intensity_norm > low_intensity_threshold) & 
                                          (k_intensity_norm < high_intensity_threshold)).astype(float)
        
        # Add K intensity weighting feature
        # This creates a smooth weighting that emphasizes rare concentration ranges
        # Use normalized intensity percentile for weighting
        intensity_percentile = k_intensity_norm
        
        # Create concentration-dependent weighting (higher weight for extreme values)
        k_intensity_weight = 1.0 + 2.0 * (np.abs(intensity_percentile - 0.5) ** 2)
        X_df['k_intensity_weight'] = k_intensity_weight

        # Add distribution emphasis feature
        # This helps models focus on underrepresented regions
        distribution_emphasis = np.where(
            X_df['concentration_range_low'] == 1, 2.5,  # High emphasis on low concentrations
            np.where(X_df['concentration_range_high'] == 1, 2.0,  # High emphasis on high concentrations
                    1.0)  # Normal emphasis on mid-range
        )
        X_df['distribution_emphasis'] = distribution_emphasis
        
        logger.debug(f"MinimalConcentrationFeatures: Added {len(self.feature_names_out_)} features to {X.shape[1]} raw features")
        
        # Return DataFrame to preserve feature names for models that need them (like LightGBM)
        return X_df
        
    def get_feature_names_out(self, input_features=None):
        """Return feature names for output features."""
        if input_features is not None:
            # Combine input feature names with new concentration features
            if hasattr(input_features, 'tolist'):
                input_names = input_features.tolist()
            else:
                input_names = list(input_features)
            return input_names + self.feature_names_out_
        else:
            return self.feature_names_out_
            
    def _validate_input(self, X):
        """Validate and prepare input data."""
        if hasattr(X, 'values'):  # DataFrame
            return X.values if not isinstance(X, pd.DataFrame) else X
        return np.asarray(X)
        
    def _calculate_k_intensity_percentiles(self, X):
        """Calculate K intensity percentiles for weighting."""
        try:
            k_intensity = self._extract_k_intensity_proxy(X)
            percentiles = np.linspace(0, 100, 101)
            values = np.percentile(k_intensity, percentiles)
            return {
                'percentiles': percentiles / 100.0,  # Convert to 0-1 range
                'values': values
            }
        except Exception as e:
            logger.warning(f"Could not calculate K intensity percentiles: {e}")
            return None
            
    def _extract_k_intensity_proxy(self, X):
        """
        Extract a proxy for potassium intensity from raw spectral data.
        
        Since we don't have wavelength information in raw mode, we use
        statistical proxies based on the spectral data distribution.
        """
        X_array = X.values if isinstance(X, pd.DataFrame) else X
        
        # Use the peak intensity in the spectrum as a proxy
        # This assumes higher peak intensities correlate with higher concentrations
        peak_intensity = np.max(X_array, axis=1)
        
        # Also use the 90th percentile intensity as additional signal
        percentile_90 = np.percentile(X_array, 90, axis=1)
        
        # Combine peak and high percentile for more robust proxy
        k_intensity_proxy = 0.7 * peak_intensity + 0.3 * percentile_90
        
        return k_intensity_proxy

class ConcentrationRangeFeatures(BaseEstimator, TransformerMixin):
    """
    Transformer that adds concentration-aware features for improved AutoGluon performance.
    
    Instead of using sample weights, this transformer creates features that help
    the ensemble learn concentration-specific patterns, allowing different models
    in the ensemble to specialize in different concentration ranges.
    """
    
    def __init__(self, 
                 low_threshold: float = None,
                 high_threshold: float = None,
                 use_target_percentiles: bool = True,
                 low_percentile: float = 25.0,
                 high_percentile: float = 75.0,
                 enable_range_indicators: bool = True,
                 enable_spectral_modulation: bool = True,
                 enable_ratio_adjustments: bool = True,
                 enable_concentration_interactions: bool = True):
        """
        Initialize the concentration range feature transformer.
        
        Args:
            low_threshold: Fixed threshold for low concentration (if None, will be calculated from targets)
            high_threshold: Fixed threshold for high concentration (if None, will be calculated from targets)
            use_target_percentiles: If True, calculate thresholds from target distribution
            low_percentile: Percentile to use for low threshold (when use_target_percentiles=True)
            high_percentile: Percentile to use for high threshold (when use_target_percentiles=True)
            enable_range_indicators: Add binary and continuous range indicators
            enable_spectral_modulation: Add concentration-modulated spectral features
            enable_ratio_adjustments: Add concentration-adjusted ratio features
            enable_concentration_interactions: Add interaction features between concentration and spectral data
        """
        self.low_threshold = low_threshold
        self.high_threshold = high_threshold
        self.use_target_percentiles = use_target_percentiles
        self.low_percentile = low_percentile
        self.high_percentile = high_percentile
        self.enable_range_indicators = enable_range_indicators
        self.enable_spectral_modulation = enable_spectral_modulation
        self.enable_ratio_adjustments = enable_ratio_adjustments
        self.enable_concentration_interactions = enable_concentration_interactions
        
        # These will be learned during fit()
        self.p_intensity_percentiles_ = None
        self.pc_ratio_percentiles_ = None
        self.feature_statistics_ = None
        self.feature_names_out_ = []
        
        # Target-derived thresholds (learned from actual concentration data)
        self.fitted_low_threshold_ = None
        self.fitted_high_threshold_ = None
        self.target_statistics_ = None
        
    def fit(self, X: pd.DataFrame, y: Optional[pd.Series] = None):
        """
        Fit the transformer by learning data distribution characteristics.
        
        Args:
            X: Feature matrix with spectral features
            y: Target concentrations (REQUIRED for target-aware thresholds)
        """
        # Learn target distribution characteristics first (if provided)
        if y is not None and self.use_target_percentiles:
            self._learn_target_characteristics(y)
            logger.info(f"Learned concentration thresholds from target data: "
                       f"low={self.fitted_low_threshold_:.3f}, high={self.fitted_high_threshold_:.3f}")
        else:
            # Fallback to fixed thresholds or defaults
            self.fitted_low_threshold_ = self.low_threshold or 0.25
            self.fitted_high_threshold_ = self.high_threshold or 0.40
            if y is None:
                logger.warning("No target concentrations provided. Using fixed thresholds.")
            logger.info(f"Using fixed concentration thresholds: "
                       f"low={self.fitted_low_threshold_:.3f}, high={self.fitted_high_threshold_:.3f}")
        
        # Learn data distribution characteristics for intelligent feature creation
        self._learn_data_characteristics(X, y)
        
        # Generate feature names based on input features and enabled options
        self._generate_feature_names(X)
        
        logger.info(f"ConcentrationRangeFeatures fitted. Will generate {len(self.feature_names_out_)} new features.")
        return self
        
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Transform features by adding concentration-aware enhancements.
        
        Args:
            X: Input feature matrix
            
        Returns:
            Enhanced feature matrix with concentration-aware features
        """
        if self.feature_statistics_ is None:
            raise ValueError("Transformer must be fitted before transform")
            
        X_enhanced = X.copy()
        
        # Add range indicator features
        if self.enable_range_indicators:
            X_enhanced = self._add_range_indicators(X_enhanced)
            
        # Add spectral modulation features
        if self.enable_spectral_modulation:
            X_enhanced = self._add_spectral_modulation(X_enhanced)
            
        # Add ratio adjustment features
        if self.enable_ratio_adjustments:
            X_enhanced = self._add_ratio_adjustments(X_enhanced)
            
        # Add concentration interaction features
        if self.enable_concentration_interactions:
            X_enhanced = self._add_concentration_interactions(X_enhanced)
            
        logger.debug(f"Added {len(X_enhanced.columns) - len(X.columns)} concentration-aware features")
        return X_enhanced
        
    def get_feature_names_out(self, input_features=None):
        """Return feature names for output features."""
        if input_features is None:
            return self.feature_names_out_
        else:
            return list(input_features) + self.feature_names_out_
            
    def _learn_target_characteristics(self, y: pd.Series):
        """Learn concentration distribution characteristics from target data."""
        # Handle both pandas Series and numpy arrays
        if isinstance(y, pd.Series):
            y_clean = y.dropna()
        else:
            # For numpy arrays, remove NaN values
            y_clean = y[~np.isnan(y)]
        
        if len(y_clean) == 0:
            logger.warning("No valid target concentrations found. Using default thresholds.")
            self.fitted_low_threshold_ = self.low_threshold or 0.25
            self.fitted_high_threshold_ = self.high_threshold or 0.40
            return
        
        # Calculate thresholds based on target distribution percentiles
        self.fitted_low_threshold_ = np.percentile(y_clean, self.low_percentile)
        self.fitted_high_threshold_ = np.percentile(y_clean, self.high_percentile)
        
        # Store comprehensive target statistics
        self.target_statistics_ = {
            'min': np.min(y_clean),
            'max': np.max(y_clean),
            'mean': np.mean(y_clean),
            'std': np.std(y_clean),
            'p10': np.percentile(y_clean, 10),
            'p25': np.percentile(y_clean, 25),
            'p50': np.percentile(y_clean, 50),
            'p75': np.percentile(y_clean, 75),
            'p90': np.percentile(y_clean, 90),
            'count': len(y_clean)
        }
        
        # Ensure thresholds are reasonable
        concentration_range = self.target_statistics_['max'] - self.target_statistics_['min']
        min_gap = concentration_range * 0.1  # At least 10% of range between thresholds
        
        if self.fitted_high_threshold_ - self.fitted_low_threshold_ < min_gap:
            # Adjust thresholds to ensure meaningful separation
            center = (self.fitted_low_threshold_ + self.fitted_high_threshold_) / 2
            self.fitted_low_threshold_ = max(self.target_statistics_['min'], center - min_gap/2)
            self.fitted_high_threshold_ = min(self.target_statistics_['max'], center + min_gap/2)
            logger.info(f"Adjusted thresholds to ensure minimum separation: "
                       f"low={self.fitted_low_threshold_:.3f}, high={self.fitted_high_threshold_:.3f}")
    
    def _learn_data_characteristics(self, X: pd.DataFrame, y: Optional[pd.Series] = None):
        """Learn key statistics about the spectral data distribution."""
        self.feature_statistics_ = {}
        
        # Learn K intensity characteristics if available (potassium target)
        k_intensity_cols = [col for col in X.columns if 'K_I' in col and ('peak_area' in col or 'peak_height' in col)]
        if k_intensity_cols:
            k_intensities = X[k_intensity_cols].fillna(0).sum(axis=1)
            self.k_intensity_percentiles_ = {
                'k10': np.percentile(k_intensities, 10),
                'k25': np.percentile(k_intensities, 25),
                'k50': np.percentile(k_intensities, 50),
                'k75': np.percentile(k_intensities, 75),
                'k90': np.percentile(k_intensities, 90)
            }
        
        # Learn K/C ratio characteristics if available (potassium/carbon)
        if 'K_C_ratio' in X.columns:
            kc_ratios = X['K_C_ratio'].fillna(0)
            self.kc_ratio_percentiles_ = {
                'k10': np.percentile(kc_ratios, 10),
                'k25': np.percentile(kc_ratios, 25),
                'k50': np.percentile(kc_ratios, 50),
                'k75': np.percentile(kc_ratios, 75),
                'k90': np.percentile(kc_ratios, 90)
            }
        else:
            raise ValueError("K_C_ratio not found in features. Ensure potassium (K_I) features are properly extracted.")
            
        # Only learn statistics for elements that are actually present in the transformed features
        # Build list of elements to track based on what's actually in the data
        elements_to_track = []
        
        # Always track K_I (potassium) as it's the target element
        elements_to_track.append('K_I')
        
        # Check if C_I features exist (used for P/C ratio)
        if any('C_I' in col for col in X.columns):
            elements_to_track.append('C_I')
            
        # Only add other elements if they're actually present in the features
        # These would only be present if enable_oxygen_hydrogen or other flags are True
        for element in ['N_I', 'H_I', 'O_I', 'CA_I', 'K_I', 'S_I', 'P_I']:
            if any(element in col for col in X.columns):
                elements_to_track.append(element)
                logger.debug(f"Found {element} features in data, will track statistics")
        
        # Learn general feature statistics only for present spectral features
        spectral_cols = [col for col in X.columns if any(element in col for element in elements_to_track)]
        logger.info(f"Learning statistics for {len(spectral_cols)} spectral features from elements: {elements_to_track}")
        
        for col in spectral_cols:
            if X[col].notna().sum() > 10:  # Only if we have enough data
                self.feature_statistics_[col] = {
                    'mean': X[col].mean(),
                    'std': X[col].std(),
                    'p25': np.percentile(X[col].dropna(), 25),
                    'p75': np.percentile(X[col].dropna(), 75)
                }
                
    def _generate_feature_names(self, X: pd.DataFrame):
        """Generate names for the new features that will be created."""
        self.feature_names_out_ = []
        
        if self.enable_range_indicators:
            self.feature_names_out_.extend([
                'concentration_range_low',
                'concentration_range_medium', 
                'concentration_range_high',
                'concentration_intensity_score',
                'concentration_ratio_score'
            ])
            
        # Only add spectral modulation features if we have the required k_intensity data
        if (self.enable_spectral_modulation and 
            hasattr(self, 'k_intensity_percentiles_') and 
            self.k_intensity_percentiles_ is not None):
            self.feature_names_out_.extend([
                'k_intensity_concentration_weight',
                'k_spectral_concentration_indicator'
            ])
            
        # Only add ratio adjustment features if K_C_ratio column exists
        if self.enable_ratio_adjustments and 'K_C_ratio' in X.columns:
            self.feature_names_out_.extend([
                'kc_ratio_concentration_adjusted',
                'kc_ratio_extreme_indicator'
            ])
            
        # Only add interaction features if we have the required feature columns
        if self.enable_concentration_interactions:
            # Add interaction features for key spectral features (potassium only)
            key_features = [col for col in X.columns if any(key in col for key in ['K_I_simple', 'K_C_ratio', 'KC_height_ratio'])][:3]
            for feature in key_features:
                self.feature_names_out_.append(f'{feature}_concentration_interaction')
                
    def _add_range_indicators(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Add concentration range indicator features.
        
        These help AutoGluon identify and learn patterns specific to different
        concentration ranges without needing explicit sample weighting.
        """
        # Estimate concentration likelihood from spectral features
        concentration_score = self._estimate_concentration_likelihood(X)
        
        # Create soft range indicators (continuous values 0-1) using fitted thresholds
        X['concentration_range_low'] = 1.0 / (1.0 + np.exp(10 * (concentration_score - self.fitted_low_threshold_)))
        X['concentration_range_high'] = 1.0 / (1.0 + np.exp(-10 * (concentration_score - self.fitted_high_threshold_)))
        X['concentration_range_medium'] = 1.0 - X['concentration_range_low'] - X['concentration_range_high']
        
        # Add composite concentration indicators
        if hasattr(self, 'k_intensity_percentiles_') and self.k_intensity_percentiles_:
            k_intensity_cols = [col for col in X.columns if 'K_I' in col and ('peak_area' in col or 'peak_height' in col)]
            if k_intensity_cols:
                k_intensities = X[k_intensity_cols].fillna(0).sum(axis=1)
                # Normalize K intensity score based on learned distribution
                intensity_score = (k_intensities - self.k_intensity_percentiles_['k25']) / (
                    self.k_intensity_percentiles_['k75'] - self.k_intensity_percentiles_['k25'] + 1e-6)
                X['concentration_intensity_score'] = np.clip(intensity_score, 0, 2)
            else:
                raise ValueError("No K_I intensity features found. Ensure potassium features are properly extracted.")
        else:
            raise ValueError("No K_I intensity percentiles found. Ensure potassium features are properly extracted.")
            
        # Add K/C ratio-based concentration score
        if 'K_C_ratio' in X.columns and hasattr(self, 'kc_ratio_percentiles_') and self.kc_ratio_percentiles_:
            kc_ratio_score = (X['K_C_ratio'].fillna(0) - self.kc_ratio_percentiles_['k25']) / (
                self.kc_ratio_percentiles_['k75'] - self.kc_ratio_percentiles_['k25'] + 1e-6)
            X['concentration_ratio_score'] = np.clip(kc_ratio_score, 0, 2)
        else:
            raise ValueError("K_C_ratio not found or no ratio percentiles available. Ensure potassium features are properly extracted.")
            
        return X
        
    def _add_spectral_modulation(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Add features that modulate spectral intensity based on estimated concentration.
        
        This helps models learn that the same spectral intensity might indicate
        different concentrations depending on other contextual features.
        """
        # Prioritize K intensity for potassium prediction
        if hasattr(self, 'k_intensity_percentiles_') and self.k_intensity_percentiles_:
            # Calculate K intensity concentration weight
            k_intensity_cols = [col for col in X.columns if 'K_I' in col and ('peak_area' in col or 'peak_height' in col)]
            if k_intensity_cols:
                k_intensities = X[k_intensity_cols].fillna(0).sum(axis=1)
                
                # Create concentration-dependent weighting
                # High weights for extreme values (low/high concentrations)
                intensity_percentile = np.clip(
                    (k_intensities - self.k_intensity_percentiles_['k10']) / 
                    (self.k_intensity_percentiles_['k90'] - self.k_intensity_percentiles_['k10'] + 1e-6), 
                    0, 1
                )
                
                # U-shaped weighting: higher weights for extreme percentiles
                concentration_weight = 1.0 + 2.0 * (np.abs(intensity_percentile - 0.5) ** 2)
                X['k_intensity_concentration_weight'] = concentration_weight
                
                # Binary indicator for extreme K intensities
                extreme_mask = (k_intensities <= self.k_intensity_percentiles_['k10']) | \
                              (k_intensities >= self.k_intensity_percentiles_['k90'])
                X['k_spectral_concentration_indicator'] = extreme_mask.astype(float)
            else:
                raise ValueError("No K_I intensity features found. Ensure potassium features are properly extracted.")
        else:
            raise ValueError("No K_I intensity percentiles available. Ensure potassium features are properly extracted.")
            
        return X
        
    def _add_ratio_adjustments(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Add concentration-adjusted ratio features.
        
        These help capture non-linear relationships between ratios and concentration
        that might be missed by standard ratio features.
        """
        if 'K_C_ratio' in X.columns and hasattr(self, 'kc_ratio_percentiles_') and self.kc_ratio_percentiles_:
            kc_ratio = X['K_C_ratio'].fillna(0)
            
            # Concentration-adjusted K/C ratio
            # Apply stronger adjustment for extreme values
            ratio_adjustment = 1.0 + 0.5 * np.abs(kc_ratio - self.kc_ratio_percentiles_['k50']) / (
                self.kc_ratio_percentiles_['k75'] - self.kc_ratio_percentiles_['k25'] + 1e-6)
            X['kc_ratio_concentration_adjusted'] = kc_ratio * ratio_adjustment
            
            # Extreme ratio indicator
            extreme_ratio_mask = (kc_ratio <= self.kc_ratio_percentiles_['k10']) | \
                                (kc_ratio >= self.kc_ratio_percentiles_['k90'])
            X['kc_ratio_extreme_indicator'] = extreme_ratio_mask.astype(float)
        else:
            raise ValueError("K_C_ratio not found or no ratio percentiles available. Ensure potassium features are properly extracted.")
        
        return X
        
    def _add_concentration_interactions(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Add interaction features between concentration indicators and key spectral features.
        
        This allows AutoGluon models to learn concentration-specific feature relationships.
        """
        # Get concentration likelihood estimate
        concentration_score = self._estimate_concentration_likelihood(X)
        
        # Add interactions with key features (potassium only)
        key_features = [col for col in X.columns if any(key in col for key in ['K_I_simple', 'K_C_ratio', 'KC_height_ratio'])][:3]
        
        for feature in key_features:
            if feature in X.columns:
                # Interaction: feature value modulated by concentration estimate
                interaction = X[feature].fillna(0) * concentration_score
                X[f'{feature}_concentration_interaction'] = interaction
                
        return X
        
    def _estimate_concentration_likelihood(self, X: pd.DataFrame) -> np.ndarray:
        """
        Estimate relative concentration likelihood from spectral features.
        
        This is a heuristic based on P intensity and P/C ratio to create
        concentration-aware features without knowing actual concentrations.
        Now uses target-derived statistics when available.
        """
        # Use target mean if available, otherwise fallback to default
        default_concentration = self.target_statistics_['mean'] if self.target_statistics_ else 0.35
        concentration_range = self.fitted_high_threshold_ - self.fitted_low_threshold_
        
        score = np.full(len(X), default_concentration)
        
        # Use K intensity (potassium target)
        if hasattr(self, 'k_intensity_percentiles_') and self.k_intensity_percentiles_:
            k_intensity_cols = [col for col in X.columns if 'K_I' in col and ('peak_area' in col or 'peak_height' in col)]
            if k_intensity_cols:
                k_intensities = X[k_intensity_cols].fillna(0).sum(axis=1)
                # Normalize to target concentration range
                intensity_norm = (k_intensities - self.k_intensity_percentiles_['k10']) / (
                    self.k_intensity_percentiles_['k90'] - self.k_intensity_percentiles_['k10'] + 1e-6)
                # Map to actual target range instead of fixed range
                min_target = self.target_statistics_['min'] if self.target_statistics_ else 0.2
                max_target = self.target_statistics_['max'] if self.target_statistics_ else 0.5
                score = min_target + (max_target - min_target) * np.clip(intensity_norm, 0, 1)
            else:
                raise ValueError("No K_I intensity features found. Ensure potassium features are properly extracted.")
        else:
            raise ValueError("No K_I intensity percentiles available. Ensure potassium features are properly extracted.")
                
        # Adjust with K/C ratio if available
        if 'K_C_ratio' in X.columns and hasattr(self, 'kc_ratio_percentiles_') and self.kc_ratio_percentiles_:
            kc_ratio = X['K_C_ratio'].fillna(0)
            ratio_norm = (kc_ratio - self.kc_ratio_percentiles_['k25']) / (
                self.kc_ratio_percentiles_['k75'] - self.kc_ratio_percentiles_['k25'] + 1e-6)
            ratio_adjustment = concentration_range * 0.2 * np.clip(ratio_norm, -1, 1)  # Scale by actual range
            min_target = self.target_statistics_['min'] if self.target_statistics_ else 0.15
            max_target = self.target_statistics_['max'] if self.target_statistics_ else 0.5
            score = np.clip(score + ratio_adjustment, min_target, max_target)
        else:
            logger.warning("K_C_ratio not found for concentration estimation adjustment. Using intensity-only estimation.")
            
        return score


def create_enhanced_feature_pipeline_with_concentration(config, strategy: str, exclude_scaler: bool = False, use_parallel: bool = False, n_jobs: int = -1):
    """
    Create a feature pipeline that includes concentration-aware features.
    
    This is a drop-in replacement for create_feature_pipeline that adds
    concentration range features for improved AutoGluon performance.
    
    Supports both raw spectral mode and feature engineering mode based on
    config.use_raw_spectral_data.
    
    Args:
        config: Pipeline configuration
        strategy: Feature strategy ('K_only', 'simple_only', 'full_context')
        exclude_scaler: Whether to exclude StandardScaler from pipeline
        use_parallel: Whether to use parallel processing for feature generation
        n_jobs: Number of parallel jobs (-1 for all cores, -2 for all but one)
    """
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.impute import SimpleImputer
    from src.features.feature_engineering import SpectralFeatureGenerator, RawSpectralTransformer
    from src.utils.helpers import OutlierClipper
    
    if config.use_raw_spectral_data:
        # Raw spectral mode - add minimal concentration features for distribution awareness
        logger.info("Using raw spectral data with minimal concentration features for distribution handling")
        
        steps = [
            ('raw_spectral', RawSpectralTransformer(config=config)),
            ('minimal_concentration', MinimalConcentrationFeatures())
        ]
    else:
        # Feature engineering mode - configure concentration features based on strategy
        if strategy == "K_only":
            # Focus on K-specific concentration patterns
            concentration_config = {
                'enable_range_indicators': True,
                'enable_spectral_modulation': True,
                'enable_ratio_adjustments': False,  # No K/C ratio in K_only
                'enable_concentration_interactions': True
            }
        elif strategy == "simple_only":
            # Balanced approach for simple features
            concentration_config = {
                'enable_range_indicators': True,
                'enable_spectral_modulation': True,
                'enable_ratio_adjustments': True,
                'enable_concentration_interactions': True
            }
        elif strategy == "full_context":
            # Full concentration-aware enhancement
            concentration_config = {
                'enable_range_indicators': True,
                'enable_spectral_modulation': True,
                'enable_ratio_adjustments': True,
                'enable_concentration_interactions': True
            }
        else:
            raise ValueError(f"Unknown strategy: {strategy}")
        
        # Use parallel or sequential feature generator based on parameters
        logger.info(f"[DEBUG CONCENTRATION] use_parallel={use_parallel}, n_jobs={n_jobs}")
        if use_parallel:
            from src.features.parallel_feature_engineering import ParallelSpectralFeatureGenerator
            feature_generator = ParallelSpectralFeatureGenerator(
                config=config, strategy=strategy, n_jobs=n_jobs
            )
            logger.info(f"Using PARALLEL feature generation with {n_jobs} jobs for concentration pipeline")
        else:
            feature_generator = SpectralFeatureGenerator(config=config, strategy=strategy)
            logger.info(f"Using SEQUENTIAL feature generation for concentration pipeline")
            
        steps = [
            ('spectral_features', feature_generator),
            ('concentration_features', ConcentrationRangeFeatures(**concentration_config)),
            ('imputer', SimpleImputer(strategy='mean')),
            ('clipper', OutlierClipper())
        ]
    
    # Add StandardScaler unless explicitly excluded (e.g., for AutoGluon)
    if not exclude_scaler:
        steps.append(('scaler', StandardScaler()))
    
    pipeline = Pipeline(steps)
    scaler_info = "without StandardScaler" if exclude_scaler else "with StandardScaler"
    parallel_info = " (PARALLEL)" if use_parallel else ""
    
    if config.use_raw_spectral_data:
        logger.info(f"Created RAW SPECTRAL pipeline with minimal concentration features {scaler_info}.")
    else:
        logger.info(f"Created enhanced feature engineering pipeline{parallel_info} with concentration features for strategy: '{strategy}' {scaler_info}.")
    return pipeline