"""
Classification Prediction Module

This module defines the ClassificationPredictor class, which handles loading a trained 
classification model and making binary predictions on new, unseen spectral data.
"""
from collections import defaultdict
import logging
from pathlib import Path
import joblib
import pandas as pd
import numpy as np

from src.config.pipeline_config import Config
from src.data_management.data_manager import DataManager
from src.cleansing.data_cleanser import DataCleanser
from src.utils.custom_exceptions import PipelineError

logger = logging.getLogger(__name__)


class ClassificationPredictor:
    """Handles loading classification models and making binary predictions on new data."""

    def __init__(self, config: Config):
        """
        Initializes the ClassificationPredictor.

        Args:
            config: The pipeline configuration object.
        """
        self.config = config
        self.data_cleanser = DataCleanser(config)
        # Use the same data manager methods for consistency
        self.data_manager = DataManager(config)

    def _load_wavelength_metadata(self, model_path: Path):
        """
        Loads wavelength standardization metadata if it exists.
        
        Args:
            model_path: Path to the model file
        """
        import json
        
        # Classification models are always .pkl files, not directories
        metadata_path = model_path.with_suffix('.wavelength_metadata.json')
        
        if metadata_path.exists():
            try:
                with open(metadata_path, 'r') as f:
                    metadata = json.load(f)
                
                # Load the global wavelength range into data manager
                if 'global_wavelength_range' in metadata:
                    self.data_manager._global_wavelength_range = (
                        metadata['global_wavelength_range']['min'],
                        metadata['global_wavelength_range']['max']
                    )
                    logger.info(
                        f"Loaded wavelength standardization range from model: "
                        f"{metadata['global_wavelength_range']['min']:.2f} - "
                        f"{metadata['global_wavelength_range']['max']:.2f} nm"
                    )
                    
                # Override config settings if they differ
                if metadata.get('wavelength_standardization_enabled'):
                    if not self.config.enable_wavelength_standardization:
                        logger.warning(
                            "Model was trained with wavelength standardization, "
                            "but it's currently disabled. Enabling it for prediction."
                        )
                        self.config.enable_wavelength_standardization = True
                        
            except Exception as e:
                logger.warning(f"Could not load wavelength metadata: {e}")

    def _load_model(self, model_path: Path):
        """
        Loads a trained classification model from a file.
        
        Args:
            model_path: Path to the model file (.pkl)
            
        Returns:
            Loaded sklearn pipeline
        """
        if not model_path.exists():
            raise FileNotFoundError(f"Model file not found: {model_path}")
        
        try:
            logger.info(f"Loading classification model from: {model_path}")
            model = joblib.load(model_path)
            
            # Load wavelength metadata if available
            self._load_wavelength_metadata(model_path)
            
            # Extract model information
            if hasattr(model, 'named_steps') and 'classifier' in model.named_steps:
                classifier_name = type(model.named_steps['classifier']).__name__
                logger.info(f"Loaded classification model: {classifier_name}")
                
                # Log threshold information from filename
                if 'threshold' in model_path.name:
                    parts = model_path.name.split('_')
                    for i, part in enumerate(parts):
                        if part == 'threshold' and i + 1 < len(parts):
                            threshold = parts[i + 1]
                            logger.info(f"Model threshold: {threshold}")
                            break
            
            return model
            
        except Exception as e:
            raise PipelineError(f"Failed to load classification model: {e}")

    def make_prediction(self, input_file: Path, model_path: Path) -> dict:
        """
        Makes a binary classification prediction for a single raw spectral file.

        This method encapsulates the full prediction process:
        1. Loads the specified trained classification model.
        2. Loads and cleans the raw spectral data using same process as training.
        3. Formats the data into the structure expected by the model.
        4. Returns prediction result with probability.

        Args:
            input_file: Path to the raw spectral data file (.csv.txt).
            model_path: Path to the trained model (.pkl file).

        Returns:
            Dictionary containing:
            - 'prediction': Binary prediction (0 or 1)
            - 'probability': Probability of positive class
            - 'label': Human-readable label ('Low' or 'High')
            - 'threshold': Classification threshold used
        
        Raises:
            FileNotFoundError: If the input file does not exist.
            PipelineError: If the data cannot be processed or prediction fails.
        """
        if not input_file.exists():
            raise FileNotFoundError(f"Input file not found: {input_file}")

        # 1. Load the model
        model = self._load_model(model_path)

        # 2. Load and clean the input data using EXACTLY the same process as training
        logger.info(f"Processing input file: {input_file.name}")
        
        # Use the same data loading process as training pipeline
        df = self.data_manager._read_raw_intensity_data(input_file)
        wavelengths = df['Wavelength'].values
        intensity_cols = [col for col in df.columns if col != 'Wavelength']
        intensities = df[intensity_cols].values
        
        # Apply wavelength standardization if enabled (must be before cleansing)
        if self.config.enable_wavelength_standardization:
            wavelengths, intensities = self.data_manager.standardize_wavelength_grid(
                wavelengths, intensities,
                interpolation_method=self.config.wavelength_interpolation_method,
                use_global_range=True  # Use global range from training if available
            )
        
        # Ensure intensities is 2D for consistency with training
        if intensities.ndim == 1:
            intensities = intensities.reshape(-1, 1)
            
        # Apply the same cleansing process as training
        clean_intensities = self.data_cleanser.clean_spectra(str(input_file), intensities)

        if clean_intensities.size == 0:
            raise PipelineError(f"No data remaining for {input_file.name} after cleansing. Cannot predict.")

        # 3. Format data into DataFrame using EXACTLY the same format as training
        # This matches the format used in load_and_clean_data() from main.py
        input_data = pd.DataFrame([{
            "wavelengths": wavelengths,
            "intensities": clean_intensities
        }])
        
        # 4. Make prediction using the full pipeline
        try:
            prediction = model.predict(input_data)[0]
            
            # Get prediction probability if available
            probability = None
            if hasattr(model, 'predict_proba'):
                try:
                    proba = model.predict_proba(input_data)[0]
                    probability = proba[1]  # Probability of positive class
                except:
                    logger.warning("Could not get prediction probability")
            
            # Extract threshold from model path
            threshold = 0.3  # Default threshold
            if 'threshold' in model_path.name:
                parts = model_path.name.split('_')
                for i, part in enumerate(parts):
                    if part == 'threshold' and i + 1 < len(parts):
                        try:
                            threshold = float(parts[i + 1])
                        except ValueError:
                            pass
                        break
            
            # Create result dictionary
            result = {
                'prediction': int(prediction),
                'probability': probability,
                'label': 'High' if prediction == 1 else 'Low',
                'threshold': threshold,
                'sample_file': input_file.name
            }
            
            logger.info(f"Prediction for {input_file.name}: {result['label']} (probability: {probability:.4f if probability else 'N/A'})")
            
            return result
            
        except Exception as e:
            raise PipelineError(f"Prediction failed for {input_file.name}: {e}")

    def make_batch_predictions(self, input_dir: Path, model_path: Path) -> pd.DataFrame:
        """
        Processes a directory of raw files, averages them by sample ID, cleans them,
        and makes binary classification predictions on the valid samples using EXACTLY 
        the same process as training.
        
        Args:
            input_dir: Directory containing raw spectral files (.csv.txt)
            model_path: Path to the trained classification model (.pkl)
            
        Returns:
            DataFrame with columns: sample_id, prediction, probability, label, threshold
        """
        logger.info(f"Starting batch classification from directory: {input_dir}")
        model = self._load_model(model_path)

        # 1. Group raw files by sample ID using EXACTLY the same method as training
        files_by_sample = defaultdict(list)
        for file_path in input_dir.glob('*.csv.txt'):
            prefix = self.data_manager._extract_file_prefix(file_path.name)
            files_by_sample[prefix].append(file_path)
        logger.info(f"Found {len(files_by_sample)} unique sample IDs to process.")

        # Extract threshold from model path
        threshold = 0.3  # Default threshold
        if 'threshold' in model_path.name:
            parts = model_path.name.split('_')
            for i, part in enumerate(parts):
                if part == 'threshold' and i + 1 < len(parts):
                    try:
                        threshold = float(parts[i + 1])
                    except ValueError:
                        pass
                    break

        prediction_results = []
        for sample_id, file_paths in files_by_sample.items():
            try:
                # 2. Average the files using EXACTLY the same method as training
                wavelengths, averaged_intensities = self.data_manager.average_files_in_memory(file_paths)

                if averaged_intensities is None:
                    raise ValueError("Averaging failed, no data returned.")

                # 2b. Apply wavelength standardization if enabled (must be before cleansing)
                if self.config.enable_wavelength_standardization:
                    wavelengths, averaged_intensities = self.data_manager.standardize_wavelength_grid(
                        wavelengths, averaged_intensities,
                        interpolation_method=self.config.wavelength_interpolation_method,
                        use_global_range=True  # Use global range from training if available
                    )

                # 3. Clean the averaged sample using EXACTLY the same method as training
                clean_intensities = self.data_cleanser.clean_spectra(sample_id, averaged_intensities)
                
                if clean_intensities.size > 0:
                    # 4a. Format data using EXACTLY the same format as training
                    # This matches the format used in load_and_clean_data() and process_validation_data()
                    input_data = pd.DataFrame([{
                        "wavelengths": wavelengths,
                        "intensities": clean_intensities
                    }])
                    
                    # 5. Make prediction using the full pipeline
                    try:
                        prediction = model.predict(input_data)[0]
                        
                        # Get prediction probability if available
                        probability = None
                        if hasattr(model, 'predict_proba'):
                            try:
                                proba = model.predict_proba(input_data)[0]
                                probability = proba[1]  # Probability of positive class
                            except:
                                logger.warning(f"Could not get prediction probability for {sample_id}")
                        
                        prediction_results.append({
                            'sample_id': sample_id,
                            'prediction': int(prediction),
                            'probability': probability,
                            'label': 'High' if prediction == 1 else 'Low',
                            'threshold': threshold
                        })
                        
                        logger.info(f"Sample {sample_id}: {prediction_results[-1]['label']} (probability: {probability:.4f if probability else 'N/A'})")
                        
                    except Exception as e:
                        logger.error(f"Prediction failed for sample {sample_id}: {e}")
                        prediction_results.append({
                            'sample_id': sample_id,
                            'prediction': None,
                            'probability': None,
                            'label': 'Error',
                            'threshold': threshold,
                            'error': str(e)
                        })
                else:
                    logger.warning(f"No data remaining for {sample_id} after cleansing. Skipping prediction.")
                    prediction_results.append({
                        'sample_id': sample_id,
                        'prediction': None,
                        'probability': None,
                        'label': 'No Data',
                        'threshold': threshold,
                        'error': 'No data after cleansing'
                    })
                    
            except Exception as e:
                logger.error(f"Processing failed for sample {sample_id}: {e}")
                prediction_results.append({
                    'sample_id': sample_id,
                    'prediction': None,
                    'probability': None,
                    'label': 'Error',
                    'threshold': threshold,
                    'error': str(e)
                })

        # Convert results to DataFrame
        results_df = pd.DataFrame(prediction_results)
        
        # Summary statistics
        total_samples = len(results_df)
        successful_predictions = len(results_df[results_df['prediction'].notna()])
        high_predictions = len(results_df[results_df['prediction'] == 1])
        low_predictions = len(results_df[results_df['prediction'] == 0])
        
        logger.info(f"\nBatch Classification Summary:")
        logger.info(f"  Total samples: {total_samples}")
        logger.info(f"  Successful predictions: {successful_predictions}")
        logger.info(f"  High class predictions: {high_predictions}")
        logger.info(f"  Low class predictions: {low_predictions}")
        logger.info(f"  Failed predictions: {total_samples - successful_predictions}")
        logger.info(f"  Classification threshold: {threshold}")

        return results_df