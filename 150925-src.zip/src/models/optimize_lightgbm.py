#!/usr/bin/env python3
"""
Dedicated LightGBM Optimization Script

This script focuses specifically on optimizing LightGBM for better R² performance
with advanced techniques and comprehensive hyperparameter tuning.
"""
import argparse
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import cross_val_score, cross_val_predict, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.isotonic import IsotonicRegression
import lightgbm as lgb
import optuna
from datetime import datetime
import joblib

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.config.pipeline_config import config
from src.config.config_manager import config_manager
from src.data_management.data_manager import DataManager
from src.features.feature_engineering import create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.reporting.reporter import Reporter
from src.utils.helpers import calculate_regression_metrics, setup_logging
from src.cleansing.data_cleanser import DataCleanser
from src.utils.custom_exceptions import DataValidationError
from src.models.base_optimizer import BaseOptimizer
from src.models.enhanced_optuna_strategies import get_enhanced_optimization_config

logger = logging.getLogger(__name__)

class LightGBMOptimizer(BaseOptimizer):
    """Advanced LightGBM optimization with spectral data focus.
    
    IMPORTANT: To avoid CV/evaluation mismatch, use hold-out validation by providing
    X_val and y_val to optimize(). This ensures parameters are optimized using the
    same train/validation approach as final evaluation, preventing the mismatch where:
    - Optimization uses 3-fold CV (~341 samples per fold)  
    - Final evaluation uses full training set (~512 samples)
    
    Optimized for small datasets (25 features, 512 samples) with:
    - Conservative parameter ranges to avoid overfitting
    - Complexity penalties for overly complex models  
    - Baseline comparison with default parameters
    - Smart search ranges focused around known good defaults
    """
    
    def __init__(self, config, strategy='full_context', use_parallel_features=False, feature_n_jobs=-1):
        super().__init__(config)  # Initialize base optimizer
        self.strategy = strategy
        self.use_parallel_features = use_parallel_features
        self.feature_n_jobs = feature_n_jobs
        
        # Calibration for when sample weights are used
        self.calibrator = None
        self.use_calibration = False
        
        # Use concentration-aware features if enabled in config
        if config.use_concentration_features:
            logger.info("Using enhanced feature pipeline with concentration-aware features for LightGBM optimization")
            self.feature_pipeline = create_enhanced_feature_pipeline_with_concentration(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
        else:
            logger.info(f"Using standard feature pipeline for LightGBM optimization (parallel={use_parallel_features}, feature_n_jobs={feature_n_jobs})")
            self.feature_pipeline = create_feature_pipeline(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
            
        self.best_params = None
        self.best_score = float('-inf')
        self._cached_features = None  # Cache transformed features
        self._fitted_feature_pipeline = None
        self._cached_val_features = None  # Cache validation features
        self.use_holdout_validation = False  # Initialize to False
        
    def _precompute_features(self):
        """Pre-compute and cache features for parallel optimization."""
        if self._cached_features is not None:
            return  # Already computed
            
        # Prepare data - drop sample_id for feature extraction
        X_train_features = self.X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_train.columns else self.X_train
        
        # Prepare validation data if using hold-out validation
        X_val_features = None
        if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and hasattr(self, 'X_val') and self.X_val is not None:
            if hasattr(self.X_val, 'drop') and hasattr(self.X_val, 'columns'):
                # X_val is a DataFrame
                X_val_features = self.X_val.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_val.columns else self.X_val
            else:
                # X_val is not a DataFrame (maybe array), use as is
                X_val_features = self.X_val
        
        # Build pipeline steps
        pipeline_steps = [
            ('features', self.feature_pipeline),
            ('scaler', StandardScaler())
        ]
        
        # Add dimension reduction if configured
        if self.config.use_dimension_reduction:
            from src.features.dimension_reduction import DimensionReductionFactory
            reducer = DimensionReductionFactory.create_reducer(
                method=self.config.dimension_reduction.method,
                params=self.config.dimension_reduction.get_params()
            )
            pipeline_steps.append(('dimension_reduction', reducer))
            logger.info(f"Adding {self.config.dimension_reduction.method} dimension reduction to pipeline")
        
        feature_pipeline = Pipeline(pipeline_steps)
        
        # Transform features step by step to log intermediate counts
        # Step 1: Feature engineering
        features_transformed = feature_pipeline.named_steps['features'].fit_transform(X_train_features, self.y_train)
        features_after_engineering = features_transformed.shape[1]
        logger.info(f"Features after engineering: {features_after_engineering}")
        
        # Step 2: Scaling
        features_scaled = feature_pipeline.named_steps['scaler'].fit_transform(features_transformed)
        
        # Step 3: Feature selection (if enabled) - takes priority over dimension reduction
        if self.config.use_feature_selection:
            logger.info(f"[LIGHTGBM OPTIMIZER] Applying feature selection: {self.config.feature_selection_method}")
            features_selected = self.apply_feature_selection(features_scaled, self.y_train, model_name="LightGBM")
            features_after_selection = features_selected.shape[1]
            logger.info(f"[LIGHTGBM OPTIMIZER] Feature selection complete: {features_scaled.shape[1]} → {features_after_selection} features")
            features_final = features_selected
        # Step 4: Dimension reduction (if enabled and no feature selection)
        elif self.config.use_dimension_reduction and 'dimension_reduction' in feature_pipeline.named_steps:
            reducer = feature_pipeline.named_steps['dimension_reduction']
            
            # Special handling for PLS which requires target values
            if hasattr(reducer, '__class__') and reducer.__class__.__name__ == 'PLSReducer':
                features_final = reducer.fit_transform(features_scaled, self.y_train)
            else:
                features_final = reducer.fit_transform(features_scaled)
            
            features_after_reduction = features_final.shape[1]
            logger.info(f"{self.config.dimension_reduction.method.upper()} applied: {features_after_engineering} → {features_after_reduction} components")
        else:
            features_final = features_scaled
            logger.info(f"No dimension reduction applied - using all {features_after_engineering} features")
        
        # Convert to DataFrame with proper column names to maintain feature name consistency
        if self.config.use_dimension_reduction and 'dimension_reduction' in feature_pipeline.named_steps:
            # For dimension reduction, create generic feature names
            feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
        else:
            # For non-reduced features, try to get original feature names
            try:
                # Get feature names from the feature engineering pipeline
                feature_transformer = feature_pipeline.named_steps['features']
                if hasattr(feature_transformer, 'get_feature_names_out'):
                    feature_names = feature_transformer.get_feature_names_out()
                else:
                    # Fallback to generic names
                    feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
            except:
                # Fallback to generic names
                feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
        
        # Create DataFrame with proper column names
        # Handle case where y_train might be numpy array without index attribute
        if hasattr(self.y_train, 'index'):
            # y_train is pandas Series with index
            index_to_use = self.y_train.index
        else:
            # y_train is numpy array - no index available
            index_to_use = None
        
        self._cached_features = pd.DataFrame(features_final, columns=feature_names, index=index_to_use)
        self._fitted_feature_pipeline = feature_pipeline
        
        # Transform validation data with the same fitted pipeline if using hold-out validation
        if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and X_val_features is not None:
            # Step 1: Feature engineering
            val_features_transformed = self._fitted_feature_pipeline.named_steps['features'].transform(X_val_features)
            # Step 2: Scaling
            val_features_scaled = self._fitted_feature_pipeline.named_steps['scaler'].transform(val_features_transformed)
            
            # Step 3: Apply feature selection if it was used
            if self.config.use_feature_selection and self.feature_selector is not None:
                val_features_final = self.feature_selector.transform(val_features_scaled)
            # Step 4: Apply dimension reduction if it was used
            elif self.config.use_dimension_reduction and 'dimension_reduction' in self._fitted_feature_pipeline.named_steps:
                reducer = self._fitted_feature_pipeline.named_steps['dimension_reduction']
                val_features_final = reducer.transform(val_features_scaled)
            else:
                val_features_final = val_features_scaled
            
            self._cached_val_features = pd.DataFrame(val_features_final, columns=feature_names)
            logger.info(f"Validation features cached: {self._cached_val_features.shape}")
        else:
            self._cached_val_features = None
        
        logger.info(f"Features going into model: {self._cached_features.shape[1]} (with proper column names)")
        logger.info(f"Training samples: {self._cached_features.shape[0]}")
        logger.info(f"Feature names: {list(self._cached_features.columns[:5])}{'...' if len(self._cached_features.columns) > 5 else ''}")
        
    def create_advanced_objective(self, trial):
        """Advanced objective function combining multiple metrics."""
        
        # Suggest hyperparameters optimized for 25 features & 512 samples
        # Enhanced parameter suggestion with smart search space (Strategy D)
        if hasattr(self, '_enhanced_config') and self._enhanced_config:
            params = self._enhanced_config['smart_search_space'].suggest_correlated_lightgbm_params(trial)
        else:
            # Fallback to conservative parameters for small datasets
            params = {
                'n_estimators': trial.suggest_int('n_estimators', 50, 300),  # Conservative range around default 100
                'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.1, log=True),  # Focus around default 0.05
                'num_leaves': trial.suggest_int('num_leaves', 10, 63),  # Conservative for small dataset (max = 2^depth - 1)
                'max_depth': trial.suggest_int('max_depth', 3, 8),  # Shallow trees, focus around default 4
                'min_child_samples': trial.suggest_int('min_child_samples', 3, 8),  # Even more conservative, start from default 3
                'min_child_weight': trial.suggest_float('min_child_weight', 0.001, 2.0),  # More conservative range
                'subsample': trial.suggest_float('subsample', 0.75, 1.0),  # Even more conservative around default 0.8
                'feature_fraction': trial.suggest_float('feature_fraction', 0.7, 1.0),  # Even more conservative
                'reg_alpha': trial.suggest_float('reg_alpha', 0.0, 1.0),  # Even smaller regularization range
                'reg_lambda': trial.suggest_float('reg_lambda', 0.0, 2.0),  # Even smaller regularization range
                'min_split_gain': trial.suggest_float('min_split_gain', 0.0, 0.1),  # Much more conservative for small dataset
                'bagging_freq': trial.suggest_int('bagging_freq', 0, 5),  # Include option to disable (0)
                'max_bin': trial.suggest_int('max_bin', 100, 300),  # Conservative range
                'verbosity': -1,
                'random_state': 42,
                'objective': 'regression',
                'metric': 'rmse'
            }
        
        # Add GPU support if available
        if self.config.use_gpu:
            try:
                params['device'] = 'gpu'
                params['gpu_platform_id'] = 0  
                params['gpu_device_id'] = 0
            except:
                logger.warning("GPU not available for LightGBM, falling back to CPU")
                params['device'] = 'cpu'
        
        # Create model
        model = lgb.LGBMRegressor(**params)
        
        # Use pre-computed features (no feature computation in parallel workers)
        if self._cached_features is None:
            logger.error("Features not pre-computed! Call _precompute_features() first.")
            return -1000.0
        
        try:
            if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and self._cached_val_features is not None:
                # Use hold-out validation (matches final evaluation approach)
                model.fit(self._cached_features, self.y_train)
                
                # Predict on validation set
                y_val_pred = model.predict(self._cached_val_features)
                
                # Calculate metrics
                from sklearn.metrics import r2_score, mean_squared_error
                r2_score_val = r2_score(self.y_val, y_val_pred)
                rmse_score_val = np.sqrt(mean_squared_error(self.y_val, y_val_pred))
                
                # Use single values (no variance for single evaluation)
                r2_scores = np.array([r2_score_val])
                rmse_scores = np.array([rmse_score_val])
            else:
                # Cross-validation with multiple metrics (3-fold for speed during optimization)
                cv = KFold(n_splits=3, shuffle=True, random_state=42)
                
                # R² scores - use pre-computed features
                r2_scores = cross_val_score(model, self._cached_features, self.y_train, 
                                           cv=cv, scoring='r2', n_jobs=1, error_score='raise')
                
                # RMSE scores (negative MSE)
                rmse_scores = -cross_val_score(model, self._cached_features, self.y_train, 
                                              cv=cv, scoring='neg_root_mean_squared_error', n_jobs=1, error_score='raise')
        except Exception as e:
            logger.error(f"Evaluation failed: {e}")
            return -1000.0
        
        # Combined objective: maximize R² while minimizing RMSE variance
        r2_mean = np.mean(r2_scores)
        r2_std = np.std(r2_scores)
        rmse_mean = np.mean(rmse_scores)
        rmse_std = np.std(rmse_scores)
        
        # For small datasets, add penalty for overly complex models to favor simpler, more generalizable models
        complexity_penalty = 0.0
        if params['n_estimators'] > 150:  # Lower threshold - penalty for too many trees
            complexity_penalty += 0.005 * (params['n_estimators'] - 150) / 100
        if params['min_child_samples'] <= 3:  # Penalty for minimal child samples (prone to overfitting)
            complexity_penalty += 0.01
        if params['max_depth'] > 5:  # Lower threshold - penalty for deep trees
            complexity_penalty += 0.008 * (params['max_depth'] - 5)
        if params['num_leaves'] > 40:  # Lower threshold - penalty for too many leaves
            complexity_penalty += 0.005 * (params['num_leaves'] - 40) / 40
        if params.get('min_split_gain', 0.0) > 0.05:  # Penalty for very restrictive split gain
            complexity_penalty += 0.01
        
        # Weighted combination favoring R² with stability and complexity penalties
        stability_penalty = 0.1 * (r2_std + rmse_std)
        objective_score = r2_mean - stability_penalty - complexity_penalty
        
        # Log trial results with complexity info
        logger.info(f"Trial {trial.number}: R²={r2_mean:.4f}, RMSE={rmse_mean:.4f}, "
                   f"Complexity penalty={complexity_penalty:.4f}, Score={objective_score:.4f}")
        
        # Report intermediate results
        trial.report(objective_score, step=0)
        
        return float(objective_score)
    
    def optimize(self, X_train, y_train, X_val=None, y_val=None, n_trials=100, timeout=3600):
        """Run optimization with enhanced strategies (A-D).
        
        Args:
            X_train: Training features
            y_train: Training targets  
            X_val: Validation features (if None, uses cross-validation)
            y_val: Validation targets (if None, uses cross-validation)
        """
        self.X_train = X_train
        self.y_train = y_train
        
        # Initialize enhanced optimization strategies
        dataset_size = len(X_train)
        self._enhanced_config = get_enhanced_optimization_config(
            model_name='lightgbm',
            dataset_size=dataset_size,
            n_trials=n_trials,
            reports_dir=self.config.reports_dir
        )
        logger.info(f"Enhanced optimization strategies initialized for dataset_size={dataset_size}, n_trials={n_trials}")
        self.X_val = X_val
        self.y_val = y_val
        
        # Check if validation data is properly provided
        valid_X_val = X_val is not None and hasattr(X_val, '__len__') and len(X_val) > 0
        valid_y_val = y_val is not None and hasattr(y_val, '__len__') and len(y_val) > 0
        self.use_holdout_validation = valid_X_val and valid_y_val
        
        if X_val is not None or y_val is not None:
            # Some validation data was provided but may be invalid
            if not self.use_holdout_validation:
                logger.warning(f"Invalid validation data provided: X_val={type(X_val)}, y_val={type(y_val)}")
                logger.warning("Falling back to cross-validation")

        if self.use_holdout_validation:
            logger.info("Using hold-out validation (matches final evaluation approach)")
        else:
            logger.info("Using cross-validation (may not match final evaluation)")
        
        # Pre-compute features once before parallel optimization to avoid redundant computation
        logger.info("Pre-computing features for parallel optimization...")
        self._precompute_features()
        logger.info(f"Features pre-computed. Shape: {self._cached_features.shape}")
        
        # Determine number of parallel workers
        from multiprocessing import cpu_count
        config_n_jobs = getattr(self.config.parallel, 'model_n_jobs', 1)
        
        if config_n_jobs == -1:
            n_jobs = max(1, min(4, cpu_count() // 2))  # Conservative parallel execution
            logger.info(f"Using {n_jobs} parallel workers for LightGBM optimization (auto-detected)")
        elif config_n_jobs > 1:
            n_jobs = min(config_n_jobs, cpu_count())
            logger.info(f"Using {n_jobs} parallel workers for LightGBM optimization")
        else:
            n_jobs = 1
            logger.info("Using single worker for LightGBM optimization")
        
        # Create study with adaptive pruning based on number of trials
        # For high trial counts (1000+), use more conservative pruning
        if n_trials >= 1000:
            n_startup_trials = min(100, n_trials // 10)  # 10% startup trials, max 100
            n_warmup_steps = 20
            interval_steps = 5
            logger.info(f"Using conservative pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        elif n_trials >= 500:
            n_startup_trials = min(50, n_trials // 15)   # ~7% startup trials, max 50
            n_warmup_steps = 15
            interval_steps = 3
            logger.info(f"Using moderate pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        else:
            n_startup_trials = min(20, n_trials // 5)    # 20% startup trials, max 20
            n_warmup_steps = 10
            interval_steps = 2
            logger.info(f"Using standard pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        
        study = optuna.create_study(
            direction='maximize',
            pruner=optuna.pruners.MedianPruner(
                n_startup_trials=n_startup_trials,
                n_warmup_steps=n_warmup_steps,
                interval_steps=interval_steps
            ),
            sampler=optuna.samplers.TPESampler(
                n_startup_trials=min(n_startup_trials, 20),  # Use same startup as pruner, max 20
                n_ei_candidates=50,
                multivariate=True,
                warn_independent_sampling=False
            )
        )
        
        # Add default parameters as a baseline trial to compare against
        default_params = {
            'n_estimators': 100,
            'learning_rate': 0.05,
            'num_leaves': 31,  # LightGBM default
            'max_depth': 4,
            'min_child_samples': 3,
            'min_child_weight': 0.001,  # LightGBM default
            'subsample': 0.8,
            'reg_alpha': 0.0,
            'reg_lambda': 0.0,
            'min_split_gain': 0.0,
            'bagging_freq': 0,  # Disabled by default
            'feature_fraction': 0.8,
            'max_bin': 255,  # LightGBM default
            'verbosity': -1,
            'random_state': 42,
            'objective': 'regression',
            'metric': 'rmse'
        }
        
        if self.config.use_gpu:
            default_params['device'] = 'gpu'
            default_params['gpu_platform_id'] = 0
            default_params['gpu_device_id'] = 0
        
        logger.info("Adding default parameters as baseline trial to compare against optimization...")
        study.enqueue_trial(default_params)
        
        # Optimize
        study.optimize(
            self.create_advanced_objective,
            n_trials=n_trials,
            timeout=timeout,
            n_jobs=n_jobs,
            show_progress_bar=True
        )
        
        self.best_params = study.best_params
        self.best_score = study.best_value
        self._study_trials = study.trials  # Store for later reference
        
        # Log comparison with default parameters
        if len(study.trials) > 0:
            default_trial = study.trials[0]  # First trial should be our enqueued default
            logger.info("\n=== OPTIMIZATION SUMMARY ===")
            if default_trial.value is not None:
                logger.info(f"Default parameters score: {default_trial.value:.4f}")
                logger.info(f"Best optimized score: {self.best_score:.4f}")
                improvement = self.best_score - default_trial.value
                logger.info(f"Improvement: {improvement:.4f} ({improvement*100:.2f}% relative)")
                
                if improvement < 0.001:  # Very small improvement
                    logger.warning("Optimization provided minimal improvement. Default parameters may already be optimal for this dataset size.")
                    logger.warning("Consider using default parameters to avoid overfitting on small dataset.")
            else:
                logger.warning("Default trial failed, cannot compare with baseline")
        
        return study
    
    def train_final_model(self, X_train, y_train, X_test, y_test):
        """Train final model with best parameters."""
        if not self.best_params:
            raise ValueError("Must run optimization first")
        
        # Check if optimization provided meaningful improvement, if not use defaults
        improvement = 0.0
        if hasattr(self, 'best_score') and len(getattr(self, '_study_trials', [])) > 0:
            default_score = getattr(self._study_trials[0], 'value', None) if hasattr(self, '_study_trials') else None
            if default_score is not None:
                improvement = self.best_score - default_score
        
        # Use safer parameters if optimization improvement is minimal or parameters seem too restrictive
        use_safe_params = (
            improvement < 0.02 or  # Increased threshold for small improvement
            self.best_params.get('min_child_samples', 3) >= 6 or  # More sensitive - catch restrictive parameters earlier
            self.best_params.get('min_split_gain', 0) > 0.05 or   # More sensitive - catch restrictive split gains earlier
            self.best_params.get('num_leaves', 31) <= 20 or       # More sensitive - catch restrictive leaf counts earlier
            self.best_params.get('learning_rate', 0.1) < 0.02 or  # Catch very low learning rates
            self.best_params.get('feature_fraction', 1.0) < 0.6   # Catch very restrictive feature sampling
        )
        
        if use_safe_params:
            logger.warning(f"Using safer default parameters due to minimal improvement ({improvement:.4f}) or restrictive optimized parameters")
            final_params = {
                'n_estimators': min(self.best_params.get('n_estimators', 100), 150),  # More conservative cap
                'learning_rate': max(self.best_params.get('learning_rate', 0.05), 0.05),  # Force reasonable learning rate
                'num_leaves': max(min(self.best_params.get('num_leaves', 31), 63), 25),  # Ensure reasonable leaf count: 25-63
                'max_depth': min(self.best_params.get('max_depth', 4), 6),  # More conservative depth cap
                'min_child_samples': max(min(self.best_params.get('min_child_samples', 3), 8), 3),  # Force range 3-8
                'min_child_weight': max(self.best_params.get('min_child_weight', 0.001), 0.001),  # Keep default minimum
                'subsample': max(self.best_params.get('subsample', 0.8), 0.8),  # Force higher sampling
                'feature_fraction': max(self.best_params.get('feature_fraction', 0.8), 0.8),  # Force higher feature sampling (replaces colsample_bytree)
                'reg_alpha': min(self.best_params.get('reg_alpha', 0.0), 0.5),  # More conservative regularization
                'reg_lambda': min(self.best_params.get('reg_lambda', 0.0), 1.0),  # More conservative regularization
                'min_split_gain': min(self.best_params.get('min_split_gain', 0.0), 0.01),  # Much more conservative split gain
                'bagging_freq': max(self.best_params.get('bagging_freq', 0), 1) if self.best_params.get('bagging_freq', 0) > 0 else 0,
                'max_bin': min(self.best_params.get('max_bin', 255), 255),
                'verbosity': -1,
                'random_state': 42,
                'objective': 'regression',
                'metric': 'rmse'
            }
        else:
            final_params = self.best_params.copy()
        
        # Add GPU support
        if self.config.use_gpu:
            try:
                final_params['device'] = 'gpu'
                final_params['gpu_platform_id'] = 0
                final_params['gpu_device_id'] = 0
            except:
                logger.warning("GPU not available, falling back to CPU")
                final_params['device'] = 'cpu'
        
        # Create final pipeline
        final_model = lgb.LGBMRegressor(**final_params)
        
        # Use the fitted feature pipeline from optimization (includes fitted reducer)
        if self._fitted_feature_pipeline is None:
            raise ValueError("Must run optimization first to get fitted feature pipeline")
        
        # Create final pipeline with model
        final_pipeline = Pipeline([
            ('features_and_reduction', self._fitted_feature_pipeline),
            ('model', final_model)
        ])
        
        # Prepare data - drop sample_id for feature extraction
        X_train_features = X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_train.columns else X_train
        X_test_features = X_test.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_test.columns else X_test
        
        # Log feature selection status
        if self.config.use_feature_selection and self.feature_selector is not None:
            logger.info(f"Feature selection enabled: {self.config.feature_selection_method} - {self.feature_selector.selected_features_.sum()} features selected")
        
        # Log dimension reduction status
        if self.config.use_dimension_reduction and 'dimension_reduction' in self._fitted_feature_pipeline.named_steps:
            reducer = self._fitted_feature_pipeline.named_steps['dimension_reduction']
            # Get the number of components from the fitted reducer
            if hasattr(reducer, 'optimal_components_'):  # VAE with auto selection
                n_components = reducer.optimal_components_
            elif hasattr(reducer, 'n_components_'):  # Standard sklearn reducers
                n_components = reducer.n_components_
            elif hasattr(reducer, 'n_components'):  # Config parameter
                n_components = reducer.n_components
            elif hasattr(reducer, 'get_n_components'):  # Method to get components
                n_components = reducer.get_n_components()
            else:
                n_components = 'unknown'
            logger.info(f"Applying fitted {self.config.dimension_reduction.method} dimension reduction for validation")
            logger.info(f"Using pre-fitted reducer with {n_components} components")
        
        # Train only the model (features are already transformed by fitted pipeline)
        logger.info("Transforming features using fitted pipeline...")
        X_train_processed = self._fitted_feature_pipeline.transform(X_train_features)
        X_test_processed = self._fitted_feature_pipeline.transform(X_test_features)
        
        logger.info(f"Final feature dimensions - Train: {X_train_processed.shape}, Test: {X_test_processed.shape}")
        
        # Fit only the model with pre-processed features
        logger.info("Training final model with pre-processed features...")
        
        # Calculate sample weights if enabled
        sample_weights = None
        if self.config.use_sample_weights:
            sample_weights = self._calculate_sample_weights(y_train)
            logger.info(f"LightGBM training with sample weights (method: {getattr(self.config, 'sample_weight_method', 'default')})")
            final_model.fit(X_train_processed, y_train, sample_weight=sample_weights)
        else:
            final_model.fit(X_train_processed, y_train)
        
        # Setup calibration if sample weights are used
        self._setup_calibration_if_needed(final_model, X_train_processed, y_train)
        
        # Evaluate
        train_pred_raw = final_pipeline.predict(X_train_features)
        train_pred = train_pred_raw  # Skip sample-weight calibration
        test_pred_raw = final_pipeline.predict(X_test_features)
        test_pred = test_pred_raw  # Skip sample-weight calibration
        
        # Apply post-processing calibration from base class
        train_pred, test_pred = self.apply_post_calibration(
            y_train, train_pred, y_test, test_pred, model_name="LightGBM"
        )
        
        train_metrics = calculate_regression_metrics(y_train, train_pred)
        test_metrics = calculate_regression_metrics(y_test, test_pred)
        
        # Enhanced logging with all metrics
        logger.info("=" * 60)
        logger.info("🎯 LightGBM Final Model Training Complete!")
        logger.info("=" * 60)
        logger.info(f"Training Metrics:")
        logger.info(f"  R²: {train_metrics['r2']:.4f}")
        logger.info(f"  RMSE: {train_metrics['rmse']:.4f}")
        logger.info(f"  RRMSE: {train_metrics.get('rrmse', 0):.2f}%")
        logger.info(f"  MAE: {train_metrics['mae']:.4f}")
        logger.info(f"  MAPE: {train_metrics.get('mape', 0):.2f}%")
        logger.info(f"  Within 20.5%: {train_metrics.get('within_20.5%', 0):.2f}%")
        
        logger.info(f"\nTest Metrics:")
        logger.info(f"  R²: {test_metrics['r2']:.4f}")
        logger.info(f"  RMSE: {test_metrics['rmse']:.4f}")
        logger.info(f"  RRMSE: {test_metrics.get('rrmse', 0):.2f}%")
        logger.info(f"  MAE: {test_metrics['mae']:.4f}")
        logger.info(f"  MAPE: {test_metrics.get('mape', 0):.2f}%")
        logger.info(f"  Within 20.5%: {test_metrics.get('within_20.5%', 0):.2f}%")
        
        logger.info(f"\nBest Parameters:")
        for param, value in (self.best_params or {}).items():
            logger.info(f"  {param}: {value}")
        
        logger.info(f"Strategy: {self.strategy}")
        logger.info(f"GPU enabled: {self.config.use_gpu}")
        if improvement > 0:
            logger.info(f"Optimization improvement: {improvement:.4f}")
        logger.info("=" * 60)
        
        
        return final_pipeline, train_metrics, test_metrics