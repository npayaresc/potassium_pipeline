#!/usr/bin/env python3
"""
Dedicated Random Forest Optimization Script

This script focuses specifically on optimizing Random Forest for better R² performance
with advanced techniques and comprehensive hyperparameter tuning.
"""
import argparse
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import cross_val_score, cross_val_predict, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.isotonic import IsotonicRegression
from sklearn.ensemble import RandomForestRegressor
import optuna
from datetime import datetime
import joblib

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.config.pipeline_config import config
from src.config.config_manager import config_manager
from src.data_management.data_manager import DataManager
from src.features.feature_engineering import create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.reporting.reporter import Reporter
from src.utils.helpers import calculate_regression_metrics, setup_logging
from src.cleansing.data_cleanser import DataCleanser
from src.utils.custom_exceptions import DataValidationError
from src.models.base_optimizer import BaseOptimizer
from src.models.enhanced_optuna_strategies import get_enhanced_optimization_config

logger = logging.getLogger(__name__)

class RandomForestOptimizer(BaseOptimizer):
    """Advanced Random Forest optimization with spectral data focus."""
    
    def __init__(self, config, strategy='full_context', use_parallel_features=False, feature_n_jobs=-1):
        super().__init__(config)  # Initialize base optimizer
        self.strategy = strategy
        self.use_parallel_features = use_parallel_features
        self.feature_n_jobs = feature_n_jobs
        
        # Calibration for when sample weights are used
        self.calibrator = None
        self.use_calibration = False
        
        # Use concentration-aware features if enabled in config
        if config.use_concentration_features:
            logger.info("Using enhanced feature pipeline with concentration-aware features for Random Forest optimization")
            self.feature_pipeline = create_enhanced_feature_pipeline_with_concentration(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
        else:
            logger.info(f"Using standard feature pipeline for Random Forest optimization (parallel={use_parallel_features}, feature_n_jobs={feature_n_jobs})")
            self.feature_pipeline = create_feature_pipeline(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
            
        self.best_params = None
        self.best_score = float('-inf')
        self._cached_features = None  # Cache transformed features
        self._fitted_feature_pipeline = None
        self._cached_val_features = None  # Cache validation features
        self.use_holdout_validation = False  # Initialize to False
        
    def _precompute_features(self):
        """Pre-compute and cache features for parallel optimization."""
        if self._cached_features is not None:
            return  # Already computed
            
        # Prepare data - drop sample_id for feature extraction
        X_train_features = self.X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_train.columns else self.X_train
        
        # Prepare validation data if using hold-out validation
        X_val_features = None
        if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and hasattr(self, 'X_val') and self.X_val is not None:
            if hasattr(self.X_val, 'drop') and hasattr(self.X_val, 'columns'):
                # X_val is a DataFrame
                X_val_features = self.X_val.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_val.columns else self.X_val
            else:
                # X_val is not a DataFrame (maybe array), use as is
                X_val_features = self.X_val
        
        # Build pipeline steps
        pipeline_steps = [
            ('features', self.feature_pipeline),
            ('scaler', StandardScaler())
        ]
        
        # Add feature selection if enabled
        if self.config.use_feature_selection:
            from src.features.feature_selector import SpectralFeatureSelector
            feature_selector = SpectralFeatureSelector(self.config)
            pipeline_steps.append(('feature_selection', feature_selector))
            logger.info(f"[FEATURE SELECTION] Enabled - Method: {self.config.feature_selection_method}, "
                       f"Target features: {self.config.n_features_to_select}")
        
        # Add dimension reduction if configured
        if self.config.use_dimension_reduction:
            from src.features.dimension_reduction import DimensionReductionFactory
            reducer = DimensionReductionFactory.create_reducer(
                method=self.config.dimension_reduction.method,
                params=self.config.dimension_reduction.get_params()
            )
            pipeline_steps.append(('dimension_reduction', reducer))
            logger.info(f"Adding {self.config.dimension_reduction.method} dimension reduction to pipeline")
        
        feature_pipeline = Pipeline(pipeline_steps)
        
        # Transform features step by step to log intermediate counts
        # Step 1: Feature engineering
        features_transformed = feature_pipeline.named_steps['features'].fit_transform(X_train_features, self.y_train)
        features_after_engineering = features_transformed.shape[1]
        logger.info(f"Features after engineering: {features_after_engineering}")
        
        # Step 2: Scaling
        features_scaled = feature_pipeline.named_steps['scaler'].fit_transform(features_transformed)
        
        # Step 2.5: Feature selection (if enabled)
        if self.config.use_feature_selection and 'feature_selection' in feature_pipeline.named_steps:
            feature_selector = feature_pipeline.named_steps['feature_selection']
            features_selected = feature_selector.fit_transform(features_scaled, self.y_train)
            features_after_selection = features_selected.shape[1]
            logger.info(f"[FEATURE SELECTION] Applied: {features_scaled.shape[1]} → {features_after_selection} features")
            features_for_reduction = features_selected
        else:
            features_for_reduction = features_scaled
        
        # Step 3: Dimension reduction (if enabled)
        if self.config.use_dimension_reduction and 'dimension_reduction' in feature_pipeline.named_steps:
            reducer = feature_pipeline.named_steps['dimension_reduction']
            
            # Special handling for PLS which requires target values
            if hasattr(reducer, '__class__') and reducer.__class__.__name__ == 'PLSReducer':
                features_final = reducer.fit_transform(features_for_reduction, self.y_train)
            else:
                features_final = reducer.fit_transform(features_for_reduction)
            
            features_after_reduction = features_final.shape[1]
            logger.info(f"{self.config.dimension_reduction.method.upper()} applied: {features_for_reduction.shape[1]} → {features_after_reduction} components")
        else:
            features_final = features_for_reduction
            if self.config.use_feature_selection and 'feature_selection' in feature_pipeline.named_steps:
                logger.info(f"No dimension reduction applied - using {features_after_selection} selected features")
            else:
                logger.info(f"No dimension reduction applied - using all {features_after_engineering} features")
        
        # Convert to DataFrame with proper column names to maintain feature name consistency
        if self.config.use_dimension_reduction and 'dimension_reduction' in feature_pipeline.named_steps:
            # For dimension reduction, create generic feature names
            feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
        else:
            # For non-reduced features, try to get original feature names
            try:
                # Get feature names from the feature engineering pipeline
                feature_transformer = feature_pipeline.named_steps['features']
                if hasattr(feature_transformer, 'get_feature_names_out'):
                    feature_names = feature_transformer.get_feature_names_out()
                else:
                    # Fallback to generic names
                    feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
            except:
                # Fallback to generic names
                feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
        
        # Create DataFrame with proper column names
        # Handle case where y_train might be numpy array without index attribute
        if hasattr(self.y_train, 'index'):
            # y_train is pandas Series with index
            index_to_use = self.y_train.index
        else:
            # y_train is numpy array - no index available
            index_to_use = None
        
        self._cached_features = pd.DataFrame(features_final, columns=feature_names, index=index_to_use)
        self._fitted_feature_pipeline = feature_pipeline
        
        # Transform validation data with the same fitted pipeline if using hold-out validation
        if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and X_val_features is not None:
            val_features_transformed = self._fitted_feature_pipeline.transform(X_val_features)
            self._cached_val_features = pd.DataFrame(val_features_transformed, columns=feature_names)
            logger.info(f"Validation features cached: {self._cached_val_features.shape}")
        else:
            self._cached_val_features = None
        
        logger.info(f"Features going into model: {self._cached_features.shape[1]} (with proper column names)")
        logger.info(f"Training samples: {self._cached_features.shape[0]}")
        logger.info(f"Feature names: {list(self._cached_features.columns[:5])}{'...' if len(self._cached_features.columns) > 5 else ''}")
        
    def create_advanced_objective(self, trial):
        """Advanced objective function combining multiple metrics."""
        
        # Conservative hyperparameters adapted for dataset size (~2,500 samples)
        params = {
            'n_estimators': trial.suggest_int('n_estimators', 200, 800),  # Reduced from 1000 to prevent overfitting
            'max_depth': trial.suggest_categorical('max_depth', [8, 10, 12, 15, 20]),  # Removed None and deep options (25,30,40,50)
            'min_samples_split': trial.suggest_int('min_samples_split', 5, 25),  # Increased from 2 to prevent overfitting
            'min_samples_leaf': trial.suggest_int('min_samples_leaf', 3, 15),  # Increased from 1 to prevent overfitting
            'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', 0.4, 0.6, 0.8]),  # More conservative feature sampling
            'min_weight_fraction_leaf': trial.suggest_float('min_weight_fraction_leaf', 0.0, 0.05),  # Reduced from 0.1
            'max_leaf_nodes': trial.suggest_categorical('max_leaf_nodes', [None, 100, 200, 400]),  # Removed 50 (too restrictive) and 500
            'min_impurity_decrease': trial.suggest_float('min_impurity_decrease', 0.0, 0.005),  # More conservative regularization
            'ccp_alpha': trial.suggest_float('ccp_alpha', 0.0, 0.005),  # More conservative pruning
            'random_state': 42,
            'n_jobs': -1
        }
        
        # Bootstrap configuration
        bootstrap = trial.suggest_categorical('bootstrap', [True, False])
        params['bootstrap'] = bootstrap
        
        if bootstrap:
            params['oob_score'] = trial.suggest_categorical('oob_score', [True, False])
            params['max_samples'] = trial.suggest_float('max_samples', 0.5, 1.0)
        else:
            params['max_samples'] = None
            params['oob_score'] = False
        
        # Warm start for efficiency
        params['warm_start'] = trial.suggest_categorical('warm_start', [True, False])
        
        # Create model
        model = RandomForestRegressor(**params)
        
        # Use pre-computed features (no feature computation in parallel workers)
        if self._cached_features is None:
            logger.error("Features not pre-computed! Call _precompute_features() first.")
            return -1000.0
        
        try:
            if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and self._cached_val_features is not None and hasattr(self, 'y_val') and self.y_val is not None:
                # Use hold-out validation (matches final evaluation approach)
                model.fit(self._cached_features, self.y_train)
                y_val_pred = model.predict(self._cached_val_features)
                
                from sklearn.metrics import r2_score, mean_squared_error
                r2_score_val = r2_score(self.y_val, y_val_pred)
                rmse_score_val = np.sqrt(mean_squared_error(self.y_val, y_val_pred))
                
                # Use single values (no variance for single evaluation)
                r2_scores = np.array([r2_score_val])
                rmse_scores = np.array([rmse_score_val])
            else:
                # Cross-validation with multiple metrics (3-fold for speed during optimization)
                cv = KFold(n_splits=3, shuffle=True, random_state=42)
                
                # R² scores - use pre-computed features
                r2_scores = cross_val_score(model, self._cached_features, self.y_train, 
                                           cv=cv, scoring='r2', n_jobs=1, error_score='raise')
                
                # RMSE scores (negative MSE)
                rmse_scores = -cross_val_score(model, self._cached_features, self.y_train, 
                                              cv=cv, scoring='neg_root_mean_squared_error', n_jobs=1, error_score='raise')
        except Exception as e:
            logger.error(f"Evaluation failed: {e}")
            return -1000.0
        
        # Combined objective: maximize R² while minimizing RMSE variance
        r2_mean = np.mean(r2_scores)
        r2_std = np.std(r2_scores)
        rmse_mean = np.mean(rmse_scores)
        rmse_std = np.std(rmse_scores)
        
        # Weighted combination favoring R² with stability penalty
        stability_penalty = 0.1 * (r2_std + rmse_std)
        objective_score = r2_mean - stability_penalty
        
        # Log trial results
        logger.info(f"Trial {trial.number}: R²={r2_mean:.4f}, RMSE={rmse_mean:.4f}, Score={objective_score:.4f}")
        
        # Report intermediate results
        trial.report(objective_score, step=0)
        
        return float(objective_score)
    
    def optimize(self, X_train, y_train, X_val=None, y_val=None, n_trials=100, timeout=3600):
        """Run optimization with advanced pruning.
        
        Args:
            X_train: Training features
            y_train: Training targets  
            X_val: Validation features (if None, uses cross-validation)
            y_val: Validation targets (if None, uses cross-validation)
        """
        self.X_train = X_train
        self.y_train = y_train
        self.X_val = X_val
        self.y_val = y_val
        
        # Check if validation data is properly provided
        valid_X_val = X_val is not None and hasattr(X_val, '__len__') and len(X_val) > 0
        valid_y_val = y_val is not None and hasattr(y_val, '__len__') and len(y_val) > 0
        self.use_holdout_validation = valid_X_val and valid_y_val
        
        if X_val is not None or y_val is not None:
            # Some validation data was provided but may be invalid
            if not self.use_holdout_validation:
                logger.warning(f"Invalid validation data provided: X_val={type(X_val)}, y_val={type(y_val)}")
                logger.warning("Falling back to cross-validation")

        if self.use_holdout_validation:
            logger.info("Using hold-out validation (matches final evaluation approach)")
        else:
            logger.info("Using cross-validation (may not match final evaluation)")
        
        # Pre-compute features once before parallel optimization to avoid redundant computation
        logger.info("Pre-computing features for parallel optimization...")
        self._precompute_features()
        logger.info(f"Features pre-computed. Shape: {self._cached_features.shape}")
        
        # Determine number of parallel workers
        from multiprocessing import cpu_count
        config_n_jobs = getattr(self.config.parallel, 'model_n_jobs', 1)
        
        if config_n_jobs == -1:
            n_jobs = max(1, min(4, cpu_count() // 2))  # Conservative parallel execution
            logger.info(f"Using {n_jobs} parallel workers for Random Forest optimization (auto-detected)")
        elif config_n_jobs > 1:
            n_jobs = min(config_n_jobs, cpu_count())
            logger.info(f"Using {n_jobs} parallel workers for Random Forest optimization")
        else:
            n_jobs = 1
            logger.info("Using single worker for Random Forest optimization")
        
        # Create study with adaptive pruning based on number of trials
        # For high trial counts (1000+), use more conservative pruning
        if n_trials >= 1000:
            n_startup_trials = min(100, n_trials // 10)  # 10% startup trials, max 100
            n_warmup_steps = 20
            interval_steps = 5
            logger.info(f"Using conservative pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        elif n_trials >= 500:
            n_startup_trials = min(50, n_trials // 15)   # ~7% startup trials, max 50
            n_warmup_steps = 15
            interval_steps = 3
            logger.info(f"Using moderate pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        else:
            n_startup_trials = min(20, n_trials // 5)    # 20% startup trials, max 20
            n_warmup_steps = 10
            interval_steps = 2
            logger.info(f"Using standard pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        
        study = optuna.create_study(
            direction='maximize',
            pruner=optuna.pruners.MedianPruner(
                n_startup_trials=n_startup_trials,
                n_warmup_steps=n_warmup_steps,
                interval_steps=interval_steps
            ),
            sampler=optuna.samplers.TPESampler(
                n_startup_trials=min(n_startup_trials, 20),  # Use same startup as pruner, max 20
                n_ei_candidates=50,
                multivariate=True,
                warn_independent_sampling=False
            )
        )
        
        # Optimize
        study.optimize(
            self.create_advanced_objective,
            n_trials=n_trials,
            timeout=timeout,
            n_jobs=n_jobs,
            show_progress_bar=True
        )
        
        self.best_params = study.best_params
        self.best_score = study.best_value
        self._study_trials = study.trials  # Store for later reference
        
        return study
    
    def train_final_model(self, X_train, y_train, X_test, y_test):
        """Train final model with best parameters."""
        if not self.best_params:
            raise ValueError("Must run optimization first")
        
        # Check if optimization provided meaningful improvement, if not use safer parameters
        improvement = 0.0
        if hasattr(self, 'best_score') and hasattr(self, '_study_trials') and len(self._study_trials) > 0:
            default_score = self._study_trials[0].value if self._study_trials[0].value is not None else None
            if default_score is not None:
                improvement = self.best_score - default_score
        
        # Use safer parameters if optimization improvement is minimal or parameters seem too restrictive
        use_safe_params = (
            improvement < 0.02 or  # Increased threshold for small improvement
            self.best_params.get('min_samples_leaf', 1) >= 8 or   # More sensitive - catch restrictive parameters earlier
            self.best_params.get('min_samples_split', 2) >= 12 or # More sensitive - catch restrictive parameters earlier
            self.best_params.get('ccp_alpha', 0) > 0.003 or       # More sensitive - catch high pruning earlier
            (self.best_params.get('max_depth') is not None and self.best_params.get('max_depth', 30) >= 40) or  # Catch very deep trees
            (isinstance(self.best_params.get('max_features'), (int, float)) and self.best_params.get('max_features', 1.0) < 0.5)  # Catch very restrictive feature sampling
        )
        
        if use_safe_params:
            logger.warning(f"Using safer default parameters due to minimal improvement ({improvement:.4f}) or restrictive optimized parameters")
            final_params = {
                'n_estimators': min(self.best_params.get('n_estimators', 100), 500),  # Cap at reasonable level
                'max_depth': self.best_params.get('max_depth', None) if self.best_params.get('max_depth') is None else min(self.best_params.get('max_depth', 30), 30),
                'min_samples_split': min(self.best_params.get('min_samples_split', 2), 8),  # Not too restrictive
                'min_samples_leaf': min(self.best_params.get('min_samples_leaf', 1), 5),   # Not too restrictive
                'max_features': self.best_params.get('max_features', 'sqrt'),
                'min_weight_fraction_leaf': min(self.best_params.get('min_weight_fraction_leaf', 0.0), 0.05),
                'max_leaf_nodes': self.best_params.get('max_leaf_nodes', None),
                'min_impurity_decrease': min(self.best_params.get('min_impurity_decrease', 0.0), 0.005),
                'ccp_alpha': min(self.best_params.get('ccp_alpha', 0.0), 0.005),  # Not too high
                'bootstrap': self.best_params.get('bootstrap', True),
                'oob_score': self.best_params.get('oob_score', False),
                'max_samples': self.best_params.get('max_samples', None),
                'warm_start': self.best_params.get('warm_start', False),
                'random_state': 42,
                'n_jobs': -1
            }
        else:
            final_params = self.best_params.copy()
        
        # Create final pipeline
        final_model = RandomForestRegressor(**final_params)
        
        # Use the fitted feature pipeline from optimization (includes fitted reducer)
        if self._fitted_feature_pipeline is None:
            raise ValueError("Must run optimization first to get fitted feature pipeline")
        
        # Create final pipeline with model
        final_pipeline = Pipeline([
            ('features_and_reduction', self._fitted_feature_pipeline),
            ('model', final_model)
        ])
        
        # Prepare data - drop sample_id for feature extraction
        X_train_features = X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_train.columns else X_train
        X_test_features = X_test.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_test.columns else X_test
        
        # Log dimension reduction status
        if self.config.use_dimension_reduction and 'dimension_reduction' in self._fitted_feature_pipeline.named_steps:
            reducer = self._fitted_feature_pipeline.named_steps['dimension_reduction']
            # Get the number of components from the fitted reducer
            if hasattr(reducer, 'optimal_components_'):  # VAE with auto selection
                n_components = reducer.optimal_components_
            elif hasattr(reducer, 'n_components_'):  # Standard sklearn reducers
                n_components = reducer.n_components_
            elif hasattr(reducer, 'n_components'):  # Config parameter
                n_components = reducer.n_components
            elif hasattr(reducer, 'get_n_components'):  # Method to get components
                n_components = reducer.get_n_components()
            else:
                n_components = 'unknown'
            logger.info(f"Applying fitted {self.config.dimension_reduction.method} dimension reduction for validation")
            logger.info(f"Using pre-fitted reducer with {n_components} components")
        
        # Train only the model (features are already transformed by fitted pipeline)
        logger.info("Transforming features using fitted pipeline...")
        X_train_processed = self._fitted_feature_pipeline.transform(X_train_features)
        X_test_processed = self._fitted_feature_pipeline.transform(X_test_features)
        
        logger.info(f"Final feature dimensions - Train: {X_train_processed.shape}, Test: {X_test_processed.shape}")
        
        # Fit only the model with pre-processed features
        logger.info("Training final model with pre-processed features...")
        
        # Calculate sample weights if enabled
        sample_weights = None
        if self.config.use_sample_weights:
            sample_weights = self._calculate_sample_weights(y_train)
            logger.info(f"RandomForest training with sample weights (method: {getattr(self.config, 'sample_weight_method', 'default')})")
            final_model.fit(X_train_processed, y_train, sample_weight=sample_weights)
        else:
            final_model.fit(X_train_processed, y_train)
        
        # Setup calibration if sample weights are used
        self._setup_calibration_if_needed(final_model, X_train_processed, y_train)
        
        # Evaluate
        train_pred_raw = final_pipeline.predict(X_train_features)
        train_pred = train_pred_raw  # Skip sample-weight calibration
        test_pred_raw = final_pipeline.predict(X_test_features)
        test_pred = test_pred_raw  # Skip sample-weight calibration
        
        # Apply post-processing calibration if enabled
        train_pred, test_pred = self.apply_post_calibration(
            y_train, train_pred, y_test, test_pred, "RandomForest"
        )
        
        train_metrics = calculate_regression_metrics(y_train, train_pred)
        test_metrics = calculate_regression_metrics(y_test, test_pred)
        
        # Enhanced logging with all metrics
        logger.info("=" * 60)
        logger.info("🎯 Random Forest Final Model Training Complete!")
        logger.info("=" * 60)
        logger.info(f"Training Metrics:")
        logger.info(f"  R²: {train_metrics['r2']:.4f}")
        logger.info(f"  RMSE: {train_metrics['rmse']:.4f}")
        logger.info(f"  RRMSE: {train_metrics.get('rrmse', 0):.2f}%")
        logger.info(f"  MAE: {train_metrics['mae']:.4f}")
        logger.info(f"  MAPE: {train_metrics.get('mape', 0):.2f}%")
        logger.info(f"  Within 20.5%: {train_metrics.get('within_20.5%', 0):.2f}%")
        
        logger.info(f"\nTest Metrics:")
        logger.info(f"  R²: {test_metrics['r2']:.4f}")
        logger.info(f"  RMSE: {test_metrics['rmse']:.4f}")
        logger.info(f"  RRMSE: {test_metrics.get('rrmse', 0):.2f}%")
        logger.info(f"  MAE: {test_metrics['mae']:.4f}")
        logger.info(f"  MAPE: {test_metrics.get('mape', 0):.2f}%")
        logger.info(f"  Within 20.5%: {test_metrics.get('within_20.5%', 0):.2f}%")
        
        logger.info(f"\nBest Parameters:")
        for param, value in (self.best_params or {}).items():
            logger.info(f"  {param}: {value}")
        
        logger.info(f"Strategy: {self.strategy}")
        logger.info(f"GPU enabled: {self.config.use_gpu}")
        logger.info("=" * 60)
        
        # Setup calibration if sample weights are used
        self._setup_calibration_if_needed(final_model, X_train_processed, y_train)
        
        return final_pipeline, train_metrics, test_metrics