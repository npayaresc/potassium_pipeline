#!/usr/bin/env python3
"""
Dedicated XGBoost Optimization Script

This script focuses specifically on optimizing XGBoost for better R² performance
with advanced techniques and comprehensive hyperparameter tuning.
"""
import argparse
import logging
import threading
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import cross_val_score, cross_val_predict, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.isotonic import IsotonicRegression
import xgboost as xgb
import optuna
from datetime import datetime

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.config.pipeline_config import config
from src.config.config_manager import config_manager
from src.data_management.data_manager import DataManager
from src.features.feature_engineering import create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.features.feature_selector import SpectralFeatureSelector
from src.reporting.reporter import Reporter
from src.utils.helpers import calculate_regression_metrics, setup_logging
from src.cleansing.data_cleanser import DataCleanser
from src.utils.custom_exceptions import DataValidationError
from src.models.base_optimizer import BaseOptimizer
from src.models.enhanced_optuna_strategies import get_enhanced_optimization_config

logger = logging.getLogger(__name__)

def setup_pipeline_config(use_gpu: bool = False, validation_dir=None, config_path=None):
    """Sets up dynamic configuration values and creates all necessary directories."""
    if config_path:
        stored_config_path = Path(config_path)
        updated_config = config_manager.apply_config(config, stored_config_path)
        logger.info(f"Loaded configuration from: {config_path}")
    else:
        updated_config = config
    
    updated_config.run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    updated_config.use_gpu = use_gpu
    if validation_dir is not None:
        updated_config.custom_validation_dir = validation_dir
    
    if use_gpu:
        logger.info("GPU mode enabled - models will use CUDA acceleration where available")
    else:
        logger.info("GPU mode disabled - models will use CPU only")
    
    project_root = Path(__file__).resolve().parents[2]
    
    # Define all paths relative to the project root
    data_dir = project_root / "data"
    raw_data_dir = data_dir / "raw" / "data_5278_Phase3"
    processed_data_dir = data_dir / "processed"
    averaged_files_dir = data_dir / "averaged_files_per_sample"
    cleansed_files_dir = data_dir / "cleansed_files_per_sample"
    model_dir = project_root / "models"
    reports_dir = project_root / "reports"
    log_dir = project_root / "logs"
    bad_files_dir = project_root / "bad_files"
    bad_prediction_files_dir = project_root / "bad_prediction_files"
    reference_data_path = project_root / "data" / "reference_data" / "Final_Lab_Data_Nico_New.xlsx"
    
    # Create all directories first
    for dir_path in [
        processed_data_dir, averaged_files_dir, cleansed_files_dir,
        model_dir, reports_dir, log_dir, bad_files_dir, bad_prediction_files_dir
    ]:
        dir_path.mkdir(parents=True, exist_ok=True)
    
    # Assign paths to config
    updated_config.data_dir = data_dir
    updated_config.raw_data_dir = raw_data_dir
    updated_config.processed_data_dir = processed_data_dir
    updated_config.averaged_files_dir = averaged_files_dir
    updated_config.cleansed_files_dir = cleansed_files_dir
    updated_config.model_dir = model_dir
    updated_config.reports_dir = reports_dir
    updated_config.log_dir = log_dir
    updated_config.bad_files_dir = bad_files_dir
    updated_config.bad_prediction_files_dir = bad_prediction_files_dir
    updated_config.reference_data_path = reference_data_path
    updated_config.sample_id_column = "Sample ID"
    
    setup_logging()
    return updated_config

def run_data_preparation(cfg):
    """Orchestrates the initial data preparation: averaging raw files."""
    data_manager = DataManager(cfg)
    data_manager.average_raw_files()

def load_and_clean_data(cfg):
    """Loads averaged data, cleans it, saves the clean version, and moves bad files."""
    import shutil
    from collections import defaultdict
    
    data_manager = DataManager(cfg)
    metadata = data_manager.load_and_prepare_metadata()
    training_files = data_manager.get_training_data_paths()
    data_cleanser = DataCleanser(cfg)
    processed_data_for_training = []

    # Determine global wavelength range from raw files if standardization is enabled
    if cfg.enable_wavelength_standardization:
        data_manager._global_wavelength_range = data_manager.determine_global_wavelength_range_from_raw_files()

    logger.info(f"Cleansing {len(training_files)} averaged files...")
    for file_path in training_files:
        wavelengths, intensities = data_manager.load_spectral_file(file_path)
        
        # Apply wavelength standardization if enabled
        if cfg.enable_wavelength_standardization:
            wavelengths, intensities = data_manager.standardize_wavelength_grid(
                wavelengths, intensities, 
                interpolation_method=cfg.wavelength_interpolation_method
            )
        
        # Ensure intensity is 2D for the cleanser
        if intensities.ndim == 1:
            intensities = intensities.reshape(-1, 1)

        clean_intensities = data_cleanser.clean_spectra(str(file_path), intensities)
        
        if clean_intensities.size > 0:
            # Save the cleansed file for auditing and reuse
            cleansed_path = cfg.cleansed_files_dir / file_path.name
            cleansed_df = pd.DataFrame({'Wavelength': wavelengths})
            
            for i in range(clean_intensities.shape[1]):
                cleansed_df[f'Intensity{i+1}'] = clean_intensities[:, i]
                
            cleansed_df.to_csv(cleansed_path, index=False)

            # Prepare the data for in-memory use
            sample_id = file_path.name.replace('.csv.txt', '')
            target = metadata.loc[metadata[cfg.sample_id_column] == sample_id, cfg.target_column].values[0]
            processed_data_for_training.append({
                 cfg.sample_id_column: sample_id, "wavelengths": wavelengths,
                "intensities": clean_intensities, cfg.target_column: target
            })
        else:
            # File had too many outliers; move to bad_files
            try:
                destination = cfg.bad_files_dir / file_path.name
                shutil.move(str(file_path), str(destination))
                logger.warning(f"Moved bad averaged file {file_path.name} to {cfg.bad_files_dir}")
            except Exception as e:
                logger.error(f"Failed to move bad file {file_path.name}: {e}")
    
    if not processed_data_for_training:
        raise DataValidationError("No data left after cleansing. Aborting pipeline.")
    
    logger.info(f"Data cleaning complete. {len(processed_data_for_training)} files are ready for training.")
    return pd.DataFrame(processed_data_for_training), data_manager

class XGBoostOptimizer(BaseOptimizer):
    """Advanced XGBoost optimization with spectral data focus."""
    
    def __init__(self, config, strategy='full_context', use_parallel_features=False, feature_n_jobs=-1):
        super().__init__(config)  # Initialize BaseOptimizer
        self.config = config
        self.strategy = strategy
        self.use_parallel_features = use_parallel_features
        self.feature_n_jobs = feature_n_jobs
        
        # Use concentration-aware features if enabled in config
        if config.use_concentration_features:
            logger.info("Using enhanced feature pipeline with concentration-aware features for XGBoost optimization")
            self.feature_pipeline = create_enhanced_feature_pipeline_with_concentration(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
        else:
            logger.info(f"Using standard feature pipeline for XGBoost optimization (parallel={use_parallel_features}, feature_n_jobs={feature_n_jobs})")
            self.feature_pipeline = create_feature_pipeline(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
            
        self.best_params = None
        self.best_score = float('-inf')
        self._cached_features = None  # Cache transformed features
        self._fitted_feature_pipeline = None
        self._cached_val_features = None  # Cache validation features
        self.use_holdout_validation = False  # Initialize to False
        self._pipeline_fitted = False
        self._feature_lock = threading.Lock()  # Thread safety for parallel trials
        
        # Initialize post-calibration attributes
        self.post_calibrator = None
        self.post_calibration_config = None
        
        # Calibration for when sample weights are used
        self.calibrator = None
        self.use_calibration = False
        
    def _precompute_features(self):
        """Pre-compute and cache features for parallel optimization."""
        if self._cached_features is not None:
            return  # Already computed
            
        # Prepare data - drop sample_id for feature extraction
        X_train_features = self.X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_train.columns else self.X_train
        
        # Prepare validation data if using hold-out validation
        X_val_features = None
        if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and hasattr(self, 'X_val') and self.X_val is not None:
            if hasattr(self.X_val, 'drop') and hasattr(self.X_val, 'columns'):
                # X_val is a DataFrame
                X_val_features = self.X_val.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_val.columns else self.X_val
            else:
                # X_val is not a DataFrame (maybe array), use as is
                X_val_features = self.X_val
        
        # Build pipeline steps
        pipeline_steps = [
            ('features', self.feature_pipeline),
            ('scaler', StandardScaler())
        ]
        
        # Add dimension reduction if configured
        if self.config.use_dimension_reduction:
            from src.features.dimension_reduction import DimensionReductionFactory
            reducer = DimensionReductionFactory.create_reducer(
                method=self.config.dimension_reduction.method,
                params=self.config.dimension_reduction.get_params()
            )
            pipeline_steps.append(('dimension_reduction', reducer))
            logger.info(f"Adding {self.config.dimension_reduction.method} dimension reduction to pipeline")
        
        feature_pipeline = Pipeline(pipeline_steps)
        
        # Transform features step by step to log intermediate counts
        # Step 1: Feature engineering
        features_transformed = feature_pipeline.named_steps['features'].fit_transform(X_train_features, self.y_train)
        features_after_engineering = features_transformed.shape[1]
        logger.info(f"Features after engineering: {features_after_engineering}")
        
        # Step 2: Scaling
        features_scaled = feature_pipeline.named_steps['scaler'].fit_transform(features_transformed)
        
        # Get index for DataFrames
        if hasattr(self.y_train, 'index'):
            index_to_use = self.y_train.index
        else:
            index_to_use = None
            
        # Step 3: Feature selection (if enabled) - replaces dimension reduction
        if self.config.use_feature_selection:
            # Apply feature selection using SpectralFeatureSelector
            logger.info(f"[XGBOOST OPTIMIZER] Applying feature selection: {self.config.feature_selection_method}")
            feature_selector = SpectralFeatureSelector(self.config)
            features_selected = feature_selector.fit_transform(features_scaled, self.y_train)
            features_after_selection = features_selected.shape[1]
            logger.info(f"[XGBOOST OPTIMIZER] Feature selection complete: {features_scaled.shape[1]} → {features_after_selection} features")
            features_final = features_selected
            # Store the fitted selector for later use
            self._fitted_feature_selector = feature_selector
        # Step 4: Dimension reduction (if enabled and no feature selection)
        elif self.config.use_dimension_reduction and 'dimension_reduction' in feature_pipeline.named_steps:
            reducer = feature_pipeline.named_steps['dimension_reduction']
            
            # Special handling for PLS which requires target values
            if hasattr(reducer, '__class__') and reducer.__class__.__name__ == 'PLSReducer':
                features_final = reducer.fit_transform(features_scaled, self.y_train)
            else:
                features_final = reducer.fit_transform(features_scaled)
            
            features_after_reduction = features_final.shape[1]
            logger.info(f"{self.config.dimension_reduction.method.upper()} applied: {features_after_engineering} → {features_after_reduction} components")
        else:
            features_final = features_scaled
            logger.info(f"No dimension reduction applied - using all {features_after_engineering} features")
        
        # Convert to DataFrame with proper column names to maintain feature name consistency
        if self.config.use_dimension_reduction and 'dimension_reduction' in feature_pipeline.named_steps:
            # For dimension reduction, create generic feature names
            feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
        else:
            # For non-reduced features, try to get original feature names
            try:
                # Get feature names from the feature engineering pipeline
                feature_transformer = feature_pipeline.named_steps['features']
                if hasattr(feature_transformer, 'get_feature_names_out'):
                    feature_names = feature_transformer.get_feature_names_out()
                else:
                    # Fallback to generic names
                    feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
            except:
                # Fallback to generic names
                feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
        
        # Create DataFrame with proper column names
        # Handle case where y_train might be numpy array without index attribute
        if hasattr(self.y_train, 'index'):
            # y_train is pandas Series with index
            index_to_use = self.y_train.index
        else:
            # y_train is numpy array - no index available
            index_to_use = None
        
        self._cached_features = pd.DataFrame(features_final, columns=feature_names, index=index_to_use)
        self._fitted_feature_pipeline = feature_pipeline
        self._pipeline_fitted = True
        
        # Transform validation data with the same fitted pipeline if using hold-out validation
        if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and X_val_features is not None:
            # Step 1: Feature engineering
            val_features_transformed = self._fitted_feature_pipeline.named_steps['features'].transform(X_val_features)
            # Step 2: Scaling
            val_features_scaled = self._fitted_feature_pipeline.named_steps['scaler'].transform(val_features_transformed)
            
            # Step 3: Apply feature selection if enabled
            if self.config.use_feature_selection and hasattr(self, '_fitted_feature_selector'):
                val_features_final = self._fitted_feature_selector.transform(val_features_scaled)
            # Step 4: Apply dimension reduction if enabled
            elif self.config.use_dimension_reduction and 'dimension_reduction' in self._fitted_feature_pipeline.named_steps:
                reducer = self._fitted_feature_pipeline.named_steps['dimension_reduction']
                val_features_final = reducer.transform(val_features_scaled)
            else:
                val_features_final = val_features_scaled
            
            self._cached_val_features = pd.DataFrame(val_features_final, columns=feature_names)
            logger.info(f"Validation features cached: {self._cached_val_features.shape}")
        else:
            self._cached_val_features = None
        
        logger.info(f"Features going into model: {self._cached_features.shape[1]}")
        logger.info(f"Training samples: {self._cached_features.shape[0]}")
        
    def create_advanced_objective(self, trial):
        """Advanced objective function combining multiple metrics."""
        
        # Debug: Check data format
        if hasattr(self, 'X_train') and len(self.X_train) > 0:
            logger.debug(f"X_train type: {type(self.X_train)}, shape: {getattr(self.X_train, 'shape', 'No shape')}")
            if hasattr(self.X_train, 'iloc'):
                logger.debug(f"First sample type: {type(self.X_train.iloc[0])}")
        
        # Enhanced parameter suggestion with smart search space (Strategy D)
        if hasattr(self, '_enhanced_config') and self._enhanced_config:
            params = self._enhanced_config['smart_search_space'].suggest_correlated_xgboost_params(trial)
            params.update({'verbosity': 0})
        else:
            # Fallback to conservative hyperparameters for dataset size (~1,200 samples)
            params = {
                'n_estimators': trial.suggest_int('n_estimators', 200, 800),  # Reduced from 300-1200 to prevent overfitting
                'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.15, log=True),  # Slightly higher minimum for fewer trees
                'max_depth': trial.suggest_int('max_depth', 4, 8),  # Reduced from 4-12 to prevent overfitting
                'min_child_weight': trial.suggest_int('min_child_weight', 3, 15),  # Increased from 1-10 to prevent overfitting
                'subsample': trial.suggest_float('subsample', 0.7, 1.0),  # Keep same - already conservative
                'colsample_bytree': trial.suggest_float('colsample_bytree', 0.7, 1.0),  # Keep same - already conservative
                'colsample_bylevel': trial.suggest_float('colsample_bylevel', 0.7, 1.0),  # Keep same - already conservative
                'colsample_bynode': trial.suggest_float('colsample_bynode', 0.7, 1.0),  # Keep same - already conservative
                'reg_alpha': trial.suggest_float('reg_alpha', 0.0, 2.0),  # Slightly reduced from 3.0 for better balance
                'reg_lambda': trial.suggest_float('reg_lambda', 0.5, 8.0),  # Increased minimum for more regularization
                'gamma': trial.suggest_float('gamma', 0.0, 1.5),  # Slightly reduced from 2.0
                'max_delta_step': trial.suggest_int('max_delta_step', 0, 2),  # Reduced from 0-3
                'tree_method': 'hist',
                'random_state': 42,
                'verbosity': 0
            }
        
        # Adjust XGBoost internal parallelism based on Optuna parallelism
        # This is set dynamically in the optimize() method
        if hasattr(self, '_xgb_n_jobs'):
            params['n_jobs'] = self._xgb_n_jobs
        else:
            params['n_jobs'] = 4  # Default fallback
        
        # Add GPU support if available
        if self.config.use_gpu:
            try:
                import torch
                if torch.cuda.is_available():
                    params['device'] = 'cuda'
                    params['tree_method'] = 'hist'  # Use hist with device='cuda' for GPU (XGBoost 2.0+)
                    if trial.number == 0:  # Only log once
                        logger.info(f"GPU detected and enabled: {torch.cuda.get_device_name(0)}")
                else:
                    logger.warning("CUDA not available, falling back to CPU")
                    params['device'] = 'cpu'
                    params['tree_method'] = 'hist'
            except:
                logger.warning("GPU not available, falling back to CPU")
                params['device'] = 'cpu'
                params['tree_method'] = 'hist'
        else:
            params['tree_method'] = 'hist'
        
        # Use pre-computed features (no feature computation in parallel workers)
        if self._cached_features is None:
            logger.error("Features not pre-computed! Call _precompute_features() first.")
            return -1000.0
        
        # Create model
        model = xgb.XGBRegressor(**params)
        
        try:
            if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and self._cached_val_features is not None:
                # Use hold-out validation (matches final evaluation approach)
                model.fit(self._cached_features, self.y_train)
                
                # Predict on validation set
                y_val_pred = model.predict(self._cached_val_features)
                
                # Calculate metrics
                from sklearn.metrics import r2_score, mean_squared_error
                r2_score_val = r2_score(self.y_val, y_val_pred)
                rmse_score_val = np.sqrt(mean_squared_error(self.y_val, y_val_pred))
                
                # Use single values (no variance for single evaluation)
                r2_scores = np.array([r2_score_val])
                rmse_scores = np.array([rmse_score_val])
            else:
                # Cross-validation with multiple metrics (3-fold for speed during optimization)
                cv = KFold(n_splits=3, shuffle=True, random_state=42)
                
                # R² scores - use pre-computed features
                r2_scores = cross_val_score(model, self._cached_features, self.y_train, 
                                           cv=cv, scoring='r2', n_jobs=1, error_score='raise')
                
                # RMSE scores (negative MSE)
                rmse_scores = -cross_val_score(model, self._cached_features, self.y_train, 
                                              cv=cv, scoring='neg_root_mean_squared_error', n_jobs=1, error_score='raise')
        except Exception as e:
            logger.error(f"Evaluation failed: {e}")
            return -1000.0
        
        # Combined objective: maximize R² while minimizing RMSE variance
        r2_mean = np.mean(r2_scores)
        r2_std = np.std(r2_scores)
        rmse_mean = np.mean(rmse_scores)
        rmse_std = np.std(rmse_scores)
        
        # Weighted combination favoring R² with stability penalty
        stability_penalty = 0.1 * (r2_std + rmse_std)
        objective_score = r2_mean - stability_penalty
        
        # Log trial results
        logger.info(f"Trial {trial.number}: R²={r2_mean:.4f}, RMSE={rmse_mean:.4f}, Score={objective_score:.4f}")
        
        # Report intermediate results
        trial.report(objective_score, step=0)
        
        return objective_score
    
    def optimize(self, X_train, y_train, X_val=None, y_val=None, n_trials=100, timeout=7200):
        """Run optimization with enhanced strategies (A-D).
        
        Args:
            X_train: Training features
            y_train: Training targets  
            X_val: Validation features (if None, uses cross-validation)
            y_val: Validation targets (if None, uses cross-validation)
        """
        self.X_train = X_train
        self.y_train = y_train
        self.X_val = X_val
        self.y_val = y_val
        
        # Initialize enhanced optimization strategies
        dataset_size = len(X_train)
        self._enhanced_config = get_enhanced_optimization_config(
            model_name='xgboost',
            dataset_size=dataset_size,
            n_trials=n_trials,
            reports_dir=self.config.reports_dir
        )
        logger.info(f"Enhanced optimization strategies initialized for dataset_size={dataset_size}, n_trials={n_trials}")
        
        # Check if validation data is properly provided
        valid_X_val = X_val is not None and hasattr(X_val, '__len__') and len(X_val) > 0
        valid_y_val = y_val is not None and hasattr(y_val, '__len__') and len(y_val) > 0
        self.use_holdout_validation = valid_X_val and valid_y_val
        
        if X_val is not None or y_val is not None:
            # Some validation data was provided but may be invalid
            if not self.use_holdout_validation:
                logger.warning(f"Invalid validation data provided: X_val={type(X_val)}, y_val={type(y_val)}")
                logger.warning("Falling back to cross-validation")

        if self.use_holdout_validation:
            logger.info("Using hold-out validation (matches final evaluation approach)")
        else:
            logger.info("Using cross-validation (may not match final evaluation)")
        
        # Pre-compute features once before parallel optimization to avoid redundant computation
        logger.info("Pre-computing features for parallel optimization...")
        self._precompute_features()
        logger.info(f"Features pre-computed. Shape: {self._cached_features.shape}")
        
        # Use n_jobs from config if available, with GPU-aware adjustments
        import multiprocessing
        cpu_count = multiprocessing.cpu_count
        
        if hasattr(self.config, 'parallel') and hasattr(self.config.parallel, 'model_n_jobs'):
            config_n_jobs = self.config.parallel.model_n_jobs
            
            if self.config.use_gpu:
                # With GPU, limit Optuna parallelism since XGBoost uses GPU internally
                # GPU memory constraints typically limit parallel trials
                n_jobs = min(2, config_n_jobs) if config_n_jobs > 0 else 1
                self._xgb_n_jobs = max(1, cpu_count() // 2)  # XGBoost can use more cores when GPU is handling main compute
                logger.info(f"GPU mode: using {n_jobs} parallel Optuna workers (limited from config value {config_n_jobs})")
                logger.info(f"XGBoost internal parallelism set to {self._xgb_n_jobs} threads")
            else:
                # For CPU, balance between Optuna and XGBoost parallelism
                if config_n_jobs == -1:
                    # Auto mode: balance between Optuna and XGBoost
                    n_jobs = max(1, min(4, cpu_count() // 4))  # Use 1/4 of cores for Optuna, max 4
                    self._xgb_n_jobs = max(1, cpu_count() // n_jobs)  # Remaining cores for XGBoost
                    logger.info(f"CPU auto mode: {n_jobs} Optuna workers, {self._xgb_n_jobs} XGBoost threads per trial")
                elif config_n_jobs > 1:
                    # Multiple Optuna workers: reduce XGBoost parallelism
                    n_jobs = min(config_n_jobs, cpu_count() // 2)  # Don't oversubscribe
                    self._xgb_n_jobs = max(1, cpu_count() // n_jobs)  # Divide cores among trials
                    logger.info(f"CPU parallel mode: {n_jobs} Optuna workers, {self._xgb_n_jobs} XGBoost threads per trial")
                else:
                    # Single Optuna worker: XGBoost can use all cores
                    n_jobs = 1
                    self._xgb_n_jobs = -1  # Let XGBoost use all available cores
                    logger.info(f"CPU sequential mode: 1 Optuna worker, XGBoost using all cores")
        else:
            # Fallback if config doesn't have tuner settings
            n_jobs = 1
            self._xgb_n_jobs = -1
            logger.warning("No tuner config found, using single Optuna worker with full XGBoost parallelism")
        
        # Create study with adaptive pruning based on number of trials
        # For high trial counts (1000+), use more conservative pruning
        if n_trials >= 1000:
            n_startup_trials = min(100, n_trials // 10)  # 10% startup trials, max 100
            n_warmup_steps = 20
            interval_steps = 5
            logger.info(f"Using conservative pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        elif n_trials >= 500:
            n_startup_trials = min(50, n_trials // 15)   # ~7% startup trials, max 50
            n_warmup_steps = 15
            interval_steps = 3
            logger.info(f"Using moderate pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        else:
            n_startup_trials = min(20, n_trials // 5)    # 20% startup trials, max 20
            n_warmup_steps = 10
            interval_steps = 2
            logger.info(f"Using standard pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        
        # Use enhanced sampling strategy (Strategy B)
        enhanced_sampler = self._enhanced_config['advanced_sampling'].get_best_sampler()
        
        study = optuna.create_study(
            direction='maximize',
            pruner=optuna.pruners.MedianPruner(
                n_startup_trials=n_startup_trials,
                n_warmup_steps=n_warmup_steps,
                interval_steps=interval_steps
            ),
            sampler=enhanced_sampler
        )
        
        # Note: The first trial will fit the feature pipeline and cache features
        # This happens inside create_advanced_objective when _cached_features is None
        logger.info(f"Starting XGBoost optimization with {n_trials} trials, timeout={timeout}s")
        logger.info(f"Parallel execution: {n_jobs} worker(s)")
        
        # Optimize with parallel execution if beneficial
        study.optimize(
            self.create_advanced_objective,
            n_trials=n_trials,
            timeout=timeout,
            n_jobs=n_jobs,
            show_progress_bar=True
        )
        
        self.best_params = study.best_params
        self.best_score = study.best_value
        self._study_trials = study.trials  # Store for later reference
        
        # Perform parameter importance analysis (Strategy C)
        try:
            importance_analyzer = self._enhanced_config['importance_analyzer']
            param_importance = importance_analyzer.analyze_study(study, 'xgboost')
            self._param_importance = param_importance
            logger.info("Parameter importance analysis completed")
        except Exception as e:
            logger.warning(f"Parameter importance analysis failed: {e}")
            self._param_importance = {}
        
        logger.info(f"Optimization complete. Best score: {self.best_score:.4f}")
        logger.info(f"Best parameters: {self.best_params}")
        
        return study
    
    def train_final_model(self, X_train, y_train, X_test, y_test):
        """Train final model with best parameters."""
        if not self.best_params:
            raise ValueError("Must run optimization first")
        
        # Check if optimization provided meaningful improvement, if not use safer parameters
        improvement = 0.0
        if hasattr(self, 'best_score') and hasattr(self, '_study_trials') and len(self._study_trials) > 0:
            default_score = self._study_trials[0].value if self._study_trials[0].value is not None else None
            if default_score is not None:
                improvement = self.best_score - default_score
        
        # Use safer parameters if optimization improvement is minimal or parameters seem too restrictive
        use_safe_params = (
            improvement < 0.02 or  # Increased threshold for small improvement
            self.best_params.get('min_child_weight', 1) >= 6 or   # More sensitive - catch restrictive parameters earlier
            self.best_params.get('gamma', 0) > 0.5 or             # More sensitive - catch restrictive gamma earlier
            self.best_params.get('max_depth', 6) >= 9 or          # More sensitive - catch very deep trees earlier
            self.best_params.get('learning_rate', 0.1) < 0.01 or  # Catch very low learning rates
            self.best_params.get('colsample_bytree', 1.0) < 0.6   # Catch very restrictive feature sampling
        )
        
        if use_safe_params:
            logger.warning(f"Using safer default parameters due to minimal improvement ({improvement:.4f}) or restrictive optimized parameters")
            final_params = {
                'n_estimators': min(self.best_params.get('n_estimators', 100), 200),  # Cap at reasonable level
                'learning_rate': max(self.best_params.get('learning_rate', 0.1), 0.02),  # Not too low
                'max_depth': min(self.best_params.get('max_depth', 6), 8),  # Cap depth
                'min_child_weight': min(self.best_params.get('min_child_weight', 1), 5),  # Not too restrictive
                'subsample': max(self.best_params.get('subsample', 1.0), 0.7),
                'colsample_bytree': max(self.best_params.get('colsample_bytree', 1.0), 0.7),
                'colsample_bylevel': max(self.best_params.get('colsample_bylevel', 1.0), 0.7),
                'colsample_bynode': max(self.best_params.get('colsample_bynode', 1.0), 0.7),
                'reg_alpha': min(self.best_params.get('reg_alpha', 0.0), 1.0),
                'reg_lambda': min(self.best_params.get('reg_lambda', 1.0), 3.0),
                'gamma': min(self.best_params.get('gamma', 0.0), 0.5),  # Not too restrictive
                'max_delta_step': self.best_params.get('max_delta_step', 0),
                'tree_method': 'hist',
                'random_state': 42,
                'verbosity': 0
            }
        else:
            final_params = self.best_params.copy()
        
        # Add GPU support
        if self.config.use_gpu:
            try:
                final_params['device'] = 'cuda'
                final_params['tree_method'] = 'hist'  # Use hist with device='cuda' for GPU (XGBoost 2.0+)
                # Remove gpu_id if it exists to avoid conflicts
                final_params.pop('gpu_id', None)
            except:
                logger.warning("GPU not available, falling back to CPU")
                final_params['device'] = 'cpu'
                final_params['tree_method'] = 'hist'
        else:
            final_params['tree_method'] = 'hist'
        
        # Create final model
        final_model = xgb.XGBRegressor(**final_params)
        
        # Prepare data - drop sample_id for feature extraction
        X_train_features = X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_train.columns else X_train
        X_test_features = X_test.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_test.columns else X_test
        
        # Use cached feature pipeline if available, otherwise create new one
        if hasattr(self, '_fitted_feature_pipeline'):
            logger.info("Using cached feature pipeline for final model")
            X_train_transformed = self._fitted_feature_pipeline.transform(X_train_features)
            X_test_transformed = self._fitted_feature_pipeline.transform(X_test_features)
            
            # Apply feature selection if it was used during optimization
            if self.config.use_feature_selection and hasattr(self, '_fitted_feature_selector'):
                logger.info("Applying cached feature selection to final model training data")
                X_train_transformed = self._fitted_feature_selector.transform(X_train_transformed)
                X_test_transformed = self._fitted_feature_selector.transform(X_test_transformed)
                logger.info(f"Features after selection: {X_train_transformed.shape[1]}")
            
            # Calculate sample weights if enabled
            sample_weights = None
            if self.config.use_sample_weights:
                sample_weights = self._calculate_sample_weights(y_train)
                logger.info(f"XGBoost training with sample weights (method: {getattr(self.config, 'sample_weight_method', 'default')})")
                final_model.fit(X_train_transformed, y_train, sample_weight=sample_weights)
            else:
                # Train model on transformed features
                final_model.fit(X_train_transformed, y_train)
            
            # Setup calibration if sample weights are used
            self._setup_calibration_if_needed(final_model, X_train_transformed, y_train)
            
            # Create final pipeline for saving - include all steps from fitted pipeline
            pipeline_steps = [
                ('features', self._fitted_feature_pipeline.named_steps['features']),
                ('scaler', self._fitted_feature_pipeline.named_steps['scaler'])
            ]
            
            # Include feature selection if it was used
            if self.config.use_feature_selection and hasattr(self, '_fitted_feature_selector'):
                pipeline_steps.append(('feature_selection', self._fitted_feature_selector))
            # Include dimension reduction if it was in the fitted pipeline
            elif 'dimension_reduction' in self._fitted_feature_pipeline.named_steps:
                pipeline_steps.append(('dimension_reduction', self._fitted_feature_pipeline.named_steps['dimension_reduction']))
            
            # Add calibrated model if calibration is available
            if self.use_calibration and self.calibrator is not None:
                calibrated_model = CalibratedModelWrapper(final_model, self.calibrator)
                pipeline_steps.append(('model', calibrated_model))
                logger.info("Included calibration in saved XGBoost pipeline (cached path)")
            else:
                pipeline_steps.append(('model', final_model))
            final_pipeline = Pipeline(pipeline_steps)
        else:
            # Fallback to creating new pipeline
            pipeline_steps = [
                ('features', self.feature_pipeline),
                ('scaler', StandardScaler())
            ]
            
            # Add feature selection if configured
            if self.config.use_feature_selection:
                if hasattr(self, '_fitted_feature_selector'):
                    # Use the fitted feature selector from optimization
                    pipeline_steps.append(('feature_selection', self._fitted_feature_selector))
                    logger.info(f"Adding fitted feature selection to final pipeline: {self.config.feature_selection_method}")
                else:
                    # Create new selector if not available (should not happen in normal flow)
                    feature_selector = SpectralFeatureSelector(self.config)
                    pipeline_steps.append(('feature_selection', feature_selector))
                    logger.warning(f"Creating new feature selector for final pipeline: {self.config.feature_selection_method}")
                    logger.warning("This may cause feature mismatch - fitted selector preferred")
            # Add dimension reduction if configured
            elif self.config.use_dimension_reduction:
                from src.features.dimension_reduction import DimensionReductionFactory
                reducer = DimensionReductionFactory.create_reducer(
                    method=self.config.dimension_reduction.method,
                    params=self.config.dimension_reduction.get_params()
                )
                pipeline_steps.append(('dimension_reduction', reducer))
                logger.info(f"Adding {self.config.dimension_reduction.method} dimension reduction to final pipeline")
            
            # Add calibrated model if calibration is available
            if self.use_calibration and self.calibrator is not None:
                calibrated_model = CalibratedModelWrapper(final_model, self.calibrator)
                pipeline_steps.append(('model', calibrated_model))
                logger.info("Included calibration in saved XGBoost pipeline (fallback path)")
            else:
                pipeline_steps.append(('model', final_model))
            final_pipeline = Pipeline(pipeline_steps)
            
            # Calculate sample weights if enabled
            sample_weights = None
            if self.config.use_sample_weights:
                sample_weights = self._calculate_sample_weights(y_train)
                logger.info(f"XGBoost training with sample weights (method: {getattr(self.config, 'sample_weight_method', 'default')})")
                final_pipeline.fit(X_train_features, y_train, model__sample_weight=sample_weights)
            else:
                final_pipeline.fit(X_train_features, y_train)
            
            # Setup calibration using the full pipeline
            X_train_transformed = final_pipeline[:-1].transform(X_train_features)  # Everything except model
            self._setup_calibration_if_needed(final_pipeline.named_steps['model'], X_train_transformed, y_train)
            
            # Get properly transformed features for metrics
            X_train_transformed = final_pipeline[:-1].transform(X_train_features)
            X_test_transformed = final_pipeline[:-1].transform(X_test_features)
        
        # Evaluate - use the model on transformed features for consistency
        train_pred_raw = final_model.predict(X_train_transformed)
        test_pred_raw = final_model.predict(X_test_transformed)
        
        # Calculate metrics at each stage
        # Stage 1: Raw predictions (no calibration)
        raw_train_metrics = calculate_regression_metrics(y_train, train_pred_raw)
        raw_test_metrics = calculate_regression_metrics(y_test, test_pred_raw)
        
        # Stage 2: Skip sample-weight calibration (use only post-calibration)
        train_pred = train_pred_raw
        test_pred = test_pred_raw
        
        # Calculate metrics after sample-weight calibration
        if self.use_calibration and self.calibrator is not None:
            cal_train_metrics = calculate_regression_metrics(y_train, train_pred)
            cal_test_metrics = calculate_regression_metrics(y_test, test_pred)
            
            # Log sample-weight calibration improvements
            logger.info("=" * 60)
            logger.info("SAMPLE-WEIGHT CALIBRATION RESULTS:")
            logger.info("-" * 50)
            logger.info("TEST SET - Raw → Sample-Weight Calibrated:")
            logger.info(f"  R²: {raw_test_metrics['r2']:.4f} → {cal_test_metrics['r2']:.4f} "
                       f"({'↑' if cal_test_metrics['r2'] > raw_test_metrics['r2'] else '↓'} "
                       f"{abs(cal_test_metrics['r2'] - raw_test_metrics['r2']):.4f})")
            logger.info(f"  RMSE: {raw_test_metrics['rmse']:.4f} → {cal_test_metrics['rmse']:.4f} "
                       f"({'↓' if cal_test_metrics['rmse'] < raw_test_metrics['rmse'] else '↑'} "
                       f"{abs(cal_test_metrics['rmse'] - raw_test_metrics['rmse']):.4f})")
            logger.info(f"  Within 20.5%: {raw_test_metrics['within_20.5%']:.2f}% → "
                       f"{cal_test_metrics['within_20.5%']:.2f}% "
                       f"({'↑' if cal_test_metrics['within_20.5%'] > raw_test_metrics['within_20.5%'] else '↓'} "
                       f"{abs(cal_test_metrics['within_20.5%'] - raw_test_metrics['within_20.5%']):.2f}%)")
            logger.info(f"  MAPE: {raw_test_metrics['mape']:.2f}% → {cal_test_metrics['mape']:.2f}% "
                       f"({'↓' if cal_test_metrics['mape'] < raw_test_metrics['mape'] else '↑'} "
                       f"{abs(cal_test_metrics['mape'] - raw_test_metrics['mape']):.2f}%)")
            logger.info("=" * 60)
        else:
            cal_train_metrics = raw_train_metrics
            cal_test_metrics = raw_test_metrics
        
        # Stage 3: Apply post-processing calibration if enabled using standardized method
        train_pred, test_pred = self.apply_post_calibration(
            y_train, train_pred, y_test, test_pred, "XGBoost"
        )
        
        # Final metrics after all calibrations
        train_metrics = calculate_regression_metrics(y_train, train_pred)
        test_metrics = calculate_regression_metrics(y_test, test_pred)
        
        # Log overall improvement summary
        logger.info("=" * 60)
        logger.info("📊 OVERALL CALIBRATION SUMMARY (TEST SET):")
        logger.info("-" * 50)
        logger.info("Metric         | Raw      | Cal      | Post-Cal | Total Δ")
        logger.info("-" * 60)
        logger.info(f"R²             | {raw_test_metrics['r2']:8.4f} | {cal_test_metrics['r2']:8.4f} | {test_metrics['r2']:8.4f} | "
                   f"{'↑' if test_metrics['r2'] > raw_test_metrics['r2'] else '↓'}{abs(test_metrics['r2'] - raw_test_metrics['r2']):.4f}")
        logger.info(f"RMSE           | {raw_test_metrics['rmse']:8.4f} | {cal_test_metrics['rmse']:8.4f} | {test_metrics['rmse']:8.4f} | "
                   f"{'↓' if test_metrics['rmse'] < raw_test_metrics['rmse'] else '↑'}{abs(test_metrics['rmse'] - raw_test_metrics['rmse']):.4f}")
        logger.info(f"Within 20.5%   | {raw_test_metrics['within_20.5%']:7.2f}% | {cal_test_metrics['within_20.5%']:7.2f}% | {test_metrics['within_20.5%']:7.2f}% | "
                   f"{'↑' if test_metrics['within_20.5%'] > raw_test_metrics['within_20.5%'] else '↓'}{abs(test_metrics['within_20.5%'] - raw_test_metrics['within_20.5%']):.2f}%")
        logger.info(f"MAPE           | {raw_test_metrics['mape']:7.2f}% | {cal_test_metrics['mape']:7.2f}% | {test_metrics['mape']:7.2f}% | "
                   f"{'↓' if test_metrics['mape'] < raw_test_metrics['mape'] else '↑'}{abs(test_metrics['mape'] - raw_test_metrics['mape']):.2f}%")
        logger.info("=" * 60)
        
        # Wrap the pipeline with post-calibration if it was used
        if self.post_calibrator is not None and getattr(self.config, 'use_post_calibration', False):
            from src.models.post_calibrated_wrapper import PostCalibratedModelWrapper
            logger.info("Wrapping model with post-calibration for deployment")
            calibrated_pipeline = PostCalibratedModelWrapper(
                final_pipeline, 
                self.post_calibrator, 
                self.post_calibration_config
            )
            return calibrated_pipeline, train_metrics, test_metrics
        
        return final_pipeline, train_metrics, test_metrics
    
    # _calculate_sample_weights method removed - now inherits improved magnesium-adapted 
    # implementation from BaseOptimizer with proper agronomic range weighting
    
    def _setup_calibration_if_needed(self, model, X_train, y_train):
        """Setup calibration if sample weights are being used."""
        if not self.config.use_sample_weights:
            return
            
        logger.info("Sample weights detected - setting up prediction calibration for XGBoost")
        
        try:
            # Generate cross-validation predictions
            logger.info("Generating cross-validation predictions for XGBoost calibration...")
            cv_predictions = cross_val_predict(model, X_train, y_train, cv=5)
            
            # Fit isotonic regression calibrator
            self.calibrator = IsotonicRegression(out_of_bounds='clip')
            self.calibrator.fit(cv_predictions, y_train)
            self.use_calibration = True
            
            # Log calibration diagnostics
            calibrated_cv_preds = self.calibrator.transform(cv_predictions)
            original_bias = np.mean(cv_predictions - y_train)
            calibrated_bias = np.mean(calibrated_cv_preds - y_train)
            
            logger.info(f"XGBoost calibration setup complete:")
            logger.info(f"  Original bias: {original_bias:.4f}")
            logger.info(f"  Calibrated bias: {calibrated_bias:.4f}")
            logger.info(f"  Bias improvement: {abs(original_bias) - abs(calibrated_bias):+.4f}")
            
        except Exception as e:
            logger.warning(f"Failed to setup calibration for XGBoost: {e}")
            logger.info("Continuing without calibration")
            self.use_calibration = False
            self.calibrator = None
    
    def _apply_post_processing_calibration(self, y_train, train_pred, y_test, test_pred):
        """Apply post-processing calibration to improve specific metrics."""
        from src.models.calibration_utils import PrecisionCalibrator
        import numpy as np
        
        calibration_method = getattr(self.config, 'post_calibration_method', 'isotonic')
        target_metric = getattr(self.config, 'post_calibration_target', 'within_20.5')
        
        logger.info("=" * 50)
        logger.info("POST-PROCESSING CALIBRATION ACTIVATED")
        logger.info(f"Method: {calibration_method}")
        logger.info(f"Target metric: {target_metric}")
        logger.info(f"Training samples: {len(y_train)}")
        logger.info("=" * 50)
        
        # Create sample weights based on target metric
        if target_metric == 'within_20.5':
            # Focus on reducing errors in the middle range where within_20.5% is typically worst
            weights = np.ones_like(y_train)
            p25, p75 = np.percentile(y_train, [25, 75])
            mask = (y_train >= p25) & (y_train <= p75)
            weights[mask] = 2.0
            weights = weights / weights.mean()
        elif target_metric == 'mape':
            # Inverse weighting by true value (MAPE is worse for small values)
            weights = 1.0 / (y_train + 0.01)  # Add small constant to avoid division by zero
            weights = weights / weights.mean()
        else:
            weights = None
            
        # Fit calibrator on training data
        calibrator = PrecisionCalibrator(method=calibration_method)
        calibrator.fit(y_train, train_pred, sample_weight=weights)
        
        # Apply calibration to both sets
        train_pred_cal = calibrator.transform(train_pred)
        test_pred_cal = calibrator.transform(test_pred)
        
        # Ensure predictions stay in reasonable bounds
        train_pred_cal = np.clip(train_pred_cal, 0, max(y_train.max() * 1.2, 1.0))
        test_pred_cal = np.clip(test_pred_cal, 0, max(y_test.max() * 1.2, 1.0))
        
        # Calculate improvement metrics
        from src.utils.helpers import calculate_regression_metrics
        original_train_metrics = calculate_regression_metrics(y_train, train_pred)
        original_test_metrics = calculate_regression_metrics(y_test, test_pred)
        calibrated_train_metrics = calculate_regression_metrics(y_train, train_pred_cal)
        calibrated_test_metrics = calculate_regression_metrics(y_test, test_pred_cal)
        
        logger.info("POST-PROCESSING CALIBRATION RESULTS:")
        logger.info(f"Original test within_20.5%: {original_test_metrics['within_20.5%']:.2f}%")
        logger.info(f"Calibrated test within_20.5%: {calibrated_test_metrics['within_20.5%']:.2f}%")
        logger.info(f"Original test MAPE: {original_test_metrics['mape']:.2f}%")
        logger.info(f"Calibrated test MAPE: {calibrated_test_metrics['mape']:.2f}%")
        logger.info(f"Original test R²: {original_test_metrics['r2']:.4f}")
        logger.info(f"Calibrated test R²: {calibrated_test_metrics['r2']:.4f}")
        logger.info("=" * 50)
        
        # Store calibrator and config for later use in wrapper
        self.post_calibrator = calibrator
        self.post_calibration_config = {
            'enabled': True,
            'method': calibration_method,
            'target': target_metric
        }
        
        return train_pred_cal, test_pred_cal


class CalibratedModelWrapper:
    """Wrapper that applies calibration to model predictions."""
    
    def __init__(self, model, calibrator):
        self.model = model
        self.calibrator = calibrator
    
    def fit(self, X, y, **kwargs):
        """Fit the underlying model."""
        return self.model.fit(X, y, **kwargs)
    
    def predict(self, X):
        """Make predictions and apply calibration."""
        raw_predictions = self.model.predict(X)
        return self.calibrator.transform(raw_predictions)
    
    def __getattr__(self, name):
        """Delegate other attributes to the underlying model."""
        return getattr(self.model, name)


def main():
    parser = argparse.ArgumentParser(description="XGBoost Optimization")
    parser.add_argument("--strategy", default="full_context", help="Feature strategy")
    parser.add_argument("--trials", type=int, default=200, help="Number of optimization trials")
    parser.add_argument("--timeout", type=int, default=7200, help="Timeout in seconds")
    parser.add_argument("--gpu", action="store_true", help="Use GPU")
    args = parser.parse_args()
    
    # Setup
    cfg = setup_pipeline_config(use_gpu=args.gpu)
    run_data_preparation(cfg)
    full_dataset, data_manager = load_and_clean_data(cfg)
    train_df, test_df = data_manager.create_reproducible_splits(full_dataset)
    
    # Extract features and targets - use same format as ModelTrainer
    X_train = train_df.drop(columns=[cfg.target_column])
    y_train = train_df[cfg.target_column].values
    
    X_test = test_df.drop(columns=[cfg.target_column])
    y_test = test_df[cfg.target_column].values
    
    # Optimize
    optimizer = XGBoostOptimizer(cfg, args.strategy)
    study = optimizer.optimize(X_train, y_train, args.trials, args.timeout)
    
    # Train final model
    final_pipeline, train_metrics, test_metrics = optimizer.train_final_model(
        X_train, y_train, X_test, y_test
    )
    
    # Results
    print(f"\nOptimization Results:")
    print(f"Best R² Score: {optimizer.best_score:.4f}")
    print(f"Best Parameters: {optimizer.best_params}")
    print(f"\nFinal Model Performance:")
    print(f"Train R²: {train_metrics['r2']:.4f}")
    print(f"Test R²: {test_metrics['r2']:.4f}")
    print(f"Test RMSE: {test_metrics['rmse']:.4f}")
    
    # Save model with display strategy name
    from main import get_display_strategy_name
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    display_strategy = get_display_strategy_name(args.strategy, getattr(cfg, 'use_raw_spectral_data', False))
    model_path = cfg.model_dir / f"optimized_xgboost_{display_strategy}_{timestamp}.pkl"
    import joblib
    joblib.dump(final_pipeline, model_path)
    print(f"Model saved to: {model_path}")
    
    # Save configuration
    optimized_config = cfg.copy(deep=True)
    optimized_config.model_params.xgboost = optimizer.best_params
    config_name = f"optimized_xgboost_{args.strategy}_{timestamp}"
    config_manager.save_config(optimized_config, config_name, 
                             f"Optimized XGBoost config - R²: {test_metrics['r2']:.4f}")

if __name__ == "__main__":
    main()