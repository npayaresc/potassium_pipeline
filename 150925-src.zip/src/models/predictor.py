"""
Prediction Module

This module defines the Predictor class, which handles loading a trained model
and making predictions on new, unseen spectral data.
"""
from collections import defaultdict
import logging
from pathlib import Path
import shutil
import joblib
import pandas as pd
import numpy as np

from src.features.feature_engineering import create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.features.dimension_reduction import DimensionReducer
from src.config.pipeline_config import Config
from src.data_management.data_manager import DataManager
from src.cleansing.data_cleanser import DataCleanser
from src.utils.custom_exceptions import PipelineError

# Conditionally import AutoGluon to avoid errors if it's not installed
try:
    from autogluon.tabular import TabularPredictor
    AUTOGLUON_AVAILABLE = True
except ImportError:
    AUTOGLUON_AVAILABLE = False

from src.models.custom_autogluon import AutoGluonRegressor

# Check for post-calibration wrapper
try:
    from src.models.post_calibrated_wrapper import PostCalibratedModelWrapper
    POST_CALIBRATION_AVAILABLE = True
except ImportError:
    POST_CALIBRATION_AVAILABLE = False
    PostCalibratedModelWrapper = None

logger = logging.getLogger(__name__)

class CalibratedModelWrapper:
    """Wrapper that applies calibration to model predictions."""
    
    def __init__(self, model, calibrator):
        self.model = model
        self.calibrator = calibrator
    
    def fit(self, X, y, sample_weight=None, **kwargs):
        """Fit the underlying model."""
        return self.model.fit(X, y, sample_weight=sample_weight, **kwargs)
    
    def predict(self, X):
        """Make predictions and apply calibration."""
        raw_predictions = self.model.predict(X)
        return self.calibrator.transform(raw_predictions)
    
    def __getattr__(self, name):
        """Delegate other attributes to the underlying model."""
        return getattr(self.model, name)

class Predictor:
    """Handles loading models and making predictions on new data."""

    def __init__(self, config: Config):
        """
        Initializes the Predictor.

        Args:
            config: The pipeline configuration object.
        """
        self.config = config
        self.data_cleanser = DataCleanser(config)
        # Use the same data manager methods for consistency
        self.data_manager = DataManager(config)
        
    def _detect_model_calibration_status(self, model, model_path: Path) -> tuple:
        """
        Detects if a model has calibration applied (both sample-weight and post-calibration).
        
        Args:
            model: The loaded model object
            model_path: Path to the model file or directory
            
        Returns:
            Tuple of (has_sample_weight_calibration, has_post_calibration)
        """
        has_sample_weight_cal = False
        has_post_cal = False
        
        # Check for post-calibration wrapper
        if POST_CALIBRATION_AVAILABLE and isinstance(model, PostCalibratedModelWrapper):
            has_post_cal = True
            logger.info("Post-calibration detected in model")
            if model.post_calibration_config:
                logger.info(f"  Method: {model.post_calibration_config.get('method', 'unknown')}")
                logger.info(f"  Target: {model.post_calibration_config.get('target', 'unknown')}")
            # Check the wrapped model for sample-weight calibration
            model = model.model  # Get the wrapped model for further checks
        
        # Check for standard pipeline with CalibratedModelWrapper
        if hasattr(model, 'named_steps') and 'model' in model.named_steps:
            model_step = model.named_steps['model']
            if 'CalibratedModelWrapper' in str(type(model_step)):
                has_sample_weight_cal = True
        
        # Check for AutoGluon calibration file
        if model_path.is_dir():
            calibration_path = model_path / "calibrator.pkl"
            if calibration_path.exists():
                has_sample_weight_cal = True
        
        # Check for custom neural network pipeline calibration
        if hasattr(model, 'calibrator') and model.calibrator is not None:
            has_sample_weight_cal = True
            
        return has_sample_weight_cal, has_post_cal
    
    def _load_wavelength_metadata(self, model_path: Path):
        """
        Loads wavelength standardization metadata if it exists.
        
        Args:
            model_path: Path to the model file or directory
        """
        import json
        
        # Determine metadata path based on model type
        if model_path.is_dir():
            # AutoGluon model directory
            metadata_path = model_path / "wavelength_metadata.json"
        else:
            # Standard model file
            metadata_path = model_path.with_suffix('.wavelength_metadata.json')
        
        if metadata_path.exists():
            try:
                with open(metadata_path, 'r') as f:
                    metadata = json.load(f)
                
                # Load the global wavelength range into data manager
                if 'global_wavelength_range' in metadata:
                    self.data_manager._global_wavelength_range = (
                        metadata['global_wavelength_range']['min'],
                        metadata['global_wavelength_range']['max']
                    )
                    logger.info(
                        f"Loaded wavelength standardization range from model: "
                        f"{metadata['global_wavelength_range']['min']:.2f} - "
                        f"{metadata['global_wavelength_range']['max']:.2f} nm"
                    )
                    
                # Override config settings if they differ
                if metadata.get('wavelength_standardization_enabled'):
                    if not self.config.enable_wavelength_standardization:
                        logger.warning(
                            "Model was trained with wavelength standardization, "
                            "but it's currently disabled. Enabling it for prediction."
                        )
                        self.config.enable_wavelength_standardization = True
                    
                    # Use the same interpolation method and resolution as training
                    if 'interpolation_method' in metadata:
                        self.config.wavelength_interpolation_method = metadata['interpolation_method']
                    if 'wavelength_resolution' in metadata:
                        self.config.wavelength_resolution = metadata['wavelength_resolution']
                        
            except Exception as e:
                logger.warning(f"Could not load wavelength metadata: {e}")
        else:
            if self.config.enable_wavelength_standardization:
                logger.warning(
                    f"Wavelength standardization is enabled but no metadata found for model. "
                    f"Prediction will use local wavelength ranges."
                )

    def _load_model(self, model_path: Path) -> tuple:
        """
        Loads a model, handling both standard .pkl and AutoGluon models.

        Args:
            model_path: Path to the model file or directory.

        Returns:
            A tuple of (model, needs_manual_features) where needs_manual_features 
            indicates if manual feature transformation is required.
        """
        # First, check if wavelength metadata exists for this model
        self._load_wavelength_metadata(model_path)
        if model_path.is_dir():
            # This is an AutoGluon model directory (legacy format)
            if not AUTOGLUON_AVAILABLE:
                raise ImportError("AutoGluon is not installed, but trying to load an AutoGluon model.")
            logger.info(f"Loading legacy AutoGluon model from directory: {model_path}")
            logger.warning("Loading legacy AutoGluon format. Consider re-training to get consistent pipeline format.")
            
            # Load feature pipeline
            self.feature_pipeline = joblib.load(model_path / "feature_pipeline.pkl")
            
            # Load feature selector if it exists
            feature_selector_path = model_path / "feature_selector.pkl"
            if feature_selector_path.exists():
                self.feature_selector = joblib.load(feature_selector_path)
                logger.info(f"Loaded feature selector from: {feature_selector_path}")
                logger.info(f"Selected features: {self.feature_selector.selected_features_.sum()}")
            else:
                self.feature_selector = None
                logger.info("No feature selector found - using all features")
            
            # Load dimension reducer if it exists (new modular system)
            reducer_path = model_path / "dimension_reducer.pkl"
            pca_path = model_path / "pca_transformer.pkl"  # Legacy support
            
            if reducer_path.exists():
                self.dimension_reducer = DimensionReducer.load(str(reducer_path))
                logger.info(f"Loaded dimension reducer from: {reducer_path}")
                logger.info(f"Dimension reduction method: {self.dimension_reducer.__class__.__name__}")
                logger.info(f"Components: {self.dimension_reducer.get_n_components()}")
            elif pca_path.exists():
                # Legacy PCA support
                self.dimension_reducer = joblib.load(pca_path)
                logger.info(f"Loaded legacy PCA transformer from: {pca_path}")
                logger.info(f"PCA components: {self.dimension_reducer.n_components_}, variance retained: {self.dimension_reducer.explained_variance_ratio_.sum():.2%}")
            else:
                self.dimension_reducer = None
                logger.info("No dimension reducer found - using full feature set")
            
            # Use AutoGluonRegressor wrapper to include calibration logic
            autogluon_regressor = AutoGluonRegressor(
                config=self.config.autogluon, 
                model_path=model_path,
                pipeline_config=self.config
            )
            
            # Check if AutoGluon model has calibration
            calibration_path = model_path / "calibrator.pkl"
            is_autogluon_calibrated = calibration_path.exists()
            
            if is_autogluon_calibrated:
                logger.info("AutoGluon model has calibration - predictions will be calibrated for sample weight bias correction")
            
            # Log sample weighting status for awareness
            if hasattr(self.config.autogluon, 'use_improved_config') and self.config.autogluon.use_improved_config:
                logger.info("AutoGluon model trained with sample weighting enabled - predictions will reflect concentration-aware training")
            
            # Log global sample weighting status
            if getattr(self.config, 'use_sample_weights', False):
                logger.info(f"Pipeline configured with sample weighting (method: {getattr(self.config, 'sample_weight_method', 'unknown')})")
                if is_autogluon_calibrated:
                    logger.info("Model trained with sample weights - using calibrated predictions to correct systematic bias")
            
            # Log raw spectral mode status
            if getattr(self.config, 'use_raw_spectral_data', False):
                logger.info("Raw spectral mode enabled - model expects raw intensity features")
            autogluon_regressor.predictor = TabularPredictor.load(str(model_path))
            
            # Set correct feature names based on whether dimension reduction was used
            if self.dimension_reducer is not None:
                # Model expects reduced dimension names
                if hasattr(self.dimension_reducer, 'n_components_'):
                    # Legacy PCA
                    n_components = self.dimension_reducer.n_components_
                    prefix = "pca"
                else:
                    # New modular system
                    n_components = self.dimension_reducer.get_n_components()
                    prefix = self.dimension_reducer.__class__.__name__.replace('Reducer', '').lower()
                
                autogluon_regressor.feature_names_in_ = [f"{prefix}_component_{i}" for i in range(n_components)]
            else:
                # Model expects engineered feature names
                try:
                    feature_names = self.feature_pipeline.get_feature_names_out()
                    if hasattr(feature_names, 'tolist'):
                        feature_names = feature_names.tolist()
                    else:
                        feature_names = list(feature_names)
                except Exception as e:
                    logger.warning(f"Could not get feature names from pipeline: {e}")
                    # Fall back to building feature names manually
                    feature_names = self._build_feature_names_from_pipeline()
                autogluon_regressor.feature_names_in_ = feature_names
                
            return autogluon_regressor, True  # True = needs manual feature transformation
            
        elif model_path.suffix == '.pkl':
            # This is a standard scikit-learn pipeline (regular, fine-tuned, or new AutoGluon format)
            logger.info(f"Loading scikit-learn pipeline from file: {model_path}")
            pipeline = joblib.load(model_path)
            
            # Detect calibration and what type of pipeline this is for logging
            is_calibrated = False
            if hasattr(pipeline, 'neural_network') and hasattr(pipeline, 'feature_pipeline'):
                # This is a NeuralNetworkPipeline
                logger.info("Detected Neural Network pipeline with custom serialization")
            elif hasattr(pipeline, 'named_steps') and 'model' in pipeline.named_steps:
                model_step = pipeline.named_steps['model']
                model_type = str(type(model_step))
                
                # Check if this is a calibrated model
                if 'CalibratedModelWrapper' in model_type:
                    is_calibrated = True
                    logger.info("Detected calibrated model wrapper - predictions will be calibrated for sample weight bias correction")
                    # Get the actual underlying model type for logging
                    if hasattr(model_step, 'model'):
                        underlying_model_type = str(type(model_step.model))
                        if 'AutoGluon' in underlying_model_type:
                            logger.info("Underlying model: AutoGluon wrapper in consistent pipeline format")
                        elif 'NeuralNetwork' in underlying_model_type:
                            logger.info("Underlying model: Neural Network model in standard pipeline format")
                        elif any(lib in underlying_model_type for lib in ['XGBoost', 'LightGBM', 'CatBoost', 'RandomForest', 'ExtraTrees']):
                            logger.info(f"Underlying model: {type(model_step.model).__name__}")
                        else:
                            logger.info(f"Underlying model: {type(model_step.model).__name__}")
                elif 'AutoGluon' in model_type:
                    logger.info("Detected AutoGluon wrapper in consistent pipeline format")
                elif 'NeuralNetwork' in model_type:
                    logger.info("Detected Neural Network model in standard pipeline format")
                elif any(lib in model_type for lib in ['XGBoost', 'LightGBM', 'CatBoost', 'RandomForest', 'ExtraTrees']):
                    logger.info(f"Detected extracted AutoGluon or standard model: {type(model_step).__name__}")
                else:
                    logger.info(f"Detected standard pipeline model: {type(model_step).__name__}")
            else:
                logger.info(f"Detected custom pipeline: {type(pipeline).__name__}")
            
            # Log calibration status
            if is_calibrated:
                logger.info("Model trained with sample weights - using calibrated predictions to correct systematic bias")
            
            return pipeline, False  # False = standard pipeline format (handles features internally)
        else:
            raise PipelineError(f"Invalid model path: {model_path}. Must be a .pkl file or a directory.")

    def make_prediction(self, input_file: Path, model_path: Path) -> float:
        """
        Makes a magnesium prediction for a single raw spectral file.

        This method encapsulates the full prediction process:
        1. Loads the specified trained model.
        2. Loads and cleans the raw spectral data using same process as training.
        3. Formats the data into the structure expected by the model.
        4. Returns a single prediction value.

        Args:
            input_file: Path to the raw spectral data file (.csv.txt).
            model_path: Path to the trained model (.pkl file or AutoGluon directory).

        Returns:
            The predicted magnesium concentration as a float.
        
        Raises:
            FileNotFoundError: If the input file does not exist.
            PipelineError: If the data cannot be processed or prediction fails.
        """
        if not input_file.exists():
            raise FileNotFoundError(f"Input file not found: {input_file}")

        # 1. Load the model
        model, needs_manual_features = self._load_model(model_path)
        
        # Check and log calibration status for single prediction
        has_sample_cal, has_post_cal = self._detect_model_calibration_status(model, model_path)
        if has_sample_cal:
            logger.info("Single prediction will use sample-weight calibrated model - correcting for sample weight bias")
        if has_post_cal:
            logger.info("Single prediction will use post-calibrated model - enhanced accuracy for target metrics")

        # 2. Load and clean the input data using EXACTLY the same process as training
        logger.info(f"Processing input file: {input_file.name}")
        
        # Use the same data loading process as training pipeline
        df = self.data_manager._read_raw_intensity_data(input_file)
        wavelengths = df['Wavelength'].values
        intensity_cols = [col for col in df.columns if col != 'Wavelength']
        intensities = df[intensity_cols].values
        
        # Apply wavelength standardization if enabled (must be before cleansing)
        if self.config.enable_wavelength_standardization:
            wavelengths, intensities = self.data_manager.standardize_wavelength_grid(
                wavelengths, intensities,
                interpolation_method=self.config.wavelength_interpolation_method,
                use_global_range=True  # Use global range from training if available
            )
        
        # Ensure intensities is 2D for consistency with training
        if intensities.ndim == 1:
            intensities = intensities.reshape(-1, 1)
            
        # Apply the same cleansing process as training
        clean_intensities = self.data_cleanser.clean_spectra(str(input_file), intensities)

        if clean_intensities.size == 0:
            raise PipelineError(f"No data remaining for {input_file.name} after cleansing. Cannot predict.")

        # 3. Format data into DataFrame using EXACTLY the same format as training
        # This matches the format used in load_and_clean_data() from main.py
        input_data = pd.DataFrame([{
            "wavelengths": wavelengths,
            "intensities": clean_intensities
        }])
        
        # 4. Make prediction using the full pipeline
        if needs_manual_features:
            # Legacy AutoGluon format - apply manual feature transformation
            # Check if this is raw spectral mode (bypass traditional feature engineering)
            if getattr(self.config, 'use_raw_spectral_data', False):
                # Raw spectral mode: extract raw intensities directly from peak regions
                logger.debug("Using raw spectral mode - extracting intensities from peak regions")
                input_data_features = self._extract_raw_spectral_features(input_data)
            else:
                # Traditional feature engineering mode
                # Step 4a: Apply feature engineering
                input_data_features = self.feature_pipeline.transform(input_data)
                logger.debug("Applied manual feature transformation for legacy format")
                
                # Step 4a.5: Apply feature selection if the model uses it
                if hasattr(self, 'feature_selector') and self.feature_selector is not None:
                    input_data_features = self.feature_selector.transform(input_data_features)
                    logger.debug(f"Applied feature selection: {input_data_features.shape[1]} features selected")
            
            # Step 4b: Apply dimension reduction if the model uses it
            if hasattr(self, 'dimension_reducer') and self.dimension_reducer is not None:
                input_data_features = self.dimension_reducer.transform(input_data_features)
                logger.debug(f"Applied dimension reduction: {input_data_features.shape[1]} components")
                
                # Create DataFrame with component names for AutoGluon
                if hasattr(self.dimension_reducer, 'n_components_'):
                    # Legacy PCA
                    prefix = "pca"
                else:
                    # New modular system
                    prefix = self.dimension_reducer.__class__.__name__.replace('Reducer', '').lower()
                    
                feature_columns = [f"{prefix}_component_{i}" for i in range(input_data_features.shape[1])]
                input_data_final = pd.DataFrame(input_data_features, columns=feature_columns)
            else:
                # No dimension reduction - use feature pipeline output directly
                try:
                    feature_columns = self.feature_pipeline.get_feature_names_out()
                except Exception as e:
                    logger.debug(f"Could not get feature names from pipeline: {e}")
                    # Fall back to building feature names manually
                    feature_columns = self._build_feature_names_from_pipeline()
                    if feature_columns is None:
                        # Last resort: use generic names
                        feature_columns = [f"feature_{i}" for i in range(input_data_features.shape[1])]
                input_data_final = pd.DataFrame(input_data_features, columns=feature_columns)
                
            prediction_result = model.predict(input_data_final)
        else:
            # Standard pipeline format - features are handled internally
            prediction_result = model.predict(input_data)
        
        # Extract the single float value from the prediction output
        predicted_value = prediction_result[0] if isinstance(prediction_result, (np.ndarray, pd.Series)) else prediction_result
        
        logger.info(f"Predicted Magnesium %: {predicted_value:.4f}")
        return float(predicted_value)

    
    def make_batch_predictions(self, input_dir: Path, model_path: Path) -> pd.DataFrame:
        """
        Processes a directory of raw files, averages them by sample ID, cleans them,
        and makes predictions on the valid samples using EXACTLY the same process as training.
        """
        logger.info(f"Starting batch prediction from directory: {input_dir}")
        model, needs_manual_features = self._load_model(model_path)
        
        # Check and log calibration status for batch predictions
        has_sample_cal, has_post_cal = self._detect_model_calibration_status(model, model_path)
        if has_sample_cal:
            logger.info("Batch predictions will use sample-weight calibrated model - correcting for sample weight bias")
        if has_post_cal:
            logger.info("Batch predictions will use post-calibrated model - enhanced accuracy for target metrics")

        # 1. Group raw files by sample ID using EXACTLY the same method as training
        files_by_sample = defaultdict(list)
        for file_path in input_dir.glob('*.csv.txt'):
            prefix = self.data_manager._extract_file_prefix(file_path.name)
            files_by_sample[prefix].append(file_path)
        logger.info(f"Found {len(files_by_sample)} unique sample IDs to process.")

        prediction_results = []
        for sample_id, file_paths in files_by_sample.items():
            try:
                # 2. Average the files using EXACTLY the same method as training
                wavelengths, averaged_intensities = self.data_manager.average_files_in_memory(file_paths)

                if averaged_intensities is None:
                    raise ValueError("Averaging failed, no data returned.")

                # 2b. Apply wavelength standardization if enabled (must be before cleansing)
                if self.config.enable_wavelength_standardization:
                    wavelengths, averaged_intensities = self.data_manager.standardize_wavelength_grid(
                        wavelengths, averaged_intensities,
                        interpolation_method=self.config.wavelength_interpolation_method,
                        use_global_range=True  # Use global range from training if available
                    )

                # 3. Clean the averaged sample using EXACTLY the same method as training
                clean_intensities = self.data_cleanser.clean_spectra(sample_id, averaged_intensities)
                
                if clean_intensities.size > 0:
                    # 4a. Format data using EXACTLY the same format as training
                    # This matches the format used in load_and_clean_data() and process_validation_data()
                    input_data = pd.DataFrame([{
                        "wavelengths": wavelengths,
                        "intensities": clean_intensities
                    }])
                    
                    # 5. Make prediction using the appropriate pipeline format
                    if needs_manual_features:
                        # Legacy AutoGluon format - apply manual feature transformation
                        # Check if this is raw spectral mode (bypass traditional feature engineering)
                        if getattr(self.config, 'use_raw_spectral_data', False):
                            # Raw spectral mode: extract raw intensities directly from peak regions
                            input_data_features = self._extract_raw_spectral_features(input_data)
                        else:
                            # Traditional feature engineering mode
                            # Step 5a: Apply feature engineering
                            input_data_features = self.feature_pipeline.transform(input_data)
                            
                            # Step 5a.5: Apply feature selection if the model uses it
                            if hasattr(self, 'feature_selector') and self.feature_selector is not None:
                                input_data_features = self.feature_selector.transform(input_data_features)
                        
                        # Step 5b: Apply dimension reduction if the model uses it
                        if hasattr(self, 'dimension_reducer') and self.dimension_reducer is not None:
                            input_data_features = self.dimension_reducer.transform(input_data_features)
                            
                            # Create DataFrame with component names for AutoGluon
                            if hasattr(self.dimension_reducer, 'n_components_'):
                                # Legacy PCA
                                prefix = "pca"
                            else:
                                # New modular system
                                prefix = self.dimension_reducer.__class__.__name__.replace('Reducer', '').lower()
                                
                            feature_columns = [f"{prefix}_component_{i}" for i in range(input_data_features.shape[1])]
                            input_data_final = pd.DataFrame(input_data_features, columns=feature_columns)
                        else:
                            # No dimension reduction - use feature pipeline output directly
                            try:
                                feature_columns = self.feature_pipeline.get_feature_names_out()
                            except Exception as e:
                                logger.debug(f"Could not get feature names from pipeline: {e}")
                                # Fall back to building feature names manually
                                feature_columns = self._build_feature_names_from_pipeline()
                                if feature_columns is None:
                                    # Last resort: use generic names
                                    feature_columns = [f"feature_{i}" for i in range(input_data_features.shape[1])]
                            input_data_final = pd.DataFrame(input_data_features, columns=feature_columns)
                            
                        prediction = model.predict(input_data_final)[0]
                    else:
                        # Standard pipeline format - features are handled internally
                        prediction = model.predict(input_data)[0]
                    
                    prediction_results.append({'sampleId': sample_id, 'PredictedValue': prediction, 'Status': 'Success'})
                else:
                    # 4b. Handle bad files - same as training pipeline
                    logger.warning(f"Sample {sample_id} flagged as outlier; copying source files.")
                    for raw_file in file_paths:
                        shutil.copy(raw_file, self.config.bad_prediction_files_dir)
                    prediction_results.append({'sampleId': sample_id, 'PredictedValue': np.nan, 'Status': 'Failed - Outlier'})
            
            except Exception as e:
                logger.error(f"Failed to process sample {sample_id}: {e}")
                import traceback
                logger.debug(f"Traceback for {sample_id}:\n{traceback.format_exc()}")
                prediction_results.append({'sampleId': sample_id, 'PredictedValue': np.nan, 'Status': f'Failed - {e}'})
        
        results_df = pd.DataFrame(prediction_results)
        
        # If using legacy AutoGluon model, perform evaluation with reference data
        if needs_manual_features and hasattr(model, 'evaluate_predictions'):
            logger.info("AutoGluon model detected. Performing evaluation with reference data...")
            try:
                evaluation_results = model.evaluate_predictions(results_df)
                if evaluation_results:
                    # Generate calibration plot
                    plot_path = model.generate_calibration_plot(evaluation_results)
                    if plot_path:
                        logger.info(f"Calibration plot generated: {plot_path}")
                    
                    # Save detailed evaluation results
                    eval_path = model.save_evaluation_results(evaluation_results)
                    if eval_path:
                        logger.info(f"Detailed evaluation results saved: {eval_path}")
                        
            except Exception as e:
                logger.warning(f"Evaluation failed: {e}")
        
        return results_df
    
    def _extract_raw_spectral_features(self, input_data: pd.DataFrame) -> np.ndarray:
        """
        Extract raw spectral intensities from peak regions for raw spectral mode.
        
        This method replicates the logic from RawSpectralTransformer to extract
        intensities directly from the defined peak regions without feature engineering.
        
        Args:
            input_data: DataFrame with 'wavelengths' and 'intensities' columns
            
        Returns:
            Numpy array of raw intensities from peak regions
        """
        try:
            from src.spectral_extraction.raw_spectral_transformer import RawSpectralTransformer
            
            # Create transformer with the same configuration used during training
            transformer = RawSpectralTransformer(
                peak_regions=self.config.all_regions,  # Use all configured peak regions
                enable_minimal_concentration_features=self.config.use_concentration_features
            )
            
            # Apply transformation to extract raw spectral features
            raw_features = transformer.fit_transform(input_data)
            
            logger.debug(f"Extracted {raw_features.shape[1]} raw spectral features from {len(self.config.all_regions)} peak regions")
            return raw_features
            
        except Exception as e:
            logger.error(f"Failed to extract raw spectral features: {e}")
            logger.warning("Falling back to traditional feature engineering")
            # Fallback to traditional feature engineering if raw extraction fails
            return self.feature_pipeline.transform(input_data)
    
    def _build_feature_names_from_pipeline(self):
        """
        Build feature names by manually combining outputs from each pipeline step.
        This is needed because sklearn's Pipeline.get_feature_names_out() doesn't
        always work correctly with custom transformers, especially with concentration features.
        """
        try:
            # Start with base input features
            current_names = ['wavelengths', 'intensities']
            
            # Step 1: SpectralFeatureGenerator (transforms input features to spectral features)
            spectral_step = self.feature_pipeline.named_steps.get('spectral_features')
            if spectral_step and hasattr(spectral_step, 'get_feature_names_out'):
                current_names = list(spectral_step.get_feature_names_out())
                logger.debug(f"After spectral_features: {len(current_names)} features")
            
            # Step 2: ConcentrationRangeFeatures (adds concentration-aware features)
            concentration_step = self.feature_pipeline.named_steps.get('concentration_features')
            if concentration_step and hasattr(concentration_step, 'get_feature_names_out'):
                # ConcentrationRangeFeatures adds features to the existing ones
                concentration_names = concentration_step.get_feature_names_out(current_names)
                current_names = list(concentration_names)
                logger.debug(f"After concentration_features: {len(current_names)} features")
            
            # Steps 3-5: Imputer, Clipper, Scaler (don't change feature names, just pass through)
            # These steps don't modify feature names, they just transform the data
            
            return current_names
            
        except Exception as e:
            logger.debug(f"Failed to build feature names from pipeline: {e}")
            return None