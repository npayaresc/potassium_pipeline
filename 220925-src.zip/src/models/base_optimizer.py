"""Base optimizer class with post-processing calibration and feature selection support."""

import numpy as np
import pandas as pd
import logging
from typing import Tuple, Optional, Union
from src.models.calibration_utils import PrecisionCalibrator
from src.utils.helpers import calculate_regression_metrics
from src.features.feature_selector import SpectralFeatureSelector

logger = logging.getLogger(__name__)


class BaseOptimizer:
    """Base class for model optimizers with post-calibration and feature selection support."""
    
    def __init__(self, config):
        """Initialize base optimizer."""
        self.config = config
        self.post_calibrator = None
        self.post_calibration_config = None
        self.feature_selector = None
        self.selected_features_ = None
        
    def apply_post_calibration(self, y_train, train_pred, y_test, test_pred, 
                              model_name: str = "model") -> Tuple[np.ndarray, np.ndarray]:
        """
        Apply post-processing calibration if enabled in config.
        
        Args:
            y_train: Training targets
            train_pred: Training predictions
            y_test: Test targets  
            test_pred: Test predictions
            model_name: Name of the model for logging
            
        Returns:
            Tuple of (calibrated_train_pred, calibrated_test_pred)
        """
        # Check if post-calibration is enabled
        use_post_calibration = getattr(self.config, 'use_post_calibration', False)
        
        if not use_post_calibration:
            logger.info(f"[{model_name.upper()}] Post-processing calibration is DISABLED")
            return train_pred, test_pred
            
        # Get calibration settings
        calibration_method = getattr(self.config, 'post_calibration_method', 'isotonic')
        target_metric = getattr(self.config, 'post_calibration_target', 'within_20.5')
        
        # Store config for later use
        self.post_calibration_config = {
            'enabled': True,
            'method': calibration_method,
            'target': target_metric
        }
        
        logger.info("=" * 60)
        logger.info(f"[{model_name.upper()}] POST-PROCESSING CALIBRATION ACTIVATED")
        logger.info(f"Method: {calibration_method}")
        logger.info(f"Target metric: {target_metric}")
        logger.info(f"Training samples: {len(y_train)}")
        logger.info(f"Test samples: {len(y_test)}")
        logger.info("=" * 60)
        
        try:
            # Create sample weights based on target metric
            if target_metric == 'within_20.5':
                # Focus on middle range for within_20.5% improvement
                weights = np.ones_like(y_train)
                p25, p75 = np.percentile(y_train, [25, 75])
                mask = (y_train >= p25) & (y_train <= p75)
                weights[mask] = 2.0
                weights = weights / weights.mean()
                logger.info(f"[{model_name.upper()}] Using middle-range weighting (25th-75th percentile)")
                
            elif target_metric == 'mape':
                # Inverse weighting for MAPE improvement
                weights = 1.0 / (y_train + 0.01)
                weights = weights / weights.mean()
                logger.info(f"[{model_name.upper()}] Using inverse-value weighting for MAPE")
                
            else:
                weights = None
                logger.info(f"[{model_name.upper()}] Using uniform weights")
            
            # Fit calibrator on training data
            self.post_calibrator = PrecisionCalibrator(method=calibration_method)
            self.post_calibrator.fit(y_train, train_pred, sample_weight=weights)
            
            # Apply calibration
            train_pred_cal = self.post_calibrator.transform(train_pred)
            test_pred_cal = self.post_calibrator.transform(test_pred)
            
            # Clip to reasonable bounds
            train_pred_cal = np.clip(train_pred_cal, 0, max(y_train.max() * 1.2, 1.0))
            test_pred_cal = np.clip(test_pred_cal, 0, max(y_test.max() * 1.2, 1.0))
            
            # Calculate and log improvements
            original_train_metrics = calculate_regression_metrics(y_train, train_pred)
            original_test_metrics = calculate_regression_metrics(y_test, test_pred)
            calibrated_train_metrics = calculate_regression_metrics(y_train, train_pred_cal)
            calibrated_test_metrics = calculate_regression_metrics(y_test, test_pred_cal)
            
            logger.info(f"[{model_name.upper()}] POST-CALIBRATION RESULTS:")
            logger.info("-" * 50)
            logger.info("TEST SET - Before Post-Cal → After Post-Cal:")
            logger.info(f"  R²: {original_test_metrics['r2']:.4f} → {calibrated_test_metrics['r2']:.4f} "
                       f"({'↑' if calibrated_test_metrics['r2'] > original_test_metrics['r2'] else '↓'} "
                       f"{abs(calibrated_test_metrics['r2'] - original_test_metrics['r2']):.4f})")
            logger.info(f"  RMSE: {original_test_metrics['rmse']:.4f} → {calibrated_test_metrics['rmse']:.4f} "
                       f"({'↓' if calibrated_test_metrics['rmse'] < original_test_metrics['rmse'] else '↑'} "
                       f"{abs(calibrated_test_metrics['rmse'] - original_test_metrics['rmse']):.4f})")
            logger.info(f"  Within 20.5%: {original_test_metrics['within_20.5%']:.2f}% → "
                       f"{calibrated_test_metrics['within_20.5%']:.2f}% "
                       f"({'↑' if calibrated_test_metrics['within_20.5%'] > original_test_metrics['within_20.5%'] else '↓'} "
                       f"{abs(calibrated_test_metrics['within_20.5%'] - original_test_metrics['within_20.5%']):.2f}%)")
            logger.info(f"  MAPE: {original_test_metrics['mape']:.2f}% → {calibrated_test_metrics['mape']:.2f}% "
                       f"({'↓' if calibrated_test_metrics['mape'] < original_test_metrics['mape'] else '↑'} "
                       f"{abs(calibrated_test_metrics['mape'] - original_test_metrics['mape']):.2f}%)")
            
            logger.info("-" * 50)
            logger.info("TRAINING SET - Before Post-Cal → After Post-Cal:")
            logger.info(f"  R²: {original_train_metrics['r2']:.4f} → {calibrated_train_metrics['r2']:.4f}")
            logger.info(f"  RMSE: {original_train_metrics['rmse']:.4f} → {calibrated_train_metrics['rmse']:.4f}")
            logger.info(f"  Within 20.5%: {original_train_metrics['within_20.5%']:.2f}% → "
                       f"{calibrated_train_metrics['within_20.5%']:.2f}%")
            logger.info(f"  MAPE: {original_train_metrics['mape']:.2f}% → {calibrated_train_metrics['mape']:.2f}%")
            logger.info("=" * 60)
            
            return train_pred_cal, test_pred_cal
            
        except Exception as e:
            logger.error(f"[{model_name.upper()}] Post-calibration failed: {e}")
            logger.info(f"[{model_name.upper()}] Continuing without calibration")
            return train_pred, test_pred
    
    def _calculate_sample_weights(self, y):
        """Calculate sample weights based on configuration adapted for magnesium distribution."""
        import numpy as np
        
        method = getattr(self.config, 'sample_weight_method', 'distribution_based')
        
        if method == 'weighted_r2':
            # Enhanced weighted_r2 method adapted for magnesium
            percentiles = np.percentile(y, [25, 75])
            weights = np.ones_like(y, dtype=float)
            
            # Critical deficient range (< 0.15%) - highest priority
            weights[y < 0.15] = 3.5
            # Low range (0.15-0.25%) - high priority
            weights[(y >= 0.15) & (y < 0.25)] = 2.8
            # Bottom quartile (excluding already weighted ranges)
            mask_q1 = (y >= 0.25) & (y <= percentiles[0])
            weights[mask_q1] = 2.2
            # Top quartile
            weights[y >= percentiles[1]] = 1.4
            
            # Normalize weights
            weights = weights / weights.mean()
            logger.info(f"Magnesium-adapted weighted_r2 weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}")
            return weights
            
        elif method == 'legacy':
            # Legacy method adapted for actual magnesium ranges (0.001-3.22%)
            weights = np.ones_like(y, dtype=float)
            for i, val in enumerate(y):
                if val < 0.10: weights[i] = 4.0     # Ultra-low (1.7% of data)
                elif 0.10 <= val < 0.15: weights[i] = 3.5  # Deficient (6.2% of data)
                elif 0.15 <= val < 0.25: weights[i] = 2.8  # Low (6.0% of data)
                elif 0.25 <= val < 0.45: weights[i] = 2.2  # Optimal target (10.0% of data)
                elif 0.45 <= val < 0.60: weights[i] = 1.0  # Adequate (17.4% of data)
                elif 0.60 <= val < 1.00: weights[i] = 0.8  # High (25.2% of data)
                else: weights[i] = 0.6  # Very high (33.6% of data)
            
            # Normalize weights
            weights = weights / weights.mean()
            logger.info(f"Magnesium-adapted legacy weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}")
            return weights
            
        elif method == 'distribution_based':
            # Distribution-based weighting with magnesium-specific frequency correction
            # Use actual magnesium percentiles: [0.167%, 0.475%, 0.723%, 1.200%, 1.630%]
            bins = np.percentile(y, [0, 10, 25, 50, 75, 90, 100])
            bin_indices = np.digitize(y, bins) - 1
            
            weights = np.ones_like(y, dtype=float)
            # Expected frequency for each bin (should be ~16.7% each for 6 bins)
            expected_freq = len(y) / 6
            
            for i in range(len(bins) - 1):
                mask = (bin_indices == i)
                actual_count = mask.sum()
                if actual_count > 0:
                    # Inverse frequency weighting with magnesium adjustment
                    base_weight = expected_freq / actual_count
                    
                    # Apply magnesium-specific multipliers for critical ranges
                    bin_center = (bins[i] + bins[i + 1]) / 2
                    if bin_center < 0.15:
                        multiplier = 1.5  # Boost deficient range
                    elif bin_center < 0.45:
                        multiplier = 1.3  # Boost optimal range
                    elif bin_center > 1.0:
                        multiplier = 0.8  # Reduce excessive range
                    else:
                        multiplier = 1.0
                    
                    weights[mask] = base_weight * multiplier
            
            # Normalize weights
            weights = weights / weights.mean()
            logger.info(f"Potassium-adapted distribution weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}")
            return weights
            
        elif method == 'hybrid':
            # Advanced hybrid approach combining agronomic knowledge with data distribution
            weights = np.ones_like(y, dtype=float)
            
            # Step 1: Agronomic importance weighting
            for i, val in enumerate(y):
                if val < 0.15:
                    weights[i] = 4.0  # Critical deficiency - highest weight
                elif 0.15 <= val < 0.25:
                    weights[i] = 3.2  # Low - high weight
                elif 0.25 <= val < 0.45:
                    weights[i] = 2.5  # Optimal target range - elevated weight
                elif 0.45 <= val < 0.60:
                    weights[i] = 1.2  # Adequate - slight boost
                elif 0.60 <= val < 1.00:
                    weights[i] = 0.9  # High - slight reduction
                else:
                    weights[i] = 0.7  # Excessive - reduced weight
            
            # Step 2: Frequency-based adjustment
            percentiles = np.percentile(y, [10, 25, 50, 75, 90])
            freq_adjustments = np.ones_like(y, dtype=float)
            
            # Bottom 10% (under-represented in training)
            freq_adjustments[y <= percentiles[0]] *= 1.4
            # Top 10% (over-represented)
            freq_adjustments[y >= percentiles[4]] *= 0.8
            
            # Step 3: Combine agronomic and frequency weights
            weights = weights * freq_adjustments
            
            # Normalize weights
            weights = weights / weights.mean()
            logger.info(f"Magnesium-adapted hybrid weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}")
            return weights
            
        else:
            logger.warning(f"Unknown sample weight method: {method}, using uniform weights")
            return np.ones_like(y, dtype=float)
    
    def apply_feature_selection(self, X_train: Union[np.ndarray, pd.DataFrame], 
                               y_train: Union[np.ndarray, pd.Series],
                               X_test: Optional[Union[np.ndarray, pd.DataFrame]] = None,
                               model_name: str = "model") -> Union[Tuple[Union[np.ndarray, pd.DataFrame], Union[np.ndarray, pd.DataFrame]], 
                                                                  Union[np.ndarray, pd.DataFrame]]:
        """
        Apply feature selection if enabled in config.
        
        Args:
            X_train: Training features
            y_train: Training targets
            X_test: Optional test features to transform
            model_name: Name of the model for logging
            
        Returns:
            If X_test provided: Tuple of (X_train_selected, X_test_selected)
            Otherwise: X_train_selected
        """
        if not self.config.use_feature_selection:
            logger.info(f"[{model_name.upper()}] Feature selection is DISABLED")
            if X_test is not None:
                return X_train, X_test
            return X_train
            
        logger.info("=" * 60)
        logger.info(f"[{model_name.upper()}] FEATURE SELECTION ACTIVATED")
        logger.info(f"Method: {self.config.feature_selection_method}")
        logger.info(f"Number of features to select: {self.config.n_features_to_select}")
        logger.info(f"Original feature count: {X_train.shape[1]}")
        logger.info("=" * 60)
        
        try:
            # Check for NaN values before feature selection
            if isinstance(X_train, pd.DataFrame):
                if X_train.isnull().any().any():
                    nan_cols = X_train.columns[X_train.isnull().any()].tolist()
                    logger.warning(f"[{model_name.upper()}] Input contains NaN in columns: {nan_cols[:10]}...")
                    X_train = X_train.fillna(0)
                    logger.info(f"[{model_name.upper()}] Filled NaN values with 0 before feature selection")
            elif isinstance(X_train, np.ndarray) and np.isnan(X_train).any():
                nan_count = np.sum(np.isnan(X_train))
                logger.warning(f"[{model_name.upper()}] Input contains {nan_count} NaN values")
                X_train = np.nan_to_num(X_train, nan=0.0)
                logger.info(f"[{model_name.upper()}] Replaced NaN values with 0 before feature selection")

            # Create and fit feature selector
            self.feature_selector = SpectralFeatureSelector(self.config)
            X_train_selected = self.feature_selector.fit_transform(X_train, y_train)
            
            # Store selected features
            self.selected_features_ = self.feature_selector.selected_features_
            
            # Log results
            logger.info(f"[{model_name.upper()}] Features selected: {X_train_selected.shape[1]}/{X_train.shape[1]}")
            
            # Show top features if available
            feature_scores = self.feature_selector.get_feature_scores()
            if feature_scores is not None and len(feature_scores) < 100:
                top_features = feature_scores[feature_scores['selected']].head(10)
                logger.info(f"[{model_name.upper()}] Top 10 selected features:")
                for idx, row in top_features.iterrows():
                    logger.info(f"  {row['feature']}: {row['score']:.4f}")
            
            logger.info("=" * 60)
            
            # Transform test set if provided
            if X_test is not None:
                X_test_selected = self.feature_selector.transform(X_test)
                return X_train_selected, X_test_selected
            
            return X_train_selected
            
        except Exception as e:
            logger.error(f"[{model_name.upper()}] Feature selection failed: {e}")
            logger.info(f"[{model_name.upper()}] Continuing without feature selection")
            if X_test is not None:
                return X_train, X_test
            return X_train
    
    def _setup_calibration_if_needed(self, model, X_train, y_train):
        """
        Setup calibration if sample weights are being used.
        
        This is a default no-op implementation. Child classes can override
        this method to implement model-specific calibration setup.
        """
        # Default implementation does nothing - child classes can override if needed
        pass
    
    def _apply_calibration(self, predictions):
        """Apply sample-weight calibration if available."""
        if hasattr(self, 'use_calibration') and self.use_calibration and hasattr(self, 'calibrator') and self.calibrator is not None:
            logger.debug("Applying sample-weight calibration to predictions")
            return self.calibrator.transform(predictions)
        return predictions