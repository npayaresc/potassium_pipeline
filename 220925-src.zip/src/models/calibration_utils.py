"""Calibration utilities for improving model predictions."""

import numpy as np
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LinearRegression
import joblib
import logging

logger = logging.getLogger(__name__)


class PrecisionCalibrator:
    """Calibrate predictions to improve within_20.5% and MAPE metrics."""
    
    def __init__(self, method='isotonic'):
        """
        Initialize calibrator.
        
        Args:
            method: 'isotonic', 'linear', or 'piecewise'
        """
        self.method = method
        self.calibrator = None
        self.is_fitted = False
        
    def fit(self, y_true, y_pred, sample_weight=None):
        """
        Fit calibration model.
        
        Args:
            y_true: True target values
            y_pred: Model predictions
            sample_weight: Optional sample weights
        """
        if self.method == 'isotonic':
            self.calibrator = IsotonicRegression(out_of_bounds='clip')
            self.calibrator.fit(y_pred, y_true, sample_weight=sample_weight)
            
        elif self.method == 'linear':
            self.calibrator = LinearRegression()
            self.calibrator.fit(y_pred.reshape(-1, 1), y_true, sample_weight=sample_weight)
            
        elif self.method == 'piecewise':
            # Piecewise linear calibration for different ranges
            self.calibrators = {}
            percentiles = [0, 25, 50, 75, 100]
            self.thresholds = np.percentile(y_true, percentiles)
            
            for i in range(len(percentiles) - 1):
                mask = (y_true >= self.thresholds[i]) & (y_true < self.thresholds[i + 1])
                if mask.sum() > 10:  # Need enough samples
                    calibrator = LinearRegression()
                    weights = sample_weight[mask] if sample_weight is not None else None
                    calibrator.fit(y_pred[mask].reshape(-1, 1), y_true[mask], 
                                 sample_weight=weights)
                    self.calibrators[i] = calibrator
                    
        self.is_fitted = True
        logger.info(f"Calibrator fitted using {self.method} method")
        
    def transform(self, y_pred):
        """
        Apply calibration to predictions.
        
        Args:
            y_pred: Model predictions to calibrate
            
        Returns:
            Calibrated predictions
        """
        if not self.is_fitted:
            raise ValueError("Calibrator must be fitted first")
            
        if self.method in ['isotonic', 'linear']:
            if self.method == 'linear':
                return self.calibrator.predict(y_pred.reshape(-1, 1))
            return self.calibrator.transform(y_pred)
            
        elif self.method == 'piecewise':
            calibrated = np.zeros_like(y_pred)
            for i, calibrator in self.calibrators.items():
                if i < len(self.thresholds) - 1:
                    mask = (y_pred >= self.thresholds[i]) & (y_pred < self.thresholds[i + 1])
                    if mask.sum() > 0:
                        calibrated[mask] = calibrator.predict(y_pred[mask].reshape(-1, 1))
            return calibrated
            
    def fit_transform(self, y_true, y_pred, sample_weight=None):
        """Fit and transform in one step."""
        self.fit(y_true, y_pred, sample_weight)
        return self.transform(y_pred)
        
    def save(self, filepath):
        """Save calibrator to file."""
        joblib.dump(self, filepath)
        logger.info(f"Calibrator saved to {filepath}")
        
    @classmethod
    def load(cls, filepath):
        """Load calibrator from file."""
        return joblib.load(filepath)


def apply_adaptive_calibration(y_true, y_pred, target_metric='within_20.5'):
    """
    Apply adaptive calibration to improve specific metrics.
    
    Args:
        y_true: True values
        y_pred: Predictions
        target_metric: 'within_20.5' or 'mape'
        
    Returns:
        Calibrated predictions
    """
    if target_metric == 'within_20.5':
        # Focus on reducing errors in the middle range
        weights = np.ones_like(y_true)
        # Higher weight for samples in the middle 50%
        p25, p75 = np.percentile(y_true, [25, 75])
        mask = (y_true >= p25) & (y_true <= p75)
        weights[mask] = 2.0
        
    elif target_metric == 'mape':
        # Inverse weighting by true value (MAPE is worse for small values)
        weights = 1.0 / (y_true + 0.01)  # Add small constant to avoid division by zero
        weights = weights / weights.mean()  # Normalize
        
    else:
        weights = None
        
    calibrator = PrecisionCalibrator(method='isotonic')
    return calibrator.fit_transform(y_true, y_pred, sample_weight=weights)