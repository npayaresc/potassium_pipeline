"""
Classification Model Trainer for Potassium Pipeline

This module provides classification training capabilities for predicting
whether potassium levels are above or below a specified threshold (default: 0.3%).
"""

import logging
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional
import joblib

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier

from src.config.pipeline_config import Config
from src.features.feature_engineering import create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.features.feature_selector import SpectralFeatureSelector
from src.utils.classification_helpers import (
    create_binary_labels, calculate_classification_metrics, 
    print_classification_report, calculate_class_weights
)
from src.utils.helpers import OutlierClipper
from src.models.base_optimizer import BaseOptimizer

logger = logging.getLogger(__name__)


class ClassificationTrainer(BaseOptimizer):
    """Trainer for classification models predicting magnesium levels above/below threshold."""
    
    def __init__(self, config: Config, strategy: str = "simple_only", threshold: float = 0.3, 
                 use_parallel_features: bool = False, feature_n_jobs: int = -1):
        """
        Initialize classification trainer.
        
        Args:
            config: Pipeline configuration
            strategy: Feature engineering strategy
            threshold: Classification threshold for magnesium levels
            use_parallel_features: Whether to use parallel processing for feature generation
            feature_n_jobs: Number of parallel jobs for feature generation
        """
        super().__init__(config)
        self.strategy = strategy
        self.threshold = threshold
        self.use_parallel_features = use_parallel_features
        self.feature_n_jobs = feature_n_jobs
        self.models_trained = {}
        self.results = {}
        
        logger.info(f"Initialized Classification Trainer")
        logger.info(f"  Strategy: {strategy}")
        logger.info(f"  Threshold: {threshold}")
        logger.info(f"  Parallel Features: {use_parallel_features}")
        if use_parallel_features:
            logger.info(f"  Feature Jobs: {feature_n_jobs}")
        logger.info(f"  Task: Predict Mg >= {threshold} (High) vs Mg < {threshold} (Low)")
    
    def _get_feature_pipeline(self):
        """Create feature engineering pipeline based on strategy."""
        logger.info(f"[DEBUG] Creating feature pipeline with use_parallel={self.use_parallel_features}, n_jobs={self.feature_n_jobs}")
        logger.info(f"[DEBUG] use_concentration_features={self.config.use_concentration_features}")
        
        if self.config.use_concentration_features:
            pipeline = create_enhanced_feature_pipeline_with_concentration(
                self.config, self.strategy, use_parallel=self.use_parallel_features, 
                n_jobs=self.feature_n_jobs
            )
        else:
            pipeline = create_feature_pipeline(
                self.config, self.strategy, use_parallel=self.use_parallel_features, 
                n_jobs=self.feature_n_jobs
            )
        
        return pipeline
    
    def _get_classification_models(self) -> Dict[str, Any]:
        """Get dictionary of classification models with optimized parameters."""
        models = {}
        
        # Logistic Regression
        models['logistic'] = LogisticRegression(
            random_state=42,
            max_iter=2000,
            class_weight='balanced'
        )
        
        # Random Forest
        models['random_forest'] = RandomForestClassifier(
            n_estimators=200,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            class_weight='balanced',
            random_state=42
        )
        
        # Extra Trees
        models['extratrees'] = ExtraTreesClassifier(
            n_estimators=200,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            class_weight='balanced',
            random_state=42
        )
        
        # SVM
        models['svm'] = SVC(
            kernel='rbf',
            probability=True,  # Enable probability predictions
            class_weight='balanced',
            random_state=42
        )
        
        # Naive Bayes
        models['naive_bayes'] = GaussianNB()
        
        # K-Nearest Neighbors
        models['knn'] = KNeighborsClassifier(
            n_neighbors=5,
            weights='distance'
        )
        
        # XGBoost
        if self.config.use_gpu:
            xgb_params = {
                'objective': 'binary:logistic',
                'eval_metric': 'logloss',
                'tree_method': 'hist',
                'device': 'cuda',
                'random_state': 42,
                'scale_pos_weight': 1  # Will be set dynamically
            }
        else:
            xgb_params = {
                'objective': 'binary:logistic',
                'eval_metric': 'logloss',
                'tree_method': 'hist',
                'random_state': 42,
                'scale_pos_weight': 1  # Will be set dynamically
            }
        
        models['xgboost'] = XGBClassifier(**xgb_params)
        
        # LightGBM
        if self.config.use_gpu:
            lgb_params = {
                'objective': 'binary',
                'metric': 'binary_logloss',
                'device': 'gpu',
                'random_state': 42,
                'verbose': -1,
                'class_weight': 'balanced'
            }
        else:
            lgb_params = {
                'objective': 'binary',
                'metric': 'binary_logloss',
                'random_state': 42,
                'verbose': -1,
                'class_weight': 'balanced'
            }
        
        models['lightgbm'] = LGBMClassifier(**lgb_params)
        
        # CatBoost
        if self.config.use_gpu:
            cat_params = {
                'objective': 'Logloss',
                'task_type': 'GPU',
                'random_state': 42,
                'verbose': False,
                'class_weights': [1, 1]  # Will be set dynamically
            }
        else:
            cat_params = {
                'objective': 'Logloss',
                'task_type': 'CPU',
                'random_state': 42,
                'verbose': False,
                'class_weights': [1, 1]  # Will be set dynamically
            }
        
        models['catboost'] = CatBoostClassifier(**cat_params)
        
        return models
    
    def train_models(self, train_df: pd.DataFrame, test_df: pd.DataFrame) -> Dict[str, Dict]:
        """
        Train all classification models and evaluate performance.
        
        Args:
            train_df: Training DataFrame with continuous magnesium values
            test_df: Test DataFrame with continuous magnesium values
            
        Returns:
            Dictionary of model results
        """
        logger.info("Starting classification model training")
        
        # Extract features and create binary labels
        X_train = train_df.drop(columns=[self.config.target_column, self.config.sample_id_column])
        y_train_continuous = train_df[self.config.target_column]
        y_train_binary = create_binary_labels(y_train_continuous, self.threshold)
        
        X_test = test_df.drop(columns=[self.config.target_column, self.config.sample_id_column])
        y_test_continuous = test_df[self.config.target_column]
        y_test_binary = create_binary_labels(y_test_continuous, self.threshold)
        
        logger.info(f"Training set: {X_train.shape[0]} samples, {X_train.shape[1]} features")
        logger.info(f"Test set: {X_test.shape[0]} samples")
        
        # ===================================================================
        # FEATURE ENGINEERING - Done ONCE for all models
        # ===================================================================
        logger.info("=== Performing feature engineering (ONCE for all models) ===")
        feature_pipeline = self._get_feature_pipeline()
        
        # Fit and transform features ONCE - pass target values if concentration features are enabled
        logger.info("Fitting feature pipeline on training data...")
        if self.config.use_concentration_features or self.config.use_raw_spectral_data:
            logger.info("Using target-aware feature fitting for concentration-dependent features")
            X_train_features = self._fit_transform_with_targets(feature_pipeline, X_train, y_train_continuous)
        else:
            X_train_features = feature_pipeline.fit_transform(X_train)
        logger.info("Transforming test data...")  
        X_test_features = feature_pipeline.transform(X_test)
        
        logger.info(f"Features engineered: {X_train_features.shape[1]} features for {X_train_features.shape[0]} train + {X_test_features.shape[0]} test samples")
        logger.info("=== Feature engineering complete - now training models ===")
        
        # Get classification models
        models = self._get_classification_models()
        
        results = {}
        
        for model_name, base_model in models.items():
            logger.info(f"\n{'='*60}")
            logger.info(f"Training {model_name.upper()}")
            logger.info('='*60)
            
            try:
                # Create pipeline steps WITHOUT feature engineering (already done)
                pipeline_steps = [
                    ('scaler', StandardScaler()),
                    ('imputer', SimpleImputer(strategy='median')),
                    ('clipper', OutlierClipper(percentile=99.0, factor=1.5))
                ]
                
                # Add feature selection if enabled
                if self.config.use_feature_selection:
                    feature_selector = SpectralFeatureSelector(self.config)
                    pipeline_steps.append(('feature_selection', feature_selector))
                    logger.info(f"[CLASSIFICATION] Added feature selection: {self.config.feature_selection_method}")
                
                # Add classifier
                pipeline_steps.append(('classifier', base_model))
                
                # Create pipeline (without feature engineering)
                pipeline = Pipeline(pipeline_steps)
                
                # Calculate class weights if supported
                class_weights = calculate_class_weights(y_train_binary, method='balanced')
                
                # Update model parameters for XGBoost and CatBoost class weights
                base_model = pipeline.named_steps['classifier']
                if model_name == 'xgboost' and hasattr(base_model, 'scale_pos_weight'):
                    # XGBoost uses scale_pos_weight = n_negative / n_positive
                    n_negative = np.sum(y_train_binary == 0)
                    n_positive = np.sum(y_train_binary == 1)
                    if n_positive > 0:
                        base_model.scale_pos_weight = n_negative / n_positive
                        logger.info(f"[XGBOOST] Set scale_pos_weight={base_model.scale_pos_weight:.3f}")
                elif model_name == 'catboost' and hasattr(base_model, 'class_weights'):
                    # CatBoost uses class_weights = [weight_class_0, weight_class_1]  
                    base_model.class_weights = [class_weights[0], class_weights[1]]
                    logger.info(f"[CATBOOST] Set class_weights={base_model.class_weights}")
                
                # Handle class weights for models that support sample_weight
                if hasattr(base_model, 'fit') and 'sample_weight' in base_model.fit.__code__.co_varnames:
                    # Convert class weights to sample weights
                    sample_weights = np.array([class_weights[y] for y in y_train_binary])
                    
                    # Train with sample weights using pre-engineered features
                    pipeline.fit(X_train_features, y_train_binary, classifier__sample_weight=sample_weights)
                    logger.info(f"[{model_name.upper()}] Trained with sample weights")
                else:
                    # Train without sample weights using pre-engineered features
                    pipeline.fit(X_train_features, y_train_binary)
                    logger.info(f"[{model_name.upper()}] Trained without sample weights")
                
                # Make predictions using pre-engineered features
                y_train_pred = pipeline.predict(X_train_features)
                y_test_pred = pipeline.predict(X_test_features)
                
                # Get probabilities if available using pre-engineered features
                y_train_proba = None
                y_test_proba = None
                if hasattr(pipeline, 'predict_proba'):
                    try:
                        y_train_proba = pipeline.predict_proba(X_train_features)[:, 1]
                        y_test_proba = pipeline.predict_proba(X_test_features)[:, 1]
                    except:
                        logger.warning(f"Could not get probabilities for {model_name}")
                
                # Calculate metrics
                train_metrics = calculate_classification_metrics(
                    y_train_binary, y_train_pred, y_train_proba
                )
                test_metrics = calculate_classification_metrics(
                    y_test_binary, y_test_pred, y_test_proba
                )
                
                # Store results
                results[model_name] = {
                    'pipeline': pipeline,
                    'train_metrics': train_metrics,
                    'test_metrics': test_metrics,
                    'y_test_pred': y_test_pred,
                    'y_test_proba': y_test_proba,
                    'threshold': self.threshold
                }
                
                # Log results
                logger.info(f"\n[{model_name.upper()}] RESULTS:")
                logger.info(f"  Train Accuracy: {train_metrics['accuracy']:.4f}")
                logger.info(f"  Test Accuracy:  {test_metrics['accuracy']:.4f}")
                logger.info(f"  Test F1:        {test_metrics['f1']:.4f}")
                logger.info(f"  Test Precision: {test_metrics['precision']:.4f}")
                logger.info(f"  Test Recall:    {test_metrics['recall']:.4f}")
                if test_metrics.get('roc_auc'):
                    logger.info(f"  Test ROC AUC:   {test_metrics['roc_auc']:.4f}")
                
                # Print detailed classification report
                print_classification_report(y_test_binary, y_test_pred, model_name)
                
                # Save complete pipeline (features + model) for inference
                complete_pipeline_steps = [
                    ('features', feature_pipeline),
                    ('scaler', pipeline.named_steps['scaler']),
                    ('imputer', pipeline.named_steps['imputer']),
                    ('clipper', pipeline.named_steps['clipper'])
                ]
                
                # Add feature selection if it was used
                if 'feature_selection' in pipeline.named_steps:
                    complete_pipeline_steps.append(('feature_selection', pipeline.named_steps['feature_selection']))
                
                # Add trained classifier
                complete_pipeline_steps.append(('classifier', pipeline.named_steps['classifier']))
                
                # Create complete pipeline for saving
                complete_pipeline = Pipeline(complete_pipeline_steps)
                
                model_path = self.config.model_dir / f"{model_name}_classification_threshold_{self.threshold}_{self.strategy}.pkl"
                joblib.dump(complete_pipeline, model_path)
                logger.info(f"Model saved to: {model_path}")
                results[model_name]['model_path'] = str(model_path)
                
            except Exception as e:
                logger.error(f"Failed to train {model_name}: {e}")
                import traceback
                logger.debug(f"Traceback for {model_name}:\n{traceback.format_exc()}")
                continue
        
        self.results = results
        return results
    
    def get_best_model(self, metric='f1') -> Tuple[str, Dict]:
        """
        Get the best performing model based on specified metric.
        
        Args:
            metric: Metric to use for selection ('accuracy', 'f1', 'precision', 'recall', 'roc_auc')
            
        Returns:
            Tuple of (model_name, model_results)
        """
        if not self.results:
            raise ValueError("No models have been trained yet")
        
        best_score = -1
        best_model_name = None
        
        for model_name, result in self.results.items():
            score = result['test_metrics'].get(metric)
            if score is not None and score > best_score:
                best_score = score
                best_model_name = model_name
        
        if best_model_name is None:
            raise ValueError(f"No models have valid {metric} scores")
        
        logger.info(f"Best model by {metric}: {best_model_name} (score: {best_score:.4f})")
        return best_model_name, self.results[best_model_name]
    
    def create_comparison_report(self) -> pd.DataFrame:
        """Create a comparison report of all trained models."""
        if not self.results:
            raise ValueError("No models have been trained yet")
        
        comparison_data = []
        
        for model_name, result in self.results.items():
            test_metrics = result['test_metrics']
            comparison_data.append({
                'model': model_name,
                'accuracy': test_metrics['accuracy'],
                'balanced_accuracy': test_metrics['balanced_accuracy'],
                'precision': test_metrics['precision'],
                'recall': test_metrics['recall'],
                'f1': test_metrics['f1'],
                'mcc': test_metrics['mcc'],
                'roc_auc': test_metrics.get('roc_auc', np.nan),
                'n_samples': test_metrics['n_samples'],
                'threshold': self.threshold
            })
        
        df_comparison = pd.DataFrame(comparison_data)
        df_comparison = df_comparison.sort_values('f1', ascending=False)
        
        # Save comparison report
        report_path = self.config.reports_dir / f"classification_comparison_threshold_{self.threshold}_{self.strategy}.csv"
        df_comparison.to_csv(report_path, index=False)
        logger.info(f"Comparison report saved to: {report_path}")

        return df_comparison

    def _fit_transform_with_targets(self, pipeline, X, y):
        """
        Fit and transform a pipeline while passing target values to steps that need them.

        This handles both MinimalConcentrationFeatures (raw spectral mode) and
        ConcentrationRangeFeatures (feature engineering mode) that need target values
        to learn distribution statistics.
        """
        X_current = X.copy()

        for step_name, transformer in pipeline.steps:
            if step_name in ['minimal_concentration', 'concentration_features']:
                # These steps need target values to learn concentration thresholds
                transformer.fit(X_current, y)
                X_current = transformer.transform(X_current)
                logger.debug(f"Step '{step_name}': fitted with targets, shape {X_current.shape}")
            else:
                # Regular fit/transform without targets
                transformer.fit(X_current)
                X_current = transformer.transform(X_current)
                logger.debug(f"Step '{step_name}': fitted without targets, shape {X_current.shape}")

        return X_current