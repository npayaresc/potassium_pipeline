"""
Model Training Module: Defines the training and evaluation process for standard models.
"""
import logging
from pathlib import Path
import joblib
import pandas as pd
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.decomposition import PCA
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import cross_val_predict
from sklearn.linear_model import Ridge, Lasso, ElasticNet
from src.features.dimension_reduction import DimensionReductionFactory
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from .neural_network import NeuralNetworkRegressor
from .custom_autogluon import AutoGluonRegressor

from typing import Optional
from src.config.pipeline_config import Config
from src.features.feature_engineering import create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.features.feature_selector import SpectralFeatureSelector
from src.utils.helpers import calculate_regression_metrics
from src.reporting.reporter import Reporter
from src.models.tuner_objectives_improved import calculate_weighted_r2_objective
from src.data_management.data_manager import DataManager
from src.models.base_optimizer import BaseOptimizer
from src.models.post_calibrated_wrapper import PostCalibratedModelWrapper
from src.models.calibration_utils import PrecisionCalibrator

logger = logging.getLogger(__name__)


class CalibratedModelWrapper:
    """Wrapper that applies calibration to model predictions."""
    
    def __init__(self, model, calibrator):
        self.model = model
        self.calibrator = calibrator
    
    def fit(self, X, y, sample_weight=None, **kwargs):
        """Fit the underlying model."""
        return self.model.fit(X, y, sample_weight=sample_weight, **kwargs)
    
    def predict(self, X):
        """Make predictions and apply calibration."""
        raw_predictions = self.model.predict(X)
        return self.calibrator.transform(raw_predictions)
    
    def __getattr__(self, name):
        """Delegate other attributes to the underlying model."""
        return getattr(self.model, name)

class ModelTrainer(BaseOptimizer):
    """Handles the training and evaluation of regression models."""
    def __init__(self, config: Config, strategy: str, reporter: Reporter, data_manager: Optional[DataManager] = None, use_parallel_features: bool = False, feature_n_jobs: int = -1):
        super().__init__(config)  # Initialize base optimizer
        self.strategy = strategy
        self.reporter = reporter
        self.data_manager = data_manager
        self.use_parallel_features = use_parallel_features
        self.feature_n_jobs = feature_n_jobs
        
        # Calibration for when sample weights are used
        self.calibrators = {}  # Store calibrators per model
        self.use_calibration = False
        
        # Use concentration-aware features if enabled in config
        if config.use_concentration_features:
            logger.info("Using enhanced feature pipeline with concentration-aware features for all models")
            self.feature_pipeline = create_enhanced_feature_pipeline_with_concentration(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
        else:
            logger.info(f"Using standard feature pipeline (parallel={use_parallel_features}, n_jobs={feature_n_jobs})")
            self.feature_pipeline = create_feature_pipeline(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)

    def _get_model(self, model_name: str) -> Pipeline:
        """
        Returns a scikit-learn pipeline for the requested model, using
        parameters defined in the central configuration file.
        """
        base_model_name = model_name.replace("_pca", "")
        
        # Fetch the parameter dictionary from the config
        try:
            params = getattr(self.config.model_params, base_model_name).copy()
        except AttributeError:
            raise ValueError(f"Parameters for model '{base_model_name}' not found in config.")

        # Define the model instance using the fetched parameters
        model_map = {
            "ridge": Ridge, "lasso": Lasso, "elastic_net": ElasticNet,
            "random_forest": RandomForestRegressor, "gradient_boost": GradientBoostingRegressor,
            "xgboost": XGBRegressor, "lightgbm": LGBMRegressor,
            "catboost": CatBoostRegressor, "svr": SVR,
            "extratrees": ExtraTreesRegressor,
            "neural_network": NeuralNetworkRegressor,
            "neural_network_light": NeuralNetworkRegressor,
            "autogluon": AutoGluonRegressor,
            "ridge_pca": Ridge, "lasso_pca": Lasso, "elastic_net_pca": ElasticNet,
            "random_forest_pca": RandomForestRegressor, "gradient_boost_pca": GradientBoostingRegressor,
            "xgboost_pca": XGBRegressor, "lightgbm_pca": LGBMRegressor,
            "catboost_pca": CatBoostRegressor, "svr_pca": SVR,
            "extratrees_pca": ExtraTreesRegressor,
            "neural_network_pca": NeuralNetworkRegressor,
            "neural_network_light_pca": NeuralNetworkRegressor,
            "autogluon_pca": AutoGluonRegressor,
        }
        
        if base_model_name not in model_map:
            raise ValueError(f"Unknown model name: {model_name}")
        
        # Add universal parameters
        if base_model_name not in ["svr", "neural_network", "neural_network_light", "autogluon"]:
             params['random_state'] = self.config.random_state
        if base_model_name == 'lightgbm': params['verbose'] = -1
        if base_model_name == 'catboost': params['verbose'] = 0
        
        # Special handling for neural networks
        if base_model_name in ["neural_network", "neural_network_light"]:
            if 'random_state' not in params:
                params['random_state'] = self.config.random_state
            if self.config.use_gpu:
                params['device'] = 'cuda'
                logger.info(f"GPU enabled for Neural Network (device='cuda')")
        
        # Special handling for AutoGluon
        elif base_model_name == "autogluon":
            from pathlib import Path
            import tempfile
            
            # Create a temporary directory for this AutoGluon model
            temp_dir = Path(tempfile.mkdtemp(prefix="autogluon_"))
            params['model_path'] = temp_dir
            params['config'] = self.config.autogluon  # Use the AutoGluon config
            params['pipeline_config'] = self.config  # Pass full config for compatibility
            logger.info(f"AutoGluon will use temporary directory: {temp_dir}")
        
        # Add GPU parameters when GPU is enabled
        if self.config.use_gpu:
            if base_model_name == 'xgboost':
                params['tree_method'] = 'hist'
                params['device'] = 'cuda:0'  # Use device format instead of separate gpu_id
                logger.info(f"GPU enabled for XGBoost (device='cuda:0')")
            elif base_model_name == 'lightgbm':
                # Use CUDA for NVIDIA GPU (container will have CUDA-enabled LightGBM)
                params['device'] = 'cuda'
                params['gpu_device_id'] = 0
                # Mark that we're attempting GPU mode for fallback handling
                params['_gpu_fallback_enabled'] = True
                logger.info(f"GPU enabled for LightGBM using CUDA (device='cuda')")
            elif base_model_name == 'catboost':
                params['task_type'] = 'GPU'
                params['devices'] = '0'
                logger.info(f"GPU enabled for CatBoost (task_type='GPU')")
        
        # Add parallel processing for tree-based models
        if base_model_name in ['random_forest', 'extratrees']:
            params['n_jobs'] = -1  # Use all available cores
            logger.info(f"Parallel processing enabled for {base_model_name} (n_jobs=-1)")

        # Handle GPU fallback for LightGBM
        if base_model_name == 'lightgbm' and params.get('_gpu_fallback_enabled'):
            # Remove the fallback marker from params
            params_clean = params.copy()
            params_clean.pop('_gpu_fallback_enabled', None)
            
            try:
                # Try to create LightGBM with GPU
                regressor = model_map[base_model_name](**params_clean)
                logger.info("LightGBM successfully initialized with GPU support")
            except Exception as e:
                # If GPU fails, fallback to CPU
                logger.warning(f"LightGBM GPU initialization failed: {e}")
                logger.warning("Falling back to CPU mode for LightGBM")
                
                # Remove GPU-specific parameters and use CPU
                cpu_params = params_clean.copy()
                cpu_params['device'] = 'cpu'
                cpu_params.pop('gpu_device_id', None)
                cpu_params.pop('gpu_platform_id', None)
                
                regressor = model_map[base_model_name](**cpu_params)
                logger.info("LightGBM successfully initialized with CPU fallback")
        else:
            regressor = model_map[base_model_name](**params)
        
        # Construct the final model pipeline with feature selection and dimension reduction if configured
        model_steps = []
        
        # Add feature selection if enabled
        if self.config.use_feature_selection:
            feature_selector = SpectralFeatureSelector(self.config)
            model_steps.append(('feature_selection', feature_selector))
            logger.info(f"[FEATURE SELECTION] Enabled - Method: {self.config.feature_selection_method}, "
                       f"Target features: {self.config.n_features_to_select}")
        
        # Handle backward compatibility with _pca suffix
        if "_pca" in model_name:
            # Legacy PCA support
            pca_components = getattr(self.config.autogluon, 'pca_n_components', 0.90)
            model_steps.append(('dimension_reduction', PCA(n_components=pca_components)))
        elif self.config.use_dimension_reduction:
            # New modular dimension reduction
            reducer = DimensionReductionFactory.create_reducer(
                method=self.config.dimension_reduction.method,
                params=self.config.dimension_reduction.get_params()
            )
            model_steps.append(('dimension_reduction', reducer))
            logger.info(f"Using {self.config.dimension_reduction.method} dimension reduction")
        
        model_steps.append(('regressor', regressor))
        
        return Pipeline(model_steps)
    
    # _calculate_sample_weights method removed - now inherits improved potassium-adapted 
    # implementation from BaseOptimizer with proper agronomic range weighting
    
    def _retry_lightgbm_with_cpu_fallback(self, model_pipeline, X_train, y_train, sample_weights=None, has_dimension_reduction=False, dimension_reducer=None):
        """Retry LightGBM training with CPU fallback if GPU training fails."""
        base_model_name = model_pipeline.named_steps['regressor'].__class__.__name__.lower()
        
        if 'lgbm' not in base_model_name and 'lightgbm' not in base_model_name:
            return False  # Not a LightGBM model
            
        try:
            # Original training already failed, now try with CPU fallback
            regressor = model_pipeline.named_steps['regressor']
            
            # Get original parameters and modify for CPU
            original_params = regressor.get_params()
            cpu_params = original_params.copy()
            cpu_params['device'] = 'cpu'
            cpu_params.pop('gpu_device_id', None)
            cpu_params.pop('gpu_platform_id', None)
            
            # Create new CPU-based LightGBM regressor
            from lightgbm import LGBMRegressor
            cpu_regressor = LGBMRegressor(**cpu_params)
            
            # Replace the regressor in the pipeline
            model_pipeline.steps[-1] = ('regressor', cpu_regressor)
            
            # Retry training with CPU
            logger.warning("Retrying LightGBM training with CPU fallback")
            if sample_weights is not None:
                if has_dimension_reduction and dimension_reducer.__class__.__name__ == 'PLSReducer':
                    model_pipeline.named_steps['regressor'].fit(X_train, y_train, sample_weight=sample_weights)
                else:
                    model_pipeline.fit(X_train, y_train, regressor__sample_weight=sample_weights)
            else:
                if has_dimension_reduction and dimension_reducer.__class__.__name__ == 'PLSReducer':
                    model_pipeline.named_steps['regressor'].fit(X_train, y_train)
                else:
                    model_pipeline.fit(X_train, y_train)
                    
            logger.info("LightGBM CPU fallback training successful")
            return True
            
        except Exception as fallback_error:
            logger.error(f"LightGBM CPU fallback also failed: {fallback_error}")
            return False

    def _model_supports_sample_weight(self, model_name: str) -> bool:
        """
        Check if a model supports sample_weight parameter in fit().
        
        Args:
            model_name: Name of the model
            
        Returns:
            True if model supports sample_weight, False otherwise
        """
        base_model_name = model_name.replace('_pca', '')
        # Most sklearn and tree-based models support sample_weight
        supported_models = {
            'ridge', 'lasso', 'elastic_net', 'random_forest', 'gradient_boost',
            'xgboost', 'lightgbm', 'catboost', 'extratrees', 'neural_network', 
            'neural_network_light'
        }
        # SVR and AutoGluon don't support standard sklearn sample_weight parameter
        unsupported_models = {'svr', 'autogluon'}
        
        return base_model_name in supported_models

    def train_and_evaluate(self, train_df: pd.DataFrame, test_df: pd.DataFrame):
        """Trains all specified models and evaluates their performance."""
        X_train_raw = train_df.drop(columns=[self.config.target_column])
        y_train = train_df[self.config.target_column]
        X_test_raw = test_df.drop(columns=[self.config.target_column])
        y_test = test_df[self.config.target_column]
        logger.info(f"Starting training for feature strategy: {self.strategy}")
        
        # We need sample_id from the test set for detailed prediction saving
        test_sample_ids = X_test_raw[self.config.sample_id_column]

        # Fit feature pipeline on data without sample_id
        # Pass target values if using concentration features OR raw spectral mode for target-aware feature creation
        X_train_features = X_train_raw.drop(columns=[self.config.sample_id_column])
        if self.config.use_concentration_features:
            logger.info("Fitting enhanced feature pipeline with target concentrations for concentration-aware features")
            # Use the same target-aware fitting method as AutoGluon
            X_train = self._fit_transform_with_targets(self.feature_pipeline, X_train_features, y_train)
        elif self.config.use_raw_spectral_data:
            logger.info("Fitting raw spectral feature pipeline with target concentrations for minimal concentration features")
            # Use the same target-aware fitting method as AutoGluon
            X_train = self._fit_transform_with_targets(self.feature_pipeline, X_train_features, y_train)
        else:
            self.feature_pipeline.fit(X_train_features)
            X_train = self.feature_pipeline.transform(X_train_features)
            
        X_test = self.feature_pipeline.transform(X_test_raw.drop(columns=[self.config.sample_id_column]))

        # Calculate sample weights if enabled
        sample_weights = None
        if self.config.use_sample_weights:
            sample_weights = self._calculate_sample_weights(y_train)
            logger.info(f"Sample weights enabled using method: {self.config.sample_weight_method}")
        else:
            logger.info("Sample weights disabled")

        for model_name in self.config.models_to_train:
            logger.info(f"--- Training model: {model_name} ---")
            model_pipeline = self._get_model(model_name)
            
            # Log initial feature count
            original_features = X_train.shape[1]
            logger.info(f"Original feature count: {original_features}")
            
            # Check for dimension reduction in pipeline and special handling for PLS
            has_dimension_reduction = False
            dimension_reducer = None
            for name, step in model_pipeline.steps:
                if name == 'dimension_reduction':
                    has_dimension_reduction = True
                    dimension_reducer = step
                    break
            
            # For PLS, we need to fit with y values
            if has_dimension_reduction and hasattr(dimension_reducer, '__class__') and \
               dimension_reducer.__class__.__name__ == 'PLSReducer':
                logger.info("Fitting PLS dimension reduction with target values")
                # Fit PLS separately with y values
                dimension_reducer.fit(X_train, y_train)
                X_train_reduced = dimension_reducer.transform(X_train)
                X_test_reduced = dimension_reducer.transform(X_test)
                
                # Update the data for subsequent model fitting
                X_train_for_model = X_train_reduced
                X_test_for_model = X_test_reduced
                
                # Log dimension reduction
                logger.info(f"Features after {dimension_reducer.__class__.__name__}: "
                           f"{X_train.shape[1]} → {X_train_reduced.shape[1]}")
            else:
                X_train_for_model = X_train
                X_test_for_model = X_test
            
            # Fit model with or without sample weights
            base_model_name = model_name.replace('_pca', '')
            
            # Check if neural network is configured to use sample weights
            if base_model_name in ["neural_network", "neural_network_light"]:
                nn_params = getattr(self.config.model_params, base_model_name)
                nn_use_sample_weights = nn_params.get('use_sample_weights', False)
                
                if nn_use_sample_weights and self.config.use_sample_weights and sample_weights is not None:
                    logger.info(f"Training {model_name} with both sample weights and custom loss weighting")
                    try:
                        if has_dimension_reduction and dimension_reducer.__class__.__name__ == 'PLSReducer':
                            # Use reduced data for PLS
                            model_pipeline.named_steps['regressor'].fit(X_train_for_model, y_train, sample_weight=sample_weights)
                        else:
                            model_pipeline.fit(X_train_for_model, y_train, regressor__sample_weight=sample_weights)
                    except Exception as e:
                        # Check if it's a LightGBM GPU error and retry with CPU fallback
                        if 'lightgbm' in model_name.lower() and ('CUDA' in str(e) or 'gpu' in str(e).lower()):
                            logger.warning(f"LightGBM GPU training failed: {e}")
                            if not self._retry_lightgbm_with_cpu_fallback(model_pipeline, X_train_for_model, y_train, 
                                                                         sample_weights, has_dimension_reduction, dimension_reducer):
                                raise e
                        else:
                            raise e
                else:
                    logger.info(f"Training {model_name} with custom loss weighting only (sample weights disabled)")
                    try:
                        if has_dimension_reduction and dimension_reducer.__class__.__name__ == 'PLSReducer':
                            # Use reduced data for PLS
                            model_pipeline.named_steps['regressor'].fit(X_train_for_model, y_train)
                        else:
                            model_pipeline.fit(X_train_for_model, y_train)
                    except Exception as e:
                        # Check if it's a LightGBM GPU error and retry with CPU fallback
                        if 'lightgbm' in model_name.lower() and ('CUDA' in str(e) or 'gpu' in str(e).lower()):
                            logger.warning(f"LightGBM GPU training failed: {e}")
                            if not self._retry_lightgbm_with_cpu_fallback(model_pipeline, X_train_for_model, y_train, 
                                                                         None, has_dimension_reduction, dimension_reducer):
                                raise e
                        else:
                            raise e
            elif base_model_name == "autogluon":
                # AutoGluon requires DataFrame input and handles sample weights internally
                logger.info(f"Training {model_name} - AutoGluon handles sample weighting internally")
                
                # Convert to DataFrame for AutoGluon
                X_train_df = pd.DataFrame(X_train_for_model, columns=[f"feature_{i}" for i in range(X_train_for_model.shape[1])])
                X_train_df[self.config.target_column] = y_train.values
                
                # AutoGluon fit method expects (X, y) where y is the target column name
                if has_dimension_reduction and dimension_reducer.__class__.__name__ == 'PLSReducer':
                    # Use reduced data for PLS
                    model_pipeline.named_steps['regressor'].fit(X_train_df, self.config.target_column)
                else:
                    model_pipeline.fit(X_train_df, self.config.target_column)
            elif (self.config.use_sample_weights and 
                  sample_weights is not None and 
                  self._model_supports_sample_weight(model_name)):
                
                logger.info(f"Training {model_name} with sample weights")
                try:
                    if has_dimension_reduction and dimension_reducer.__class__.__name__ == 'PLSReducer':
                        # Use reduced data for PLS
                        model_pipeline.named_steps['regressor'].fit(X_train_for_model, y_train, sample_weight=sample_weights)
                    else:
                        model_pipeline.fit(X_train_for_model, y_train, regressor__sample_weight=sample_weights)
                except Exception as e:
                    # Check if it's a LightGBM GPU error and retry with CPU fallback
                    if 'lightgbm' in model_name.lower() and ('CUDA' in str(e) or 'gpu' in str(e).lower()):
                        logger.warning(f"LightGBM GPU training failed: {e}")
                        if not self._retry_lightgbm_with_cpu_fallback(model_pipeline, X_train_for_model, y_train, 
                                                                     sample_weights, has_dimension_reduction, dimension_reducer):
                            raise e
                    else:
                        raise e
            else:
                if self.config.use_sample_weights and not self._model_supports_sample_weight(model_name):
                    logger.warning(f"Model {model_name} does not support sample weights, training without weights")
                try:
                    if has_dimension_reduction and dimension_reducer.__class__.__name__ == 'PLSReducer':
                        # Use reduced data for PLS
                        model_pipeline.named_steps['regressor'].fit(X_train_for_model, y_train)
                    else:
                        model_pipeline.fit(X_train_for_model, y_train)
                except Exception as e:
                    # Check if it's a LightGBM GPU error and retry with CPU fallback
                    if 'lightgbm' in model_name.lower() and ('CUDA' in str(e) or 'gpu' in str(e).lower()):
                        logger.warning(f"LightGBM GPU training failed: {e}")
                        if not self._retry_lightgbm_with_cpu_fallback(model_pipeline, X_train_for_model, y_train, 
                                                                     None, has_dimension_reduction, dimension_reducer):
                            raise e
                    else:
                        raise e
            
            # Log dimension reduction if applied
            reduced_features = None
            if "_pca" in model_name and 'pca' in model_pipeline.named_steps:
                # Legacy PCA support
                pca_component = model_pipeline.named_steps['pca']
                reduced_features = pca_component.n_components_
                variance_retained = pca_component.explained_variance_ratio_.sum()
                logger.info(f"Legacy PCA applied: {original_features} → {reduced_features} features "
                           f"(retained {variance_retained:.1%} variance)")
            elif has_dimension_reduction:
                # New modular dimension reduction
                if hasattr(dimension_reducer, '__class__'):
                    method_name = dimension_reducer.__class__.__name__.replace('Reducer', '')
                    reduced_features = dimension_reducer.get_n_components()
                    logger.info(f"{method_name} applied: {original_features} → {reduced_features} features")
                    
            # Update neural network input_dim if dimension reduction was applied
            if reduced_features and base_model_name in ["neural_network", "neural_network_light"]:
                regressor = model_pipeline.named_steps['regressor']
                if hasattr(regressor, 'input_dim'):
                    logger.info(f"Neural network input dimension adjusted from {regressor.input_dim} to {reduced_features}")
                    regressor.input_dim = reduced_features

            # Setup calibration if sample weights are used
            self._setup_calibration_if_needed(model_name, model_pipeline, X_train_for_model, y_train, 
                                            has_dimension_reduction, dimension_reducer)

            # Make predictions for both train and test data
            if has_dimension_reduction and dimension_reducer.__class__.__name__ == 'PLSReducer':
                y_train_pred_raw = model_pipeline.named_steps['regressor'].predict(X_train_for_model)
                y_test_pred_raw = model_pipeline.named_steps['regressor'].predict(X_test_for_model)
            else:
                y_train_pred_raw = model_pipeline.predict(X_train_for_model)
                y_test_pred_raw = model_pipeline.predict(X_test_for_model)
            
            # Apply calibration if available
            # Skip sample-weight calibration (use only post-calibration)
            y_train_pred = y_train_pred_raw
            y_test_pred = y_test_pred_raw
            
            # Apply post-processing calibration from base class
            y_train_pred, y_pred = self.apply_post_calibration(
                y_train, y_train_pred, y_test, y_test_pred, model_name=model_name.upper()
            )
            
            metrics = calculate_regression_metrics(y_test, y_pred)
            logger.info(f"Evaluation metrics for {model_name}: {metrics}")
            
            params = model_pipeline.named_steps['regressor'].get_params()
            
            # Use the reporter to add results
            self.reporter.add_run_results(self.strategy, model_name, metrics, params)
            
            # Use the reporter to save detailed predictions and plots
            predictions_df = self.reporter.save_prediction_results(
                y_test, y_pred, test_sample_ids, self.strategy, model_name
            )
            self.reporter.generate_calibration_plot(predictions_df, self.strategy, model_name)
            
            # Handle saving differently for neural networks vs other models
            base_model_name = model_name.replace('_pca', '')
            if base_model_name in ["neural_network", "neural_network_light"]:
                # For neural networks, use their custom save method with optional calibration
                if model_name in self.calibrators:
                    calibrated_model = CalibratedModelWrapper(model_pipeline, self.calibrators[model_name])
                    self.save_neural_network_pipeline(self.feature_pipeline, calibrated_model, model_name, with_calibration=True)
                    logger.info(f"Included calibration in neural network pipeline for {model_name}")
                else:
                    self.save_neural_network_pipeline(self.feature_pipeline, model_pipeline, model_name)
            else:
                # For other models, use standard pipeline saving with optional calibration
                if model_name in self.calibrators:
                    # Create calibrated model wrapper
                    calibrated_model = CalibratedModelWrapper(model_pipeline, self.calibrators[model_name])
                    full_pipeline = Pipeline([
                        ('features', self.feature_pipeline),
                        ('model', calibrated_model)
                    ])
                    logger.info(f"Included calibration in saved pipeline for {model_name}")
                else:
                    full_pipeline = Pipeline([
                        ('features', self.feature_pipeline),
                        ('model', model_pipeline)
                    ])
                self.save_pipeline(full_pipeline, model_name)

    def save_pipeline(self, pipeline: Pipeline, model_name: str):
        """Saves the complete scikit-learn pipeline."""
        from main import get_display_strategy_name
        display_strategy = get_display_strategy_name(self.strategy, getattr(self.config, 'use_raw_spectral_data', False))
        filename = f"{display_strategy}_{model_name}_{self.config.run_timestamp}.pkl"
        save_path = Path(self.config.model_dir) / filename
        
        # Save the pipeline
        joblib.dump(pipeline, save_path)
        logger.info(f"Pipeline for {model_name} saved to: {save_path}")
        
        # If wavelength standardization is enabled, save the wavelength range
        if self.config.enable_wavelength_standardization and self.data_manager and self.data_manager._global_wavelength_range:
            # Use the global wavelength range from the training DataManager
            global_range = self.data_manager._global_wavelength_range
            
            # Save wavelength range metadata alongside the model
            metadata_path = save_path.with_suffix('.wavelength_metadata.json')
            import json
            metadata = {
                'wavelength_standardization_enabled': True,
                'global_wavelength_range': {
                    'min': global_range[0],
                    'max': global_range[1]
                },
                'wavelength_resolution': self.config.wavelength_resolution,
                'interpolation_method': self.config.wavelength_interpolation_method
            }
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            logger.info(f"Wavelength metadata saved to: {metadata_path}")

    def _fit_transform_with_targets(self, pipeline, X, y):
        """
        Fit and transform a pipeline while passing target values to steps that need them.

        This handles both MinimalConcentrationFeatures (raw spectral mode) and
        ConcentrationRangeFeatures (feature engineering mode) that need target values
        to learn distribution statistics.
        """
        X_current = X.copy()

        for step_name, transformer in pipeline.steps:
            if step_name in ['minimal_concentration', 'concentration_features']:
                # These steps need target values to learn concentration thresholds
                transformer.fit(X_current, y)
                X_current = transformer.transform(X_current)
                logger.debug(f"Step '{step_name}': fitted with targets, shape {X_current.shape}")
            else:
                # Regular fit/transform without targets
                transformer.fit(X_current)
                X_current = transformer.transform(X_current)
                logger.debug(f"Step '{step_name}': fitted without targets, shape {X_current.shape}")

        return X_current
    
    def save_neural_network_pipeline(self, feature_pipeline: Pipeline, model_pipeline: Pipeline, model_name: str, with_calibration: bool = False):
        """Saves neural network with custom serialization to handle PyTorch components."""
        from main import get_display_strategy_name
        display_strategy = get_display_strategy_name(self.strategy, getattr(self.config, 'use_raw_spectral_data', False))
        filename = f"{display_strategy}_{model_name}_{self.config.run_timestamp}.pkl"
        save_path = Path(self.config.model_dir) / filename
        
        # Extract the neural network regressor from the pipeline
        nn_regressor = model_pipeline.named_steps['regressor']
        
        # Create a custom pipeline that handles neural network loading
        from src.models.neural_network_pipeline import NeuralNetworkPipeline
        
        # Create a deployable pipeline that can handle neural network loading
        deployable_pipeline = NeuralNetworkPipeline(
            feature_pipeline=feature_pipeline,
            neural_network=nn_regressor
        )
        
        # Save using joblib (this will work because we handle PyTorch serialization internally)
        joblib.dump(deployable_pipeline, save_path)
        logger.info(f"Neural network pipeline for {model_name} saved to: {save_path}")
        
        # If wavelength standardization is enabled, save the wavelength range
        if self.config.enable_wavelength_standardization and self.data_manager and self.data_manager._global_wavelength_range:
            # Use the global wavelength range from the training DataManager
            global_range = self.data_manager._global_wavelength_range
            
            # Save wavelength range metadata alongside the model
            metadata_path = save_path.with_suffix('.wavelength_metadata.json')
            import json
            metadata = {
                'wavelength_standardization_enabled': True,
                'global_wavelength_range': {
                    'min': global_range[0],
                    'max': global_range[1]
                },
                'wavelength_resolution': self.config.wavelength_resolution,
                'interpolation_method': self.config.wavelength_interpolation_method
            }
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            logger.info(f"Wavelength metadata saved to: {metadata_path}")

    def _setup_calibration_if_needed(self, model_name: str, model_pipeline: Pipeline, 
                                    X_train: np.ndarray, y_train: pd.Series, 
                                    has_dimension_reduction: bool, dimension_reducer):
        """
        Setup calibration if sample weights are being used.
        Uses cross-validation to avoid overfitting the calibrator.
        """
        # Check if sample weights are enabled
        if not self.config.use_sample_weights:
            return
            
        logger.info(f"Sample weights detected - setting up prediction calibration for {model_name}")
        
        try:
            # Create a temporary model for cross-validation
            if has_dimension_reduction and dimension_reducer.__class__.__name__ == "PLSReducer":
                # For PLS, use the regressor directly
                cv_model = model_pipeline.named_steps["regressor"]
            else:
                cv_model = model_pipeline
            
            # Generate cross-validation predictions
            logger.info(f"Generating cross-validation predictions for calibration of {model_name}...")
            cv_predictions = cross_val_predict(cv_model, X_train, y_train, cv=5)
            
            # Fit isotonic regression calibrator
            calibrator = IsotonicRegression(out_of_bounds="clip")
            calibrator.fit(cv_predictions, y_train)
            self.calibrators[model_name] = calibrator
            self.use_calibration = True
            
            # Log calibration diagnostics
            calibrated_cv_preds = calibrator.transform(cv_predictions)
            original_bias = np.mean(cv_predictions - y_train)
            calibrated_bias = np.mean(calibrated_cv_preds - y_train)
            
            logger.info(f"Calibration setup complete for {model_name}:")
            logger.info(f"  Original bias: {original_bias:.4f}")
            logger.info(f"  Calibrated bias: {calibrated_bias:.4f}")
            logger.info(f"  Bias improvement: {abs(original_bias) - abs(calibrated_bias):+.4f}")
            
        except Exception as e:
            logger.warning(f"Failed to setup calibration for {model_name}: {e}")
            logger.info(f"Continuing without calibration for {model_name}")
    
    def _apply_calibration(self, model_name: str, predictions: np.ndarray) -> np.ndarray:
        """Apply calibration to predictions if calibrator is available."""
        if model_name in self.calibrators:
            logger.debug(f"Applying calibration to {model_name} predictions")
            return self.calibrators[model_name].transform(predictions)
        return predictions

