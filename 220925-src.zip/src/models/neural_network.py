"""
Neural Network model for magnesium concentration prediction.

This module implements a PyTorch neural network specifically designed for
spectroscopic regression tasks with proper regularization for small datasets.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset
import logging
from typing import Optional, Tuple, Dict, Any
import joblib
import os

logger = logging.getLogger(__name__)


def get_activation_function(activation: str):
    """Get activation function by name."""
    activations = {
        'relu': nn.ReLU(),
        'leaky_relu': nn.LeakyReLU(),
        'elu': nn.ELU(),
        'gelu': nn.GELU(),
        'tanh': nn.Tanh(),
        'sigmoid': nn.Sigmoid()
    }
    return activations.get(activation, nn.ReLU())


class SafeBatchNorm1d(nn.Module):
    """Batch normalization that handles single-sample batches gracefully."""
    
    def __init__(self, num_features, eps=1e-5, momentum=0.1):
        super().__init__()
        self.num_features = num_features
        self.eps = eps
        self.momentum = momentum
        
        # Parameters
        self.weight = nn.Parameter(torch.ones(num_features))
        self.bias = nn.Parameter(torch.zeros(num_features))
        
        # Running statistics (not used during training with single samples)
        self.register_buffer('running_mean', torch.zeros(num_features))
        self.register_buffer('running_var', torch.ones(num_features))
    
    def forward(self, x):
        if self.training and x.size(0) == 1:
            # For single samples during training, just apply scale and bias without normalization
            return x * self.weight + self.bias
        elif self.training and x.size(0) > 1:
            # Normal batch normalization for multiple samples
            mean = x.mean(dim=0)
            var = x.var(dim=0, unbiased=False)
            x_norm = (x - mean) / torch.sqrt(var + self.eps)
            return x_norm * self.weight + self.bias
        else:
            # Use running statistics during evaluation
            x_norm = (x - self.running_mean) / torch.sqrt(self.running_var + self.eps)
            return x_norm * self.weight + self.bias


class DynamicNN(nn.Module):
    """Dynamic neural network architecture with configurable layers and activations."""
    
    def __init__(self, input_dim: int, hidden_layers: Tuple[int, ...], dropout_rate: float = 0.3, 
                 activation: str = 'relu', use_batch_norm: bool = True):
        super().__init__()
        
        # Validate inputs
        if isinstance(hidden_layers, str):
            raise ValueError(f"hidden_layers must be a tuple of integers, got string: {hidden_layers}")
        if not isinstance(hidden_layers, (tuple, list)):
            raise ValueError(f"hidden_layers must be a tuple or list, got: {type(hidden_layers)}")
        if not all(isinstance(x, int) for x in hidden_layers):
            raise ValueError(f"All hidden_layers values must be integers, got: {hidden_layers}")
        
        layers = []
        prev_dim = input_dim
        
        for i, layer_dim in enumerate(hidden_layers):
            # Linear layer
            layers.append(nn.Linear(prev_dim, layer_dim))
            
            # Batch normalization (except for last layer)
            # Use SafeBatchNorm1d to handle single-sample batches during cross-validation
            if use_batch_norm and i < len(hidden_layers) - 1:
                layers.append(SafeBatchNorm1d(layer_dim))
            
            # Activation
            layers.append(get_activation_function(activation))
            
            # Dropout (with decreasing rate for deeper layers)
            dropout_factor = max(0.5, 1 - i * 0.1)
            layers.append(nn.Dropout(dropout_rate * dropout_factor))
            
            prev_dim = layer_dim
        
        # Output layer
        layers.append(nn.Linear(prev_dim, 1))
        
        self.model = nn.Sequential(*layers)
        
    def forward(self, x):
        return self.model(x)


class PotassiumNN(nn.Module):
    """Full neural network architecture for potassium prediction with dynamic sizing."""
    
    def __init__(self, input_dim: int = 98, dropout_rate: float = 0.4):
        super().__init__()
        
        # Dynamic architecture based on input dimension
        # Architecture decision ranges:
        # - Small features (<50): 2-3 layers, compression ratio 0.5-0.8
        # - Medium features (50-150): 3-4 layers, compression ratio 0.6-0.8
        # - Large features (150-300): 4-5 layers, compression ratio 0.5-0.7
        # - Very large features (>300): 4-5 layers, compression ratio 0.3-0.5
        
        if input_dim < 50:
            # Small feature space: simple architecture
            hidden1 = max(32, int(input_dim * 0.8))
            hidden2 = max(16, int(hidden1 * 0.5))
            layers = [
                nn.Linear(input_dim, hidden1),
                SafeBatchNorm1d(hidden1),
                nn.ReLU(),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden1, hidden2),
                SafeBatchNorm1d(hidden2),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.7),
                
                nn.Linear(hidden2, 1)
            ]
        elif input_dim < 150:
            # Medium feature space: standard architecture
            hidden1 = min(128, max(64, int(input_dim * 0.7)))
            hidden2 = int(hidden1 * 0.5)
            hidden3 = max(16, int(hidden2 * 0.5))
            layers = [
                nn.Linear(input_dim, hidden1),
                SafeBatchNorm1d(hidden1),
                nn.ReLU(),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden1, hidden2),
                SafeBatchNorm1d(hidden2),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.8),
                
                nn.Linear(hidden2, hidden3),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.6),
                
                nn.Linear(hidden3, 1)
            ]
        elif input_dim < 300:
            # Large feature space: deeper architecture
            hidden1 = min(256, max(128, int(input_dim * 0.6)))
            hidden2 = int(hidden1 * 0.5)
            hidden3 = int(hidden2 * 0.5)
            hidden4 = max(16, int(hidden3 * 0.5))
            layers = [
                nn.Linear(input_dim, hidden1),
                SafeBatchNorm1d(hidden1),
                nn.ReLU(),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden1, hidden2),
                SafeBatchNorm1d(hidden2),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.9),
                
                nn.Linear(hidden2, hidden3),
                SafeBatchNorm1d(hidden3),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.7),
                
                nn.Linear(hidden3, hidden4),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.5),
                
                nn.Linear(hidden4, 1)
            ]
        else:
            # Very large feature space: aggressive compression
            hidden1 = min(512, max(256, int(input_dim * 0.4)))
            hidden2 = int(hidden1 * 0.5)
            hidden3 = int(hidden2 * 0.5)
            hidden4 = max(32, int(hidden3 * 0.5))
            layers = [
                nn.Linear(input_dim, hidden1),
                SafeBatchNorm1d(hidden1),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 1.2),  # Higher dropout for very wide layers
                
                nn.Linear(hidden1, hidden2),
                SafeBatchNorm1d(hidden2),
                nn.ReLU(),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden2, hidden3),
                SafeBatchNorm1d(hidden3),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.8),
                
                nn.Linear(hidden3, hidden4),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.6),
                
                nn.Linear(hidden4, 1)
            ]
        
        self.model = nn.Sequential(*layers)
        
        # Log architecture for debugging
        logger.info(f"PotassiumNN architecture for {input_dim} features: {[layer for layer in layers if isinstance(layer, nn.Linear)]}")
        
    def forward(self, x):
        return self.model(x).squeeze()


class LightPotassiumNN(nn.Module):
    """Lightweight neural network with dynamic sizing optimized for spectroscopic datasets."""
    
    def __init__(self, input_dim: int = 98, dropout_rate: float = 0.5):
        super().__init__()
        
        # Dynamic lightweight architecture based on input dimension
        # Keeps it simple but scales appropriately
        if input_dim < 50:
            hidden1 = max(16, int(input_dim * 0.6))
            hidden2 = max(8, int(hidden1 * 0.5))
            layers = [
                nn.Linear(input_dim, hidden1),
                SafeBatchNorm1d(hidden1),
                nn.ReLU(),
                nn.Dropout(dropout_rate),
                nn.Linear(hidden1, 1)
            ]
        elif input_dim < 150:
            hidden1 = min(64, max(24, int(input_dim * 0.4)))
            hidden2 = max(12, int(hidden1 * 0.5))
            layers = [
                nn.Linear(input_dim, hidden1),
                SafeBatchNorm1d(hidden1),
                nn.ReLU(),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden1, hidden2),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.6),
                
                nn.Linear(hidden2, 1)
            ]
        else:  # input_dim >= 150
            hidden1 = min(96, max(32, int(input_dim * 0.3)))
            hidden2 = max(16, int(hidden1 * 0.5))
            hidden3 = max(8, int(hidden2 * 0.5))
            layers = [
                nn.Linear(input_dim, hidden1),
                SafeBatchNorm1d(hidden1),
                nn.ReLU(),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden1, hidden2),
                SafeBatchNorm1d(hidden2),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.7),
                
                nn.Linear(hidden2, hidden3),
                nn.ReLU(),
                nn.Dropout(dropout_rate * 0.5),
                
                nn.Linear(hidden3, 1)
            ]
        
        self.model = nn.Sequential(*layers)
        
        # Log architecture for debugging
        logger.info(f"LightPotassiumNN architecture for {input_dim} features: {[layer for layer in layers if isinstance(layer, nn.Linear)]}")
        
    def forward(self, x):
        return self.model(x).squeeze()


class AutoGluonOptimizedNN(nn.Module):
    """Dynamic neural network architecture based on AutoGluon's best configurations."""
    
    def __init__(self, input_dim: int = 98, dropout_rate: float = 0.237138):
        super().__init__()
        
        # Dynamic architecture inspired by AutoGluon's best practices
        # Maintains the proven 4-layer depth but scales width dynamically
        if input_dim < 50:
            # Small input: Conservative scaling
            hidden_size = max(64, int(input_dim * 1.5))
            layers = [
                SafeBatchNorm1d(input_dim),
                nn.Linear(input_dim, hidden_size),
                nn.ReLU(),
                SafeBatchNorm1d(hidden_size),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden_size, hidden_size//2),
                nn.ReLU(),
                SafeBatchNorm1d(hidden_size//2),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden_size//2, 1)
            ]
        elif input_dim < 150:
            # Medium input: Balanced scaling (close to original 200 for ~98 features)
            hidden_size = min(256, max(128, int(input_dim * 1.8)))
            layers = [
                SafeBatchNorm1d(input_dim),
                
                nn.Linear(input_dim, hidden_size),
                nn.ReLU(),
                SafeBatchNorm1d(hidden_size),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden_size, hidden_size),
                nn.ReLU(),
                SafeBatchNorm1d(hidden_size),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden_size, hidden_size//2),
                nn.ReLU(),
                SafeBatchNorm1d(hidden_size//2),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden_size//2, 1)
            ]
        else:
            # Large input: Full 4-layer architecture with larger hidden sizes
            hidden_size = min(512, max(200, int(input_dim * 1.2)))
            layers = [
                SafeBatchNorm1d(input_dim),
                
                nn.Linear(input_dim, hidden_size),
                nn.ReLU(),
                SafeBatchNorm1d(hidden_size),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden_size, hidden_size),
                nn.ReLU(),
                SafeBatchNorm1d(hidden_size),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden_size, hidden_size),
                nn.ReLU(),
                SafeBatchNorm1d(hidden_size),
                nn.Dropout(dropout_rate),
                
                nn.Linear(hidden_size, hidden_size//2),
                nn.ReLU(),
                
                nn.Linear(hidden_size//2, 1)
            ]
        
        self.model = nn.Sequential(*layers)
        
        # Log architecture for debugging
        logger.info(f"AutoGluonOptimizedNN architecture for {input_dim} features: {[layer for layer in layers if isinstance(layer, nn.Linear)]}")
        
    def forward(self, x):
        return self.model(x).squeeze()


class PotassiumLoss(nn.Module):
    """Custom loss function with concentration-based weighting."""
    
    def __init__(self, alpha: float = 0.1, range_focused: bool = False, target_range: tuple = (0.2, 0.5)):
        super().__init__()
        self.alpha = alpha
        self.range_focused = range_focused
        self.target_min, self.target_max = target_range
        self._batch_count = 0
        
    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        # Base MSE loss
        mse = (pred - target) ** 2
        
        if self.range_focused:
            # Range specialist mode: focus heavily on 0.2-0.5% range
            in_target_range = (target >= self.target_min) & (target <= self.target_max)
            near_boundaries = ((target >= (self.target_min - 0.05)) & (target <= (self.target_min + 0.05))) | \
                             ((target >= (self.target_max - 0.05)) & (target <= (self.target_max + 0.05)))
            
            weights = torch.where(
                in_target_range,
                torch.tensor(3.0, device=target.device),  # Heavy weight for target range
                torch.where(
                    near_boundaries,
                    torch.tensor(2.0, device=target.device),  # Medium weight for boundaries
                    torch.tensor(0.5, device=target.device)   # Lower weight for outside range
                )
            )
            
            # Log range specialist statistics occasionally
            self._batch_count += 1
            if self._batch_count % 200 == 0:
                in_range_count = torch.sum(in_target_range).item()
                boundary_count = torch.sum(near_boundaries).item()
                total_count = len(target)
                if hasattr(logger, 'debug'):
                    logger.debug(f"Range specialist loss: {in_range_count}/{total_count} in target range (3.0x), "
                               f"{boundary_count}/{total_count} near boundaries (2.0x)")
        else:
            # Standard mode: light weighting based on quantiles
            if len(target) > 10:  # Only apply weighting if we have enough samples
                p10 = torch.quantile(target, 0.10)
                p90 = torch.quantile(target, 0.90)
                
                # Very light weighting for only the most extreme values (top/bottom 10%)
                weights = torch.where(
                    (target <= p10) | (target >= p90),
                    torch.tensor(1.2, device=target.device),  # Much lighter weighting
                    torch.tensor(1.0, device=target.device)
                )
            else:
                # For small batches, use uniform weighting
                weights = torch.ones_like(target)
            
            # Log weighting statistics occasionally (every 200 batches to reduce noise)
            self._batch_count += 1
            if self._batch_count % 200 == 0:
                if len(target) > 10:
                    extreme_count = torch.sum((target <= p10) | (target >= p90)).item()
                    total_count = len(target)
                    if hasattr(logger, 'debug'):
                        logger.debug(f"Loss weighting: {extreme_count}/{total_count} samples weighted 1.2x (p10={p10:.3f}, p90={p90:.3f})")
        
        # Apply weights to loss
        weighted_mse = mse * weights
        
        return weighted_mse.mean()


class NeuralNetworkRegressor(BaseEstimator, RegressorMixin):
    """Scikit-learn compatible wrapper for PyTorch neural network."""
    
    def __init__(
        self,
        input_dim: Optional[int] = None,
        model_type: str = 'full',  # 'full', 'light', or 'autogluon'
        epochs: int = 400,
        batch_size: int = 32,
        learning_rate: float = 0.001,
        weight_decay: float = 0.01,
        dropout_rate: float = 0.3,
        early_stopping_patience: int = 30,
        device: Optional[str] = None,
        random_state: int = 42,
        verbose: bool = True,
        use_sample_weights: bool = False,  # Whether to use sample weights or custom loss only
        range_focused: bool = False,  # Enable range specialist mode
        target_range: tuple = (0.2, 0.5),  # Target concentration range for specialist mode
        # New optimization parameters
        hidden_layers: Optional[Tuple[int, ...]] = None,  # Custom architecture
        activation: str = 'relu',  # Activation function
        optimizer: str = 'adam',  # Optimizer type
        momentum: float = 0.9,  # SGD momentum
        lr_scheduler: Optional[str] = None,  # Learning rate scheduler
        step_size: int = 30,  # Step scheduler step size
        gamma: float = 0.1,  # Scheduler decay factor
        use_batch_norm: bool = True,  # Use batch normalization
        **kwargs  # Accept any additional parameters
    ):
        self.input_dim = input_dim
        self.model_type = model_type
        self.epochs = epochs
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.dropout_rate = dropout_rate
        self.early_stopping_patience = early_stopping_patience
        self.device = device
        self.random_state = random_state
        self.verbose = verbose
        self.use_sample_weights = use_sample_weights
        self.range_focused = range_focused
        self.target_range = target_range
        
        # New optimization parameters
        self.hidden_layers = hidden_layers
        self.activation = activation
        self.optimizer = optimizer
        self.momentum = momentum
        self.lr_scheduler = lr_scheduler
        self.step_size = step_size
        self.gamma = gamma
        self.use_batch_norm = use_batch_norm
        
        # Will be set during fit
        self.model_ = None
        self.scaler_ = None
        self.loss_fn_ = None
        self.optimizer_ = None
        self.scheduler_ = None
        self.train_losses_ = []
        self.val_losses_ = []
        
    def _get_device(self):
        if self.device is None:
            return torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        return torch.device(self.device)
        
    def _create_model(self, input_dim: int) -> nn.Module:
        # If custom hidden layers are provided, use dynamic architecture
        if self.hidden_layers is not None:
            return DynamicNN(
                input_dim=input_dim,
                hidden_layers=self.hidden_layers,
                dropout_rate=self.dropout_rate,
                activation=self.activation,
                use_batch_norm=self.use_batch_norm
            )
        # Otherwise use predefined architectures
        elif self.model_type == 'full':
            return PotassiumNN(input_dim, self.dropout_rate)
        elif self.model_type == 'light':
            return LightPotassiumNN(input_dim, self.dropout_rate)
        elif self.model_type == 'autogluon':
            return AutoGluonOptimizedNN(input_dim, self.dropout_rate)
        else:
            raise ValueError(f"Unknown model_type: {self.model_type}. Valid options: 'full', 'light', 'autogluon'")
            
    def fit(self, X, y, sample_weight=None, validation_data=None):
        """Fit the neural network model."""
        # Handle sample weight configuration
        if sample_weight is not None and not self.use_sample_weights:
            logger.info("Neural network ignoring sample_weight parameter - using custom loss weighting instead")
            sample_weight = None
        elif sample_weight is not None and self.use_sample_weights:
            logger.info("Neural network using both sample weights and custom loss weighting")
        elif sample_weight is None and self.use_sample_weights:
            logger.warning("Neural network configured to use sample weights but none provided")
        
        # Set random seeds
        torch.manual_seed(self.random_state)
        np.random.seed(self.random_state)
        
        # Get device
        device = self._get_device()
        if self.verbose:
            logger.info(f"Using device: {device}")
        
        # Determine input dimension
        if self.input_dim is None:
            self.input_dim = X.shape[1]
        
        # Log the input dimension for neural network
        if self.verbose:
            logger.info(f"Neural network input dimension: {self.input_dim} features")
            
        # Scale features
        self.scaler_ = StandardScaler()
        X_scaled = self.scaler_.fit_transform(X)
        
        # Create model
        self.model_ = self._create_model(self.input_dim).to(device)
        
        # Loss and optimizer with range specialist support
        self.loss_fn_ = PotassiumLoss(
            range_focused=self.range_focused,
            target_range=self.target_range
        )
        
        # Create optimizer based on parameter
        if self.optimizer == 'adam':
            self.optimizer_ = torch.optim.Adam(
                self.model_.parameters(),
                lr=self.learning_rate,
                weight_decay=self.weight_decay
            )
        elif self.optimizer == 'adamw':
            self.optimizer_ = torch.optim.AdamW(
                self.model_.parameters(),
                lr=self.learning_rate,
                weight_decay=self.weight_decay,
                betas=(0.9, 0.999)
            )
        elif self.optimizer == 'sgd':
            self.optimizer_ = torch.optim.SGD(
                self.model_.parameters(),
                lr=self.learning_rate,
                weight_decay=self.weight_decay,
                momentum=self.momentum
            )
        else:
            raise ValueError(f"Unknown optimizer: {self.optimizer}")
        
        # Create scheduler based on parameter
        if self.lr_scheduler == 'step':
            self.scheduler_ = torch.optim.lr_scheduler.StepLR(
                self.optimizer_,
                step_size=self.step_size,
                gamma=self.gamma
            )
        elif self.lr_scheduler == 'exponential':
            self.scheduler_ = torch.optim.lr_scheduler.ExponentialLR(
                self.optimizer_,
                gamma=self.gamma
            )
        elif self.lr_scheduler == 'cosine':
            self.scheduler_ = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer_,
                T_max=self.epochs
            )
        else:
            # Default to ReduceLROnPlateau
            self.scheduler_ = torch.optim.lr_scheduler.ReduceLROnPlateau(
                self.optimizer_, 
                mode='min',
                factor=0.5,
                patience=10,
                min_lr=1e-6
            )
        
        # Create validation split if not provided
        if validation_data is None:
            # Use 20% of data for validation
            val_size = int(0.2 * len(X_scaled))
            train_size = len(X_scaled) - val_size
            
            # Random split
            indices = torch.randperm(len(X_scaled))
            train_indices = indices[:train_size]
            val_indices = indices[train_size:]
            
            X_train = X_scaled[train_indices]
            y_train = y.values[train_indices] if hasattr(y, 'values') else y[train_indices]
            X_val = X_scaled[val_indices]
            y_val = y.values[val_indices] if hasattr(y, 'values') else y[val_indices]
            
            validation_data = (X_val, y_val)
            logger.info(f"Created validation split: {train_size} train, {val_size} validation")
        else:
            X_train = X_scaled
            y_train = y.values if hasattr(y, 'values') else y
        
        # Convert to tensors
        X_tensor = torch.FloatTensor(X_train).to(device)
        y_tensor = torch.FloatTensor(y_train).to(device)
        
        # Create data loader with or without sample weights
        if sample_weight is not None and self.use_sample_weights:
            weight_tensor = torch.FloatTensor(sample_weight[:len(X_train)]).to(device)
            dataset = TensorDataset(X_tensor, y_tensor, weight_tensor)
        else:
            dataset = TensorDataset(X_tensor, y_tensor)
            
        train_loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
        
        # Validation data
        val_loader = None
        if validation_data is not None:
            X_val, y_val = validation_data
            X_val_scaled = self.scaler_.transform(X_val)
            X_val_tensor = torch.FloatTensor(X_val_scaled).to(device)
            y_val_tensor = torch.FloatTensor(y_val.values if hasattr(y_val, 'values') else y_val).to(device)
            val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
            val_loader = DataLoader(val_dataset, batch_size=self.batch_size)
        
        # Training loop
        best_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(self.epochs):
            # Training phase
            self.model_.train()
            train_loss = 0.0
            
            for batch_data in train_loader:
                self.optimizer_.zero_grad()
                
                # Handle different batch formats based on sample weight usage
                if len(batch_data) == 3:  # X, y, sample_weights
                    batch_X, batch_y, batch_w = batch_data
                    predictions = self.model_(batch_X)
                    
                    # Use custom loss function and apply sample weights
                    base_loss = self.loss_fn_(predictions, batch_y)
                    # Apply sample weights by multiplying with individual losses
                    individual_losses = (predictions - batch_y) ** 2
                    weighted_losses = individual_losses * batch_w
                    loss = weighted_losses.mean()
                else:  # X, y only
                    batch_X, batch_y = batch_data
                    predictions = self.model_(batch_X)
                    
                    # Use custom loss function only (handles concentration weighting internally)
                    loss = self.loss_fn_(predictions, batch_y)
                
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model_.parameters(), max_norm=1.0)
                self.optimizer_.step()
                
                train_loss += loss.item() * len(batch_X)
                
            train_loss /= len(dataset)
            self.train_losses_.append(train_loss)
            
            # Validation phase
            if val_loader is not None:
                self.model_.eval()
                val_loss = 0.0
                
                with torch.no_grad():
                    for batch_X, batch_y in val_loader:
                        predictions = self.model_(batch_X)
                        loss = self.loss_fn_(predictions, batch_y)
                        val_loss += loss.item() * len(batch_X)
                        
                val_loss /= len(val_dataset)
                self.val_losses_.append(val_loss)
                
                # Learning rate scheduling - different schedulers need different inputs
                if self.lr_scheduler in ['step', 'exponential', 'cosine']:
                    self.scheduler_.step()  # These don't need loss
                else:
                    self.scheduler_.step(val_loss)  # ReduceLROnPlateau needs loss
                
                # Early stopping
                if val_loss < best_loss:
                    best_loss = val_loss
                    patience_counter = 0
                    # Save best model state
                    self.best_model_state_ = self.model_.state_dict().copy()
                else:
                    patience_counter += 1
                    
                if patience_counter >= self.early_stopping_patience:
                    if self.verbose:
                        logger.info(f"Early stopping at epoch {epoch}")
                    break
                    
                if self.verbose and epoch % 10 == 0:
                    logger.info(f"Epoch {epoch}: train_loss={train_loss:.4f}, val_loss={val_loss:.4f}")
            else:
                if self.verbose and epoch % 10 == 0:
                    logger.info(f"Epoch {epoch}: train_loss={train_loss:.4f}")
                    
        # Load best model state if available
        if hasattr(self, 'best_model_state_'):
            self.model_.load_state_dict(self.best_model_state_)
            
        # Log training summary
        if self.verbose:
            y_numpy = y_tensor.cpu().numpy()
            
            if self.range_focused:
                # Range specialist training summary
                target_min, target_max = self.target_range
                in_range_samples = np.sum((y_numpy >= target_min) & (y_numpy <= target_max))
                boundary_samples = np.sum(((y_numpy >= (target_min - 0.05)) & (y_numpy <= (target_min + 0.05))) | 
                                        ((y_numpy >= (target_max - 0.05)) & (y_numpy <= (target_max + 0.05))))
                total_samples = len(y_numpy)
                
                logger.info(f"Range Specialist Neural network training complete:")
                logger.info(f"  - Target range: {target_min}-{target_max}% magnesium")
                logger.info(f"  - {in_range_samples}/{total_samples} samples ({in_range_samples/total_samples*100:.1f}%) in target range (3.0x weight)")
                logger.info(f"  - {boundary_samples}/{total_samples} samples ({boundary_samples/total_samples*100:.1f}%) near boundaries (2.0x weight)")
            else:
                # Standard training summary
                extreme_samples = np.sum((y_numpy < 0.25) | (y_numpy > 0.40))
                total_samples = len(y_numpy)
                extreme_percentage = extreme_samples / total_samples * 100
                
                logger.info(f"Neural network training complete:")
                logger.info(f"  - Used custom loss weighting (1.2x weight for extreme values)")
                logger.info(f"  - {extreme_samples}/{total_samples} samples ({extreme_percentage:.1f}%) received extra weighting")
            
            logger.info(f"  - Final training loss: {self.train_losses_[-1]:.4f}")
            if self.val_losses_:
                logger.info(f"  - Final validation loss: {self.val_losses_[-1]:.4f}")
            
        return self
        
    def predict(self, X):
        """Make predictions."""
        device = self._get_device()
        
        # Scale features
        X_scaled = self.scaler_.transform(X)
        X_tensor = torch.FloatTensor(X_scaled).to(device)
        
        # Make predictions
        self.model_.eval()
        with torch.no_grad():
            predictions = self.model_(X_tensor)
            
        return predictions.cpu().numpy().flatten()
        
    def get_params(self, deep=True):
        """Get parameters for scikit-learn compatibility."""
        return {
            'input_dim': self.input_dim,
            'model_type': self.model_type,
            'epochs': self.epochs,
            'batch_size': self.batch_size,
            'learning_rate': self.learning_rate,
            'weight_decay': self.weight_decay,
            'dropout_rate': self.dropout_rate,
            'early_stopping_patience': self.early_stopping_patience,
            'device': self.device,
            'random_state': self.random_state,
            'verbose': self.verbose,
            'use_sample_weights': self.use_sample_weights,
            'range_focused': self.range_focused,
            'target_range': self.target_range
        }
        
    def set_params(self, **params):
        """Set parameters for scikit-learn compatibility."""
        for key, value in params.items():
            setattr(self, key, value)
        return self
        
    def save_model(self, filepath: str):
        """Save the model to disk."""
        # Create directory if needed
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        # Save everything needed for reconstruction
        save_dict = {
            'model_state_dict': self.model_.state_dict(),
            'model_type': self.model_type,
            'input_dim': self.input_dim,
            'dropout_rate': self.dropout_rate,
            'scaler': self.scaler_,
            'train_losses': self.train_losses_,
            'val_losses': self.val_losses_,
            'params': self.get_params()
        }
        
        joblib.dump(save_dict, filepath)
        logger.info(f"Neural network model saved to {filepath}")
        
    @classmethod
    def load_model(cls, filepath: str) -> 'NeuralNetworkRegressor':
        """Load a saved model from disk."""
        save_dict = joblib.load(filepath)
        
        # Create instance with saved parameters
        model = cls(**save_dict['params'])
        
        # Recreate the neural network
        model.model_ = model._create_model(save_dict['input_dim'])
        model.model_.load_state_dict(save_dict['model_state_dict'])
        model.model_.eval()
        
        # Restore other attributes
        model.scaler_ = save_dict['scaler']
        model.train_losses_ = save_dict['train_losses']
        model.val_losses_ = save_dict['val_losses']
        
        logger.info(f"Neural network model loaded from {filepath}")
        return model