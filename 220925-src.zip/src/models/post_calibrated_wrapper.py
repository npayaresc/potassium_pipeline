"""
Post-Calibrated Model Wrapper

This module provides a wrapper for models with post-processing calibration.
"""
import numpy as np
import logging
from typing import Optional
from src.models.calibration_utils import PrecisionCalibrator

logger = logging.getLogger(__name__)


class PostCalibratedModelWrapper:
    """Wrapper that applies post-processing calibration to model predictions."""
    
    def __init__(self, model, post_calibrator: Optional[PrecisionCalibrator] = None, 
                 post_calibration_config: Optional[dict] = None):
        """
        Initialize the wrapper.
        
        Args:
            model: The trained model or pipeline
            post_calibrator: Fitted PrecisionCalibrator instance
            post_calibration_config: Configuration dict with 'enabled', 'method', 'target'
        """
        self.model = model
        self.post_calibrator = post_calibrator
        self.post_calibration_config = post_calibration_config or {}
        
    def predict(self, X):
        """
        Make predictions and apply post-calibration if available.
        
        Args:
            X: Input features
            
        Returns:
            Calibrated predictions
        """
        # Get raw predictions
        raw_predictions = self.model.predict(X)
        
        # Apply post-calibration if available
        if self.post_calibrator is not None and self.post_calibration_config.get('enabled', False):
            logger.info(f"Applying post-calibration (method: {self.post_calibration_config.get('method', 'unknown')}, "
                       f"target: {self.post_calibration_config.get('target', 'unknown')})")
            calibrated_predictions = self.post_calibrator.transform(raw_predictions)
            
            # Log improvement if we have enough predictions
            if len(raw_predictions) > 1:
                avg_raw = np.mean(raw_predictions)
                avg_cal = np.mean(calibrated_predictions)
                logger.debug(f"Post-calibration adjustment: {avg_raw:.4f} → {avg_cal:.4f}")
            
            return calibrated_predictions
        else:
            return raw_predictions
    
    def fit(self, X, y, **kwargs):
        """Fit the underlying model."""
        return self.model.fit(X, y, **kwargs)
    
    def __getattr__(self, name):
        """Delegate other attributes to the underlying model."""
        return getattr(self.model, name)
    
    def __getstate__(self):
        """Custom pickling to save all components."""
        return {
            'model': self.model,
            'post_calibrator': self.post_calibrator,
            'post_calibration_config': self.post_calibration_config
        }
    
    def __setstate__(self, state):
        """Custom unpickling to restore all components."""
        self.model = state['model']
        self.post_calibrator = state.get('post_calibrator')
        self.post_calibration_config = state.get('post_calibration_config', {})