#!/usr/bin/env python3
"""
Unified Model Optimization Script

This script provides a unified interface to optimize any model in the pipeline
with model-specific hyperparameter tuning and advanced optimization techniques.
"""
import argparse
import logging
import pandas as pd
import numpy as np
from typing import Optional
from pathlib import Path
from datetime import datetime
import joblib

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.config.pipeline_config import config
from src.config.config_manager import config_manager
from src.data_management.data_manager import DataManager
from src.utils.helpers import setup_logging
from src.utils.custom_exceptions import DataValidationError

# Import all optimizers
from .optimize_xgboost import XGBoostOptimizer
from .optimize_lightgbm import LightGBMOptimizer
from .optimize_catboost import CatBoostOptimizer
from .optimize_random_forest import RandomForestOptimizer
from .optimize_extratrees import ExtraTreesOptimizer
from .optimize_neural_network import NeuralNetworkOptimizer
from .optimize_autogluon import AutoGluonOptimizer

logger = logging.getLogger(__name__)

class UnifiedModelOptimizer:
    """Unified interface for optimizing any model type."""
    
    OPTIMIZER_MAP = {
        'xgboost': XGBoostOptimizer,
        'lightgbm': LightGBMOptimizer,
        'catboost': CatBoostOptimizer,
        'random_forest': RandomForestOptimizer,
        'extratrees': ExtraTreesOptimizer,
        'neural_network': NeuralNetworkOptimizer,
        'neural_network_light': NeuralNetworkOptimizer,
        'autogluon': AutoGluonOptimizer,
    }
    
    def __init__(self):
        self.results = {}
    
    def optimize_model(self, model_name: str, config, strategy: str = 'full_context',
                      X_train=None, y_train=None, X_test=None, y_test=None,
                      n_trials: int = 200, timeout: int = 3600,
                      use_parallel_features: Optional[bool] = None, feature_n_jobs: Optional[int] = None):
        """Optimize a specific model."""

        # Use config defaults if not provided
        if use_parallel_features is None:
            use_parallel_features = config.parallel.use_feature_parallel
        if feature_n_jobs is None:
            feature_n_jobs = config.parallel.feature_n_jobs

        # Check and handle NaN values in input data
        if X_train is not None:
            if isinstance(X_train, pd.DataFrame):
                if X_train.isnull().any().any():
                    nan_cols = X_train.columns[X_train.isnull().any()].tolist()
                    logger.warning(f"[{model_name.upper()}] Training data contains NaN in columns: {nan_cols[:10]}...")
                    X_train = X_train.fillna(0)
                    logger.info(f"[{model_name.upper()}] Filled NaN values with 0 in training data")
            elif isinstance(X_train, np.ndarray) and np.isnan(X_train).any():
                nan_count = np.sum(np.isnan(X_train))
                logger.warning(f"[{model_name.upper()}] Training data contains {nan_count} NaN values")
                X_train = np.nan_to_num(X_train, nan=0.0)
                logger.info(f"[{model_name.upper()}] Replaced NaN values with 0 in training data")

        if X_test is not None:
            if isinstance(X_test, pd.DataFrame):
                if X_test.isnull().any().any():
                    X_test = X_test.fillna(0)
                    logger.info(f"[{model_name.upper()}] Filled NaN values with 0 in test data")
            elif isinstance(X_test, np.ndarray) and np.isnan(X_test).any():
                X_test = np.nan_to_num(X_test, nan=0.0)
                logger.info(f"[{model_name.upper()}] Replaced NaN values with 0 in test data")
        
        if model_name not in self.OPTIMIZER_MAP:
            raise ValueError(f"Model '{model_name}' not supported. Available: {list(self.OPTIMIZER_MAP.keys())}")
        
        logger.info(f"Starting optimization for {model_name} with strategy {strategy}")
        logger.info(f"Using {n_trials} trials with {timeout}s timeout per model")
        
        # Initialize optimizer
        optimizer_class = self.OPTIMIZER_MAP[model_name]
        
        # Handle neural network variants
        if model_name == 'neural_network_light':
            optimizer = optimizer_class(config, strategy, model_type='light', use_parallel_features=use_parallel_features, feature_n_jobs=feature_n_jobs)
        elif model_name == 'neural_network':
            optimizer = optimizer_class(config, strategy, model_type='full', use_parallel_features=use_parallel_features, feature_n_jobs=feature_n_jobs)
        else:
            optimizer = optimizer_class(config, strategy, use_parallel_features=use_parallel_features, feature_n_jobs=feature_n_jobs)
        
        # Run optimization with appropriate signature
        # All optimizers now support hold-out validation to avoid CV/evaluation mismatch
        if X_test is not None and y_test is not None:
            from sklearn.model_selection import train_test_split
            # Use small validation split to leave most data for training
            X_opt_train, X_opt_val, y_opt_train, y_opt_val = train_test_split(
                X_train, y_train, test_size=0.15, random_state=42)
            logger.info(f"Using hold-out validation for {model_name} optimization to match final evaluation approach")
            study = optimizer.optimize(X_opt_train, y_opt_train, X_opt_val, y_opt_val, n_trials, timeout)
        else:
            # Fall back to cross-validation if no test data available
            logger.info(f"No test data available, using cross-validation for {model_name} optimization")
            study = optimizer.optimize(X_train, y_train, None, None, n_trials, timeout)
        
        # Train final model with strategy parameter for neural networks (enables reporting)
        # For neural networks, check if validation data should be used
        if model_name in ['neural_network', 'neural_network_light']:
            # Check if we have validation data configured
            X_validation = None
            y_validation = None
            
            # If validation directory is specified in config, try to load validation data
            if hasattr(config, 'custom_validation_dir') and config.custom_validation_dir:
                try:
                    # This would require implementing validation data loading logic
                    # For now, we'll pass None and let the method work without validation data
                    pass
                except Exception as e:
                    logger.warning(f"Could not load validation data: {e}")
            
            final_pipeline, train_metrics, test_metrics = optimizer.train_final_model(
                X_train, y_train, X_test, y_test, strategy=strategy, enable_reporting=True,
                X_validation=X_validation, y_validation=y_validation
            )
        else:
            final_pipeline, train_metrics, test_metrics = optimizer.train_final_model(
                X_train, y_train, X_test, y_test
            )
        
        # Store results
        self.results[model_name] = {
            'optimizer': optimizer,
            'study': study,
            'pipeline': final_pipeline,
            'train_metrics': train_metrics,
            'test_metrics': test_metrics,
            'best_params': optimizer.best_params,
            'best_score': optimizer.best_score
        }
        
        # Save model with display strategy name
        from main import get_display_strategy_name
        timestamp = config.run_timestamp
        display_strategy = get_display_strategy_name(strategy, getattr(config, 'use_raw_spectral_data', False))
        model_path = config.model_dir / f"optimized_{model_name}_{display_strategy}_{timestamp}.pkl"
        joblib.dump(final_pipeline, model_path)
        
        # Save optimized configuration
        optimized_config = config.copy(deep=True)
        setattr(optimized_config.model_params, model_name, optimizer.best_params)
        config_name = f"optimized_{model_name}_{display_strategy}_{timestamp}"
        description = f"Optimized {model_name.title()} - R²: {test_metrics['r2']:.4f}, Strategy: {display_strategy}"
        config_manager.save_config(optimized_config, config_name, description)
        
        # Log results
        logger.info(f"{model_name} optimization completed successfully")
        logger.info(f"Best optimization score: {optimizer.best_score:.4f}")
        logger.info(f"Final test R²: {test_metrics['r2']:.4f}")
        logger.info(f"Final test RMSE: {test_metrics['rmse']:.4f}")
        logger.info(f"Final test RRMSE: {test_metrics.get('rrmse', 0):.2f}%")
        logger.info(f"Final test MAE: {test_metrics['mae']:.4f}")
        logger.info(f"Final test MAPE: {test_metrics.get('mape', 0):.2f}%")
        logger.info(f"Final test Within 20.5%: {test_metrics.get('within_20.5%', 0):.2f}%")
        logger.info(f"Model saved to: {model_path}")
        
        return {
            'model_name': model_name,
            'strategy': strategy,
            'optimization_score': optimizer.best_score,
            'train_r2': train_metrics['r2'],
            'test_r2': test_metrics['r2'],
            'test_rmse': test_metrics['rmse'],
            'test_mae': test_metrics['mae'],
            'model_path': model_path,
            'config_name': config_name,
            'best_params': optimizer.best_params,
            'pipeline': final_pipeline,  # Add the pipeline to the returned result
            'test_metrics': test_metrics  # Also add test_metrics for consistency
        }
    
    def optimize_multiple_models(self, model_names: list, config, strategy: str = 'full_context',
                                X_train=None, y_train=None, X_test=None, y_test=None,
                                n_trials: int = 200, timeout: int = 3600,
                                use_parallel_features: Optional[bool] = None, feature_n_jobs: Optional[int] = None):
        """Optimize multiple models and return comparison results."""
        
        # Use config defaults if not provided
        if use_parallel_features is None:
            use_parallel_features = config.parallel.use_feature_parallel
        if feature_n_jobs is None:
            feature_n_jobs = config.parallel.feature_n_jobs
        
        results = []
        
        for model_name in model_names:
            try:
                result = self.optimize_model(
                    model_name, config, strategy, X_train, y_train, X_test, y_test,
                    n_trials, timeout, use_parallel_features=use_parallel_features, feature_n_jobs=feature_n_jobs
                )
                results.append(result)
                
                print(f"\n--- {model_name.upper()} OPTIMIZATION RESULTS ---")
                print(f"Strategy: {result['strategy']}")
                print(f"Optimization Score: {result['optimization_score']:.4f}")
                print(f"Train R²: {result['train_r2']:.4f}")
                print(f"Test R²: {result['test_r2']:.4f}")
                print(f"Test RMSE: {result['test_rmse']:.4f}")
                print(f"Test MAE: {result['test_mae']:.4f}")
                print(f"Model saved to: {result['model_path']}")
                print("=" * 50)
                
            except Exception as e:
                logger.error(f"Failed to optimize {model_name}: {e}")
                continue
        
        # Create comparison DataFrame
        if results:
            comparison_df = pd.DataFrame(results)
            comparison_df = comparison_df.sort_values('test_r2', ascending=False)
            
            print(f"\n--- MODEL COMPARISON SUMMARY ---")
            print(comparison_df[['model_name', 'test_r2', 'test_rmse', 'optimization_score']].to_string(index=False))
            print("=" * 50)
            
            # Save comparison results
            timestamp = config.run_timestamp
            comparison_path = config.reports_dir / f"model_optimization_comparison_{strategy}_{timestamp}.csv"
            comparison_df.to_csv(comparison_path, index=False)
            logger.info(f"Comparison results saved to: {comparison_path}")
        
        return results
    
    def get_best_model(self):
        """Get the best performing model from optimization results."""
        if not self.results:
            return None
        
        best_model_name = max(self.results.keys(), 
                             key=lambda k: self.results[k]['test_metrics']['r2'])
        return best_model_name, self.results[best_model_name]


def setup_pipeline_config(use_gpu: bool = False, validation_dir=None, config_path=None):
    """Sets up dynamic configuration values and creates all necessary directories."""
    if config_path:
        stored_config_path = Path(config_path)
        updated_config = config_manager.apply_config(config, stored_config_path)
        logger.info(f"Loaded configuration from: {config_path}")
    else:
        updated_config = config
    
    updated_config.run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    updated_config.use_gpu = use_gpu
    if validation_dir is not None:
        updated_config.custom_validation_dir = validation_dir
    
    if use_gpu:
        logger.info("GPU mode enabled - models will use CUDA acceleration where available")
    else:
        logger.info("GPU mode disabled - models will use CPU only")
    
    project_root = Path(__file__).resolve().parents[2]
    
    # Define all paths relative to the project root
    data_dir = project_root / "data"
    raw_data_dir = data_dir / "raw" / "data_5278_Phase3"
    processed_data_dir = data_dir / "processed"
    averaged_files_dir = data_dir / "averaged_files_per_sample"
    cleansed_files_dir = data_dir / "cleansed_files_per_sample"
    model_dir = project_root / "models"
    reports_dir = project_root / "reports"
    log_dir = project_root / "logs"
    bad_files_dir = project_root / "bad_files"
    bad_prediction_files_dir = project_root / "bad_prediction_files"
    reference_data_path = project_root / "data" / "reference_data" / "Final_Lab_Data_Nico_New.xlsx"
    
    # Create all directories first
    for dir_path in [
        processed_data_dir, averaged_files_dir, cleansed_files_dir,
        model_dir, reports_dir, log_dir, bad_files_dir, bad_prediction_files_dir
    ]:
        dir_path.mkdir(parents=True, exist_ok=True)
    
    # Assign paths to config
    updated_config.data_dir = data_dir
    updated_config.raw_data_dir = raw_data_dir
    updated_config.processed_data_dir = processed_data_dir
    updated_config.averaged_files_dir = averaged_files_dir
    updated_config.cleansed_files_dir = cleansed_files_dir
    updated_config.model_dir = model_dir
    updated_config.reports_dir = reports_dir
    updated_config.log_dir = log_dir
    updated_config.bad_files_dir = bad_files_dir
    updated_config.bad_prediction_files_dir = bad_prediction_files_dir
    updated_config.reference_data_path = reference_data_path
    updated_config.sample_id_column = "Sample ID"
    
    setup_logging()
    return updated_config