#!/usr/bin/env python3
"""
Dedicated Neural Network Optimization Script

This script focuses specifically on optimizing Neural Networks for better R² performance
with advanced techniques and comprehensive hyperparameter tuning.
"""
import argparse
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.pipeline import Pipeline
from sklearn.isotonic import IsotonicRegression
from src.models.neural_network import NeuralNetworkRegressor
import optuna
from datetime import datetime
import joblib

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.config.pipeline_config import config
from src.config.config_manager import config_manager
from src.data_management.data_manager import DataManager
from src.features.feature_engineering import create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.utils.helpers import calculate_regression_metrics, setup_logging
from src.cleansing.data_cleanser import DataCleanser
from src.utils.custom_exceptions import DataValidationError
from src.models.base_optimizer import BaseOptimizer
from src.models.enhanced_optuna_strategies import get_enhanced_optimization_config

logger = logging.getLogger(__name__)

class NeuralNetworkOptimizer(BaseOptimizer):
    """Advanced Neural Network optimization with spectral data focus."""
    
    def __init__(self, config, strategy='full_context', model_type='full', use_parallel_features=False, feature_n_jobs=-1):
        super().__init__(config)  # Initialize base optimizer
        self.strategy = strategy
        self.model_type = model_type  # 'full' or 'light'
        self.use_parallel_features = use_parallel_features
        self.feature_n_jobs = feature_n_jobs
        
        # Calibration for when sample weights are used
        self.calibrator = None
        self.use_calibration = False
        
        # Use concentration-aware features if enabled in config
        if config.use_concentration_features:
            logger.info("Using enhanced feature pipeline with concentration-aware features for Neural Network optimization")
            self.feature_pipeline = create_enhanced_feature_pipeline_with_concentration(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
        else:
            logger.info(f"Using standard feature pipeline for Neural Network optimization (parallel={use_parallel_features}, feature_n_jobs={feature_n_jobs})")
            self.feature_pipeline = create_feature_pipeline(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
            
        self.best_params = None
        self.best_score = float('-inf')
        self._cached_features = None  # Cache transformed features
        self._fitted_feature_pipeline = None
        
    def create_advanced_objective(self, trial):
        """Advanced objective function combining multiple metrics."""
        
        # Enhanced parameter suggestion with smart search space (Strategy D)
        # Note: Neural networks are complex, so we'll use the original detailed logic for now
        
        # Suggest hyperparameters optimized for spectral data
        params = {
            'model_type': self.model_type,
            'epochs': trial.suggest_int('epochs', 50, 200),
            'batch_size': trial.suggest_categorical('batch_size', (4, 8, 16, 24, 32)),  # Slightly larger for better GPU utilization
            'learning_rate': trial.suggest_float('learning_rate', 0.0005, 0.01, log=True),  # Conservative range
            'weight_decay': trial.suggest_float('weight_decay', 0.0001, 0.01, log=True),
            'dropout_rate': trial.suggest_float('dropout_rate', 0.0, 0.4),
            'early_stopping_patience': trial.suggest_int('early_stopping_patience', 20, 60),  # More patience
            'verbose': False,
            'use_sample_weights': False,  # Use custom loss weighting instead
            'random_state': 42
        }
        
        # Dynamic architecture generation based on actual input features
        input_features = self._get_input_feature_count()
        params['hidden_layers'] = self._generate_dynamic_architecture(trial, input_features, self.model_type)
        
        # Activation function
        params['activation'] = trial.suggest_categorical('activation', ('relu', 'leaky_relu', 'elu', 'gelu'))
        
        # Optimizer parameters
        params['optimizer'] = trial.suggest_categorical('optimizer', ('adam', 'adamw', 'sgd'))
        if params['optimizer'] == 'sgd':
            params['momentum'] = trial.suggest_float('momentum', 0.8, 0.99)
        
        # Learning rate scheduler
        params['lr_scheduler'] = trial.suggest_categorical('lr_scheduler', (None, 'step', 'exponential', 'cosine'))
        if params['lr_scheduler'] == 'step':
            params['step_size'] = trial.suggest_int('step_size', 20, 60)
            params['gamma'] = trial.suggest_float('gamma', 0.5, 0.9)
        elif params['lr_scheduler'] == 'exponential':
            params['gamma'] = trial.suggest_float('gamma', 0.95, 0.99)
        
        # Batch normalization
        params['use_batch_norm'] = trial.suggest_categorical('use_batch_norm', (True, False))
        
        # Add GPU support with thread-safe device allocation
        if self.config.use_gpu:
            # For parallel trials, use the same GPU but let PyTorch handle memory management
            params['device'] = 'cuda'
        else:
            params['device'] = 'cpu'
        
        # Debug: Log the parameters to ensure proper parsing
        if 'hidden_layers' in params:
            logger.debug(f"Creating model with hidden_layers: {params['hidden_layers']} (type: {type(params['hidden_layers'])})")
        
        # Create model
        model = NeuralNetworkRegressor(**params)
        
        # Use pre-fitted features (should be set by optimize() method before parallel execution)
        if self._cached_features is None:
            raise RuntimeError("Features must be pre-fitted before trials. Call _prepare_features() in optimize() method.")
        
        # Create model-only pipeline
        model_pipeline = Pipeline([
            ('model', model)
        ])
        
        # Use hold-out validation instead of cross-validation for better performance with small dataset
        # Create 80/20 train/validation split (matching AutoGluon's approach)
        val_size = int(0.2 * len(self._cached_features))
        train_size = len(self._cached_features) - val_size
        
        # Create reproducible split
        indices = np.arange(len(self._cached_features))
        np.random.seed(42)  # Ensure reproducible splits
        np.random.shuffle(indices)
        
        train_indices = indices[:train_size]
        val_indices = indices[train_size:]
        
        X_train_fold = self._cached_features[train_indices]
        y_train_fold = self.y_train.iloc[train_indices] if hasattr(self.y_train, 'iloc') else self.y_train[train_indices]
        X_val_fold = self._cached_features[val_indices]
        y_val_fold = self.y_train.iloc[val_indices] if hasattr(self.y_train, 'iloc') else self.y_train[val_indices]
        
        try:
            # Train on training fold
            model_pipeline.fit(X_train_fold, y_train_fold)
            
            # Evaluate on both training and validation folds
            train_pred = model_pipeline.predict(X_train_fold)
            val_pred = model_pipeline.predict(X_val_fold)
            
            # Ensure predictions are 1D arrays
            if train_pred.ndim > 1:
                train_pred = train_pred.flatten()
            if val_pred.ndim > 1:
                val_pred = val_pred.flatten()
            
            # Calculate R² and RMSE for both sets
            from sklearn.metrics import r2_score, mean_squared_error
            train_r2 = r2_score(y_train_fold, train_pred)
            val_r2 = r2_score(y_val_fold, val_pred)
            train_rmse = np.sqrt(mean_squared_error(y_train_fold, train_pred))
            val_rmse = np.sqrt(mean_squared_error(y_val_fold, val_pred))
            
            # Use validation metrics as primary scores (like AutoGluon)
            r2_mean = val_r2
            rmse_mean = val_rmse
            
            # Calculate variance penalty based on train/val gap
            r2_std = abs(train_r2 - val_r2)  # Use gap as stability indicator
            rmse_std = abs(train_rmse - val_rmse)
            
        except Exception as e:
            logger.error(f"Hold-out validation failed: {e}")
            return -1000.0
        
        # Weighted combination favoring R² with stability penalty
        stability_penalty = 0.15 * (r2_std + rmse_std)  # Higher penalty for NN instability
        objective_score = r2_mean - stability_penalty
        
        # Log trial results
        logger.info(f"Trial {trial.number}: R²={r2_mean:.4f}, RMSE={rmse_mean:.4f}, Score={objective_score:.4f}")
        
        # Report intermediate results
        trial.report(objective_score, step=0)
        
        return objective_score
    
    def _prepare_features(self, X_train, y_train):
        """Prepare and cache features before parallel optimization trials."""
        logger.info("Preparing features for neural network optimization...")
        
        # Prepare data - drop sample_id for feature extraction
        X_train_features = X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_train.columns else X_train
        
        # Use the existing feature pipeline (already includes concentration features if enabled)
        # The pipeline already includes scaler unless explicitly excluded
        feature_pipeline = self.feature_pipeline
        
        # Add dimensionality reduction if configured (regardless of strategy)
        if self.config.use_dimension_reduction:
            from src.features.dimension_reduction import DimensionReductionFactory
            
            # Clone the existing pipeline steps and add dimensionality reduction
            pipeline_steps = list(feature_pipeline.steps)
            
            # Create reducer using the factory
            reducer = DimensionReductionFactory.create_reducer(
                method=self.config.dimension_reduction.method,
                params=self.config.dimension_reduction.get_params()
            )
            pipeline_steps.append(('dimension_reduction', reducer))
            logger.info(f"Adding {self.config.dimension_reduction.method} dimension reduction to pipeline")
            
            feature_pipeline = Pipeline(pipeline_steps)
        
        # Fit and transform features in one go using the complete pipeline
        logger.info("Transforming features using complete pipeline...")
        
        # Transform features using the complete pipeline
        self._cached_features = feature_pipeline.fit_transform(X_train_features, y_train)
        self._fitted_feature_pipeline = feature_pipeline
        
        # Log dimension reduction if it was applied
        if self.config.use_dimension_reduction and 'dimension_reduction' in [step[0] for step in feature_pipeline.steps]:
            # For logging purposes, estimate feature count reduction
            # We already have the final feature count, estimate original from pipeline structure
            features_after_reduction_count = self._cached_features.shape[1] 
            logger.info(f"{self.config.dimension_reduction.method.upper()} applied: reduced to {features_after_reduction_count} components")
        
        logger.info(f"Features prepared: {self._cached_features.shape[1]} features, {self._cached_features.shape[0]} samples")
    
    def optimize(self, X_train, y_train, X_val=None, y_val=None, n_trials=100, timeout=9600):
        """Run optimization with advanced pruning."""
        self.X_train = X_train
        self.y_train = y_train
        
        # Initialize enhanced optimization strategies
        dataset_size = len(X_train)
        self._enhanced_config = get_enhanced_optimization_config(
            model_name='neural_network',
            dataset_size=dataset_size,
            n_trials=n_trials,
            reports_dir=self.config.reports_dir
        )
        logger.info(f"Enhanced optimization strategies initialized for dataset_size={dataset_size}, n_trials={n_trials}")
        self.X_val = X_val
        self.y_val = y_val
        
        logger.info(f"Neural network optimization starting with {n_trials} trials and {timeout}s timeout")
        
        # Prepare features once before parallel trials
        self._prepare_features(X_train, y_train)
        
        # Determine optimal number of parallel workers based on GPU capacity
        # Avoid parallel workers when using GPU to prevent early termination issues
        if self.config.use_gpu:
            n_jobs = 1
            logger.info("GPU detected - using single worker to avoid resource conflicts")
        elif n_trials >= 20:
            # Use parallel workers only for CPU-only optimization
            n_jobs = min(3, max(1, n_trials // 10))  # 2-3 parallel workers optimal for small dataset
            logger.info(f"CPU optimization - using {n_jobs} parallel workers")
        else:
            n_jobs = 1
            logger.info("Using single worker for optimization")
        
        # Create study with adaptive pruning based on number of trials
        # Neural networks need more startup trials, so use higher minimums
        if n_trials >= 1000:
            n_startup_trials = min(150, n_trials // 8)   # 12.5% startup trials, max 150
            n_warmup_steps = 25
            interval_steps = 5
            logger.info(f"Using conservative NN pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        elif n_trials >= 500:
            n_startup_trials = min(75, n_trials // 10)   # 10% startup trials, max 75
            n_warmup_steps = 20
            interval_steps = 3
            logger.info(f"Using moderate NN pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        else:
            n_startup_trials = min(30, n_trials // 4)    # 25% startup trials, max 30
            n_warmup_steps = 15
            interval_steps = 2
            logger.info(f"Using standard NN pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        
        study = optuna.create_study(
            direction='maximize',
            pruner=optuna.pruners.MedianPruner(
                n_startup_trials=n_startup_trials,
                n_warmup_steps=n_warmup_steps,
                interval_steps=interval_steps
            ),
            sampler=optuna.samplers.TPESampler(
                n_startup_trials=min(n_startup_trials, 25),  # Use same startup as pruner, max 25
                n_ei_candidates=50,
                multivariate=True,
                warn_independent_sampling=False
            )
        )
        
        # Optimize with parallel execution if beneficial
        study.optimize(
            self.create_advanced_objective,
            n_trials=n_trials,
            timeout=timeout,
            n_jobs=n_jobs,
            show_progress_bar=True
        )
        
        self.best_params = study.best_params
        self.best_score = study.best_value
        
        # Perform parameter importance analysis (Strategy C)
        try:
            if hasattr(self, "_enhanced_config"):
                importance_analyzer = self._enhanced_config["importance_analyzer"]
                param_importance = importance_analyzer.analyze_study(study, "neural_network")
                self._param_importance = param_importance
                logger.info("Parameter importance analysis completed")
        except Exception as e:
            logger.warning(f"Parameter importance analysis failed: {e}")
            self._param_importance = {}
        
        return study
    
    def train_final_model(self, X_train, y_train, X_test, y_test, strategy: str = "simple_only", 
                         enable_reporting: bool = True, X_validation=None, y_validation=None):
        """Train final model with best parameters and generate comprehensive reports on test and validation sets."""
        if not self.best_params:
            raise ValueError("Must run optimization first")
        
        # Add GPU support and parse string parameters
        final_params = self.best_params.copy()
        
        # Parse hidden_layers string back to tuple if needed
        if 'hidden_layers' in final_params and isinstance(final_params['hidden_layers'], str):
            final_params['hidden_layers'] = tuple(map(int, final_params['hidden_layers'].split(',')))
            
        if self.config.use_gpu:
            final_params['device'] = 'cuda'
        else:
            final_params['device'] = 'cpu'
        
        # Create final pipeline using the same feature pipeline from optimization
        # This ensures dimensionality reduction is included if it was used during optimization
        final_model = NeuralNetworkRegressor(**final_params)
        
        if not hasattr(self, '_fitted_feature_pipeline') or self._fitted_feature_pipeline is None:
            raise ValueError("Must run optimization first to get fitted feature pipeline")
        
        # Log dimension reduction status
        if self.config.use_dimension_reduction and 'dimension_reduction' in [step[0] for step in self._fitted_feature_pipeline.steps]:
            # Find the dimension reduction step
            for step_name, step_obj in self._fitted_feature_pipeline.steps:
                if step_name == 'dimension_reduction':
                    reducer = step_obj
                    # Get the number of components from the fitted reducer
                    if hasattr(reducer, 'optimal_components_'):  # VAE with auto selection
                        n_components = reducer.optimal_components_
                    elif hasattr(reducer, 'n_components_'):  # Standard sklearn reducers
                        n_components = reducer.n_components_
                    elif hasattr(reducer, 'n_components'):  # Config parameter
                        n_components = reducer.n_components
                    elif hasattr(reducer, 'get_n_components'):  # Method to get components
                        n_components = reducer.get_n_components()
                    else:
                        n_components = 'unknown'
                    logger.info(f"Applying fitted {self.config.dimension_reduction.method} dimension reduction for validation")
                    logger.info(f"Using pre-fitted reducer with {n_components} components")
                    break
        
        # Create final pipeline with fitted feature pipeline and new model
        final_pipeline = Pipeline([
            ('features_and_reduction', self._fitted_feature_pipeline),
            ('model', final_model)
        ])
        
        # Prepare data - drop sample_id for feature extraction
        X_train_features = X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_train.columns else X_train
        X_test_features = X_test.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_test.columns else X_test
        
        # Extract sample IDs for detailed reporting (if available)
        if self.config.sample_id_column in X_test.columns:
            test_sample_ids = X_test[self.config.sample_id_column]
        else:
            # Create dummy sample IDs if not available
            test_sample_ids = pd.Series([f"sample_{i}" for i in range(len(X_test))], name="Sample ID")
        
        # Transform features using fitted pipeline (no refitting!)
        logger.info("Transforming features using fitted pipeline...")
        X_train_processed = self._fitted_feature_pipeline.transform(X_train_features)
        X_test_processed = self._fitted_feature_pipeline.transform(X_test_features)
        
        logger.info(f"Final feature dimensions - Train: {X_train_processed.shape}, Test: {X_test_processed.shape}")
        
        # Train ONLY the model with pre-processed features
        logger.info("Training final neural network model with pre-processed features...")
        
        # Calculate sample weights if enabled
        sample_weights = None
        if self.config.use_sample_weights:
            sample_weights = self._calculate_sample_weights(y_train)
            logger.info(f"NeuralNetwork training with sample weights (method: {getattr(self.config, 'sample_weight_method', 'default')})")
            final_model.fit(X_train_processed, y_train, sample_weight=sample_weights)
        else:
            final_model.fit(X_train_processed, y_train)
        
        # Setup calibration if sample weights are used
        self._setup_calibration_if_needed(final_model, X_train_processed, y_train)
        
        # Evaluate
        train_pred_raw = final_pipeline.predict(X_train_features)
        train_pred = train_pred_raw  # Skip sample-weight calibration
        test_pred_raw = final_pipeline.predict(X_test_features)
        test_pred = test_pred_raw  # Skip sample-weight calibration
        
        # Ensure predictions are 1D arrays for compatibility with reporters and metrics
        if train_pred.ndim > 1:
            train_pred = train_pred.flatten()
        if test_pred.ndim > 1:
            test_pred = test_pred.flatten()
        
        # Apply post-processing calibration from base class
        train_pred, test_pred = self.apply_post_calibration(
            y_train, train_pred, y_test, test_pred, model_name="Neural Network"
        )
        
        train_metrics = calculate_regression_metrics(y_train, train_pred)
        test_metrics = calculate_regression_metrics(y_test, test_pred)
        
        # Generate comprehensive reports if enabled
        if enable_reporting:
            from src.reporting.reporter import Reporter
            reporter = Reporter(self.config)
            
            # Add run results to reporter for test set
            model_name = f"optimized_neural_network_{self.model_type}"
            reporter.add_run_results(strategy, model_name, test_metrics, self.best_params or {})
            
            # Save detailed predictions and generate calibration plot for test set
            predictions_df = reporter.save_prediction_results(
                y_test, test_pred, test_sample_ids, strategy, model_name
            )
            reporter.generate_calibration_plot(predictions_df, strategy, model_name)
            
            # Additional validation set reporting if validation data is provided
            if X_validation is not None and y_validation is not None:
                # Prepare validation data
                X_validation_features = X_validation.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_validation.columns else X_validation
                
                # Extract validation sample IDs
                if self.config.sample_id_column in X_validation.columns:
                    validation_sample_ids = X_validation[self.config.sample_id_column]
                else:
                    validation_sample_ids = pd.Series([f"validation_sample_{i}" for i in range(len(X_validation))], name="Sample ID")
                
                # Make validation predictions
                validation_pred = final_pipeline.predict(X_validation_features)
                
                # Ensure predictions are 1D arrays
                if validation_pred.ndim > 1:
                    validation_pred = validation_pred.flatten()
                
                # Calculate validation metrics using the same function
                validation_metrics = calculate_regression_metrics(y_validation, validation_pred)
                
                # Use reporter methods for validation set
                validation_model_name = f"{model_name}_validation"
                
                # Save validation predictions using reporter
                validation_predictions_df = reporter.save_prediction_results(
                    y_validation, validation_pred, validation_sample_ids, strategy, validation_model_name
                )
                
                # Generate validation calibration plot using reporter
                reporter.generate_calibration_plot(validation_predictions_df, strategy, validation_model_name)
                
                # Save validation metrics using reporter
                reporter.save_validation_metrics(strategy, validation_model_name, validation_metrics, self.best_params or {})
                
                logger.info(f"Validation set reports generated for {model_name}")
                logger.info(f"   - Validation R²: {validation_metrics['r2']:.4f}, RMSE: {validation_metrics['rmse']:.4f}")
                logger.info(f"   - Validation RRMSE: {validation_metrics.get('rrmse', 0):.2f}%")
                logger.info(f"   - Validation MAE: {validation_metrics['mae']:.4f}")
                logger.info(f"   - Validation MAPE: {validation_metrics.get('mape', 0):.2f}%")
                logger.info(f"   - Validation Within 20.5%: {validation_metrics.get('within_20.5%', 0):.2f}%")
                logger.info(f"   - Validation prediction results and calibration plot saved")
                logger.info(f"   - Validation metrics report created")
            
            # Save summary report using reporter
            reporter.save_summary_report()
            
            logger.info(f"Comprehensive reports generated for {model_name}")
            logger.info(f"   - Test R²: {test_metrics['r2']:.4f}, RMSE: {test_metrics['rmse']:.4f}")
            logger.info(f"   - Test RRMSE: {test_metrics.get('rrmse', 0):.2f}%, MAE: {test_metrics['mae']:.4f}")
            logger.info(f"   - Test MAPE: {test_metrics.get('mape', 0):.2f}%, Within 20.5%: {test_metrics.get('within_20.5%', 0):.2f}%")
            logger.info(f"   - Test set prediction results saved")
            logger.info(f"   - Test set calibration plot generated") 
            logger.info(f"   - Summary report created")

            # Setup calibration if sample weights are used
            self._setup_calibration_if_needed(final_model, X_train_processed, y_train)

        # Wrap the pipeline with post-calibration if it was used
        if self.post_calibrator is not None and getattr(self.config, 'use_post_calibration', False):
            from src.models.post_calibrated_wrapper import PostCalibratedModelWrapper
            logger.info("Wrapping model with post-calibration for deployment")
            calibrated_pipeline = PostCalibratedModelWrapper(
                final_pipeline,
                self.post_calibrator,
                self.post_calibration_config
            )
            return calibrated_pipeline, train_metrics, test_metrics

        return final_pipeline, train_metrics, test_metrics
    
    def generate_optimization_report(self, study, final_pipeline, train_metrics, test_metrics, 
                                   X_test, y_test, strategy: str = "simple_only"):
        """Generate comprehensive optimization report with Optuna study insights."""
        if not hasattr(study, 'trials'):
            logger.warning("No study provided for optimization report")
            return
            
        # Extract sample IDs if available
        if hasattr(X_test, 'columns') and self.config.sample_id_column in X_test.columns:
            test_sample_ids = X_test[self.config.sample_id_column]
            X_test_features = X_test.drop(columns=[self.config.sample_id_column])
        else:
            test_sample_ids = pd.Series([f"sample_{i}" for i in range(len(X_test))], name="Sample ID")
            X_test_features = X_test
            
        # Make predictions for reporting
        test_pred = final_pipeline.predict(X_test_features)
        
        # Ensure predictions are 1D arrays for compatibility with reporters
        if test_pred.ndim > 1:
            test_pred = test_pred.flatten()
        
        from src.reporting.reporter import Reporter
        reporter = Reporter(self.config)
        
        # Add run results
        model_name = f"optimized_neural_network_{self.model_type}"
        reporter.add_run_results(strategy, model_name, test_metrics, self.best_params)
        
        # Generate detailed predictions and calibration plot
        predictions_df = reporter.save_prediction_results(
            y_test, test_pred, test_sample_ids, strategy, model_name
        )
        reporter.generate_calibration_plot(predictions_df, strategy, model_name)
        
        # Save Optuna optimization insights
        self._save_optuna_insights(study, strategy, model_name)
        
        # Generate summary report
        reporter.save_summary_report()
        
        logger.info(f"🎯 Neural Network Optimization Report Generated:")
        logger.info(f"   ✅ Best trial: {study.best_trial.number} with score: {self.best_score:.4f}")
        logger.info(f"   ✅ Test R²: {test_metrics['r2']:.4f}, RMSE: {test_metrics['rmse']:.4f}")
        logger.info(f"   ✅ Test RRMSE: {test_metrics.get('rrmse', 0):.2f}%")
        logger.info(f"   ✅ Test MAE: {test_metrics['mae']:.4f}")
        logger.info(f"   ✅ Test MAPE: {test_metrics.get('mape', 0):.2f}%")
        logger.info(f"   ✅ Test Within 20.5%: {test_metrics.get('within_20.5%', 0):.2f}%")
        logger.info(f"   ✅ Prediction results and calibration plot saved")
        logger.info(f"   ✅ Optuna study insights saved")
        
    def _save_optuna_insights(self, study, strategy: str, model_name: str):
        """Save Optuna study insights to JSON file."""
        try:
            import json
            
            # Extract key insights from the study
            insights = {
                'best_trial': {
                    'number': study.best_trial.number,
                    'value': study.best_value,
                    'params': study.best_params
                },
                'n_trials': len(study.trials),
                'optimization_history': [
                    {
                        'trial': trial.number,
                        'value': trial.value,
                        'state': trial.state.name
                    }
                    for trial in study.trials if trial.value is not None
                ],
                'best_params_summary': self.best_params,
                'model_type': self.model_type,
                'strategy': strategy
            }
            
            # Save to reports directory
            insights_path = self.config.reports_dir / f"{model_name}_optuna_insights_{self.config.run_timestamp}.json"
            with open(insights_path, 'w') as f:
                json.dump(insights, f, indent=2)
                
            logger.info(f"   ✅ Optuna insights saved to: {insights_path}")
            
        except Exception as e:
            logger.warning(f"Failed to save Optuna insights: {e}")
    
    def _get_input_feature_count(self) -> int:
        """Get the actual number of input features for dynamic architecture generation."""
        if hasattr(self, '_cached_features') and self._cached_features is not None:
            return self._cached_features.shape[1]
        else:
            # Fallback: estimate based on strategy and dimension reduction settings
            if self.config.use_dimension_reduction:
                # If dimension reduction is enabled, use the configured component count
                if hasattr(self.config, 'dimension_reduction') and hasattr(self.config.dimension_reduction, 'n_components'):
                    return self.config.dimension_reduction.n_components
                else:
                    return 10  # Default assumption from original code
            else:
                # No dimension reduction - estimate based on strategy
                if self.strategy == 'Mg_only':
                    return 15  # Estimate for P-only features
                elif self.strategy == 'simple_only':
                    return 20  # Estimate for simple features
                else:  # full_context
                    return 30  # Estimate for full context features
    
    def _generate_dynamic_architecture(self, trial, input_features: int, model_type: str) -> tuple:
        """
        Generate neural network architecture dynamically based on input feature count.
        
        Args:
            trial: Optuna trial object
            input_features: Number of input features
            model_type: 'full' or 'light'
            
        Returns:
            Tuple of layer sizes
        """
        # Parameter budget approach - limit total params based on dataset size
        # With ~600-900 samples, target 2-4x parameter-to-sample ratio
        max_params_ratio = trial.suggest_float('max_params_ratio', 2.0, 4.5)
        max_total_params = int(700 * max_params_ratio)
        
        if model_type == 'full':
            # Full model: 3-4 layers with flexible width
            architecture_type = trial.suggest_categorical('architecture_type', [
                'progressive_halving',  # Each layer = previous / 2
                'gradual_reduction',    # Each layer = previous * 0.75
                'balanced',             # Mix of reductions
                'deep_narrow',          # 4 layers, narrower
                'wide_shallow'          # 2-3 layers, wider
            ])
            
            if architecture_type == 'progressive_halving':
                first_mult = trial.suggest_float('first_mult', 1.8, 3.5)
                layer1 = max(8, int(input_features * first_mult))
                layer2 = max(4, layer1 // 2)
                layer3 = max(2, layer2 // 2)
                layers = (layer1, layer2, layer3)
                
            elif architecture_type == 'gradual_reduction':
                first_mult = trial.suggest_float('first_mult', 2.2, 4.5)
                layer1 = max(8, int(input_features * first_mult))
                layer2 = max(6, int(layer1 * 0.7))
                layer3 = max(4, int(layer2 * 0.7))
                layers = (layer1, layer2, layer3)
                
            elif architecture_type == 'balanced':
                first_mult = trial.suggest_float('first_mult', 2.0, 3.8)
                second_ratio = trial.suggest_float('second_ratio', 0.5, 0.8)
                third_ratio = trial.suggest_float('third_ratio', 0.4, 0.75)
                layer1 = max(8, int(input_features * first_mult))
                layer2 = max(6, int(layer1 * second_ratio))
                layer3 = max(4, int(layer2 * third_ratio))
                layers = (layer1, layer2, layer3)
                
            elif architecture_type == 'deep_narrow':
                first_mult = trial.suggest_float('first_mult', 1.5, 2.5)
                layer1 = max(8, int(input_features * first_mult))
                layer2 = max(6, int(layer1 * 0.75))
                layer3 = max(4, int(layer2 * 0.75))
                layer4 = max(2, int(layer3 * 0.75))
                layers = (layer1, layer2, layer3, layer4)
                
            else:  # wide_shallow
                first_mult = trial.suggest_float('first_mult', 3.0, 5.0)
                second_mult = trial.suggest_float('second_mult', 0.3, 0.6)
                layer1 = max(12, int(input_features * first_mult))
                layer2 = max(6, int(layer1 * second_mult))
                # Optional third layer
                if trial.suggest_categorical('add_third_layer', [True, False]):
                    layer3 = max(3, int(layer2 * 0.5))
                    layers = (layer1, layer2, layer3)
                else:
                    layers = (layer1, layer2)
        
        else:  # light model
            # Light model: 2-3 layers, more conservative
            architecture_type = trial.suggest_categorical('architecture_type', [
                'simple_halving',   # 2 layers: input*mult, prev/2
                'triple_light',     # 3 layers: smaller multipliers
                'minimal',          # Very small architecture
                'proportional'      # Scale with input size
            ])
            
            if architecture_type == 'simple_halving':
                first_mult = trial.suggest_float('first_mult', 1.5, 2.8)
                layer1 = max(6, int(input_features * first_mult))
                layer2 = max(3, layer1 // 2)
                layers = (layer1, layer2)
                
            elif architecture_type == 'triple_light':
                first_mult = trial.suggest_float('first_mult', 1.8, 2.5)
                layer1 = max(6, int(input_features * first_mult))
                layer2 = max(4, int(layer1 * 0.65))
                layer3 = max(2, int(layer2 * 0.65))
                layers = (layer1, layer2, layer3)
                
            elif architecture_type == 'minimal':
                first_mult = trial.suggest_float('first_mult', 1.0, 2.0)
                layer1 = max(4, int(input_features * first_mult))
                layer2 = max(2, max(layer1 // 3, 2))  # At least 2 neurons
                layers = (layer1, layer2)
                
            else:  # proportional
                # Scale architecture proportionally to input size
                if input_features <= 15:
                    # Small input: conservative
                    layer1 = max(6, int(input_features * 1.5))
                    layer2 = max(3, layer1 // 2)
                    layers = (layer1, layer2)
                else:
                    # Larger input: can afford more complexity
                    layer1 = max(8, int(input_features * 2.0))
                    layer2 = max(4, int(layer1 * 0.6))
                    layer3 = max(2, int(layer2 * 0.6))
                    layers = (layer1, layer2, layer3)
        
        # Check parameter budget and scale down if needed
        total_params = self._calculate_parameter_count(input_features, layers)
        if total_params > max_total_params:
            # Scale down proportionally
            scale_factor = (max_total_params / total_params) ** 0.5
            layers = tuple(max(2, int(layer * scale_factor)) for layer in layers)
            
        return layers
    
    def _calculate_parameter_count(self, input_features: int, layers: tuple) -> int:
        """Calculate total parameter count for a given architecture."""
        total_params = 0
        prev_layer_size = input_features
        
        for layer_size in layers:
            # Weights + biases
            total_params += (prev_layer_size * layer_size) + layer_size
            prev_layer_size = layer_size
        
        # Output layer (to 1 output)
        total_params += prev_layer_size + 1
        
        return total_params