"""
Tuner Objective Functions

This module contains various objective functions that can be used by Optuna
to guide the hyperparameter search towards different goals (e.g., robustness,
performance on specific data slices).

All functions now use configurable parameters from ObjectiveConfig instead of hardcoded values.
"""
import numpy as np
from sklearn.metrics import r2_score, mean_absolute_error
from src.config.pipeline_config import ObjectiveConfig

def calculate_robust_objective(cv_scores: np.ndarray, train_r2: float, test_r2: float, config: ObjectiveConfig = None) -> float:
    """Calculates a robust objective that balances performance and overfitting."""
    if config is None:
        config = ObjectiveConfig()
    
    cv_mean = np.mean(cv_scores)
    cv_std = np.std(cv_scores)
    
    stability_penalty = cv_std * config.stability_penalty_factor
    overfitting_penalty = max(0, train_r2 - cv_mean) * config.overfitting_penalty_factor
    
    return cv_mean - stability_penalty - overfitting_penalty

def calculate_concentration_weighted_objective(
    y_true: np.ndarray, y_pred: np.ndarray, base_r2: float, config: ObjectiveConfig = None
) -> float:
    """
    Calculates an objective with higher weights for specific concentrations.
    Uses either data-driven percentiles or fixed thresholds based on config.
    """
    if config is None:
        config = ObjectiveConfig()
    
    weights = np.ones_like(y_true, dtype=float)
    
    if config.use_data_driven_thresholds:
        # Use data-driven percentiles instead of fixed thresholds
        low_threshold = np.percentile(y_true, config.mape_low_percentile)
        high_threshold = np.percentile(y_true, config.mape_high_percentile)
        
        weights[y_true <= low_threshold] = config.low_concentration_weight
        weights[(y_true > low_threshold) & (y_true <= high_threshold)] = config.medium_concentration_weight
        weights[y_true > high_threshold] = config.high_concentration_weight
    else:
        # Use fixed thresholds from config
        weights[y_true <= config.low_concentration_threshold] = config.low_concentration_weight
        weights[(y_true > config.low_concentration_threshold) & 
                (y_true <= config.medium_concentration_threshold)] = config.medium_concentration_weight
        weights[y_true > config.medium_concentration_threshold] = config.high_concentration_weight
    
    weighted_mse = np.average((y_true - y_pred) ** 2, weights=weights)
    weighted_rmse = np.sqrt(weighted_mse)
    
    # Combine with R² to balance overall fit and weighted performance
    # Lower weighted_rmse is better, so we invert it.
    return base_r2 + (1 / (1 + weighted_rmse))

def calculate_mape_focused_objective(
    y_true: np.ndarray, y_pred: np.ndarray, base_r2: float, config: ObjectiveConfig = None
) -> float:
    """
    Calculates an objective focused on minimizing MAPE.
    Uses data-driven percentiles to define concentration ranges.
    """
    if config is None:
        config = ObjectiveConfig()
    
    # Create masks for different concentration ranges using percentiles
    low_percentile_value = np.percentile(y_true, config.mape_low_percentile)
    high_percentile_value = np.percentile(y_true, config.mape_high_percentile)
    
    low_mask = y_true < low_percentile_value
    med_mask = (y_true >= low_percentile_value) & (y_true < high_percentile_value)

    def get_mape(mask):
        if not np.any(mask): 
            return config.empty_range_penalty  # High penalty if no samples
        y_true_slice = y_true[mask]
        y_pred_slice = y_pred[mask]
        return np.mean(np.abs((y_true_slice - y_pred_slice) / y_true_slice)) * 100

    low_mape = get_mape(low_mask)
    med_mape = get_mape(med_mask)
    
    # Lower MAPE is better. We create an objective where higher is better.
    mape_score = ((1 / (1 + low_mape)) * config.low_mape_weight + 
                  (1 / (1 + med_mape)) * config.medium_mape_weight)
    
    return base_r2 * config.mape_r2_weight + mape_score * config.mape_score_weight