#!/usr/bin/env python3
"""
Enhanced Optuna Optimization Strategies

This module provides advanced optimization strategies for hyperparameter tuning:
- Multi-objective optimization (Strategy A)
- Advanced sampling for small datasets (Strategy B)  
- Parameter importance analysis (Strategy C)
- Smarter search spaces (Strategy D)
"""
import logging
import numpy as np
import optuna
from typing import Dict, List, Tuple, Optional, Any, Union
from datetime import datetime
import json
from pathlib import Path

logger = logging.getLogger(__name__)


class MultiObjectiveStrategy:
    """Strategy A: Multi-objective optimization for R² vs Training Time/Complexity"""
    
    def __init__(self, objectives: List[str] = None):
        """
        Initialize multi-objective strategy.
        
        Args:
            objectives: List of objectives like ['r2_score', 'training_time', 'model_complexity']
        """
        self.objectives = objectives or ['r2_score', 'training_time']
        logger.info(f"MultiObjective strategy initialized with objectives: {self.objectives}")
    
    def create_study(self, study_name: str = None) -> optuna.Study:
        """Create multi-objective Optuna study"""
        directions = []
        for obj in self.objectives:
            if obj in ['r2_score', 'accuracy', 'f1_score']:
                directions.append('maximize')
            elif obj in ['training_time', 'model_complexity', 'rmse', 'mae']:
                directions.append('minimize')
            else:
                directions.append('maximize')  # Default
        
        study = optuna.create_study(
            directions=directions,
            study_name=study_name,
            sampler=optuna.samplers.NSGAIISampler(
                population_size=50,
                mutation_prob=0.1,
                crossover_prob=0.9
            )
        )
        logger.info(f"Created multi-objective study with directions: {directions}")
        return study
    
    def evaluate_objectives(self, model, X_train, y_train, X_val, y_val, 
                          start_time: float) -> List[float]:
        """Evaluate multiple objectives for a model"""
        from sklearn.metrics import r2_score, mean_squared_error
        import time
        
        # Time the training
        fit_start = time.time()
        model.fit(X_train, y_train)
        training_time = time.time() - fit_start
        
        # Calculate R² score
        y_pred = model.predict(X_val)
        r2 = r2_score(y_val, y_pred)
        rmse = np.sqrt(mean_squared_error(y_val, y_pred))
        
        # Calculate model complexity (number of parameters/features used)
        if hasattr(model, 'n_estimators'):
            complexity = model.n_estimators
        elif hasattr(model, 'coef_'):
            complexity = np.count_nonzero(model.coef_)
        else:
            complexity = 100  # Default complexity score
        
        # Map objectives to values
        objective_values = []
        for obj in self.objectives:
            if obj == 'r2_score':
                objective_values.append(r2)
            elif obj == 'training_time':
                objective_values.append(training_time)
            elif obj == 'model_complexity':
                objective_values.append(complexity)
            elif obj == 'rmse':
                objective_values.append(rmse)
            else:
                objective_values.append(r2)  # Default to R²
        
        return objective_values


class AdvancedSamplingStrategy:
    """Strategy B: Advanced sampling for small datasets"""
    
    def __init__(self, dataset_size: int, n_trials: int):
        self.dataset_size = dataset_size
        self.n_trials = n_trials
        logger.info(f"AdvancedSampling strategy for dataset_size={dataset_size}, n_trials={n_trials}")
    
    def get_best_sampler(self) -> optuna.samplers.BaseSampler:
        """Choose the best sampler based on dataset size and trial count"""

        if self.dataset_size < 500:
            # Very small dataset: Use TPE with conservative settings
            # TPE handles mixed parameter types (categorical + continuous) better than CMA-ES
            startup_trials = min(40, max(20, self.n_trials // 8))
            logger.info(f"Using conservative TPESampler for very small dataset (n={self.dataset_size}, startup={startup_trials})")
            return optuna.samplers.TPESampler(
                n_startup_trials=startup_trials,
                n_ei_candidates=min(100, max(50, self.n_trials // 15)),
                multivariate=True,
                group=True,  # Enable group-wise sampling for correlated parameters
                warn_independent_sampling=False,
                constant_liar=True  # Better for parallel optimization
            )
        elif self.dataset_size < 2000:
            # Small dataset: Enhanced TPE with more conservative settings
            startup_trials = min(50, max(20, self.n_trials // 8))
            logger.info(f"Using enhanced TPESampler for small dataset (startup={startup_trials})")
            return optuna.samplers.TPESampler(
                n_startup_trials=startup_trials,
                n_ei_candidates=min(100, max(50, self.n_trials // 20)),
                multivariate=True,
                group=True,  # Enable group-wise sampling for correlated parameters
                warn_independent_sampling=False
            )
        else:
            # Larger dataset: Standard TPE
            logger.info("Using standard TPESampler for larger dataset")
            return optuna.samplers.TPESampler(
                n_startup_trials=min(30, self.n_trials // 15),
                n_ei_candidates=50,
                multivariate=True,
                warn_independent_sampling=False
            )


class ParameterImportanceAnalyzer:
    """Strategy C: Parameter importance analysis"""
    
    def __init__(self, save_path: Optional[Path] = None):
        self.save_path = save_path
        self.importance_results = {}
    
    def analyze_study(self, study: optuna.Study, model_name: str) -> Dict[str, float]:
        """Analyze parameter importance from completed study"""
        try:
            # Get parameter importance using mutual information
            importance = optuna.importance.get_param_importances(
                study, 
                evaluator=optuna.importance.MeanDecreaseImpurityImportanceEvaluator()
            )
            
            # Also get Shapley values if possible
            try:
                shapley_importance = optuna.importance.get_param_importances(
                    study,
                    evaluator=optuna.importance.ShapleyImportanceEvaluator()
                )
                logger.info(f"Shapley importance calculated for {model_name}")
            except Exception as e:
                logger.warning(f"Could not calculate Shapley importance: {e}")
                shapley_importance = {}
            
            # Combine results
            analysis_result = {
                'model_name': model_name,
                'timestamp': datetime.now().isoformat(),
                'n_trials': len(study.trials),
                'best_value': study.best_value,
                'parameter_importance': importance,
                'shapley_importance': shapley_importance,
                'top_5_params': dict(list(importance.items())[:5])
            }
            
            self.importance_results[model_name] = analysis_result
            
            # Log top parameters
            logger.info(f"=== Parameter Importance for {model_name} ===")
            for param, imp in list(importance.items())[:5]:
                logger.info(f"  {param}: {imp:.4f}")
            
            # Save to file if path provided
            if self.save_path:
                self._save_importance_results()
            
            return importance
            
        except Exception as e:
            logger.error(f"Failed to analyze parameter importance for {model_name}: {e}")
            return {}
    
    def _save_importance_results(self):
        """Save importance analysis to JSON file"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"parameter_importance_{timestamp}.json"
            filepath = self.save_path / filename
            
            with open(filepath, 'w') as f:
                json.dump(self.importance_results, f, indent=2)
            
            logger.info(f"Parameter importance saved to: {filepath}")
        except Exception as e:
            logger.error(f"Failed to save importance results: {e}")


class SmartSearchSpaceStrategy:
    """Strategy D: Smarter, correlated search spaces"""
    
    def __init__(self, model_type: str):
        self.model_type = model_type.lower()
        
        # Map model types to their parameter suggestion methods
        self.param_methods = {
            'xgboost': self.suggest_correlated_xgboost_params,
            'lightgbm': self.suggest_correlated_lightgbm_params,
            'catboost': self.suggest_correlated_catboost_params,
            'random_forest': self.suggest_correlated_random_forest_params,
            'extratrees': self.suggest_correlated_extratrees_params
        }
    
    def suggest_params(self, trial: optuna.Trial) -> Dict[str, Any]:
        """Suggest parameters for any supported model type"""
        method = self.param_methods.get(self.model_type)
        if method:
            return method(trial)
        else:
            logger.warning(f"No smart parameter suggestion for model type: {self.model_type}")
            return {}
    
    def suggest_correlated_xgboost_params(self, trial: optuna.Trial) -> Dict[str, Any]:
        """Suggest XGBoost parameters with intelligent correlations"""
        
        # First decide on tree growth strategy
        tree_growth = trial.suggest_categorical('tree_growth_strategy', ['depth_wise', 'leaf_wise'])
        
        params = {
            'random_state': 42,
            'tree_method': 'hist'
        }
        
        if tree_growth == 'depth_wise':
            # Optimize for depth-based growth
            max_depth = trial.suggest_int('max_depth', 3, 8)
            params.update({
                'max_depth': max_depth,
                'n_estimators': trial.suggest_int('n_estimators', 100, 600),
                'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.2, log=True),
                # Higher min_child_weight for deeper trees to prevent overfitting
                'min_child_weight': trial.suggest_int('min_child_weight', 
                                                    3 + max_depth // 2, 
                                                    15 + max_depth)
            })
        else:
            # Optimize for leaf-based growth (more complex)
            params.update({
                'max_depth': 0,  # Unlimited depth for leaf-wise
                'max_leaves': trial.suggest_int('max_leaves', 15, 255),
                'n_estimators': trial.suggest_int('n_estimators', 50, 400),  # Fewer trees for leaf-wise
                'learning_rate': trial.suggest_float('learning_rate', 0.02, 0.15, log=True),
                'min_child_weight': trial.suggest_int('min_child_weight', 1, 8)
            })
        
        # Correlated regularization: higher learning rate → more regularization
        base_reg = 0.5 if params['learning_rate'] > 0.1 else 0.0
        params.update({
            'reg_alpha': trial.suggest_float('reg_alpha', base_reg, base_reg + 2.0),
            'reg_lambda': trial.suggest_float('reg_lambda', base_reg, base_reg + 8.0),
            'gamma': trial.suggest_float('gamma', 0.0, 1.5 if params['learning_rate'] < 0.05 else 2.5)
        })
        
        # Subsample parameters (correlated)
        base_subsample = trial.suggest_float('base_subsample', 0.7, 1.0)
        params.update({
            'subsample': base_subsample,
            'colsample_bytree': trial.suggest_float('colsample_bytree', 
                                                  max(0.6, base_subsample - 0.2), 
                                                  base_subsample),
            'colsample_bylevel': trial.suggest_float('colsample_bylevel', 
                                                   max(0.6, base_subsample - 0.1), 
                                                   1.0),
            'colsample_bynode': trial.suggest_float('colsample_bynode', 
                                                  max(0.6, base_subsample - 0.1), 
                                                  1.0)
        })
        
        return params
    
    def suggest_correlated_lightgbm_params(self, trial: optuna.Trial) -> Dict[str, Any]:
        """Suggest LightGBM parameters with intelligent correlations"""
        
        # Start with tree complexity decision
        complexity_level = trial.suggest_categorical('complexity_level', ['simple', 'moderate', 'complex'])
        
        params = {
            'verbosity': -1,
            'random_state': 42,
            'force_col_wise': True
        }
        
        if complexity_level == 'simple':
            params.update({
                'num_leaves': trial.suggest_int('num_leaves', 10, 31),
                'max_depth': trial.suggest_int('max_depth', 3, 5),
                'n_estimators': trial.suggest_int('n_estimators', 100, 400),
                'learning_rate': trial.suggest_float('learning_rate', 0.05, 0.15),
                'min_child_samples': trial.suggest_int('min_child_samples', 5, 15)
            })
        elif complexity_level == 'moderate':
            params.update({
                'num_leaves': trial.suggest_int('num_leaves', 20, 63),
                'max_depth': trial.suggest_int('max_depth', 4, 7),
                'n_estimators': trial.suggest_int('n_estimators', 50, 350),
                'learning_rate': trial.suggest_float('learning_rate', 0.02, 0.12),
                'min_child_samples': trial.suggest_int('min_child_samples', 3, 10)
            })
        else:  # complex
            params.update({
                'num_leaves': trial.suggest_int('num_leaves', 31, 127),
                'max_depth': trial.suggest_int('max_depth', 5, 9),
                'n_estimators': trial.suggest_int('n_estimators', 30, 300),
                'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.08),
                'min_child_samples': trial.suggest_int('min_child_samples', 1, 8)
            })
        
        # Correlated regularization based on complexity
        reg_strength = {'simple': (0.0, 1.0), 'moderate': (0.0, 2.0), 'complex': (0.5, 3.0)}[complexity_level]
        params.update({
            'reg_alpha': trial.suggest_float('reg_alpha', reg_strength[0], reg_strength[1]),
            'reg_lambda': trial.suggest_float('reg_lambda', reg_strength[0], reg_strength[1] * 1.5)
        })
        
        # Feature sampling correlated with tree complexity  
        base_feature_fraction = 0.9 if complexity_level == 'simple' else 0.8 if complexity_level == 'moderate' else 0.7
        params.update({
            'feature_fraction': trial.suggest_float('feature_fraction', 
                                                  base_feature_fraction - 0.1, 
                                                  base_feature_fraction + 0.1),
            'subsample': trial.suggest_float('subsample', 
                                           base_feature_fraction - 0.05, 
                                           1.0)
        })
        
        return params
    
    def suggest_correlated_catboost_params(self, trial: optuna.Trial) -> Dict[str, Any]:
        """Suggest CatBoost parameters with intelligent correlations"""
        
        # Bootstrap strategy affects other parameters
        bootstrap_type = trial.suggest_categorical('bootstrap_type', ['Bayesian', 'Bernoulli', 'MVS'])
        
        # Base parameters
        params = {
            'bootstrap_type': bootstrap_type,
            'verbose': 0,
            'random_state': 42,
            'task_type': 'CPU'  # Will be overridden by GPU logic in optimizer
        }
        
        # Tree structure correlated with iterations
        iterations = trial.suggest_int('iterations', 50, 300)
        params['iterations'] = iterations
        
        # Learning rate inversely correlated with iterations
        if iterations < 100:
            lr_range = (0.05, 0.2)
        elif iterations < 200:
            lr_range = (0.03, 0.15)
        else:
            lr_range = (0.02, 0.1)
        params['learning_rate'] = trial.suggest_float('learning_rate', lr_range[0], lr_range[1], log=True)
        
        # Depth and regularization
        depth = trial.suggest_int('depth', 3, 6)
        params['depth'] = depth
        
        # More regularization for deeper trees
        base_l2 = 1.0 + (depth - 3) * 0.5  # Increase regularization with depth
        params['l2_leaf_reg'] = trial.suggest_float('l2_leaf_reg', base_l2, base_l2 + 6.0)
        
        # Min data correlated with depth
        params['min_data_in_leaf'] = trial.suggest_int('min_data_in_leaf', 
                                                      max(1, depth - 1), 
                                                      max(5, depth * 3))
        
        # Bootstrap-specific parameters
        if bootstrap_type == 'Bayesian':
            params['bagging_temperature'] = trial.suggest_float('bagging_temperature', 0.0, 2.0)
        elif bootstrap_type == 'Bernoulli':
            params['subsample'] = trial.suggest_float('subsample', 0.6, 1.0)
        elif bootstrap_type == 'MVS':
            params['subsample'] = trial.suggest_float('subsample', 0.7, 1.0)
        
        return params
    
    def suggest_correlated_random_forest_params(self, trial: optuna.Trial) -> Dict[str, Any]:
        """Suggest Random Forest parameters with intelligent correlations"""
        
        # Decide on complexity level first
        complexity = trial.suggest_categorical('complexity_level', ['simple', 'moderate', 'complex'])
        
        params = {'random_state': 42}
        
        if complexity == 'simple':
            params.update({
                'n_estimators': trial.suggest_int('n_estimators', 50, 200),
                'max_depth': trial.suggest_int('max_depth', 5, 15),
                'min_samples_split': trial.suggest_int('min_samples_split', 8, 20),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 4, 12)
            })
        elif complexity == 'moderate':
            params.update({
                'n_estimators': trial.suggest_int('n_estimators', 100, 400),
                'max_depth': trial.suggest_int('max_depth', 10, 25),
                'min_samples_split': trial.suggest_int('min_samples_split', 5, 15),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 2, 8)
            })
        else:  # complex
            params.update({
                'n_estimators': trial.suggest_int('n_estimators', 200, 600),
                'max_depth': trial.suggest_int('max_depth', 15, 35),
                'min_samples_split': trial.suggest_int('min_samples_split', 2, 10),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 5)
            })
        
        # Correlated feature sampling based on complexity
        base_features = {'simple': 0.8, 'moderate': 0.6, 'complex': 0.4}[complexity]
        params.update({
            'max_features': trial.suggest_float('max_features', 
                                              max(0.3, base_features - 0.2), 
                                              min(1.0, base_features + 0.2)),
            'bootstrap': trial.suggest_categorical('bootstrap', [True, False]),
        })
        
        if not params['bootstrap']:
            # If no bootstrap, be more conservative
            params['max_samples'] = trial.suggest_float('max_samples', 0.7, 1.0)
        
        return params
    
    def suggest_correlated_extratrees_params(self, trial: optuna.Trial) -> Dict[str, Any]:
        """Suggest ExtraTrees parameters with intelligent correlations"""
        
        # ExtraTrees are more random, so can handle more complexity
        complexity = trial.suggest_categorical('complexity_level', ['moderate', 'complex', 'very_complex'])
        
        params = {'random_state': 42, 'bootstrap': False}  # ExtraTrees typically don't use bootstrap
        
        if complexity == 'moderate':
            params.update({
                'n_estimators': trial.suggest_int('n_estimators', 100, 300),
                'max_depth': trial.suggest_int('max_depth', 10, 20),
                'min_samples_split': trial.suggest_int('min_samples_split', 5, 15),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 2, 8)
            })
        elif complexity == 'complex':
            params.update({
                'n_estimators': trial.suggest_int('n_estimators', 200, 500),
                'max_depth': trial.suggest_int('max_depth', 15, 30),
                'min_samples_split': trial.suggest_int('min_samples_split', 2, 10),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 5)
            })
        else:  # very_complex
            params.update({
                'n_estimators': trial.suggest_int('n_estimators', 300, 700),
                'max_depth': trial.suggest_int('max_depth', 20, 40),
                'min_samples_split': trial.suggest_int('min_samples_split', 2, 8),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 4)
            })
        
        # Feature sampling - ExtraTrees can handle more randomness
        params['max_features'] = trial.suggest_float('max_features', 0.3, 1.0)
        
        return params


# Convenience function to get enhanced optimizer configuration
def get_enhanced_optimization_config(model_name: str, dataset_size: int, n_trials: int, 
                                   reports_dir: Path = None) -> Dict[str, Any]:
    """
    Get complete enhanced optimization configuration for a model.
    
    Args:
        model_name: Name of the model (xgboost, lightgbm, catboost, etc.)
        dataset_size: Size of the training dataset
        n_trials: Number of optimization trials
        reports_dir: Directory to save parameter importance analysis
    
    Returns:
        Dictionary with all enhanced strategy components
    """
    
    # Multi-objective strategy
    multi_obj = MultiObjectiveStrategy(['r2_score', 'training_time'])
    
    # Advanced sampling strategy
    sampling = AdvancedSamplingStrategy(dataset_size, n_trials)
    
    # Parameter importance analyzer
    analyzer = ParameterImportanceAnalyzer(reports_dir)
    
    # Smart search space
    search_space = SmartSearchSpaceStrategy(model_name)
    
    return {
        'multi_objective': multi_obj,
        'advanced_sampling': sampling,
        'importance_analyzer': analyzer,
        'smart_search_space': search_space,
        'dataset_size': dataset_size,
        'n_trials': n_trials,
        'model_name': model_name
    }