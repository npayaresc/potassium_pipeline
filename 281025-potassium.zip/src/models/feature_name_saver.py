"""
Utility module for saving feature names alongside trained models.

This module provides shared functionality to save feature names from pipelines,
which can be used by model trainers, optimizers, and other model-saving components.
"""
import json
import logging
from pathlib import Path
from typing import Optional, List
from sklearn.pipeline import Pipeline

logger = logging.getLogger(__name__)


def save_feature_names(
    pipeline: Pipeline,
    model_path: Path,
    model_name: str,
    strategy: str,
    timestamp: str,
    model_type: str = 'standard'
) -> None:
    """
    Save feature names used by a model to a JSON file.

    Args:
        pipeline: Complete pipeline (features + model) or feature-only pipeline for NN
        model_path: Path where model was saved
        model_name: Name of the model
        strategy: Feature engineering strategy used
        timestamp: Training run timestamp
        model_type: Type of model ('standard', 'neural_network', 'autogluon', etc.)
    """
    try:
        # Extract feature names from the pipeline
        feature_names = _extract_feature_names(pipeline)

        # Extract metadata about transformations
        transformation_info = _extract_transformation_metadata(pipeline)

        # Save feature information
        feature_info = {
            'model_name': model_name,
            'model_path': str(model_path),
            'feature_count': len(feature_names) if feature_names else None,
            'feature_names': feature_names if feature_names else None,
            'pipeline_steps': [step_name for step_name, _ in pipeline.steps],
            'strategy': strategy,
            'timestamp': timestamp,
            'model_type': model_type,
            'transformations': transformation_info
        }

        feature_names_path = model_path.with_suffix('.feature_names.json')
        with open(feature_names_path, 'w') as f:
            json.dump(feature_info, f, indent=2)

        if feature_names:
            logger.info(f"Saved {len(feature_names)} feature names to: {feature_names_path}")
        else:
            logger.info(f"Saved feature metadata (no names available) to: {feature_names_path}")

    except Exception as e:
        logger.warning(f"Failed to save feature names for {model_name}: {e}")


def _extract_feature_names(pipeline: Pipeline) -> Optional[List[str]]:
    """
    Extract feature names from a pipeline, handling nested pipelines.

    The pipeline structure is typically:
    Pipeline([
        ('features', feature_pipeline),      # Feature engineering
        ('model', model_pipeline)            # Contains: feature_selection → dimension_reduction → regressor
    ])

    We need to extract features from the LAST transformer before the final regressor,
    which accounts for any feature selection or dimension reduction.

    Args:
        pipeline: Pipeline to extract feature names from

    Returns:
        List of feature names if available, None otherwise
    """
    feature_names = None

    try:
        # First, check if there's a nested 'model' pipeline (typical structure)
        # This would contain feature_selection, dimension_reduction, and regressor
        for step_name, transformer in pipeline.steps:
            if step_name == 'model' and hasattr(transformer, 'steps'):
                # Found nested model pipeline - extract from it
                logger.debug("Found nested 'model' pipeline, extracting from its steps")
                feature_names = _extract_from_nested_pipeline(transformer)
                if feature_names:
                    return feature_names
                break

        # If no nested pipeline or no features found, walk through main pipeline backwards
        # Exclude the final step (usually 'model' or 'regressor')
        if feature_names is None:
            for step_name, transformer in reversed(pipeline.steps[:-1]):
                # If this is a nested pipeline (like 'features' pipeline), look inside it
                if hasattr(transformer, 'steps'):
                    logger.debug(f"Step '{step_name}' is a nested pipeline with {len(transformer.steps)} steps, looking inside...")
                    # Walk backwards through nested steps to find the LAST step before scaler that has meaningful feature names
                    # This ensures we get the complete feature set after all transformations
                    steps_to_check = []
                    for sub_name, sub_transformer in reversed(transformer.steps):
                        # Skip steps that typically produce generic names
                        if sub_name in ['scaler', 'normalizer', 'standardscaler']:
                            logger.debug(f"  Skipping '{sub_name}' (typically produces generic names)")
                            continue
                        steps_to_check.append((sub_name, sub_transformer))

                    # Now check steps (which are already reversed, so first item is the step just before scaler)
                    for sub_name, sub_transformer in steps_to_check:
                        # First try feature_names_out_ attribute
                        if hasattr(sub_transformer, 'feature_names_out_'):
                            feature_names = list(sub_transformer.feature_names_out_)
                            logger.debug(f"  Extracted {len(feature_names)} feature names from '{step_name}.{sub_name}.feature_names_out_'")
                            break

                        # Try get_feature_names_out() method
                        elif hasattr(sub_transformer, 'get_feature_names_out'):
                            try:
                                names = sub_transformer.get_feature_names_out()
                                feature_names = names.tolist() if hasattr(names, 'tolist') else list(names)
                                # Check if these are meaningful names (not x0, x1, etc.)
                                if feature_names and not all(name.startswith('x') and name[1:].isdigit() for name in feature_names[:5]):
                                    logger.debug(f"  Extracted {len(feature_names)} feature names from '{step_name}.{sub_name}.get_feature_names_out()'")
                                    break
                                else:
                                    logger.debug(f"  '{sub_name}' returned generic names, continuing search...")
                            except Exception as e:
                                logger.debug(f"  get_feature_names_out() failed on '{sub_name}': {e}")
                                continue

                    if feature_names:
                        break

                # For non-pipeline steps, try direct extraction
                else:
                    # First try feature_names_out_ attribute
                    if hasattr(transformer, 'feature_names_out_'):
                        feature_names = list(transformer.feature_names_out_)
                        logger.debug(f"Extracted {len(feature_names)} feature names from '{step_name}.feature_names_out_'")
                        break
                    # Try get_feature_names_out() method
                    elif hasattr(transformer, 'get_feature_names_out'):
                        try:
                            names = transformer.get_feature_names_out()
                            feature_names = names.tolist() if hasattr(names, 'tolist') else list(names)
                            logger.debug(f"Extracted {len(feature_names)} feature names from '{step_name}.get_feature_names_out()'")
                            break
                        except Exception as e:
                            logger.debug(f"get_feature_names_out() failed on '{step_name}': {e}")
                            continue
    except Exception as e:
        logger.debug(f"Error extracting feature names: {e}")

    if feature_names is None:
        logger.debug("Could not extract feature names, will save metadata only")
        return []

    return feature_names


def _extract_from_nested_pipeline(nested_pipeline: Pipeline) -> Optional[List[str]]:
    """
    Extract feature names from a nested pipeline (e.g., model pipeline).

    Handles the complex case where feature_selection and/or dimension_reduction
    may be present:
    - Feature selection: CAN preserve feature names
    - Dimension reduction (PCA, PLS, etc.): CANNOT preserve original feature names

    Args:
        nested_pipeline: Nested pipeline to extract from

    Returns:
        List of feature names if available, None otherwise
    """
    feature_names = None
    has_dimension_reduction = False

    try:
        # First check if there's dimension reduction (which prevents feature name extraction)
        for step_name, transformer in nested_pipeline.steps[:-1]:
            if step_name == 'dimension_reduction':
                has_dimension_reduction = True
                logger.debug(f"Dimension reduction detected - original feature names not preserved")
                # Dimension reduction transforms features, so we can't get original names
                # Return None to indicate feature count should be used instead
                return None

        # If no dimension reduction, we can extract feature names
        # Walk backwards through nested pipeline steps, excluding final regressor
        for step_name, transformer in reversed(nested_pipeline.steps[:-1]):
            # Try custom get_selected_features() method (for SpectralFeatureSelector)
            if hasattr(transformer, 'get_selected_features'):
                feature_names = transformer.get_selected_features()
                if feature_names:
                    logger.debug(f"Extracted {len(feature_names)} selected features from '{step_name}'")
                    break

            # Try standard sklearn get_feature_names_out() method
            elif hasattr(transformer, 'get_feature_names_out'):
                feature_names = transformer.get_feature_names_out().tolist()
                logger.debug(f"Extracted {len(feature_names)} feature names from nested step '{step_name}'")
                break

    except Exception as e:
        logger.debug(f"Could not extract from nested pipeline: {e}")

    return feature_names


def _extract_transformation_metadata(pipeline: Pipeline) -> dict:
    """
    Extract metadata about transformations applied in the pipeline.

    Args:
        pipeline: Pipeline to extract metadata from

    Returns:
        Dictionary with transformation information
    """
    metadata = {
        'feature_selection': None,
        'dimension_reduction': None
    }

    try:
        # Check for nested 'model' pipeline
        for step_name, transformer in pipeline.steps:
            if step_name == 'model' and hasattr(transformer, 'steps'):
                # Found nested model pipeline - extract transformation info
                for nested_step_name, nested_transformer in transformer.steps:
                    if nested_step_name == 'feature_selection':
                        metadata['feature_selection'] = {
                            'method': nested_transformer.__class__.__name__,
                            'n_features_selected': len(nested_transformer.get_selected_features()) if hasattr(nested_transformer, 'get_selected_features') else None
                        }
                    elif nested_step_name == 'dimension_reduction':
                        n_components = None
                        if hasattr(nested_transformer, 'get_n_components'):
                            n_components = nested_transformer.get_n_components()
                        elif hasattr(nested_transformer, 'n_components_'):
                            n_components = nested_transformer.n_components_

                        metadata['dimension_reduction'] = {
                            'method': nested_transformer.__class__.__name__,
                            'n_components': n_components
                        }
    except Exception as e:
        logger.debug(f"Could not extract transformation metadata: {e}")

    return metadata


def save_feature_names_for_nn(
    feature_pipeline: Pipeline,
    model_path: Path,
    model_name: str,
    strategy: str,
    timestamp: str
) -> None:
    """
    Save feature names for neural network models.

    Neural network models have a separate feature pipeline, so we extract
    feature names from that pipeline specifically.

    Args:
        feature_pipeline: Feature extraction pipeline
        model_path: Path where model was saved
        model_name: Name of the model
        strategy: Feature engineering strategy used
        timestamp: Training run timestamp
    """
    try:
        # Extract feature names from the feature pipeline
        feature_names = _extract_feature_names_from_feature_pipeline(feature_pipeline)

        # Save feature information
        feature_info = {
            'model_name': model_name,
            'model_path': str(model_path),
            'feature_count': len(feature_names) if feature_names else None,
            'feature_names': feature_names if feature_names else None,
            'pipeline_steps': [step_name for step_name, _ in feature_pipeline.steps],
            'strategy': strategy,
            'timestamp': timestamp,
            'model_type': 'neural_network'
        }

        feature_names_path = model_path.with_suffix('.feature_names.json')
        with open(feature_names_path, 'w') as f:
            json.dump(feature_info, f, indent=2)

        if feature_names:
            logger.info(f"Saved {len(feature_names)} feature names to: {feature_names_path}")
        else:
            logger.info(f"Saved feature metadata (no names available) to: {feature_names_path}")

    except Exception as e:
        logger.warning(f"Failed to save feature names for neural network {model_name}: {e}")


def _extract_feature_names_from_feature_pipeline(feature_pipeline: Pipeline) -> Optional[List[str]]:
    """
    Extract feature names from a feature-only pipeline (used for neural networks).

    Args:
        feature_pipeline: Feature extraction pipeline

    Returns:
        List of feature names if available, None otherwise
    """
    feature_names = None

    try:
        # Walk through the pipeline steps backwards
        for step_name, transformer in reversed(feature_pipeline.steps):
            if hasattr(transformer, 'get_feature_names_out'):
                feature_names = transformer.get_feature_names_out().tolist()
                logger.debug(f"Extracted {len(feature_names)} feature names from step '{step_name}'")
                break
    except Exception as e:
        logger.debug(f"get_feature_names_out() not available: {e}")

    if feature_names is None:
        logger.debug("Could not extract feature names for neural network, will save metadata only")
        return []

    return feature_names
