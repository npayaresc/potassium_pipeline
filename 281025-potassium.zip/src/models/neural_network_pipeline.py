"""
Neural Network Pipeline Wrapper

This module provides a pipeline wrapper that properly handles neural network
serialization and deserialization for deployment and prediction.
"""
import torch
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.pipeline import Pipeline
from typing import Any, Dict
import logging

logger = logging.getLogger(__name__)


class NeuralNetworkPipeline(BaseEstimator, RegressorMixin):
    """
    A pipeline wrapper that combines feature engineering with neural network
    and handles proper PyTorch serialization for deployment.
    """
    
    def __init__(self, feature_pipeline: Pipeline = None, neural_network: Any = None):
        self.feature_pipeline = feature_pipeline
        self.neural_network = neural_network
        
    def predict(self, X):
        """Make predictions using the full pipeline."""
        # Apply feature engineering
        X_features = self.feature_pipeline.transform(X)
        
        # Make neural network predictions
        predictions = self.neural_network.predict(X_features)
        
        return predictions
    
    def get_params(self, deep=True):
        """Get parameters for scikit-learn compatibility."""
        params = {}
        if self.feature_pipeline is not None:
            if deep:
                params.update({f'feature_pipeline__{k}': v 
                              for k, v in self.feature_pipeline.get_params(deep=True).items()})
            else:
                params['feature_pipeline'] = self.feature_pipeline
                
        if self.neural_network is not None:
            if deep:
                params.update({f'neural_network__{k}': v 
                              for k, v in self.neural_network.get_params(deep=True).items()})
            else:
                params['neural_network'] = self.neural_network
                
        return params
    
    def set_params(self, **params):
        """Set parameters for scikit-learn compatibility."""
        # Separate feature pipeline and neural network parameters
        feature_params = {}
        nn_params = {}
        direct_params = {}
        
        for key, value in params.items():
            if key.startswith('feature_pipeline__'):
                feature_params[key[18:]] = value  # Remove 'feature_pipeline__' prefix
            elif key.startswith('neural_network__'):
                nn_params[key[16:]] = value  # Remove 'neural_network__' prefix
            else:
                direct_params[key] = value
        
        # Set direct parameters
        for key, value in direct_params.items():
            setattr(self, key, value)
            
        # Set feature pipeline parameters
        if feature_params and self.feature_pipeline is not None:
            self.feature_pipeline.set_params(**feature_params)
            
        # Set neural network parameters
        if nn_params and self.neural_network is not None:
            self.neural_network.set_params(**nn_params)
            
        return self
    
    def __getstate__(self):
        """Custom serialization to handle PyTorch components."""
        state = self.__dict__.copy()
        
        # Handle neural network serialization
        if self.neural_network is not None:
            # Save the neural network using its custom save method
            import tempfile
            import os
            
            # Create a temporary file for the neural network
            temp_dir = tempfile.mkdtemp()
            nn_path = os.path.join(temp_dir, 'neural_network.pkl')
            
            try:
                # Use the neural network's custom save method
                if hasattr(self.neural_network, 'save_model'):
                    self.neural_network.save_model(nn_path)
                    
                    # Load the saved data
                    import joblib
                    nn_data = joblib.load(nn_path)
                    state['_nn_serialized_data'] = nn_data
                    state['neural_network'] = None  # Remove the original object
                else:
                    # Fallback: try standard joblib serialization
                    logger.warning("Neural network doesn't have save_model method, using joblib")
                    
            except Exception as e:
                logger.error(f"Failed to serialize neural network: {e}")
                # Keep the original object and hope joblib can handle it
                
            finally:
                # Clean up temporary files
                try:
                    if os.path.exists(nn_path):
                        os.remove(nn_path)
                    os.rmdir(temp_dir)
                except:
                    pass
        
        return state
    
    def __setstate__(self, state):
        """Custom deserialization to handle PyTorch components."""
        # Restore the basic state
        self.__dict__.update(state)
        
        # Handle neural network deserialization
        if '_nn_serialized_data' in state:
            try:
                # Reconstruct the neural network from serialized data
                from src.models.neural_network import NeuralNetworkRegressor
                
                nn_data = state['_nn_serialized_data']
                
                # Create a new neural network instance
                self.neural_network = NeuralNetworkRegressor(**nn_data['params'])
                
                # Recreate the PyTorch model
                self.neural_network.model_ = self.neural_network._create_model(nn_data['input_dim'])
                self.neural_network.model_.load_state_dict(nn_data['model_state_dict'])
                self.neural_network.model_.eval()
                
                # Restore other attributes
                self.neural_network.scaler_ = nn_data['scaler']
                self.neural_network.train_losses_ = nn_data.get('train_losses', [])
                self.neural_network.val_losses_ = nn_data.get('val_losses', [])
                
                logger.info("Successfully reconstructed neural network from serialized data")
                
            except Exception as e:
                logger.error(f"Failed to deserialize neural network: {e}")
                self.neural_network = None
                
            # Clean up the temporary data
            if '_nn_serialized_data' in self.__dict__:
                del self.__dict__['_nn_serialized_data']
    
    def __repr__(self):
        """String representation."""
        return f"NeuralNetworkPipeline(feature_pipeline={self.feature_pipeline}, neural_network={self.neural_network})"