#!/usr/bin/env python3
"""
Unified Model Optimization Script

This script provides a unified interface to optimize any model in the pipeline
with model-specific hyperparameter tuning and advanced optimization techniques.
"""
import argparse
import logging
import pandas as pd
import numpy as np
from typing import Optional
from pathlib import Path
from datetime import datetime
import joblib

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.config.pipeline_config import config
from src.config.config_manager import config_manager
from src.data_management.data_manager import DataManager
from src.utils.helpers import setup_logging
from src.utils.custom_exceptions import DataValidationError
from src.models.feature_name_saver import save_feature_names

# Import all optimizers
from .optimize_xgboost import XGBoostOptimizer
from .optimize_lightgbm import LightGBMOptimizer
from .optimize_catboost import CatBoostOptimizer
from .optimize_random_forest import RandomForestOptimizer
from .optimize_extratrees import ExtraTreesOptimizer
from .optimize_neural_network import NeuralNetworkOptimizer
from .optimize_autogluon import AutoGluonOptimizer

logger = logging.getLogger(__name__)

class UnifiedModelOptimizer:
    """Unified interface for optimizing any model type."""
    
    OPTIMIZER_MAP = {
        'xgboost': XGBoostOptimizer,
        'lightgbm': LightGBMOptimizer,
        'catboost': CatBoostOptimizer,
        'random_forest': RandomForestOptimizer,
        'extratrees': ExtraTreesOptimizer,
        'neural_network': NeuralNetworkOptimizer,
        'neural_network_light': NeuralNetworkOptimizer,
        'autogluon': AutoGluonOptimizer,
    }
    
    def __init__(self):
        self.results = {}

    def optimize_model_with_shared_features(self, model_name: str, config, strategy: str,
                                           X_train_transformed, y_train,
                                           X_test_transformed, y_test,
                                           shared_pipeline, shared_feature_selector,
                                           X_train_raw, X_test_raw,
                                           n_trials: int, timeout: int,
                                           use_parallel_features: bool, feature_n_jobs: int):
        """
        Optimize a model using pre-computed shared features.

        Args:
            model_name: Name of model to optimize
            config: Pipeline configuration
            strategy: Feature strategy
            X_train_transformed: Pre-computed training features
            y_train: Training targets
            X_test_transformed: Pre-computed test features
            y_test: Test targets
            shared_pipeline: Fitted pipeline used to create features
            shared_feature_selector: Fitted feature selector (or None)
            X_train_raw: Original training data (for final model pipeline)
            X_test_raw: Original test data (for final model pipeline)
            n_trials: Number of optimization trials
            timeout: Timeout per trial
            use_parallel_features: Whether features were created in parallel
            feature_n_jobs: Number of jobs for parallel feature creation

        Returns:
            Dictionary with optimization results
        """
        if model_name not in self.OPTIMIZER_MAP:
            raise ValueError(f"Model '{model_name}' not supported. Available: {list(self.OPTIMIZER_MAP.keys())}")

        logger.info(f"Optimizing {model_name} with {X_train_transformed.shape[1]} shared features")

        # Initialize optimizer
        optimizer_class = self.OPTIMIZER_MAP[model_name]

        # Handle neural network variants
        if model_name == 'neural_network_light':
            optimizer = optimizer_class(config, strategy, model_type='light',
                                      use_parallel_features=use_parallel_features,
                                      feature_n_jobs=feature_n_jobs)
        elif model_name == 'neural_network':
            optimizer = optimizer_class(config, strategy, model_type='full',
                                      use_parallel_features=use_parallel_features,
                                      feature_n_jobs=feature_n_jobs)
        else:
            optimizer = optimizer_class(config, strategy,
                                      use_parallel_features=use_parallel_features,
                                      feature_n_jobs=feature_n_jobs)

        # Store raw data for potential use
        optimizer.X_train = X_train_raw
        optimizer.y_train = y_train
        optimizer.X_test = X_test_raw
        optimizer.y_test = y_test

        # Run optimization with hold-out validation for consistency
        from sklearn.model_selection import train_test_split
        X_opt_train, X_opt_val, y_opt_train, y_opt_val = train_test_split(
            X_train_transformed, y_train, test_size=0.15, random_state=42
        )
        logger.info(f"Using hold-out validation for {model_name} optimization")
        logger.info(f"  Opt train: {X_opt_train.shape}, Opt val: {X_opt_val.shape}")

        # CRITICAL: Inject SPLIT features into optimizer to match the data passed to optimize()
        # This prevents shape mismatches between cached features and labels
        optimizer._cached_features = X_opt_train  # Use SPLIT training features
        optimizer._cached_val_features = X_opt_val  # Use SPLIT validation features
        optimizer._fitted_feature_pipeline = shared_pipeline
        optimizer._fitted_feature_selector = shared_feature_selector
        optimizer._pipeline_fitted = True
        optimizer.use_holdout_validation = True

        logger.info(f"Injected shared features into {model_name} optimizer - skipping feature computation")

        # Run optimization (features already cached, won't recompute)
        study = optimizer.optimize(X_opt_train, y_opt_train, X_opt_val, y_opt_val, n_trials, timeout)

        # Train final model with full training data and shared pipeline
        if model_name in ['neural_network', 'neural_network_light']:
            final_pipeline, train_metrics, test_metrics = optimizer.train_final_model(
                X_train_raw, y_train, X_test_raw, y_test,
                strategy=strategy, enable_reporting=True
            )
        else:
            final_pipeline, train_metrics, test_metrics = optimizer.train_final_model(
                X_train_raw, y_train, X_test_raw, y_test
            )

        # Store results
        self.results[model_name] = {
            'optimizer': optimizer,
            'study': study,
            'pipeline': final_pipeline,
            'train_metrics': train_metrics,
            'test_metrics': test_metrics,
            'best_params': optimizer.best_params,
            'best_score': optimizer.best_score
        }

        # Save model
        from main import get_display_strategy_name
        timestamp = config.run_timestamp
        display_strategy = get_display_strategy_name(strategy, getattr(config, 'use_raw_spectral_data', False))
        model_path = config.model_dir / f"optimized_{model_name}_{display_strategy}_{timestamp}.pkl"
        joblib.dump(final_pipeline, model_path)

        # Save feature names
        save_feature_names(final_pipeline, model_path, model_name, strategy, timestamp, model_type='optimized')

        # Save optimized configuration
        optimized_config = config.copy(deep=True)
        setattr(optimized_config.model_params, model_name, optimizer.best_params)
        config_name = f"optimized_{model_name}_{display_strategy}_{timestamp}"
        description = f"Optimized {model_name.title()} - R²: {test_metrics['r2']:.4f}, Strategy: {display_strategy} (Shared Features)"
        config_manager.save_config(optimized_config, config_name, description)

        # Log results
        logger.info(f"{model_name} optimization completed successfully")
        logger.info(f"Best optimization score: {optimizer.best_score:.4f}")
        logger.info(f"Final test R²: {test_metrics['r2']:.4f}")
        logger.info(f"Final test RMSE: {test_metrics['rmse']:.4f}")
        logger.info(f"Model saved to: {model_path}")

        return {
            'model_name': model_name,
            'strategy': strategy,
            'optimization_score': optimizer.best_score,
            'train_r2': train_metrics['r2'],
            'test_r2': test_metrics['r2'],
            'test_rmse': test_metrics['rmse'],
            'test_mae': test_metrics['mae'],
            'model_path': model_path,
            'config_name': config_name,
            'best_params': optimizer.best_params,
            'pipeline': final_pipeline,
            'test_metrics': test_metrics
        }

    def optimize_model(self, model_name: str, config, strategy: str = 'full_context',
                      X_train=None, y_train=None, X_test=None, y_test=None,
                      n_trials: int = 200, timeout: int = 3600,
                      use_parallel_features: Optional[bool] = None, feature_n_jobs: Optional[int] = None):
        """Optimize a specific model."""

        # Use config defaults if not provided
        if use_parallel_features is None:
            use_parallel_features = config.parallel.use_feature_parallel
        if feature_n_jobs is None:
            feature_n_jobs = config.parallel.feature_n_jobs

        # Check and handle NaN values in input data
        if X_train is not None:
            if isinstance(X_train, pd.DataFrame):
                if X_train.isnull().any().any():
                    nan_cols = X_train.columns[X_train.isnull().any()].tolist()
                    logger.warning(f"[{model_name.upper()}] Training data contains NaN in columns: {nan_cols[:10]}...")
                    X_train = X_train.fillna(0)
                    logger.info(f"[{model_name.upper()}] Filled NaN values with 0 in training data")
            elif isinstance(X_train, np.ndarray) and np.isnan(X_train).any():
                nan_count = np.sum(np.isnan(X_train))
                logger.warning(f"[{model_name.upper()}] Training data contains {nan_count} NaN values")
                X_train = np.nan_to_num(X_train, nan=0.0)
                logger.info(f"[{model_name.upper()}] Replaced NaN values with 0 in training data")

        if X_test is not None:
            if isinstance(X_test, pd.DataFrame):
                if X_test.isnull().any().any():
                    X_test = X_test.fillna(0)
                    logger.info(f"[{model_name.upper()}] Filled NaN values with 0 in test data")
            elif isinstance(X_test, np.ndarray) and np.isnan(X_test).any():
                X_test = np.nan_to_num(X_test, nan=0.0)
                logger.info(f"[{model_name.upper()}] Replaced NaN values with 0 in test data")
        
        if model_name not in self.OPTIMIZER_MAP:
            raise ValueError(f"Model '{model_name}' not supported. Available: {list(self.OPTIMIZER_MAP.keys())}")
        
        logger.info(f"Starting optimization for {model_name} with strategy {strategy}")
        logger.info(f"Using {n_trials} trials with {timeout}s timeout per model")
        
        # Initialize optimizer
        optimizer_class = self.OPTIMIZER_MAP[model_name]
        
        # Handle neural network variants
        if model_name == 'neural_network_light':
            optimizer = optimizer_class(config, strategy, model_type='light', use_parallel_features=use_parallel_features, feature_n_jobs=feature_n_jobs)
        elif model_name == 'neural_network':
            optimizer = optimizer_class(config, strategy, model_type='full', use_parallel_features=use_parallel_features, feature_n_jobs=feature_n_jobs)
        else:
            optimizer = optimizer_class(config, strategy, use_parallel_features=use_parallel_features, feature_n_jobs=feature_n_jobs)
        
        # Run optimization with appropriate signature
        # All optimizers now support hold-out validation to avoid CV/evaluation mismatch
        if X_test is not None and y_test is not None:
            from sklearn.model_selection import train_test_split
            # Use small validation split to leave most data for training
            X_opt_train, X_opt_val, y_opt_train, y_opt_val = train_test_split(
                X_train, y_train, test_size=0.15, random_state=42)
            logger.info(f"Using hold-out validation for {model_name} optimization to match final evaluation approach")
            study = optimizer.optimize(X_opt_train, y_opt_train, X_opt_val, y_opt_val, n_trials, timeout)
        else:
            # Fall back to cross-validation if no test data available
            logger.info(f"No test data available, using cross-validation for {model_name} optimization")
            study = optimizer.optimize(X_train, y_train, None, None, n_trials, timeout)
        
        # Train final model with strategy parameter for neural networks (enables reporting)
        # For neural networks, check if validation data should be used
        if model_name in ['neural_network', 'neural_network_light']:
            # Check if we have validation data configured
            X_validation = None
            y_validation = None
            
            # If validation directory is specified in config, try to load validation data
            if hasattr(config, 'custom_validation_dir') and config.custom_validation_dir:
                try:
                    # This would require implementing validation data loading logic
                    # For now, we'll pass None and let the method work without validation data
                    pass
                except Exception as e:
                    logger.warning(f"Could not load validation data: {e}")
            
            final_pipeline, train_metrics, test_metrics = optimizer.train_final_model(
                X_train, y_train, X_test, y_test, strategy=strategy, enable_reporting=True,
                X_validation=X_validation, y_validation=y_validation
            )
        else:
            final_pipeline, train_metrics, test_metrics = optimizer.train_final_model(
                X_train, y_train, X_test, y_test
            )
        
        # Store results
        self.results[model_name] = {
            'optimizer': optimizer,
            'study': study,
            'pipeline': final_pipeline,
            'train_metrics': train_metrics,
            'test_metrics': test_metrics,
            'best_params': optimizer.best_params,
            'best_score': optimizer.best_score
        }
        
        # Save model with display strategy name
        from main import get_display_strategy_name
        timestamp = config.run_timestamp
        display_strategy = get_display_strategy_name(strategy, getattr(config, 'use_raw_spectral_data', False))
        model_path = config.model_dir / f"optimized_{model_name}_{display_strategy}_{timestamp}.pkl"
        joblib.dump(final_pipeline, model_path)

        # Save feature names
        save_feature_names(final_pipeline, model_path, model_name, strategy, timestamp, model_type='optimized')

        # Save optimized configuration
        optimized_config = config.copy(deep=True)
        setattr(optimized_config.model_params, model_name, optimizer.best_params)
        config_name = f"optimized_{model_name}_{display_strategy}_{timestamp}"
        description = f"Optimized {model_name.title()} - R²: {test_metrics['r2']:.4f}, Strategy: {display_strategy}"
        config_manager.save_config(optimized_config, config_name, description)
        
        # Log results
        logger.info(f"{model_name} optimization completed successfully")
        logger.info(f"Best optimization score: {optimizer.best_score:.4f}")
        logger.info(f"Final test R²: {test_metrics['r2']:.4f}")
        logger.info(f"Final test RMSE: {test_metrics['rmse']:.4f}")
        logger.info(f"Final test RRMSE: {test_metrics.get('rrmse', 0):.2f}%")
        logger.info(f"Final test MAE: {test_metrics['mae']:.4f}")
        logger.info(f"Final test MAPE: {test_metrics.get('mape', 0):.2f}%")
        logger.info(f"Final test Within 20.5%: {test_metrics.get('within_20.5%', 0):.2f}%")
        logger.info(f"Model saved to: {model_path}")
        
        return {
            'model_name': model_name,
            'strategy': strategy,
            'optimization_score': optimizer.best_score,
            'train_r2': train_metrics['r2'],
            'test_r2': test_metrics['r2'],
            'test_rmse': test_metrics['rmse'],
            'test_mae': test_metrics['mae'],
            'model_path': model_path,
            'config_name': config_name,
            'best_params': optimizer.best_params,
            'pipeline': final_pipeline,  # Add the pipeline to the returned result
            'test_metrics': test_metrics  # Also add test_metrics for consistency
        }
    
    def optimize_multiple_models(self, model_names: list, config, strategy: str = 'full_context',
                                X_train=None, y_train=None, X_test=None, y_test=None,
                                n_trials: int = 200, timeout: int = 3600,
                                use_parallel_features: Optional[bool] = None, feature_n_jobs: Optional[int] = None):
        """Optimize multiple models with shared feature pipeline for consistency."""

        # Use config defaults if not provided
        if use_parallel_features is None:
            use_parallel_features = config.parallel.use_feature_parallel
        if feature_n_jobs is None:
            feature_n_jobs = config.parallel.feature_n_jobs

        # CRITICAL FIX: Create shared feature pipeline ONCE for all models
        # This ensures all models see IDENTICAL features, preventing the bug where
        # each optimizer creates slightly different features due to preprocessing variations
        logger.info("="*80)
        logger.info("CREATING SHARED FEATURE PIPELINE FOR ALL MODELS")
        logger.info(f"Strategy: {strategy}, Models: {model_names}")
        logger.info("="*80)

        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler
        from src.features.feature_engineering import create_feature_pipeline

        # Drop sample_id for feature extraction if present
        X_train_features = X_train.drop(columns=[config.sample_id_column]) if config.sample_id_column in X_train.columns else X_train
        X_test_features = X_test.drop(columns=[config.sample_id_column]) if config.sample_id_column in X_test.columns else X_test

        # Create feature engineering pipeline (same as in optimizers)
        feature_transformer = create_feature_pipeline(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)

        # Build full pipeline with scaler
        pipeline_steps = [
            ('features', feature_transformer),
            ('scaler', StandardScaler())
        ]

        # Add dimension reduction if configured (same as in optimizers)
        if config.use_dimension_reduction:
            from src.features.dimension_reduction import DimensionReductionFactory
            reducer = DimensionReductionFactory.create_reducer(
                method=config.dimension_reduction.method,
                params=config.dimension_reduction.get_params()
            )
            pipeline_steps.append(('dimension_reduction', reducer))
            logger.info(f"Adding {config.dimension_reduction.method} dimension reduction to shared pipeline")

        shared_pipeline = Pipeline(pipeline_steps)

        # FIT and TRANSFORM features ONCE
        logger.info("Fitting shared feature pipeline on training data...")
        X_train_transformed = shared_pipeline.fit_transform(X_train_features, y_train)
        logger.info(f"Transforming test data with shared pipeline...")
        X_test_transformed = shared_pipeline.transform(X_test_features)

        logger.info(f"Shared features created successfully:")
        logger.info(f"  Training: {X_train_transformed.shape}")
        logger.info(f"  Test: {X_test_transformed.shape}")

        # Apply feature selection if configured (same as in optimizers)
        # Priority: SHAP-based selection > Standard selection
        shared_feature_selector = None
        if config.use_shap_feature_selection:
            from src.features.shap_feature_selector import SHAPBasedFeatureSelector

            if not config.shap_importance_file:
                raise ValueError(
                    "use_shap_feature_selection is enabled but shap_importance_file is not specified.\n"
                    "Run SHAP analysis first: ./run_shap_analysis.sh <model_path>\n"
                    "Then specify the SHAP importance file: --shap-features models/<model>_shap_importance.csv"
                )

            logger.info(f"[UNIFIED OPTIMIZER] Applying SHAP-based feature selection")
            logger.info(f"  - SHAP file: {config.shap_importance_file}")
            logger.info(f"  - Top N features: {config.shap_top_n_features}")

            # Convert to DataFrame with feature names for SHAP selector
            try:
                if hasattr(feature_transformer, 'get_feature_names_out'):
                    temp_feature_names = feature_transformer.get_feature_names_out()
                else:
                    temp_feature_names = [f"feature_{i}" for i in range(X_train_transformed.shape[1])]
            except Exception as e:
                logger.warning(f"Failed to get feature names from feature_transformer: {e}")
                temp_feature_names = [f"feature_{i}" for i in range(X_train_transformed.shape[1])]

            X_train_df = pd.DataFrame(X_train_transformed, columns=temp_feature_names)
            X_test_df = pd.DataFrame(X_test_transformed, columns=temp_feature_names)

            shared_feature_selector = SHAPBasedFeatureSelector(
                shap_importance_file=config.shap_importance_file,
                top_n=config.shap_top_n_features,
                min_importance=config.shap_min_importance
            )
            X_train_transformed_df = shared_feature_selector.fit_transform(X_train_df, y_train)
            X_test_transformed_df = shared_feature_selector.transform(X_test_df)

            # Convert back to numpy
            X_train_transformed = X_train_transformed_df.values if isinstance(X_train_transformed_df, pd.DataFrame) else X_train_transformed_df
            X_test_transformed = X_test_transformed_df.values if isinstance(X_test_transformed_df, pd.DataFrame) else X_test_transformed_df

            logger.info(f"[UNIFIED OPTIMIZER] SHAP feature selection complete: {X_train_df.shape[1]} → {X_train_transformed.shape[1]} features")

        elif config.use_feature_selection:
            from src.features.feature_selector import SpectralFeatureSelector
            logger.info(f"Applying feature selection: {config.feature_selection_method}")
            shared_feature_selector = SpectralFeatureSelector(config)
            X_train_transformed = shared_feature_selector.fit_transform(X_train_transformed, y_train)
            X_test_transformed = shared_feature_selector.transform(X_test_transformed)
            logger.info(f"Features after selection: {X_train_transformed.shape[1]}")

        # Convert to DataFrames for consistency
        # Use SHAP selected feature names if available
        if config.use_shap_feature_selection and shared_feature_selector is not None:
            feature_names = shared_feature_selector.get_feature_names_out().tolist()
        else:
            feature_names = [f"feature_{i}" for i in range(X_train_transformed.shape[1])]
        if hasattr(y_train, 'index'):
            X_train_df = pd.DataFrame(X_train_transformed, columns=feature_names, index=y_train.index)
        else:
            X_train_df = pd.DataFrame(X_train_transformed, columns=feature_names)
        X_test_df = pd.DataFrame(X_test_transformed, columns=feature_names)

        logger.info("="*80)
        logger.info(f"SHARED PIPELINE READY - All {len(model_names)} models will use identical features")
        logger.info("="*80)

        results = []

        # Optimize each model with SHARED features
        for model_name in model_names:
            try:
                logger.info(f"\nStarting optimization for {model_name} with SHARED features")

                result = self.optimize_model_with_shared_features(
                    model_name, config, strategy,
                    X_train_df, y_train, X_test_df, y_test,
                    shared_pipeline, shared_feature_selector,
                    X_train, X_test,  # Original data for final model pipeline
                    n_trials, timeout, use_parallel_features, feature_n_jobs
                )
                results.append(result)
                
                print(f"\n--- {model_name.upper()} OPTIMIZATION RESULTS ---")
                print(f"Strategy: {result['strategy']}")
                print(f"Optimization Score: {result['optimization_score']:.4f}")
                print(f"Train R²: {result['train_r2']:.4f}")
                print(f"Test R²: {result['test_r2']:.4f}")
                print(f"Test RMSE: {result['test_rmse']:.4f}")
                print(f"Test MAE: {result['test_mae']:.4f}")
                print(f"Model saved to: {result['model_path']}")
                print("=" * 50)
                
            except Exception as e:
                logger.error(f"Failed to optimize {model_name}: {e}")
                continue
        
        # Create comparison DataFrame
        if results:
            comparison_df = pd.DataFrame(results)
            comparison_df = comparison_df.sort_values('test_r2', ascending=False)
            
            print(f"\n--- MODEL COMPARISON SUMMARY ---")
            print(comparison_df[['model_name', 'test_r2', 'test_rmse', 'optimization_score']].to_string(index=False))
            print("=" * 50)
            
            # Save comparison results
            timestamp = config.run_timestamp
            comparison_path = config.reports_dir / f"model_optimization_comparison_{strategy}_{timestamp}.csv"
            comparison_df.to_csv(comparison_path, index=False)
            logger.info(f"Comparison results saved to: {comparison_path}")
        
        return results
    
    def get_best_model(self):
        """Get the best performing model from optimization results."""
        if not self.results:
            return None
        
        best_model_name = max(self.results.keys(), 
                             key=lambda k: self.results[k]['test_metrics']['r2'])
        return best_model_name, self.results[best_model_name]


def setup_pipeline_config(use_gpu: bool = False, validation_dir=None, config_path=None):
    """Sets up dynamic configuration values and creates all necessary directories."""
    if config_path:
        stored_config_path = Path(config_path)
        updated_config = config_manager.apply_config(config, stored_config_path)
        logger.info(f"Loaded configuration from: {config_path}")
    else:
        updated_config = config
    
    updated_config.run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    updated_config.use_gpu = use_gpu
    if validation_dir is not None:
        updated_config.custom_validation_dir = validation_dir
    
    if use_gpu:
        logger.info("GPU mode enabled - models will use CUDA acceleration where available")
    else:
        logger.info("GPU mode disabled - models will use CPU only")
    
    project_root = Path(__file__).resolve().parents[2]
    
    # Define all paths relative to the project root
    data_dir = project_root / "data"
    raw_data_dir = data_dir / "raw" / "data_5278_Phase3"
    processed_data_dir = data_dir / "processed"
    averaged_files_dir = data_dir / "averaged_files_per_sample"
    cleansed_files_dir = data_dir / "cleansed_files_per_sample"
    model_dir = project_root / "models"
    reports_dir = project_root / "reports"
    log_dir = project_root / "logs"
    bad_files_dir = project_root / "bad_files"
    bad_prediction_files_dir = project_root / "bad_prediction_files"
    reference_data_path = project_root / "data" / "reference_data" / "Final_Lab_Data_Nico_New.xlsx"
    
    # Create all directories first
    for dir_path in [
        processed_data_dir, averaged_files_dir, cleansed_files_dir,
        model_dir, reports_dir, log_dir, bad_files_dir, bad_prediction_files_dir
    ]:
        dir_path.mkdir(parents=True, exist_ok=True)
    
    # Assign paths to config
    updated_config.data_dir = data_dir
    updated_config.raw_data_dir = raw_data_dir
    updated_config.processed_data_dir = processed_data_dir
    updated_config.averaged_files_dir = averaged_files_dir
    updated_config.cleansed_files_dir = cleansed_files_dir
    updated_config.model_dir = model_dir
    updated_config.reports_dir = reports_dir
    updated_config.log_dir = log_dir
    updated_config.bad_files_dir = bad_files_dir
    updated_config.bad_prediction_files_dir = bad_prediction_files_dir
    updated_config.reference_data_path = reference_data_path
    updated_config.sample_id_column = "Sample ID"
    
    setup_logging()
    return updated_config