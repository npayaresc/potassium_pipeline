#!/usr/bin/env python3
"""
Dedicated AutoGluon Optimization Script

This script focuses specifically on optimizing AutoGluon for better R² performance
with advanced techniques and comprehensive hyperparameter tuning.
"""
import argparse
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import cross_val_score, KFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import optuna
from datetime import datetime
import joblib

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.config.pipeline_config import config
from src.config.config_manager import config_manager
from src.data_management.data_manager import DataManager
from src.features.feature_engineering import create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.models.custom_autogluon import AutoGluonRegressor
from src.reporting.reporter import Reporter
from src.utils.helpers import calculate_regression_metrics, setup_logging
from src.cleansing.data_cleanser import DataCleanser
from src.utils.custom_exceptions import DataValidationError
from src.models.base_optimizer import BaseOptimizer
from src.models.enhanced_optuna_strategies import get_enhanced_optimization_config

logger = logging.getLogger(__name__)

class AutoGluonOptimizer(BaseOptimizer):
    """Advanced AutoGluon optimization with spectral data focus."""
    
    def __init__(self, config, strategy='full_context', use_parallel_features=False, feature_n_jobs=-1):
        super().__init__(config)  # Initialize BaseOptimizer
        self.config = config
        self.strategy = strategy
        self.use_parallel_features = use_parallel_features
        self.feature_n_jobs = feature_n_jobs
        
        # Use concentration-aware features if enabled in config
        if config.use_concentration_features:
            logger.info("Using enhanced feature pipeline with concentration-aware features for AutoGluon optimization")
            self.feature_pipeline = create_enhanced_feature_pipeline_with_concentration(config, strategy, exclude_scaler=False, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
        else:
            logger.info(f"Using standard feature pipeline for AutoGluon optimization (parallel={use_parallel_features}, feature_n_jobs={feature_n_jobs})")
            self.feature_pipeline = create_feature_pipeline(config, strategy, exclude_scaler=False, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
            
        self.best_params = None
        self.best_score = float('-inf')
        self._cached_features = None  # Cache transformed features
        self._fitted_feature_pipeline = None
        self._cached_val_features = None  # Cache validation features
        self.use_holdout_validation = False  # Initialize to False
        self._temp_model_counter = 0
        
    def _precompute_features(self):
        """Pre-compute and cache features for parallel optimization."""
        if self._cached_features is not None:
            return  # Already computed
            
        # Prepare data - drop sample_id for feature extraction
        X_train_features = self.X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_train.columns else self.X_train
        
        # Prepare validation data if using hold-out validation
        X_val_features = None
        if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and hasattr(self, 'X_val') and self.X_val is not None:
            if hasattr(self.X_val, 'drop') and hasattr(self.X_val, 'columns'):
                # X_val is a DataFrame
                X_val_features = self.X_val.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_val.columns else self.X_val
            else:
                # X_val is not a DataFrame (maybe array), use as is
                X_val_features = self.X_val
        
        # Build pipeline steps
        pipeline_steps = [
            ('features', self.feature_pipeline),
            ('scaler', StandardScaler())
        ]
        
        # Add feature selection if enabled
        # Priority: SHAP-based selection > Standard selection
        if self.config.use_shap_feature_selection:
            from src.features.shap_feature_selector import SHAPBasedFeatureSelector

            if not self.config.shap_importance_file:
                raise ValueError(
                    "use_shap_feature_selection is enabled but shap_importance_file is not specified.\n"
                    "Run SHAP analysis first: ./run_shap_analysis.sh <model_path>\n"
                    "Then specify the SHAP importance file: --shap-features models/<model>_shap_importance.csv"
                )

            shap_selector = SHAPBasedFeatureSelector(
                shap_importance_file=self.config.shap_importance_file,
                top_n=self.config.shap_top_n_features,
                min_importance=self.config.shap_min_importance
            )
            pipeline_steps.append(('feature_selection', shap_selector))
            logger.info(f"[SHAP FEATURE SELECTION] Enabled - File: {self.config.shap_importance_file}, "
                       f"Top N: {self.config.shap_top_n_features}")

        elif self.config.use_feature_selection:
            from src.features.feature_selector import SpectralFeatureSelector
            feature_selector = SpectralFeatureSelector(self.config)
            pipeline_steps.append(('feature_selection', feature_selector))
            logger.info(f"[FEATURE SELECTION] Enabled - Method: {self.config.feature_selection_method}, "
                       f"Target features: {self.config.n_features_to_select}")
        
        # Add dimension reduction if configured
        if self.config.use_dimension_reduction:
            from src.features.dimension_reduction import DimensionReductionFactory
            reducer = DimensionReductionFactory.create_reducer(
                method=self.config.dimension_reduction.method,
                params=self.config.dimension_reduction.get_params()
            )
            pipeline_steps.append(('dimension_reduction', reducer))
            logger.info(f"Adding {self.config.dimension_reduction.method} dimension reduction to pipeline")
        
        feature_pipeline = Pipeline(pipeline_steps)
        
        # Transform features step by step to log intermediate counts
        # Step 1: Feature engineering
        features_transformed = feature_pipeline.named_steps['features'].fit_transform(X_train_features, self.y_train)
        features_after_engineering = features_transformed.shape[1]
        logger.info(f"Features after engineering: {features_after_engineering}")
        
        # Step 2: Scaling
        features_scaled = feature_pipeline.named_steps['scaler'].fit_transform(features_transformed)
        
        # Step 2.5: Feature selection (if enabled)
        if (self.config.use_shap_feature_selection or self.config.use_feature_selection) and 'feature_selection' in feature_pipeline.named_steps:
            feature_selector = feature_pipeline.named_steps['feature_selection']
            features_selected = feature_selector.fit_transform(features_scaled, self.y_train)
            features_after_selection = features_selected.shape[1]
            logger.info(f"[FEATURE SELECTION] Applied: {features_scaled.shape[1]} → {features_after_selection} features")
            features_for_reduction = features_selected
            # Update feature names for selected features
            selected_feature_names = [f"feature_{i}" for i in range(features_after_selection)]
        else:
            features_for_reduction = features_scaled
        
        # Step 3: Dimension reduction (if enabled)
        if self.config.use_dimension_reduction and 'dimension_reduction' in feature_pipeline.named_steps:
            reducer = feature_pipeline.named_steps['dimension_reduction']
            
            # Special handling for PLS which requires target values
            if hasattr(reducer, '__class__') and reducer.__class__.__name__ == 'PLSReducer':
                features_final = reducer.fit_transform(features_for_reduction, self.y_train)
            else:
                features_final = reducer.fit_transform(features_for_reduction)
            
            features_after_reduction = features_final.shape[1]
            logger.info(f"{self.config.dimension_reduction.method.upper()} applied: {features_for_reduction.shape[1]} → {features_after_reduction} components")
        else:
            features_final = features_for_reduction
            if (self.config.use_shap_feature_selection or self.config.use_feature_selection) and 'feature_selection' in feature_pipeline.named_steps:
                logger.info(f"No dimension reduction applied - using {features_after_selection} selected features")
            else:
                logger.info(f"No dimension reduction applied - using all {features_after_engineering} features")
        
        # Convert to DataFrame with proper column names to maintain feature name consistency
        if (self.config.use_shap_feature_selection or self.config.use_feature_selection) and 'feature_selection' in feature_pipeline.named_steps:
            # Use the selected feature names we created above
            feature_names = selected_feature_names
        elif self.config.use_dimension_reduction and 'dimension_reduction' in feature_pipeline.named_steps:
            # For dimension reduction, create generic feature names
            feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
        else:
            # For non-reduced, non-selected features, try to get original feature names
            try:
                # Get feature names from the feature engineering pipeline
                feature_transformer = feature_pipeline.named_steps['features']
                if hasattr(feature_transformer, 'get_feature_names_out'):
                    feature_names = feature_transformer.get_feature_names_out()
                    # Make sure we have the right number of names
                    if len(feature_names) != features_final.shape[1]:
                        feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
                else:
                    # Fallback to generic names
                    feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
            except:
                # Fallback to generic names
                feature_names = [f"feature_{i}" for i in range(features_final.shape[1])]
        
        # Create DataFrame with proper column names
        # Handle case where y_train might be numpy array without index attribute
        if hasattr(self.y_train, 'index'):
            # y_train is pandas Series with index
            index_to_use = self.y_train.index
        else:
            # y_train is numpy array - no index available
            index_to_use = None
        
        self._cached_features = pd.DataFrame(features_final, columns=feature_names, index=index_to_use)
        self._fitted_feature_pipeline = feature_pipeline
        
        # Transform validation data with the same fitted pipeline if using hold-out validation
        if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and X_val_features is not None:
            val_features_transformed = self._fitted_feature_pipeline.transform(X_val_features)

            # Use the same feature names as training (they should match after applying same transformations)
            val_feature_names = [f"feature_{i}" for i in range(val_features_transformed.shape[1])]

            self._cached_val_features = pd.DataFrame(val_features_transformed, columns=val_feature_names)
            logger.info(f"Validation features cached: {self._cached_val_features.shape}")
        else:
            self._cached_val_features = None
        
        logger.info(f"Features going into model: {self._cached_features.shape[1]} (with proper column names)")
        logger.info(f"Training samples: {self._cached_features.shape[0]}")
        logger.info(f"Feature names: {list(self._cached_features.columns[:5])}{'...' if len(self._cached_features.columns) > 5 else ''}")
        
    def create_advanced_objective(self, trial):
        """Advanced objective function combining multiple metrics."""
        
        # Create unique temporary model path for this trial
        self._temp_model_counter += 1
        temp_model_path = self.config.model_dir / f"temp_autogluon_trial_{trial.number}_{self._temp_model_counter}"
        temp_model_path.mkdir(parents=True, exist_ok=True)
        
        # Suggest hyperparameters optimized for spectral data
        autogluon_config = self.config.autogluon.model_copy(deep=True)
        
        # Core AutoGluon parameters
        autogluon_config.time_limit = trial.suggest_int('time_limit', 600, 1800)  # 10-30 minutes
        autogluon_config.presets = trial.suggest_categorical('presets', ['medium_quality', 'good_quality', 'high_quality'])
        
        # Bagging and ensemble parameters
        autogluon_config.ag_args_fit['num_bag_folds'] = trial.suggest_int('num_bag_folds', 3, 8)
        autogluon_config.ag_args_fit['num_bag_sets'] = trial.suggest_int('num_bag_sets', 1, 2)
        autogluon_config.ag_args_fit['num_stack_levels'] = trial.suggest_int('num_stack_levels', 0, 2)
        
        # Model exclusions for speed and stability
        model_exclusions = ['KNN', 'FASTAI', 'TABPFN']
        if trial.suggest_categorical('exclude_slow_models', [True, False]):
            model_exclusions.extend(['NN_TORCH'])
        autogluon_config.excluded_model_types = model_exclusions
        
        # Enhanced parameter suggestion with smart search space (Strategy D)  
        # Note: AutoGluon uses its own hyperparameter spaces, so we keep original logic
        
        # Optimize key hyperparameters for tree models
        gbm_params = {
            'num_boost_round': trial.suggest_int('gbm_num_boost_round', 100, 500),
            'learning_rate': trial.suggest_float('gbm_learning_rate', 0.01, 0.1, log=True),
            'num_leaves': trial.suggest_int('gbm_num_leaves', 15, 127),
            'feature_fraction': trial.suggest_float('gbm_feature_fraction', 0.6, 1.0),
            'min_data_in_leaf': trial.suggest_int('gbm_min_data_in_leaf', 2, 10)
        }
        
        xgb_params = {
            'n_estimators': trial.suggest_int('xgb_n_estimators', 100, 500),
            'max_depth': trial.suggest_int('xgb_max_depth', 4, 10),
            'learning_rate': trial.suggest_float('xgb_learning_rate', 0.01, 0.1, log=True),
            'subsample': trial.suggest_float('xgb_subsample', 0.6, 1.0),
            'colsample_bytree': trial.suggest_float('xgb_colsample_bytree', 0.6, 1.0),
            'reg_alpha': trial.suggest_float('xgb_reg_alpha', 0.0, 2.0),
            'reg_lambda': trial.suggest_float('xgb_reg_lambda', 0.0, 3.0)
        }
        
        cat_params = {
            'iterations': trial.suggest_int('cat_iterations', 100, 500),
            'learning_rate': trial.suggest_float('cat_learning_rate', 0.01, 0.1, log=True),
            'depth': trial.suggest_int('cat_depth', 4, 10),
            'min_data_in_leaf': trial.suggest_int('cat_min_data_in_leaf', 2, 10),
            'l2_leaf_reg': trial.suggest_float('cat_l2_leaf_reg', 0.1, 10.0)
        }
        
        # Update hyperparameters
        autogluon_config.hyperparameters = {
            'GBM': [gbm_params],
            'XGB': [xgb_params],
            'CAT': [cat_params],
            'RF': [{'n_estimators': trial.suggest_int('rf_n_estimators', 100, 300),
                   'max_features': trial.suggest_categorical('rf_max_features', ['sqrt', 0.6, 0.8]),
                   'max_depth': trial.suggest_int('rf_max_depth', 10, 25),
                   'min_samples_leaf': trial.suggest_int('rf_min_samples_leaf', 2, 8)}],
            'XT': [{'n_estimators': trial.suggest_int('xt_n_estimators', 100, 300),
                   'max_features': trial.suggest_categorical('xt_max_features', ['sqrt', 0.6, 0.8]),
                   'max_depth': trial.suggest_int('xt_max_depth', 10, 25),
                   'min_samples_leaf': trial.suggest_int('xt_min_samples_leaf', 2, 8)}]
        }
        
        # Add GPU support if available
        if self.config.use_gpu:
            autogluon_config.ag_args_fit['num_gpus'] = 1
        else:
            autogluon_config.ag_args_fit['num_gpus'] = 0
        
        # Use pre-computed features (no feature computation in parallel workers)
        if self._cached_features is None:
            logger.error("Features not pre-computed! Call _precompute_features() first.")
            return -1000.0
        
        # Prepare data - drop sample_id for index matching
        X_train_features = self.X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_train.columns else self.X_train
        
        # Create AutoGluon model with cached features
        try:
            # Get feature names, handling concentration features pipeline
            try:
                feature_columns = self._fitted_feature_pipeline.get_feature_names_out()
            except Exception as e:
                logger.debug(f"Could not get feature names from pipeline: {e}")
                # Build feature names manually for concentration features pipeline
                feature_columns = _build_feature_names_from_pipeline_helper(self._fitted_feature_pipeline)
                if feature_columns is None:
                    # Fallback to generic names
                    feature_columns = [f"feature_{i}" for i in range(self._cached_features.shape[1])]
            
            # Create DataFrame with safe index handling
            index_to_use = X_train_features.index if hasattr(X_train_features, 'index') else None
            X_cached_df = pd.DataFrame(
                self._cached_features, 
                columns=feature_columns,
                index=index_to_use
            )
            
            # Create AutoGluon regressor
            autogluon_regressor = AutoGluonRegressor(
                config=autogluon_config, 
                model_path=temp_model_path
            )
            
            if hasattr(self, 'use_holdout_validation') and self.use_holdout_validation and self._cached_val_features is not None:
                # Use hold-out validation (matches final evaluation approach)
                X_val_cached_df = pd.DataFrame(
                    self._cached_val_features, 
                    columns=[f"feature_{i}" for i in range(self._cached_val_features.shape[1])]
                )
                
                # Train AutoGluon on all training data
                autogluon_regressor.fit(X_cached_df, self.y_train)
                
                # Predict on validation set
                y_val_pred = autogluon_regressor.predict(X_val_cached_df)
                
                # Calculate metrics
                from sklearn.metrics import r2_score, mean_squared_error
                r2_score_val = r2_score(self.y_val, y_val_pred)
                rmse_score_val = np.sqrt(mean_squared_error(self.y_val, y_val_pred))
                
                # Use single values (no variance for single evaluation)
                r2_scores = [r2_score_val]
                rmse_scores = [rmse_score_val]
            else:
                # Recommendation #1: 5-fold CV for more stable estimates
                # Recommendation #4: Stratified CV to ensure balanced concentration ranges
                y_train_array = np.array(self.y_train)
                n_bins = min(5, len(np.unique(y_train_array)))
                y_binned = pd.qcut(y_train_array, q=n_bins, labels=False, duplicates='drop')

                try:
                    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
                    cv_splits = list(cv.split(X_cached_df, y_binned))
                except Exception as e:
                    logger.warning(f"Stratified CV failed ({e}), falling back to regular KFold")
                    cv = KFold(n_splits=5, shuffle=True, random_state=42)
                    cv_splits = list(cv.split(X_cached_df))

                # Custom cross-validation for AutoGluon (since it doesn't follow sklearn API exactly)
                r2_scores = []
                rmse_scores = []

                for fold, (train_idx, val_idx) in enumerate(cv_splits):
                    X_fold_train = X_cached_df.iloc[train_idx]
                    y_fold_train = self.y_train.iloc[train_idx] if hasattr(self.y_train, 'iloc') else pd.Series(self.y_train[train_idx])
                    X_fold_val = X_cached_df.iloc[val_idx]
                    y_fold_val = self.y_train.iloc[val_idx] if hasattr(self.y_train, 'iloc') else pd.Series(self.y_train[val_idx])
                    
                    # Create fold-specific temporary path
                    fold_model_path = temp_model_path / f"fold_{fold}"
                    fold_model_path.mkdir(parents=True, exist_ok=True)
                    
                    # Train AutoGluon on fold
                    fold_regressor = AutoGluonRegressor(
                        config=autogluon_config.model_copy(deep=True), 
                        model_path=fold_model_path
                    )
                    fold_regressor.fit(X_fold_train, y_fold_train)
                    
                    # Predict on validation fold
                    y_pred = fold_regressor.predict(X_fold_val)
                    
                    # Calculate metrics
                    from sklearn.metrics import r2_score, mean_squared_error
                    r2 = r2_score(y_fold_val, y_pred)
                    rmse = np.sqrt(mean_squared_error(y_fold_val, y_pred))
                    
                    r2_scores.append(r2)
                    rmse_scores.append(rmse)
                    
                    # Clean up fold model to save space
                    import shutil
                    try:
                        shutil.rmtree(fold_model_path)
                    except:
                        pass
            
            # Clean up temporary model path
            try:
                import shutil
                shutil.rmtree(temp_model_path)
            except:
                pass
            
        except Exception as e:
            logger.error(f"AutoGluon cross-validation failed: {e}")
            # Clean up on failure
            try:
                import shutil
                shutil.rmtree(temp_model_path)
            except:
                pass
            return -1000.0
        
        # Combined objective: maximize R² while minimizing RMSE variance
        r2_mean = np.mean(r2_scores)
        r2_std = np.std(r2_scores)
        rmse_mean = np.mean(rmse_scores)
        rmse_std = np.std(rmse_scores)
        
        # Weighted combination favoring R² with stability penalty
        stability_penalty = 0.2 * (r2_std + rmse_std)  # Higher penalty for AutoGluon instability
        objective_score = r2_mean - stability_penalty
        
        # Log trial results
        logger.info(f"Trial {trial.number}: R²={r2_mean:.4f}, RMSE={rmse_mean:.4f}, Score={objective_score:.4f}")
        
        # Report intermediate results
        trial.report(objective_score, step=0)
        
        return objective_score
    
    def optimize(self, X_train, y_train, X_val=None, y_val=None, n_trials=50, timeout=7200):
        """Run optimization with advanced pruning.
        
        Args:
            X_train: Training features
            y_train: Training targets  
            X_val: Validation features (if None, uses cross-validation)
            y_val: Validation targets (if None, uses cross-validation)
        """
        self.X_train = X_train
        self.y_train = y_train
        self.X_val = X_val
        self.y_val = y_val
        
        # Check if validation data is properly provided
        valid_X_val = X_val is not None and hasattr(X_val, '__len__') and len(X_val) > 0
        valid_y_val = y_val is not None and hasattr(y_val, '__len__') and len(y_val) > 0
        self.use_holdout_validation = valid_X_val and valid_y_val
        
        if X_val is not None or y_val is not None:
            # Some validation data was provided but may be invalid
            if not self.use_holdout_validation:
                logger.warning(f"Invalid validation data provided: X_val={type(X_val)}, y_val={type(y_val)}")
                logger.warning("Falling back to cross-validation")

        if self.use_holdout_validation:
            logger.info("Using hold-out validation (matches final evaluation approach)")
        else:
            logger.info("Using cross-validation (may not match final evaluation)")
        
        # Pre-compute features once before parallel optimization to avoid redundant computation
        logger.info("Pre-computing features for parallel optimization...")
        self._precompute_features()
        logger.info(f"Features pre-computed. Shape: {self._cached_features.shape}")
        
        # For AutoGluon, use conservative parallelization due to complex ensemble training
        from multiprocessing import cpu_count
        config_n_jobs = getattr(self.config.parallel, 'model_n_jobs', 1)
        
        if config_n_jobs == -1:
            n_jobs = max(1, min(2, cpu_count() // 4))  # Very conservative for AutoGluon
            logger.info(f"Using {n_jobs} parallel workers for AutoGluon optimization (auto-detected)")
        elif config_n_jobs > 2:
            n_jobs = 2  # Limit AutoGluon to 2 parallel trials max
            logger.info(f"Limiting AutoGluon to {n_jobs} parallel workers (from config: {config_n_jobs})")
        elif config_n_jobs > 1:
            n_jobs = config_n_jobs
            logger.info(f"Using {n_jobs} parallel workers for AutoGluon optimization")
        else:
            n_jobs = 1
            logger.info("Using single worker for AutoGluon optimization")
        
        # Create study with adaptive pruning based on number of trials
        # For high trial counts (1000+), use more conservative pruning
        if n_trials >= 1000:
            n_startup_trials = min(100, n_trials // 10)  # 10% startup trials, max 100
            n_warmup_steps = 20
            interval_steps = 5
            logger.info(f"Using conservative pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        elif n_trials >= 500:
            n_startup_trials = min(50, n_trials // 15)   # ~7% startup trials, max 50
            n_warmup_steps = 15
            interval_steps = 3
            logger.info(f"Using moderate pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        else:
            n_startup_trials = min(20, n_trials // 5)    # 20% startup trials, max 20
            n_warmup_steps = 10
            interval_steps = 2
            logger.info(f"Using standard pruning for {n_trials} trials: startup={n_startup_trials}, warmup={n_warmup_steps}, interval={interval_steps}")
        
        # Create study with adaptive pruning
        study = optuna.create_study(
            direction='maximize',
            pruner=optuna.pruners.MedianPruner(
                n_startup_trials=n_startup_trials,
                n_warmup_steps=n_warmup_steps,
                interval_steps=interval_steps
            ),
            sampler=optuna.samplers.TPESampler(
                n_startup_trials=min(n_startup_trials, 20),  # Use same startup as pruner, max 20
                n_ei_candidates=min(50, max(24, n_trials // 40)),  # Adaptive EI candidates
                multivariate=True,
                warn_independent_sampling=False
            )
        )
        
        # Optimize
        study.optimize(
            self.create_advanced_objective,
            n_trials=n_trials,
            timeout=timeout,
            n_jobs=n_jobs,
            show_progress_bar=True
        )
        
        self.best_params = study.best_params
        self.best_score = study.best_value
        
        # Perform parameter importance analysis (Strategy C)
        try:
            if hasattr(self, "_enhanced_config"):
                importance_analyzer = self._enhanced_config["importance_analyzer"]
                param_importance = importance_analyzer.analyze_study(study, "lightgbm")
                self._param_importance = param_importance
                logger.info("Parameter importance analysis completed")
        except Exception as e:
            logger.warning(f"Parameter importance analysis failed: {e}")
            self._param_importance = {}
        
        return study
    
    def train_final_model(self, X_train, y_train, X_test, y_test):
        """Train final model with best parameters."""
        if not self.best_params:
            raise ValueError("Must run optimization first")
        
        # Create final AutoGluon config with best parameters
        final_config = self.config.autogluon.model_copy(deep=True)
        
        # Apply best parameters
        final_config.time_limit = self.best_params.get('time_limit', 1800)
        final_config.presets = self.best_params.get('presets', 'medium_quality')
        final_config.ag_args_fit['num_bag_folds'] = self.best_params.get('num_bag_folds', 5)
        final_config.ag_args_fit['num_bag_sets'] = self.best_params.get('num_bag_sets', 1)
        final_config.ag_args_fit['num_stack_levels'] = self.best_params.get('num_stack_levels', 1)
        
        # Update hyperparameters with best parameters
        gbm_params = {k.replace('gbm_', ''): v for k, v in self.best_params.items() if k.startswith('gbm_')}
        xgb_params = {k.replace('xgb_', ''): v for k, v in self.best_params.items() if k.startswith('xgb_')}
        cat_params = {k.replace('cat_', ''): v for k, v in self.best_params.items() if k.startswith('cat_')}
        rf_params = {k.replace('rf_', ''): v for k, v in self.best_params.items() if k.startswith('rf_')}
        xt_params = {k.replace('xt_', ''): v for k, v in self.best_params.items() if k.startswith('xt_')}
        
        final_config.hyperparameters = {
            'GBM': [gbm_params] if gbm_params else final_config.hyperparameters.get('GBM', [{}]),
            'XGB': [xgb_params] if xgb_params else final_config.hyperparameters.get('XGB', [{}]),
            'CAT': [cat_params] if cat_params else final_config.hyperparameters.get('CAT', [{}]),
            'RF': [rf_params] if rf_params else final_config.hyperparameters.get('RF', [{}]),
            'XT': [xt_params] if xt_params else final_config.hyperparameters.get('XT', [{}])
        }
        
        # Add GPU support
        if self.config.use_gpu:
            final_config.ag_args_fit['num_gpus'] = 1
        else:
            final_config.ag_args_fit['num_gpus'] = 0
        
        # Create final model path
        final_model_path = (
            self.config.model_dir / "autogluon" / f"optimized_{self.strategy}_{self.config.run_timestamp}"
        )
        final_model_path.mkdir(parents=True, exist_ok=True)
        
        # Prepare data - drop sample_id for feature extraction
        X_train_features = X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_train.columns else X_train
        X_test_features = X_test.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_test.columns else X_test
        
        # Log dimension reduction status  
        if self.config.use_dimension_reduction and 'dimension_reduction' in self._fitted_feature_pipeline.named_steps:
            reducer = self._fitted_feature_pipeline.named_steps['dimension_reduction']
            # Get the number of components from the fitted reducer
            if hasattr(reducer, 'optimal_components_'):  # VAE with auto selection
                n_components = reducer.optimal_components_
            elif hasattr(reducer, 'n_components_'):  # Standard sklearn reducers
                n_components = reducer.n_components_
            elif hasattr(reducer, 'n_components'):  # Config parameter
                n_components = reducer.n_components
            elif hasattr(reducer, 'get_n_components'):  # Method to get components
                n_components = reducer.get_n_components()
            else:
                n_components = 'unknown'
            logger.info(f"Applying fitted {self.config.dimension_reduction.method} dimension reduction for validation")
            logger.info(f"Using pre-fitted reducer with {n_components} components")
        
        # Use fitted feature pipeline for final model
        logger.info("Transforming features using fitted pipeline...")
        X_train_processed = self._fitted_feature_pipeline.transform(X_train_features)
        X_test_processed = self._fitted_feature_pipeline.transform(X_test_features)
        
        logger.info(f"Final feature dimensions - Train: {X_train_processed.shape}, Test: {X_test_processed.shape}")
        
        # Get feature names, handling concentration features pipeline
        try:
            feature_columns = self._fitted_feature_pipeline.get_feature_names_out()
        except Exception as e:
            logger.debug(f"Could not get feature names from pipeline: {e}")
            # Build feature names manually for concentration features pipeline
            feature_columns = self._build_feature_names_from_pipeline()
            if feature_columns is None:
                # Fallback to generic names
                feature_columns = [f"feature_{i}" for i in range(X_train_processed.shape[1])]
        
        # Safe index handling
        train_index_to_use = X_train_features.index if hasattr(X_train_features, 'index') else None
        test_index_to_use = X_test_features.index if hasattr(X_test_features, 'index') else None
        
        X_train_processed_df = pd.DataFrame(
            X_train_processed, 
            columns=feature_columns,
            index=train_index_to_use
        )
        X_test_processed_df = pd.DataFrame(
            X_test_processed, 
            columns=feature_columns,
            index=test_index_to_use
        )
        
        # Train final AutoGluon model
        final_regressor = AutoGluonRegressor(
            config=final_config, 
            model_path=final_model_path
        )
        final_regressor.fit(X_train_processed_df, y_train)
        
        # Evaluate
        train_pred = final_regressor.predict(X_train_processed_df)
        test_pred = final_regressor.predict(X_test_processed_df)
        
        # Apply post-processing calibration if enabled
        train_pred, test_pred = self.apply_post_calibration(
            y_train, train_pred, y_test, test_pred, "AutoGluon"
        )
        
        train_metrics = calculate_regression_metrics(y_train, train_pred)
        test_metrics = calculate_regression_metrics(y_test, test_pred)

        # Wrap the model with post-calibration if it was used
        if self.post_calibrator is not None and getattr(self.config, 'use_post_calibration', False):
            from src.models.post_calibrated_wrapper import PostCalibratedModelWrapper
            logger.info("Wrapping model with post-calibration for deployment")
            calibrated_regressor = PostCalibratedModelWrapper(
                final_regressor,
                self.post_calibrator,
                self.post_calibration_config
            )
            return calibrated_regressor, train_metrics, test_metrics

        return final_regressor, train_metrics, test_metrics

def main():
    parser = argparse.ArgumentParser(description="AutoGluon Optimization")
    parser.add_argument("--strategy", default="full_context", help="Feature strategy")
    parser.add_argument("--trials", type=int, default=50, help="Number of optimization trials")
    parser.add_argument("--timeout", type=int, default=7200, help="Timeout in seconds")
    parser.add_argument("--gpu", action="store_true", help="Use GPU")
    args = parser.parse_args()
    
    # Setup
    from src.models.optimize_xgboost import setup_pipeline_config, run_data_preparation, load_and_clean_data
    cfg = setup_pipeline_config(use_gpu=args.gpu)
    run_data_preparation(cfg)
    full_dataset, data_manager = load_and_clean_data(cfg)
    train_df, test_df = data_manager.create_reproducible_splits(full_dataset)
    
    # Extract features and targets
    X_train = train_df.drop(columns=[cfg.target_column])
    y_train = train_df[cfg.target_column]
    
    X_test = test_df.drop(columns=[cfg.target_column])
    y_test = test_df[cfg.target_column]
    
    # Optimize
    optimizer = AutoGluonOptimizer(cfg, args.strategy)
    study = optimizer.optimize(X_train, y_train, args.trials, args.timeout)
    
    # Train final model
    final_regressor, train_metrics, test_metrics = optimizer.train_final_model(
        X_train, y_train, X_test, y_test
    )
    
    # Results
    print(f"\nOptimization Results:")
    print(f"Best R² Score: {optimizer.best_score:.4f}")
    print(f"Best Parameters: {optimizer.best_params}")
    print(f"\nFinal Model Performance:")
    print(f"Train R²: {train_metrics['r2']:.4f}")
    print(f"Test R²: {test_metrics['r2']:.4f}")
    print(f"Test RMSE: {test_metrics['rmse']:.4f}")
    
    # Save configuration
    optimized_config = cfg.copy(deep=True)
    config_name = f"optimized_autogluon_{args.strategy}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    config_manager.save_config(optimized_config, config_name, 
                             f"Optimized AutoGluon config - R²: {test_metrics['r2']:.4f}")

def _build_feature_names_from_pipeline_helper(pipeline):
    """
    Helper function to build feature names from pipeline.
    Moved outside class for module-level access.
    """
    try:
        current_names = ['wavelengths', 'intensities']
        
        # Step 1: SpectralFeatureGenerator
        spectral_step = pipeline.named_steps.get('spectral_features')
        if spectral_step and hasattr(spectral_step, 'get_feature_names_out'):
            current_names = list(spectral_step.get_feature_names_out())
        
        # Step 2: ConcentrationRangeFeatures
        concentration_step = pipeline.named_steps.get('concentration_features')
        if concentration_step and hasattr(concentration_step, 'get_feature_names_out'):
            concentration_names = concentration_step.get_feature_names_out(current_names)
            current_names = list(concentration_names)
        
        return current_names
    except Exception:
        return None

if __name__ == "__main__":
    main()