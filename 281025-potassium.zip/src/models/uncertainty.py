"""
Uncertainty Quantification for Potassium Predictions

Provides prediction intervals using multiple methods:
1. Quantile Regression (XGBoost, LightGBM)
2. Bootstrap Ensemble
3. Model Variance (for ensembles)
4. Conformal Prediction (distribution-free)
"""

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Literal
from pathlib import Path
import pickle

logger = logging.getLogger(__name__)


class UncertaintyQuantifier:
    """
    Quantify prediction uncertainty using multiple methods.

    Provides prediction intervals like: "Predicted 2.3% K ± 0.3%" (68% confidence)
    """

    def __init__(
        self,
        method: Literal['quantile', 'bootstrap', 'ensemble', 'conformal', 'combined'] = 'combined',
        confidence_level: float = 0.68,  # 1-sigma (68% confidence interval)
        n_bootstrap: int = 100,
        random_state: int = 42
    ):
        """
        Initialize uncertainty quantifier.

        Args:
            method: Uncertainty quantification method
                - 'quantile': Quantile regression (requires quantile models)
                - 'bootstrap': Bootstrap resampling
                - 'ensemble': Variance across ensemble models
                - 'conformal': Conformal prediction (distribution-free)
                - 'combined': Use all available methods
            confidence_level: Confidence level for intervals (default 68% = 1σ)
            n_bootstrap: Number of bootstrap samples
            random_state: Random seed for reproducibility
        """
        self.method = method
        self.confidence_level = confidence_level
        self.n_bootstrap = n_bootstrap
        self.random_state = random_state

        # Quantile levels for prediction intervals
        alpha = 1 - confidence_level
        self.lower_quantile = alpha / 2
        self.upper_quantile = 1 - alpha / 2

        # Storage for calibration
        self.calibration_residuals: Optional[np.ndarray] = None
        self.conformal_scores: Optional[np.ndarray] = None

        logger.info(f"UncertaintyQuantifier initialized: method={method}, confidence={confidence_level:.1%}")

    def fit(self, y_true: np.ndarray, y_pred: np.ndarray):
        """
        Fit/calibrate uncertainty quantification on validation data.

        Args:
            y_true: True values
            y_pred: Predicted values
        """
        residuals = np.abs(y_true - y_pred)
        self.calibration_residuals = residuals

        # Conformal prediction scores (non-conformity scores)
        self.conformal_scores = residuals

        logger.info(f"Calibrated uncertainty on {len(y_true)} samples")
        logger.info(f"  Mean absolute residual: {np.mean(residuals):.4f}")
        logger.info(f"  Std of residuals: {np.std(residuals):.4f}")

    def predict_with_intervals(
        self,
        model: Any,
        X: np.ndarray,
        models_ensemble: Optional[List[Any]] = None
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Make predictions with uncertainty intervals.

        Args:
            model: Trained model (main predictor)
            X: Features
            models_ensemble: Optional list of models for ensemble uncertainty

        Returns:
            predictions: Point predictions
            lower_bounds: Lower confidence bounds
            upper_bounds: Upper confidence bounds
        """
        predictions = model.predict(X)
        n_samples = len(predictions)

        if self.method == 'quantile':
            lower, upper = self._quantile_intervals(model, X)

        elif self.method == 'bootstrap':
            lower, upper = self._bootstrap_intervals(model, X)

        elif self.method == 'ensemble':
            if models_ensemble is None or len(models_ensemble) < 2:
                logger.warning("Ensemble method requires multiple models. Falling back to conformal.")
                lower, upper = self._conformal_intervals(predictions)
            else:
                lower, upper = self._ensemble_intervals(models_ensemble, X)

        elif self.method == 'conformal':
            lower, upper = self._conformal_intervals(predictions)

        elif self.method == 'combined':
            # Use conformal as base, enhance with ensemble if available
            lower_conf, upper_conf = self._conformal_intervals(predictions)

            if models_ensemble and len(models_ensemble) >= 2:
                lower_ens, upper_ens = self._ensemble_intervals(models_ensemble, X)
                # Average the two methods
                lower = (lower_conf + lower_ens) / 2
                upper = (upper_conf + upper_ens) / 2
            else:
                lower, upper = lower_conf, upper_conf

        else:
            raise ValueError(f"Unknown method: {self.method}")

        return predictions, lower, upper

    def _quantile_intervals(
        self,
        model: Any,
        X: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get prediction intervals from quantile regression models.

        Requires model to have quantile prediction capability.
        """
        try:
            # Try XGBoost quantile prediction
            if hasattr(model, 'predict'):
                # Check if it's a quantile regressor
                if hasattr(model, 'quantile'):
                    lower = model.predict(X, quantile=self.lower_quantile)
                    upper = model.predict(X, quantile=self.upper_quantile)
                    return lower, upper

                # Fall back to residual-based intervals
                logger.warning("Model doesn't support quantile prediction. Using residual-based intervals.")
                return self._conformal_intervals(model.predict(X))

        except Exception as e:
            logger.warning(f"Quantile prediction failed: {e}. Using conformal intervals.")
            return self._conformal_intervals(model.predict(X))

    def _bootstrap_intervals(
        self,
        model: Any,
        X: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Bootstrap-based prediction intervals (placeholder for now).

        In practice, would require retraining on bootstrap samples.
        Falls back to conformal prediction.
        """
        logger.warning("Bootstrap intervals require multiple trained models. Using conformal.")
        predictions = model.predict(X)
        return self._conformal_intervals(predictions)

    def _ensemble_intervals(
        self,
        models: List[Any],
        X: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Prediction intervals based on ensemble variance.

        Args:
            models: List of trained models
            X: Features

        Returns:
            Lower and upper bounds based on ensemble predictions
        """
        # Get predictions from all models
        all_predictions = np.array([model.predict(X) for model in models])

        # Mean prediction
        mean_pred = np.mean(all_predictions, axis=0)

        # Standard deviation across models
        std_pred = np.std(all_predictions, axis=0)

        # Convert confidence level to z-score (assuming normal distribution)
        from scipy import stats
        z_score = stats.norm.ppf(self.upper_quantile)

        # Prediction intervals
        lower = mean_pred - z_score * std_pred
        upper = mean_pred + z_score * std_pred

        return lower, upper

    def _conformal_intervals(
        self,
        predictions: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Conformal prediction intervals (distribution-free).

        Based on calibration residuals from validation set.
        """
        if self.conformal_scores is None:
            logger.warning("Conformal prediction not calibrated. Using default intervals.")
            # Use simple heuristic: ±10% of prediction
            uncertainty = 0.1 * np.abs(predictions)
            return predictions - uncertainty, predictions + uncertainty

        # Get the (1-alpha) quantile of calibration residuals
        q = np.quantile(self.conformal_scores, self.confidence_level)

        # Prediction intervals: prediction ± q
        lower = predictions - q
        upper = predictions + q

        return lower, upper

    def compute_prediction_quality(
        self,
        y_true: np.ndarray,
        predictions: np.ndarray,
        lower_bounds: np.ndarray,
        upper_bounds: np.ndarray
    ) -> Dict[str, float]:
        """
        Evaluate quality of prediction intervals.

        Args:
            y_true: True values
            predictions: Point predictions
            lower_bounds: Lower confidence bounds
            upper_bounds: Upper confidence bounds

        Returns:
            Dictionary with quality metrics
        """
        # Coverage: fraction of true values within intervals
        in_interval = (y_true >= lower_bounds) & (y_true <= upper_bounds)
        coverage = np.mean(in_interval)

        # Mean interval width
        interval_width = upper_bounds - lower_bounds
        mean_width = np.mean(interval_width)
        median_width = np.median(interval_width)

        # Relative width (normalized by prediction magnitude)
        relative_width = interval_width / (np.abs(predictions) + 1e-8)
        mean_relative_width = np.mean(relative_width)

        # Calibration error (should be close to confidence_level)
        calibration_error = np.abs(coverage - self.confidence_level)

        metrics = {
            'coverage': coverage,
            'target_coverage': self.confidence_level,
            'calibration_error': calibration_error,
            'mean_interval_width': mean_width,
            'median_interval_width': median_width,
            'mean_relative_width': mean_relative_width,
            'well_calibrated': calibration_error < 0.05  # Within 5% of target
        }

        return metrics

    def save(self, filepath: Path):
        """Save uncertainty quantifier to disk."""
        with open(filepath, 'wb') as f:
            pickle.dump(self, f)
        logger.info(f"Saved UncertaintyQuantifier to {filepath}")

    @classmethod
    def load(cls, filepath: Path) -> 'UncertaintyQuantifier':
        """Load uncertainty quantifier from disk."""
        with open(filepath, 'rb') as f:
            quantifier = pickle.load(f)
        logger.info(f"Loaded UncertaintyQuantifier from {filepath}")
        return quantifier


def format_prediction_with_uncertainty(
    prediction: float,
    lower: float,
    upper: float,
    confidence: float = 0.68
) -> str:
    """
    Format prediction with uncertainty for display.

    Args:
        prediction: Point prediction
        lower: Lower bound
        upper: Upper bound
        confidence: Confidence level

    Returns:
        Formatted string like "2.34% ± 0.15% (68% CI: 2.19% - 2.49%)"
    """
    # Calculate symmetric uncertainty
    uncertainty = (upper - lower) / 2

    # Format string
    formatted = (
        f"{prediction:.2f}% ± {uncertainty:.2f}% "
        f"({confidence:.0%} CI: {lower:.2f}% - {upper:.2f}%)"
    )

    return formatted


def create_uncertainty_report(
    y_true: np.ndarray,
    predictions: np.ndarray,
    lower_bounds: np.ndarray,
    upper_bounds: np.ndarray,
    sample_ids: Optional[List[str]] = None,
    confidence: float = 0.68,
    output_path: Optional[Path] = None
) -> pd.DataFrame:
    """
    Create detailed uncertainty report.

    Args:
        y_true: True values
        predictions: Point predictions
        lower_bounds: Lower confidence bounds
        upper_bounds: Upper confidence bounds
        sample_ids: Optional sample identifiers
        confidence: Confidence level
        output_path: Optional path to save CSV

    Returns:
        DataFrame with predictions and uncertainties
    """
    # Calculate uncertainties
    interval_width = upper_bounds - lower_bounds
    uncertainty = interval_width / 2
    relative_uncertainty = uncertainty / (np.abs(predictions) + 1e-8)

    # Check if prediction is within interval
    in_interval = (y_true >= lower_bounds) & (y_true <= upper_bounds)

    # Create DataFrame
    df = pd.DataFrame({
        'sample_id': sample_ids if sample_ids else range(len(predictions)),
        'true_value': y_true,
        'prediction': predictions,
        'uncertainty': uncertainty,
        'lower_bound': lower_bounds,
        'upper_bound': upper_bounds,
        'interval_width': interval_width,
        'relative_uncertainty_pct': relative_uncertainty * 100,
        'in_interval': in_interval,
        'absolute_error': np.abs(y_true - predictions)
    })

    # Sort by uncertainty (highest first - these need attention)
    df = df.sort_values('uncertainty', ascending=False)

    # Add formatted prediction string
    df['formatted_prediction'] = df.apply(
        lambda row: format_prediction_with_uncertainty(
            row['prediction'], row['lower_bound'], row['upper_bound'], confidence
        ),
        axis=1
    )

    # Save if requested
    if output_path:
        df.to_csv(output_path, index=False)
        logger.info(f"Saved uncertainty report to {output_path}")

    return df


def plot_uncertainty(
    y_true: np.ndarray,
    predictions: np.ndarray,
    lower_bounds: np.ndarray,
    upper_bounds: np.ndarray,
    output_path: Optional[Path] = None,
    title: str = "Predictions with Uncertainty Intervals"
):
    """
    Plot predictions with uncertainty intervals.

    Args:
        y_true: True values
        predictions: Point predictions
        lower_bounds: Lower confidence bounds
        upper_bounds: Upper confidence bounds
        output_path: Optional path to save plot
        title: Plot title
    """
    import matplotlib.pyplot as plt

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

    # Sort by true value for better visualization
    sort_idx = np.argsort(y_true)
    y_true_sorted = y_true[sort_idx]
    predictions_sorted = predictions[sort_idx]
    lower_sorted = lower_bounds[sort_idx]
    upper_sorted = upper_bounds[sort_idx]

    # Left plot: Predictions with intervals
    x = np.arange(len(y_true_sorted))
    ax1.fill_between(x, lower_sorted, upper_sorted, alpha=0.3, label='Prediction Interval')
    ax1.plot(x, predictions_sorted, 'b-', label='Predictions', linewidth=1)
    ax1.plot(x, y_true_sorted, 'ko', markersize=3, alpha=0.5, label='True Values')
    ax1.set_xlabel('Sample (sorted by true value)')
    ax1.set_ylabel('Potassium (%)')
    ax1.set_title(f'{title}\n(sorted by true value)')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # Right plot: Calibration plot
    ax2.errorbar(
        y_true, predictions,
        yerr=[predictions - lower_bounds, upper_bounds - predictions],
        fmt='o', alpha=0.5, markersize=4, elinewidth=1,
        label='Predictions with intervals'
    )

    # Perfect prediction line
    min_val = min(y_true.min(), predictions.min())
    max_val = max(y_true.max(), predictions.max())
    ax2.plot([min_val, max_val], [min_val, max_val], 'r--', label='Perfect Prediction', linewidth=2)

    ax2.set_xlabel('True Potassium (%)')
    ax2.set_ylabel('Predicted Potassium (%)')
    ax2.set_title('Calibration Plot with Uncertainty')
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()

    if output_path:
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        logger.info(f"Saved uncertainty plot to {output_path}")
        plt.close()
    else:
        plt.show()
