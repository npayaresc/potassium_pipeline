"""
Uncertainty-aware Model Training

Extends model training to include uncertainty quantification.
"""

import logging
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

from src.models.uncertainty import (
    UncertaintyQuantifier,
    create_uncertainty_report,
    plot_uncertainty
)

logger = logging.getLogger(__name__)


def train_model_with_uncertainty(
    model: Any,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    model_name: str = "model",
    uncertainty_method: str = 'conformal',
    confidence_level: float = 0.68,
    save_dir: Optional[Path] = None
) -> Dict[str, Any]:
    """
    Train model and calibrate uncertainty quantification.

    Args:
        model: Model to train (must have fit/predict methods)
        X_train: Training features
        y_train: Training targets
        X_val: Validation features (for uncertainty calibration)
        y_val: Validation targets
        X_test: Test features
        y_test: Test targets
        model_name: Name for logging/saving
        uncertainty_method: 'conformal', 'ensemble', 'combined'
        confidence_level: Confidence level (default 0.68 = 1σ)
        save_dir: Directory to save results

    Returns:
        Dictionary with model, uncertainty quantifier, and metrics
    """
    logger.info(f"Training {model_name} with uncertainty quantification...")

    # Train model
    model.fit(X_train, y_train)

    # Make predictions on validation set
    y_val_pred = model.predict(X_val)

    # Initialize and calibrate uncertainty quantifier
    quantifier = UncertaintyQuantifier(
        method=uncertainty_method,
        confidence_level=confidence_level
    )
    quantifier.fit(y_val, y_val_pred)

    # Get predictions with uncertainty on test set
    y_test_pred, lower_test, upper_test = quantifier.predict_with_intervals(
        model, X_test
    )

    # Compute standard metrics
    r2 = r2_score(y_test, y_test_pred)
    mae = mean_absolute_error(y_test, y_test_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))

    # Compute uncertainty metrics
    uncertainty_metrics = quantifier.compute_prediction_quality(
        y_test, y_test_pred, lower_test, upper_test
    )

    # Combine metrics
    metrics = {
        'model_name': model_name,
        'r2': r2,
        'mae': mae,
        'rmse': rmse,
        **uncertainty_metrics
    }

    logger.info(f"{model_name} - R²: {r2:.4f}, MAE: {mae:.4f}")
    logger.info(f"  Uncertainty coverage: {uncertainty_metrics['coverage']:.1%} "
                f"(target: {confidence_level:.1%})")
    logger.info(f"  Mean interval width: {uncertainty_metrics['mean_interval_width']:.4f}")
    logger.info(f"  Calibration error: {uncertainty_metrics['calibration_error']:.3f}")

    # Save results if directory provided
    if save_dir:
        save_dir = Path(save_dir)
        save_dir.mkdir(parents=True, exist_ok=True)

        # Save uncertainty quantifier
        quantifier.save(save_dir / f"{model_name}_uncertainty.pkl")

        # Create and save uncertainty report
        report = create_uncertainty_report(
            y_test, y_test_pred, lower_test, upper_test,
            confidence=confidence_level,
            output_path=save_dir / f"{model_name}_uncertainty_report.csv"
        )

        # Create uncertainty plot
        plot_uncertainty(
            y_test, y_test_pred, lower_test, upper_test,
            output_path=save_dir / f"{model_name}_uncertainty_plot.png",
            title=f"{model_name} Predictions with {confidence_level:.0%} Confidence Intervals"
        )

        logger.info(f"Saved uncertainty results to {save_dir}")

    return {
        'model': model,
        'uncertainty_quantifier': quantifier,
        'metrics': metrics,
        'test_predictions': y_test_pred,
        'test_lower_bounds': lower_test,
        'test_upper_bounds': upper_test
    }


def train_ensemble_with_uncertainty(
    models: List[Any],
    model_names: List[str],
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    confidence_level: float = 0.68,
    save_dir: Optional[Path] = None
) -> Dict[str, Any]:
    """
    Train ensemble of models with ensemble-based uncertainty.

    Args:
        models: List of models to train
        model_names: Names for each model
        X_train, y_train: Training data
        X_val, y_val: Validation data
        X_test, y_test: Test data
        confidence_level: Confidence level
        save_dir: Directory to save results

    Returns:
        Dictionary with trained models, uncertainty quantifier, and metrics
    """
    logger.info(f"Training ensemble of {len(models)} models with uncertainty...")

    # Train all models
    trained_models = []
    for model, name in zip(models, model_names):
        logger.info(f"  Training {name}...")
        model.fit(X_train, y_train)
        trained_models.append(model)

    # Make predictions with all models on validation set
    y_val_preds = [model.predict(X_val) for model in trained_models]
    y_val_ensemble = np.mean(y_val_preds, axis=0)

    # Initialize uncertainty quantifier with ensemble method
    quantifier = UncertaintyQuantifier(
        method='ensemble',
        confidence_level=confidence_level
    )
    quantifier.fit(y_val, y_val_ensemble)

    # Get predictions with uncertainty on test set
    y_test_preds = [model.predict(X_test) for model in trained_models]
    y_test_ensemble = np.mean(y_test_preds, axis=0)

    # Get ensemble-based intervals
    _, lower_test, upper_test = quantifier.predict_with_intervals(
        trained_models[0],  # Not used for ensemble method
        X_test,
        models_ensemble=trained_models
    )

    # Compute metrics
    r2 = r2_score(y_test, y_test_ensemble)
    mae = mean_absolute_error(y_test, y_test_ensemble)
    rmse = np.sqrt(mean_squared_error(y_test, y_test_ensemble))

    uncertainty_metrics = quantifier.compute_prediction_quality(
        y_test, y_test_ensemble, lower_test, upper_test
    )

    metrics = {
        'model_name': 'ensemble',
        'n_models': len(models),
        'r2': r2,
        'mae': mae,
        'rmse': rmse,
        **uncertainty_metrics
    }

    logger.info(f"Ensemble - R²: {r2:.4f}, MAE: {mae:.4f}")
    logger.info(f"  Uncertainty coverage: {uncertainty_metrics['coverage']:.1%}")
    logger.info(f"  Mean interval width: {uncertainty_metrics['mean_interval_width']:.4f}")

    # Save results
    if save_dir:
        save_dir = Path(save_dir)
        save_dir.mkdir(parents=True, exist_ok=True)

        quantifier.save(save_dir / "ensemble_uncertainty.pkl")

        report = create_uncertainty_report(
            y_test, y_test_ensemble, lower_test, upper_test,
            confidence=confidence_level,
            output_path=save_dir / "ensemble_uncertainty_report.csv"
        )

        plot_uncertainty(
            y_test, y_test_ensemble, lower_test, upper_test,
            output_path=save_dir / "ensemble_uncertainty_plot.png",
            title=f"Ensemble Predictions with {confidence_level:.0%} Confidence Intervals"
        )

    return {
        'models': trained_models,
        'model_names': model_names,
        'uncertainty_quantifier': quantifier,
        'metrics': metrics,
        'test_predictions': y_test_ensemble,
        'test_lower_bounds': lower_test,
        'test_upper_bounds': upper_test
    }


def predict_with_uncertainty(
    model: Any,
    uncertainty_quantifier: UncertaintyQuantifier,
    X: np.ndarray,
    sample_ids: Optional[List[str]] = None,
    output_path: Optional[Path] = None
) -> pd.DataFrame:
    """
    Make predictions with uncertainty intervals.

    Args:
        model: Trained model
        uncertainty_quantifier: Calibrated uncertainty quantifier
        X: Features
        sample_ids: Optional sample identifiers
        output_path: Optional path to save results

    Returns:
        DataFrame with predictions and uncertainties
    """
    # Get predictions with intervals
    predictions, lower, upper = uncertainty_quantifier.predict_with_intervals(model, X)

    # Create DataFrame
    uncertainty = (upper - lower) / 2
    relative_uncertainty = uncertainty / (np.abs(predictions) + 1e-8)

    df = pd.DataFrame({
        'sample_id': sample_ids if sample_ids else range(len(predictions)),
        'prediction': predictions,
        'uncertainty': uncertainty,
        'lower_bound': lower,
        'upper_bound': upper,
        'relative_uncertainty_pct': relative_uncertainty * 100
    })

    # Add formatted prediction string
    from src.models.uncertainty import format_prediction_with_uncertainty
    df['formatted_prediction'] = df.apply(
        lambda row: format_prediction_with_uncertainty(
            row['prediction'], row['lower_bound'], row['upper_bound'],
            uncertainty_quantifier.confidence_level
        ),
        axis=1
    )

    # Save if requested
    if output_path:
        df.to_csv(output_path, index=False)
        logger.info(f"Saved predictions with uncertainty to {output_path}")

    return df
