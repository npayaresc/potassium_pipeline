"""
GPU-Safe Model Tuner

Enhanced version of ModelTuner with additional GPU safety features and 
improved memory management for single-GPU systems.
"""
import logging
from catboost import CatBoostRegressor
import joblib
from pathlib import Path

import optuna
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import cross_val_score, cross_val_predict
from sklearn.pipeline import Pipeline
from src.features.dimension_reduction import DimensionReductionFactory
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from .neural_network import NeuralNetworkRegressor

from src.config.pipeline_config import Config
from src.features.feature_engineering import SpectralFeatureGenerator, create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.reporting.reporter import Reporter
from src.utils.custom_exceptions import ModelTrainingError
from src.models.tuner_objectives import (
    calculate_robust_objective,
    calculate_concentration_weighted_objective,
    calculate_mape_focused_objective
)
from src.models.tuner_objectives_improved import (
    calculate_robust_objective_v2,
    calculate_weighted_r2_objective,
    calculate_balanced_mae_objective,
    calculate_quantile_weighted_objective,
    calculate_distribution_based_objective,
    calculate_hybrid_weighted_objective
)
from src.utils.helpers import OutlierClipper, calculate_regression_metrics
from src.models.base_optimizer import BaseOptimizer
from src.models.model_tuner import ModelTuner, CalibratedModelWrapper

logger = logging.getLogger(__name__)


class GPUSafeModelTuner(ModelTuner):
    """
    GPU-Safe version of ModelTuner with enhanced memory management and safety features.
    
    Key differences from standard ModelTuner:
    - Enhanced GPU memory monitoring and management
    - Conservative GPU parameter selection
    - Improved error recovery for GPU OOM situations
    - Better resource cleanup between trials
    """
    
    def __init__(self, config: Config, reporter: Reporter, strategy: str):
        super().__init__(config, reporter, strategy)
        self._gpu_memory_fraction = 0.7  # More conservative than standard 0.8
        self._max_trials_before_cleanup = 10  # Force cleanup every N trials
        self._trial_counter = 0
        self._gpu_fallback_count = {}  # Track GPU fallbacks per model
        
        logger.info("Initialized GPU-Safe Model Tuner with enhanced memory management")
        logger.info(f"GPU memory fraction set to {self._gpu_memory_fraction} (conservative)")
        logger.info(f"Periodic cleanup every {self._max_trials_before_cleanup} trials")
    
    def _configure_gpu_parameters_safely(self, base_model_name: str, params: dict) -> dict:
        """
        Configure GPU parameters with enhanced safety features.
        More conservative than standard ModelTuner.
        """
        if not self.config.use_gpu:
            return params
            
        if base_model_name == 'xgboost':
            params['tree_method'] = 'hist'
            params['device'] = 'cuda:0'
            params['predictor'] = 'gpu_predictor'
            # More conservative memory settings
            params['max_bin'] = 128  # Reduced from 256 for safety
            params['subsample'] = min(params.get('subsample', 1.0), 0.8)  # Limit data size
            logger.info(f"GPU-Safe XGBoost: device='cuda:0', max_bin=128 (conservative)")
            
        elif base_model_name == 'lightgbm':
            params['device'] = 'gpu'
            params['gpu_platform_id'] = 0
            params['gpu_device_id'] = 0
            params['gpu_use_dp'] = False  # Use float32
            params['max_bin'] = 128  # Reduced from 255 for safety
            # Conservative memory settings
            params['min_data_in_leaf'] = max(params.get('min_data_in_leaf', 20), 10)
            logger.info(f"GPU-Safe LightGBM: device='gpu', max_bin=128 (conservative)")
            
        elif base_model_name == 'catboost':
            params['task_type'] = 'GPU'
            params['devices'] = '0'
            # More conservative GPU RAM usage
            params['gpu_ram_part'] = self._gpu_memory_fraction  # 0.7 instead of 0.8
            # Conservative training settings
            params['max_ctr_complexity'] = min(params.get('max_ctr_complexity', 4), 3)
            logger.info(f"GPU-Safe CatBoost: gpu_ram_part={self._gpu_memory_fraction} (conservative)")
        
        return params
    
    def _cleanup_gpu_resources(self):
        """
        Force cleanup of GPU resources between trials.
        """
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.synchronize()
        except ImportError:
            pass
            
        try:
            import cupy
            cupy.get_default_memory_pool().free_all_blocks()
        except ImportError:
            pass
            
        logger.debug("GPU resources cleaned up")
    
    def _get_regressor(self, model_name: str, params: dict):
        """
        GPU-safe version of _get_regressor with enhanced error handling.
        """
        try:
            # Configure GPU parameters safely
            params = self._configure_gpu_parameters_safely(model_name, params)
            
            # Get the regressor using parent method
            regressor = super()._get_regressor(model_name, params)
            
            return regressor
            
        except Exception as e:
            if any(keyword in str(e) for keyword in ["GPU", "CUDA", "cuda", "memory", "OOM"]):
                # Track fallback count
                self._gpu_fallback_count[model_name] = self._gpu_fallback_count.get(model_name, 0) + 1
                fallback_count = self._gpu_fallback_count[model_name]
                
                logger.warning(f"GPU error for {model_name} (fallback #{fallback_count}): {e}. Falling back to CPU.")
                
                # Force cleanup after GPU error
                self._cleanup_gpu_resources()
                
                # Remove GPU parameters and retry with CPU
                cpu_params = params.copy()
                gpu_keys = ['device', 'tree_method', 'predictor', 'task_type', 'devices', 
                           'gpu_platform_id', 'gpu_device_id', 'gpu_use_dp', 'gpu_ram_part',
                           'max_ctr_complexity']
                for key in gpu_keys:
                    cpu_params.pop(key, None)
                
                # Set CPU-specific parameters
                if model_name == 'xgboost':
                    cpu_params['tree_method'] = 'hist'
                    cpu_params['n_jobs'] = 1  # Single thread to avoid conflicts
                elif model_name == 'catboost':
                    cpu_params['task_type'] = 'CPU'
                    cpu_params['thread_count'] = 1
                elif model_name == 'lightgbm':
                    cpu_params['n_jobs'] = 1
                    cpu_params['device'] = 'cpu'  # Explicitly set to CPU
                
                logger.info(f"Retrying {model_name} with CPU-only configuration")
                return super()._get_regressor(model_name, cpu_params)
            else:
                raise
    
    def _objective(self, trial: optuna.Trial) -> float:
        """
        GPU-safe objective function with enhanced error handling and resource management.
        """
        self._trial_counter += 1
        
        try:
            # Cleanup GPU resources periodically
            if self._trial_counter % self._max_trials_before_cleanup == 0:
                self._cleanup_gpu_resources()
                logger.info(f"Periodic GPU cleanup after {self._trial_counter} trials")
            
            # Call parent objective function
            result = super()._objective(trial)
            
            return result
            
        except Exception as e:
            if any(keyword in str(e).lower() for keyword in ['gpu', 'cuda', 'memory', 'oom']):
                logger.warning(f"Trial {trial.number} failed with GPU/memory error: {e}")
                # Force cleanup and return poor score
                self._cleanup_gpu_resources()
                return -1000.0
            else:
                # Re-raise non-GPU errors
                raise
    
    def tune(self, train_df: pd.DataFrame, test_df: pd.DataFrame):
        """
        GPU-safe tuning with enhanced resource management.
        """
        logger.info("Starting GPU-Safe hyperparameter tuning with enhanced memory management")
        
        # Force sequential execution for GPU models to avoid conflicts
        original_models_to_tune = self.config.tuner.models_to_tune.copy()
        gpu_models = {'xgboost', 'lightgbm', 'catboost'}
        has_gpu_models = any(model in gpu_models for model in original_models_to_tune)
        
        if self.config.use_gpu and has_gpu_models:
            logger.info("GPU-Safe mode: Detected GPU models, ensuring sequential execution")
            # Override parallel model jobs to 1 for safety
            original_model_n_jobs = self.config.parallel.model_n_jobs
            self.config.parallel.model_n_jobs = 1
        
        try:
            # Call parent tune method
            result = super().tune(train_df, test_df)
            return result
        finally:
            # Restore original configuration
            if self.config.use_gpu and has_gpu_models:
                self.config.parallel.model_n_jobs = original_model_n_jobs
                
            # Always cleanup GPU resources when done
            self._cleanup_gpu_resources()
            
            # Log GPU fallback statistics
            if self._gpu_fallback_count:
                logger.info("GPU-Safe tuning completed with resource cleanup")
                logger.info("GPU Fallback Statistics:")
                for model_name, count in self._gpu_fallback_count.items():
                    logger.info(f"  {model_name}: {count} GPU fallbacks to CPU")
            else:
                logger.info("GPU-Safe tuning completed with resource cleanup (no GPU fallbacks needed)")
    
    def get_gpu_safety_stats(self) -> dict:
        """
        Return statistics about GPU safety features used during tuning.
        """
        return {
            'gpu_memory_fraction': self._gpu_memory_fraction,
            'max_trials_before_cleanup': self._max_trials_before_cleanup,
            'total_trials': self._trial_counter,
            'gpu_fallback_count': self._gpu_fallback_count.copy(),
            'periodic_cleanups': self._trial_counter // self._max_trials_before_cleanup
        }


def get_safe_n_jobs(config, models_to_tune):
    """
    Determines safe n_jobs value based on GPU usage and models being tuned.
    
    Returns:
        int: Safe number of parallel jobs
    """
    gpu_models = {'xgboost', 'lightgbm', 'catboost'}
    cpu_only_models = {'random_forest', 'extratrees', 'svr', 'ridge', 'lasso'}
    
    # Check if any GPU models are being tuned
    has_gpu_models = any(model in gpu_models for model in models_to_tune)
    
    if config.use_gpu and has_gpu_models:
        # With single GPU, run trials sequentially to avoid conflicts
        return 1
    else:
        # CPU-only models can run in parallel
        return config.parallel.model_n_jobs

def get_gpu_config_for_parallel(trial_id, total_trials):
    """
    Returns GPU configuration for parallel trials (if multi-GPU available).
    
    For single GPU systems, this should not be used - run sequentially instead.
    """
    # Example for multi-GPU systems (not applicable for single GPU)
    gpu_count = 1  # You mentioned having only 1 GPU
    
    if gpu_count == 1:
        # Single GPU - should use sequential execution
        return {
            'gpu_device_id': 0,
            'gpu_memory_fraction': 0.7  # More conservative than 0.8
        }
    else:
        # Multi-GPU - distribute trials across GPUs
        gpu_id = trial_id % gpu_count
        return {
            'gpu_device_id': gpu_id,
            'gpu_memory_fraction': 0.7 / (total_trials / gpu_count)
        }

def configure_gpu_model_safely(model_name, params, config):
    """
    Configures GPU models with memory limits and safety settings.
    More conservative than standard configuration.
    """
    if model_name == 'xgboost':
        params['tree_method'] = 'hist'
        params['device'] = 'cuda:0'
        # More conservative memory settings
        params['max_bin'] = 128  # Reduced from 256
        params['subsample'] = min(params.get('subsample', 1.0), 0.8)
        
    elif model_name == 'lightgbm':
        params['device'] = 'gpu'
        params['gpu_device_id'] = 0
        params['gpu_platform_id'] = 0
        # More conservative GPU memory usage
        params['gpu_use_dp'] = False  # Use float32 instead of float64
        params['max_bin'] = 128  # Reduced from 255
        params['min_data_in_leaf'] = max(params.get('min_data_in_leaf', 20), 10)
        
    elif model_name == 'catboost':
        params['task_type'] = 'GPU'
        params['devices'] = '0'
        # More conservative CatBoost GPU memory settings
        params['gpu_ram_part'] = 0.7  # Reduced from 0.8
        params['max_ctr_complexity'] = min(params.get('max_ctr_complexity', 4), 3)
        
    return params