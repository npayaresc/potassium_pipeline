#!/usr/bin/env python3
"""
Range Specialist Neural Network Optimizer for 0.2-0.5% Potassium Concentration.

This optimizer is specifically designed to achieve R² > 0.5 within the narrow
concentration range of 0.2-0.5% potassium, which is the critical range for
agricultural applications.
"""
import logging
import sys
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import optuna
from sklearn.model_selection import cross_val_score, KFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import joblib
import torch

# Add project root to path
sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

from src.config.pipeline_config import Config, config
from src.config.config_manager import config_manager
from src.data_management.data_manager import DataManager
from src.models.base_optimizer import BaseOptimizer
from src.models.enhanced_optuna_strategies import get_enhanced_optimization_config
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.features.feature_engineering import create_feature_pipeline
from src.models.neural_network import NeuralNetworkRegressor
from src.reporting.reporter import Reporter
from src.utils.helpers import calculate_regression_metrics, setup_logging
from src.cleansing.data_cleanser import DataCleanser

from src.models.base_optimizer import BaseOptimizer
from src.models.enhanced_optuna_strategies import get_enhanced_optimization_config

logger = logging.getLogger(__name__)

class RangeSpecialistOptimizer(BaseOptimizer):
    """
    Neural network optimizer specialized for 0.2-0.5% potassium concentration range.

    This optimizer focuses on achieving R² > 0.5 within the critical agricultural
    range of 0.2-0.5% potassium concentration.
    """
    
    def __init__(self, config: Config, strategy: str = 'simple_only', use_pca: bool = False, use_parallel_features: bool = False, feature_n_jobs: int = -1):
        """
        Initialize the range specialist optimizer.
        
        Args:
            config: Pipeline configuration
            strategy: Feature engineering strategy
            use_pca: Whether to apply PCA after feature engineering
            use_parallel: Whether to use parallel processing for feature generation
            n_jobs: Number of parallel jobs for feature generation
        """
        super().__init__(config)
        self.config = config
        self.strategy = strategy
        self.use_pca = use_pca
        self.use_parallel_features = use_parallel_features
        self.feature_n_jobs = feature_n_jobs
        
        # Force target range to 0.2-0.5 for range specialization
        self.target_min = 0.2
        self.target_max = 0.5
        
        logger.info(f"🎯 Range Specialist Neural Network Optimizer")
        logger.info(f"Target range: {self.target_min} - {self.target_max}% magnesium")
        logger.info(f"Goal: R² > 0.5 within this range")
        
        # Log dimension reduction configuration
        if config.use_dimension_reduction:
            logger.info(f"Dimension reduction: {config.dimension_reduction.method} enabled")
            if hasattr(config.dimension_reduction, 'n_components'):
                logger.info(f"Target components: {config.dimension_reduction.n_components}")
        elif self.use_pca:
            pca_variance = getattr(config.autogluon, 'pca_n_components', 0.90)
            logger.info(f"PCA enabled (will retain {pca_variance*100:.0f}% of variance)")
        else:
            logger.info(f"No dimension reduction configured")
        
        # Setup feature pipeline with concentration features
        if config.use_concentration_features:
            logger.info("Using enhanced feature pipeline with concentration-aware features")
            self.feature_pipeline = create_enhanced_feature_pipeline_with_concentration(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
        else:
            logger.info(f"Using standard feature pipeline (parallel={use_parallel_features}, feature_n_jobs={feature_n_jobs})")
            self.feature_pipeline = create_feature_pipeline(config, strategy, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
            
        self.best_params = None
        self.best_score = float('-inf')
        self.X_train = None
        self.y_train = None
        
        # Feature caching for optimization efficiency
        self._cached_features = None  # Cache transformed features
        self._fitted_feature_pipeline = None  # Cache fitted feature pipeline
        
        # Range-specific search space
        self._setup_range_specialist_search_space()
    
    def _setup_range_specialist_search_space(self):
        """Setup hyperparameter search space optimized for 0.2-0.5% range."""
        self.search_space = {
            # Use model_type instead of hidden_layers (compatible with NeuralNetworkRegressor)
            'model_type': ['full', 'light'],
            
            # Lower learning rates for fine-grained optimization
            'learning_rate': [0.0001, 0.0003, 0.0005, 0.0008, 0.001, 0.002],
            
            # Higher weight decay for narrow range (prevent overfitting)
            'weight_decay': [0.001, 0.003, 0.005, 0.008, 0.01, 0.015, 0.02],
            
            # Progressive dropout for precision
            'dropout_rate': [0.15, 0.2, 0.25, 0.3, 0.35, 0.4],
            
            # Smaller batches for better gradients on small range
            'batch_size': [8, 12, 16, 20, 24, 32],
            
            # Extended training for narrow range convergence
            'epochs': [200, 250, 300, 350, 400, 500],
            
            # More patience for narrow range optimization
            'early_stopping_patience': [30, 35, 40, 45, 50]
        }
        
        logger.info("Range specialist search space configured:")
        logger.info(f"  - Architecture variants: {len(self.search_space['model_type'])}")
        logger.info(f"  - Learning rates: {self.search_space['learning_rate']}")
        logger.info(f"  - Extended training: {min(self.search_space['epochs'])}-{max(self.search_space['epochs'])} epochs")
        logger.info("  - Feature caching enabled for optimization efficiency")
        
        # Log dimension reduction details
        if self.config.use_dimension_reduction:
            logger.info(f"  - {self.config.dimension_reduction.method.upper()} dimensionality reduction enabled")
            if hasattr(self.config.dimension_reduction, 'n_components'):
                logger.info(f"  - Target components: {self.config.dimension_reduction.n_components}")
        elif self.use_pca:
            pca_variance = getattr(self.config.autogluon, 'pca_n_components', 0.90)
            logger.info(f"  - PCA dimensionality reduction: {pca_variance*100:.0f}% variance retention")
    
    def _filter_data_to_range(self, X, y):
        """Filter data to the target concentration range."""
        range_mask = (y >= self.target_min) & (y <= self.target_max)
        X_filtered = X[range_mask]
        y_filtered = y[range_mask]
        
        logger.info(f"Data filtering: {len(y)} → {len(y_filtered)} samples "
                   f"({len(y_filtered)/len(y)*100:.1f}% retained)")
        logger.info(f"Range stats: mean={y_filtered.mean():.3f}, "
                   f"std={y_filtered.std():.3f}, "
                   f"min={y_filtered.min():.3f}, "
                   f"max={y_filtered.max():.3f}")
        
        return X_filtered, y_filtered
    
    def _range_specific_objective(self, y_true, y_pred, cv_scores):
        """
        Range-specific objective function optimized for 0.2-0.5% performance.
        
        Args:
            y_true: True values
            y_pred: Predicted values
            cv_scores: Cross-validation scores
            
        Returns:
            Objective score (higher is better)
        """
        # Base R² score
        r2 = r2_score(y_true, y_pred)
        
        # CV stability
        cv_mean = np.mean(cv_scores)
        cv_std = np.std(cv_scores)
        
        # Range-specific performance metrics
        # 1. Absolute error penalty (critical for narrow range)
        mae = mean_absolute_error(y_true, y_pred)
        mae_penalty = mae * 2.0  # Heavy penalty for absolute errors
        
        # 2. Range boundary performance (critical near 0.2 and 0.5)
        low_range_mask = y_true <= 0.3
        high_range_mask = y_true >= 0.4
        
        boundary_bonus = 0
        if np.sum(low_range_mask) > 0:
            low_r2 = r2_score(y_true[low_range_mask], y_pred[low_range_mask])
            boundary_bonus += max(0, low_r2 - 0.3) * 0.1
        
        if np.sum(high_range_mask) > 0:
            high_r2 = r2_score(y_true[high_range_mask], y_pred[high_range_mask])
            boundary_bonus += max(0, high_r2 - 0.3) * 0.1
        
        # 3. Stability penalty
        stability_penalty = min(cv_std * 0.5, 0.1)
        
        # 4. Precision bonus (reward very low MAE)
        precision_bonus = max(0, (0.02 - mae)) * 5.0  # Bonus for MAE < 0.02
        
        # Combined objective
        final_score = (cv_mean * 0.7 +        # Primary: CV performance
                      r2 * 0.2 +              # Secondary: Single fold R²
                      boundary_bonus +        # Bonus: Range boundary performance
                      precision_bonus -       # Bonus: High precision
                      stability_penalty -     # Penalty: CV instability
                      mae_penalty * 0.1)      # Penalty: Absolute errors
        
        return final_score
    
    def objective(self, trial):
        """
        Optuna objective function for range specialist optimization.
        
        Args:
            trial: Optuna trial object
            
        Returns:
            Objective value (higher is better)
        """
        # Enhanced parameter suggestion with smart search space (Strategy D)
        # Note: Range specialist uses predefined search spaces, so we keep the original logic
        
        # Sample hyperparameters
        params = {
            'model_type': trial.suggest_categorical('model_type', self.search_space['model_type']),
            'learning_rate': trial.suggest_categorical('learning_rate', self.search_space['learning_rate']),
            'weight_decay': trial.suggest_categorical('weight_decay', self.search_space['weight_decay']),
            'dropout_rate': trial.suggest_categorical('dropout_rate', self.search_space['dropout_rate']),
            'batch_size': trial.suggest_categorical('batch_size', self.search_space['batch_size']),
            'epochs': trial.suggest_categorical('epochs', self.search_space['epochs']),
            'early_stopping_patience': trial.suggest_categorical('early_stopping_patience', 
                                                                self.search_space['early_stopping_patience']),
            'use_sample_weights': trial.suggest_categorical('use_sample_weights', [False, True])
        }
        
        # Add GPU support
        device = 'cuda' if self.config.use_gpu else 'cpu'
        
        # Create range specialist neural network with range-focused loss
        neural_net = NeuralNetworkRegressor(
            model_type=params['model_type'],
            learning_rate=params['learning_rate'],
            weight_decay=params['weight_decay'],
            dropout_rate=params['dropout_rate'],
            batch_size=params['batch_size'],
            epochs=params['epochs'],
            early_stopping_patience=params['early_stopping_patience'],
            use_sample_weights=params['use_sample_weights'],
            range_focused=True,  # Enable range specialist mode
            target_range=(self.target_min, self.target_max),  # 0.2-0.5% range
            device=device,  # GPU/CPU support
            verbose=False  # Quiet during optimization
        )
        
        # Use cached features for efficiency - fit feature pipeline only once
        if self._cached_features is None:
            logger.info("🔧 Fitting feature pipeline (first trial only)...")
            # Drop sample_id for feature extraction
            X_train_features = self.X_train_filtered.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in self.X_train_filtered.columns else self.X_train_filtered
            
            # Build pipeline with feature selection and dimension reduction support
            pipeline_steps = [('features', self.feature_pipeline)]
            
            # Add feature selection if enabled (before dimension reduction)
            if self.config.use_feature_selection:
                pipeline_steps.append(('scaler', StandardScaler()))  # Scale first for feature selection
                temp_pipeline = Pipeline(pipeline_steps)
                features_scaled = temp_pipeline.fit_transform(X_train_features, self.y_train_filtered)
                
                # Apply feature selection
                features_selected = self.apply_feature_selection(features_scaled, self.y_train_filtered, model_name="RangeSpecialist")
                logger.info(f"🔧 Feature selection applied: {features_scaled.shape[1]} → {features_selected.shape[1]} features")
                
                # Store selected features and rebuild pipeline without intermediate scaler
                self._cached_features = features_selected
                # Create a simplified pipeline that just does feature engineering since selection is done
                self._fitted_feature_pipeline = Pipeline([('features', self.feature_pipeline)])
                return
            
            # Add dimension reduction if configured in config OR if PCA is explicitly requested
            if self.config.use_dimension_reduction or self.use_pca:
                if self.config.use_dimension_reduction:
                    # Use configured dimension reduction
                    from src.features.dimension_reduction import DimensionReductionFactory
                    reducer = DimensionReductionFactory.create_reducer(
                        method=self.config.dimension_reduction.method,
                        params=self.config.dimension_reduction.get_params()
                    )
                    pipeline_steps.append(('dimension_reduction', reducer))
                    logger.info(f"🔧 {self.config.dimension_reduction.method} dimension reduction added to pipeline")
                elif self.use_pca:
                    # Fallback to PCA if explicitly requested but config doesn't have dimension reduction
                    from sklearn.decomposition import PCA
                    pca_variance = getattr(self.config.autogluon, 'pca_n_components', 0.90)
                    pipeline_steps.append(('dimension_reduction', PCA(n_components=pca_variance)))
                    logger.info(f"🔧 PCA added to pipeline (retaining {pca_variance*100:.0f}% variance)")
            
            pipeline_steps.append(('scaler', StandardScaler()))
            
            feature_pipeline = Pipeline(pipeline_steps)
            self._cached_features = feature_pipeline.fit_transform(X_train_features, self.y_train_filtered)
            self._fitted_feature_pipeline = feature_pipeline
            
            # Log dimension reduction if applied
            if 'dimension_reduction' in feature_pipeline.named_steps:
                reducer = feature_pipeline.named_steps['dimension_reduction']
                original_features = X_train_features.shape[1]
                
                # Get the number of components from the fitted reducer
                if hasattr(reducer, 'optimal_components_'):  # VAE with auto selection
                    reduced_features = reducer.optimal_components_
                    method_name = self.config.dimension_reduction.method.upper() if self.config.use_dimension_reduction else 'VAE'
                elif hasattr(reducer, 'n_components_'):  # Standard sklearn reducers
                    reduced_features = reducer.n_components_
                    method_name = self.config.dimension_reduction.method.upper() if self.config.use_dimension_reduction else 'PCA'
                elif hasattr(reducer, 'n_components'):  # Config parameter
                    reduced_features = reducer.n_components
                    method_name = self.config.dimension_reduction.method.upper() if self.config.use_dimension_reduction else 'PCA'
                else:
                    reduced_features = 'unknown'
                    method_name = self.config.dimension_reduction.method.upper() if self.config.use_dimension_reduction else 'UNKNOWN'
                
                # Special handling for PCA to show variance retained
                if hasattr(reducer, 'explained_variance_ratio_'):
                    variance_retained = reducer.explained_variance_ratio_.sum()
                    logger.info(f"📊 {method_name} applied: {original_features} → {reduced_features} features "
                               f"(retained {variance_retained:.1%} variance)")
                else:
                    logger.info(f"📊 {method_name} applied: {original_features} → {reduced_features} features")
            
            logger.info(f"✅ Features cached: {self._cached_features.shape}")
        
        # Create model-only pipeline for cross-validation
        model_pipeline = Pipeline([
            ('regressor', neural_net)
        ])
        
        # Cross-validation with stratification by concentration using cached features
        try:
            # Create concentration-based stratification
            y_binned = pd.cut(self.y_train_filtered, bins=5, labels=False)
            
            # Use stratified CV to ensure balanced concentration distribution
            skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
            
            cv_scores = []
            all_y_true = []
            all_y_pred = []
            
            for train_idx, val_idx in skf.split(self._cached_features, y_binned):
                X_fold_train = self._cached_features[train_idx]
                X_fold_val = self._cached_features[val_idx]
                y_fold_train = self.y_train_filtered.iloc[train_idx]
                y_fold_val = self.y_train_filtered.iloc[val_idx]
                
                # Train model on pre-transformed features
                model_pipeline.fit(X_fold_train, y_fold_train)
                
                # Predict on validation
                y_pred = model_pipeline.predict(X_fold_val)
                
                # Calculate fold R²
                fold_r2 = r2_score(y_fold_val, y_pred)
                cv_scores.append(fold_r2)
                
                # Collect for overall metrics
                all_y_true.extend(y_fold_val.values)
                all_y_pred.extend(y_pred)
            
            # Calculate range-specific objective
            final_score = self._range_specific_objective(
                np.array(all_y_true), 
                np.array(all_y_pred), 
                cv_scores
            )
            
            # Log promising trials
            cv_mean = np.mean(cv_scores)
            cv_std = np.std(cv_scores)
            mae = mean_absolute_error(all_y_true, all_y_pred)
            
            if cv_mean > 0.4:  # Promising for >0.5 target
                logger.info(f"🚀 Trial {trial.number}: R²={cv_mean:.4f}±{cv_std:.4f}, "
                          f"MAE={mae:.4f}, model={params['model_type']}, "
                          f"lr={params['learning_rate']:.4f}")
            
            return final_score
            
        except Exception as e:
            logger.warning(f"Trial {trial.number} failed: {e}")
            return float('-inf')
    
    def optimize(self, train_df: pd.DataFrame, n_trials: int = 200):
        """
        Run range specialist optimization with enhanced strategies (A-D).
        
        Args:
            train_df: Training dataframe
            n_trials: Number of optimization trials
            
        Returns:
            Optuna study object
        """
        logger.info("🎯 Starting Range Specialist Neural Network Optimization")
        logger.info(f"Target: R² > 0.5 in range {self.target_min}-{self.target_max}%")
        logger.info(f"Optimization trials: {n_trials}")
        
        # Initialize enhanced optimization strategies
        dataset_size = len(train_df)
        self._enhanced_config = get_enhanced_optimization_config(
            model_name='neural_network',
            dataset_size=dataset_size,
            n_trials=n_trials,
            reports_dir=self.config.reports_dir
        )
        logger.info(f"Enhanced optimization strategies initialized for dataset_size={dataset_size}, n_trials={n_trials}")
        
        # Prepare data
        X_train = train_df.drop(columns=[self.config.target_column])
        y_train = train_df[self.config.target_column]
        
        # Store full training data for later caching
        self.X_train_full = X_train
        self.y_train_full = y_train
        
        # Remove sample_id for feature engineering
        X_train_features = X_train.drop(columns=[self.config.sample_id_column])
        
        # Fit feature pipeline on full data first (for better feature statistics)
        if self.config.use_concentration_features:
            self.feature_pipeline.fit(X_train_features, y_train)
        else:
            self.feature_pipeline.fit(X_train_features)
        
        # Filter to target range
        self.X_train_filtered, self.y_train_filtered = self._filter_data_to_range(X_train, y_train)
        
        if len(self.y_train_filtered) < 50:
            logger.warning(f"Only {len(self.y_train_filtered)} samples in target range. "
                          "Consider expanding range or using different approach.")
        
        # Create Optuna study with enhanced sampling (Strategy B)
        enhanced_sampler = self._enhanced_config['advanced_sampling'].get_best_sampler()
        
        study = optuna.create_study(
            direction='maximize',
            study_name='range_specialist_neural_net',
            sampler=enhanced_sampler
        )
        
        # Optimize
        study.optimize(
            self.objective, 
            n_trials=n_trials,
            n_jobs=1,  # Neural networks don't parallelize well
            show_progress_bar=True
        )
        
        # Store results
        self.best_params = study.best_params
        self.best_score = study.best_value
        
        # Perform parameter importance analysis (Strategy C)
        try:
            importance_analyzer = self._enhanced_config['importance_analyzer']
            param_importance = importance_analyzer.analyze_study(study, 'range_specialist_neural_net')
            self._param_importance = param_importance
            logger.info("Parameter importance analysis completed")
        except Exception as e:
            logger.warning(f"Parameter importance analysis failed: {e}")
            self._param_importance = {}
        
        logger.info("=" * 60)
        logger.info("🎯 Range Specialist Optimization Complete!")
        logger.info("=" * 60)
        logger.info(f"Best objective score: {self.best_score:.4f}")
        logger.info(f"Target range: {self.target_min}-{self.target_max}% magnesium")
        logger.info(f"Strategy: {self.strategy}")
        logger.info(f"PCA enabled: {self.use_pca}")
        logger.info(f"GPU support: {self.config.use_gpu}")
        logger.info(f"Best parameters:")
        for key, value in self.best_params.items():
            logger.info(f"  {key}: {value}")
        
        # Analyze top trials
        trials_df = study.trials_dataframe().sort_values('value', ascending=False)
        logger.info(f"\nTop 5 trials:")
        for i, row in trials_df.head(5).iterrows():
            logger.info(f"  Trial {int(row['number'])}: Score={row['value']:.4f}")
        
        return study
    
    def evaluate_best_model(self, train_df: pd.DataFrame, test_df: pd.DataFrame = None):
        """
        Train and evaluate the best model on the target range.
        
        Args:
            train_df: Training dataframe
            test_df: Optional test dataframe
            
        Returns:
            Tuple of (trained_pipeline, range_metrics)
        """
        if self.best_params is None:
            raise ValueError("No best parameters found. Run optimize() first.")
        
        logger.info("🔬 Training and evaluating best range specialist model...")
        
        # Prepare full training data
        X_train = train_df.drop(columns=[self.config.target_column])
        y_train = train_df[self.config.target_column]
        
        # Add GPU support for final model
        device = 'cuda' if self.config.use_gpu else 'cpu'
        
        # Create best neural network with range specialist configuration
        best_neural_net = NeuralNetworkRegressor(
            model_type=self.best_params['model_type'],
            learning_rate=self.best_params['learning_rate'],
            weight_decay=self.best_params['weight_decay'],
            dropout_rate=self.best_params['dropout_rate'],
            batch_size=self.best_params['batch_size'],
            epochs=self.best_params['epochs'],
            early_stopping_patience=self.best_params['early_stopping_patience'],
            use_sample_weights=self.best_params.get('use_sample_weights', False),
            range_focused=True,  # Enable range specialist mode
            target_range=(self.target_min, self.target_max),  # 0.2-0.5% range
            device=device,  # GPU/CPU support
            verbose=True
        )
        
        # Use cached feature pipeline if available for consistency
        if hasattr(self, '_fitted_feature_pipeline'):
            logger.info("Using cached feature pipeline for final model evaluation...")
            X_train_features = X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_train.columns else X_train
            X_train_transformed = self._fitted_feature_pipeline.transform(X_train_features)
            
            # Update neural network input dimension if PCA was applied
            if self.use_pca and 'pca' in self._fitted_feature_pipeline.named_steps:
                pca_component = self._fitted_feature_pipeline.named_steps['pca']
                reduced_features = pca_component.n_components_
                if hasattr(best_neural_net, 'input_dim'):
                    logger.info(f"🔧 Neural network input dimension adjusted from {best_neural_net.input_dim} to {reduced_features}")
                    best_neural_net.input_dim = reduced_features
            
            # Train best model on transformed features
            best_neural_net.fit(X_train_transformed, y_train)
            
            # Create a proper pickable pipeline class instead of anonymous type
            class CachedPipeline:
                """Cached pipeline wrapper that can be pickled."""
                def __init__(self, neural_net, feature_pipeline, sample_id_column):
                    self.neural_net = neural_net
                    self.feature_pipeline = feature_pipeline
                    self.sample_id_column = sample_id_column
                
                def predict(self, X):
                    # Process features like the cached function did
                    X_features = X.drop(columns=[self.sample_id_column]) if self.sample_id_column in X.columns else X
                    X_processed = self.feature_pipeline.transform(X_features)
                    return self.neural_net.predict(X_processed)
                
                def fit(self, X, y):
                    return None  # Already fitted
            
            final_pipeline = CachedPipeline(best_neural_net, self._fitted_feature_pipeline, self.config.sample_id_column)
        else:
            # Fallback to creating new pipeline
            logger.info("Creating new pipeline for final model...")
            
            # Build pipeline with dimension reduction support
            pipeline_steps = [('features', self.feature_pipeline)]
            
            # Add dimension reduction if configured in config OR if PCA is explicitly requested
            if self.config.use_dimension_reduction or self.use_pca:
                if self.config.use_dimension_reduction:
                    # Use configured dimension reduction
                    from src.features.dimension_reduction import DimensionReductionFactory
                    reducer = DimensionReductionFactory.create_reducer(
                        method=self.config.dimension_reduction.method,
                        params=self.config.dimension_reduction.get_params()
                    )
                    pipeline_steps.append(('dimension_reduction', reducer))
                elif self.use_pca:
                    # Fallback to PCA if explicitly requested but config doesn't have dimension reduction
                    from sklearn.decomposition import PCA
                    pca_variance = getattr(self.config.autogluon, 'pca_n_components', 0.90)
                    pipeline_steps.append(('dimension_reduction', PCA(n_components=pca_variance)))
            
            pipeline_steps.extend([
                ('scaler', StandardScaler()),
                ('regressor', best_neural_net)
            ])
            
            final_pipeline = Pipeline(pipeline_steps)
            
            # Train on full data (not just filtered range)
            logger.info("Training on full dataset...")
            final_pipeline.fit(X_train, y_train)
            
            # Log dimension reduction application in fallback case
            if 'dimension_reduction' in final_pipeline.named_steps:
                reducer = final_pipeline.named_steps['dimension_reduction']
                X_train_features = X_train.drop(columns=[self.config.sample_id_column]) if self.config.sample_id_column in X_train.columns else X_train
                original_features = X_train_features.shape[1]
                
                # Get the number of components from the fitted reducer
                if hasattr(reducer, 'optimal_components_'):  # VAE with auto selection
                    reduced_features = reducer.optimal_components_
                    method_name = self.config.dimension_reduction.method.upper() if self.config.use_dimension_reduction else 'VAE'
                elif hasattr(reducer, 'n_components_'):  # Standard sklearn reducers
                    reduced_features = reducer.n_components_
                    method_name = self.config.dimension_reduction.method.upper() if self.config.use_dimension_reduction else 'PCA'
                elif hasattr(reducer, 'n_components'):  # Config parameter
                    reduced_features = reducer.n_components
                    method_name = self.config.dimension_reduction.method.upper() if self.config.use_dimension_reduction else 'PCA'
                else:
                    reduced_features = 'unknown'
                    method_name = self.config.dimension_reduction.method.upper() if self.config.use_dimension_reduction else 'UNKNOWN'
                
                # Special handling for PCA to show variance retained
                if hasattr(reducer, 'explained_variance_ratio_'):
                    variance_retained = reducer.explained_variance_ratio_.sum()
                    logger.info(f"📊 {method_name} applied: {original_features} → {reduced_features} features "
                                f"(retained {variance_retained:.1%} variance)")
                else:
                    logger.info(f"📊 {method_name} applied: {original_features} → {reduced_features} features")
        
        # Evaluate on range-specific data
        range_metrics = {}
        
        # Training set range evaluation
        y_train_pred = final_pipeline.predict(X_train)
        
        # Apply post-processing calibration if enabled
        if test_df is not None:
            X_test = test_df.drop(columns=[self.config.target_column])
            y_test = test_df[self.config.target_column]
            y_test_pred = final_pipeline.predict(X_test)
            
            y_train_pred, y_test_pred = self.apply_post_calibration(
                y_train, y_train_pred, y_test, y_test_pred, "RangeSpecialist"
            )
            
        X_train_range, y_train_range = self._filter_data_to_range(X_train, y_train)
        y_train_range_pred = final_pipeline.predict(X_train_range)
        
        # Re-apply calibration to range predictions if calibration was applied
        if test_df is not None and hasattr(self, 'post_calibrator') and self.post_calibrator is not None:
            y_train_range_pred = self.post_calibrator.transform(y_train_range_pred)
        
        train_range_r2 = r2_score(y_train_range, y_train_range_pred)
        train_range_mae = mean_absolute_error(y_train_range, y_train_range_pred)
        train_range_rmse = np.sqrt(mean_squared_error(y_train_range, y_train_range_pred))
        
        # Calculate additional metrics
        train_range_metrics = calculate_regression_metrics(y_train_range, y_train_range_pred)
        
        range_metrics['train_range'] = train_range_metrics
        range_metrics['train_range']['samples'] = len(y_train_range)
        
        logger.info(f"\n📊 Training Set Range Performance (0.2-0.5%):")
        logger.info(f"  R²: {train_range_metrics['r2']:.4f}")
        logger.info(f"  MAE: {train_range_metrics['mae']:.4f}")
        logger.info(f"  RMSE: {train_range_metrics['rmse']:.4f}")
        logger.info(f"  RRMSE: {train_range_metrics.get('rrmse', 0):.2f}%")
        logger.info(f"  MAPE: {train_range_metrics.get('mape', 0):.2f}%")
        logger.info(f"  Within 20.5%: {train_range_metrics.get('within_20.5%', 0):.2f}%")
        logger.info(f"  Samples: {len(y_train_range)}")
        
        # Test set range evaluation
        if test_df is not None:
            X_test = test_df.drop(columns=[self.config.target_column])
            y_test = test_df[self.config.target_column]
            
            X_test_range, y_test_range = self._filter_data_to_range(X_test, y_test)
            
            if len(y_test_range) > 0:
                y_test_range_pred = final_pipeline.predict(X_test_range)
                
                # Apply calibration to test range predictions if calibration was applied
                if hasattr(self, 'post_calibrator') and self.post_calibrator is not None:
                    y_test_range_pred = self.post_calibrator.transform(y_test_range_pred)
                
                # Calculate comprehensive test metrics
                test_range_metrics = calculate_regression_metrics(y_test_range, y_test_range_pred)
                
                range_metrics['test_range'] = test_range_metrics
                range_metrics['test_range']['samples'] = len(y_test_range)
                
                logger.info(f"\n🎯 Test Set Range Performance (0.2-0.5%):")
                logger.info(f"  R²: {test_range_metrics['r2']:.4f} {'✅ TARGET ACHIEVED!' if test_range_metrics['r2'] > 0.5 else '❌ Below target'}")
                logger.info(f"  MAE: {test_range_metrics['mae']:.4f}")
                logger.info(f"  RMSE: {test_range_metrics['rmse']:.4f}")
                logger.info(f"  RRMSE: {test_range_metrics.get('rrmse', 0):.2f}%")
                logger.info(f"  MAPE: {test_range_metrics.get('mape', 0):.2f}%")
                logger.info(f"  Within 20.5%: {test_range_metrics.get('within_20.5%', 0):.2f}%")
                logger.info(f"  Samples: {len(y_test_range)}")
                
                # Achievement check
                if test_range_metrics['r2'] > 0.5:
                    logger.info(f"\n🎉 SUCCESS! Achieved R² = {test_range_metrics['r2']:.4f} > 0.5 in target range!")
                else:
                    logger.info(f"\n⚠️  Need improvement: R² = {test_range_metrics['r2']:.4f} < 0.5 in target range")

        # Wrap the pipeline with post-calibration if it was used
        if self.post_calibrator is not None and getattr(self.config, 'use_post_calibration', False):
            from src.models.post_calibrated_wrapper import PostCalibratedModelWrapper
            logger.info("Wrapping model with post-calibration for deployment")
            calibrated_pipeline = PostCalibratedModelWrapper(
                final_pipeline,
                self.post_calibrator,
                self.post_calibration_config
            )
            return calibrated_pipeline, range_metrics

        return final_pipeline, range_metrics
    
    def save_model(self, pipeline, metrics: dict = None):
        """Save the range specialist model and results."""
        timestamp = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
        
        # Create model directory
        model_dir = Path("models") / "range_specialist"
        model_dir.mkdir(parents=True, exist_ok=True)
        
        # Save model with dimension reduction suffix if used
        dim_suffix = ""
        if self.config.use_dimension_reduction:
            dim_suffix = f"_{self.config.dimension_reduction.method}"
        elif self.use_pca:
            dim_suffix = "_pca"
        from main import get_display_strategy_name
        display_strategy = get_display_strategy_name(self.strategy, getattr(self.config, 'use_raw_spectral_data', False))
        model_path = model_dir / f"range_specialist_{display_strategy}{dim_suffix}_{timestamp}.pkl"
        joblib.dump(pipeline, model_path)
        logger.info(f"Range specialist model saved to: {model_path}")
        
        # Save results
        results = {
            'timestamp': timestamp,
            'strategy': self.strategy,
            'use_pca': self.use_pca,
            'use_dimension_reduction': self.config.use_dimension_reduction,
            'dimension_reduction_method': self.config.dimension_reduction.method if self.config.use_dimension_reduction else None,
            'target_range': [self.target_min, self.target_max],
            'best_params': self.best_params,
            'best_score': self.best_score,
            'range_metrics': metrics or {},
            'architecture_type': 'range_specialist',
            'optimization_goal': 'R2_greater_than_0.5_in_range_0.2_to_0.5'
        }
        
        # Add dimension reduction information if used
        if hasattr(self, '_fitted_feature_pipeline') and 'dimension_reduction' in self._fitted_feature_pipeline.named_steps:
            reducer = self._fitted_feature_pipeline.named_steps['dimension_reduction']
            
            # Get dimension reduction info
            dim_info = {}
            if hasattr(reducer, 'optimal_components_'):  # VAE with auto selection
                dim_info['n_components'] = reducer.optimal_components_
                dim_info['method'] = 'VAE (auto-selected components)'
            elif hasattr(reducer, 'n_components_'):  # Standard sklearn reducers
                dim_info['n_components'] = reducer.n_components_
                dim_info['method'] = self.config.dimension_reduction.method if self.config.use_dimension_reduction else 'PCA'
            elif hasattr(reducer, 'n_components'):  # Config parameter
                dim_info['n_components'] = reducer.n_components
                dim_info['method'] = self.config.dimension_reduction.method if self.config.use_dimension_reduction else 'PCA'
            
            # Add variance info for PCA
            if hasattr(reducer, 'explained_variance_ratio_'):
                dim_info['explained_variance_ratio'] = reducer.explained_variance_ratio_.tolist()
                dim_info['total_variance_retained'] = reducer.explained_variance_ratio_.sum()
            
            results['dimension_reduction_info'] = dim_info
        
        results_path = model_dir / f"range_specialist_results{dim_suffix}_{timestamp}.json"
        with open(results_path, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        logger.info(f"Results saved to: {results_path}")
        
        # Save configuration using config_manager
        if hasattr(self, 'config') and self.config is not None:
            # Create optimized configuration with range specialist parameters
            optimized_config = self.config.model_copy(deep=True)
            
            # Add range specialist parameters to neural network config
            if hasattr(optimized_config.model_params, 'neural_network'):
                # Update neural network parameters with range specialist best params
                nn_params = optimized_config.model_params.neural_network
                if isinstance(nn_params, dict):
                    nn_params.update(self.best_params)
                else:
                    # Handle case where neural_network is a model config object
                    for param, value in self.best_params.items():
                        if hasattr(nn_params, param):
                            setattr(nn_params, param, value)
            
            # Create configuration name and description
            config_name = f"range_specialist_{self.strategy}{dim_suffix}_{timestamp}"
            
            # Determine success status for description
            range_r2 = metrics.get('test_range', {}).get('r2', metrics.get('train_range', {}).get('r2', 0)) if metrics else 0
            if range_r2 > 0.5:
                status = "SUCCESS"
                status_desc = f"R²={range_r2:.4f}"
            else:
                status = "PROGRESS"
                status_desc = f"R²={range_r2:.4f}"
            
            # Create description with dimension reduction info
            dim_desc = ""
            if self.config.use_dimension_reduction:
                dim_desc = f", DimRed: {self.config.dimension_reduction.method}"
            elif self.use_pca:
                dim_desc = ", PCA: enabled"
            
            description = f"Range Specialist NN - {status} {status_desc} in 0.2-0.5% range, Strategy: {self.strategy}{dim_desc}"
            
            try:
                config_manager.save_config(optimized_config, config_name, description)
                logger.info(f"Configuration saved as: {config_name}")
            except Exception as e:
                logger.warning(f"Failed to save configuration: {e}")
        
        return model_path

# Range Specialist Optimizer is now integrated into main.py pipeline
# Use: python main.py optimize-range-specialist --gpu --trials 300