"""
Parallel Prediction Module: Optimized version using multiprocessing
for faster sample processing during batch prediction.
"""

import logging
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp
from pathlib import Path

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def _process_sample_group(args: Tuple) -> Dict[str, Any]:
    """
    Process a single sample group (average files, standardize, clean).
    This function is designed to be pickle-able for multiprocessing.

    Args:
        args: Tuple containing (sample_id, file_paths, config_dict, global_wavelength_range)

    Returns:
        Dictionary with sample processing results
    """
    sample_id, file_paths, config_dict, global_wavelength_range = args

    try:
        # Import here to avoid pickling issues
        from src.config.pipeline_config import Config
        from src.data_management.data_manager import DataManager
        from src.cleansing.data_cleanser import DataCleanser

        # Reconstruct config from dict (configs aren't pickle-able directly)
        config = Config(**config_dict)
        data_manager = DataManager(config)
        data_cleanser = DataCleanser(config)

        # Set global wavelength range if provided
        if global_wavelength_range:
            data_manager._global_wavelength_range = global_wavelength_range

        # Step 1: Average files for this sample
        wavelengths, averaged_intensities = data_manager.average_files_in_memory(file_paths)

        if averaged_intensities is None:
            return {
                'sample_id': sample_id,
                'success': False,
                'error': 'Averaging failed, no data returned'
            }

        # Step 2: Apply wavelength standardization if enabled
        if config.enable_wavelength_standardization:
            wavelengths, averaged_intensities = data_manager.standardize_wavelength_grid(
                wavelengths, averaged_intensities,
                interpolation_method=config.wavelength_interpolation_method,
                use_global_range=True  # Use global range from training if available
            )

        # Step 3: Clean the averaged sample
        clean_intensities = data_cleanser.clean_spectra(sample_id, averaged_intensities)

        if clean_intensities.size > 0:
            return {
                'sample_id': sample_id,
                'success': True,
                'wavelengths': wavelengths,
                'intensities': clean_intensities
            }
        else:
            return {
                'sample_id': sample_id,
                'success': False,
                'error': 'Sample flagged as outlier',
                'is_outlier': True,
                'source_files': [str(f) for f in file_paths]
            }

    except Exception as e:
        return {
            'sample_id': sample_id,
            'success': False,
            'error': str(e)
        }


def parallel_process_samples(files_by_sample: Dict[str, List[Path]],
                           config,
                           global_wavelength_range: Optional[Tuple[float, float]] = None,
                           n_jobs: int = -1) -> Tuple[List[Dict], List[Dict]]:
    """
    Process multiple sample groups in parallel for batch prediction.

    Args:
        files_by_sample: Dictionary mapping sample IDs to lists of file paths
        config: Pipeline configuration
        global_wavelength_range: Global wavelength range from training
        n_jobs: Number of parallel jobs. -1 uses all CPU cores, -2 uses all but one

    Returns:
        Tuple of (successful_samples, failed_samples)
    """
    logger.info(f"Starting PARALLEL sample processing for {len(files_by_sample)} samples")

    # Determine number of workers
    if n_jobs == -1:
        n_workers = mp.cpu_count()
    elif n_jobs == -2:
        n_workers = max(1, mp.cpu_count() - 1)
    else:
        n_workers = max(1, n_jobs)

    logger.info(f"Using {n_workers} parallel workers for sample processing")

    # Prepare arguments for parallel processing
    # Convert config to dict for pickling
    config_dict = config.model_dump()

    args_list = [
        (sample_id, file_paths, config_dict, global_wavelength_range)
        for sample_id, file_paths in files_by_sample.items()
    ]

    # Process samples in parallel
    successful_samples = []
    failed_samples = []

    with ProcessPoolExecutor(max_workers=n_workers) as executor:
        # Submit all tasks
        future_to_sample = {
            executor.submit(_process_sample_group, args): args[0]
            for args in args_list
        }

        # Collect results as they complete
        for future in as_completed(future_to_sample):
            sample_id = future_to_sample[future]
            try:
                result = future.result()

                if result['success']:
                    successful_samples.append(result)
                    logger.debug(f"Successfully processed sample: {sample_id}")
                else:
                    failed_samples.append(result)
                    if result.get('is_outlier'):
                        logger.warning(f"Sample {sample_id} flagged as outlier")
                    else:
                        logger.error(f"Failed to process sample {sample_id}: {result.get('error', 'Unknown error')}")

            except Exception as e:
                failed_samples.append({
                    'sample_id': sample_id,
                    'success': False,
                    'error': f'Exception during processing: {e}'
                })
                logger.error(f"Exception while processing sample {sample_id}: {e}")

    logger.info(f"Parallel sample processing complete: {len(successful_samples)} successful, {len(failed_samples)} failed")
    return successful_samples, failed_samples