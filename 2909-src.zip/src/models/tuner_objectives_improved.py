"""
Improved Tuner Objective Functions

Following ML best practices for objective functions:
1. Consistent scaling (0-1 range preferred)
2. Single metric focus or weighted average with normalized components
3. Data-driven thresholds
4. Avoid arbitrary constants

All functions now use configurable parameters from ObjectiveConfig.
"""
import numpy as np
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from src.config.pipeline_config import ObjectiveConfig

def calculate_robust_objective_v2(cv_scores: np.ndarray, train_r2: float, test_r2: float, config: ObjectiveConfig = None) -> float:
    """
    Improved robust objective focusing on generalization.
    Returns value in [0, 1] range.
    """
    if config is None:
        config = ObjectiveConfig()
    
    cv_mean = np.mean(cv_scores)
    cv_std = np.std(cv_scores)
    
    # Normalize CV stability to [0, 1] - lower std is better
    stability_score = 1 - min(cv_std, config.cv_stability_cap) / config.cv_stability_cap
    
    # Generalization score - penalize overfitting
    generalization_gap = max(0, train_r2 - test_r2)
    generalization_score = 1 - min(generalization_gap, config.generalization_gap_cap) / config.generalization_gap_cap
    
    # Weighted combination using config values
    return (config.cv_weight * cv_mean + 
            config.stability_weight * stability_score + 
            config.generalization_weight * generalization_score)

def calculate_weighted_r2_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None, config: ObjectiveConfig = None) -> float:
    """
    Weighted R² that emphasizes accuracy on specific concentration ranges.
    Returns standard R² value in [-inf, 1] range.
    
    Args:
        y_true: True target values
        y_pred: Predicted values  
        base_r2: Legacy parameter for interface compatibility (not used)
        config: Configuration object with weighting parameters
    """
    if config is None:
        config = ObjectiveConfig()
    
    # Calculate sample weights based on concentration
    percentiles = np.percentile(y_true, [25, 75])
    
    weights = np.ones_like(y_true, dtype=float)
    # Give more weight to rare/important samples using config values
    weights[y_true <= percentiles[0]] = config.quartile_low_weight  # Bottom quartile
    weights[y_true >= percentiles[1]] = config.quartile_high_weight  # Top quartile
    
    # Calculate weighted R²
    y_mean = np.average(y_true, weights=weights)
    ss_tot = np.average((y_true - y_mean)**2, weights=weights)
    ss_res = np.average((y_true - y_pred)**2, weights=weights)
    
    return 1 - (ss_res / ss_tot) if ss_tot > 0 else 0

def calculate_balanced_mae_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None) -> float:
    """
    Balanced MAE that normalizes errors by concentration range.
    Returns value in [0, 1] range where higher is better.
    
    Args:
        y_true: True target values
        y_pred: Predicted values
        base_r2: Legacy parameter for interface compatibility (not used)
    """
    # Calculate MAE for different concentration bins
    bins = np.percentile(y_true, [0, 33, 66, 100])
    mae_scores = []
    
    for i in range(len(bins)-1):
        mask = (y_true >= bins[i]) & (y_true < bins[i+1])
        if np.any(mask):
            mae = mean_absolute_error(y_true[mask], y_pred[mask])
            # Normalize by range to make errors comparable
            range_size = bins[i+1] - bins[i]
            normalized_mae = mae / range_size if range_size > 0 else mae
            mae_scores.append(normalized_mae)
    
    # Convert to maximization objective (lower MAE is better)
    avg_normalized_mae = np.mean(mae_scores) if mae_scores else 1.0
    return 1 / (1 + avg_normalized_mae)

def calculate_quantile_weighted_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None, config: ObjectiveConfig = None) -> float:
    """
    Objective that weights performance by quantiles of the target distribution.
    Ensures good performance across the entire range.
    
    Args:
        y_true: True target values
        y_pred: Predicted values
        base_r2: Legacy parameter for interface compatibility (not used)
        config: Configuration object with quantile parameters
    """
    if config is None:
        config = ObjectiveConfig()
        
    # Split into quantiles using config
    quantiles = np.linspace(0, 100, config.n_quantiles + 1)
    bounds = np.percentile(y_true, quantiles)
    
    quantile_scores = []
    for i in range(config.n_quantiles):
        mask = (y_true >= bounds[i]) & (y_true <= bounds[i+1])
        if np.sum(mask) >= config.min_quantile_samples:  # Use config minimum
            # Calculate R² for this quantile
            r2_quantile = r2_score(y_true[mask], y_pred[mask])
            # Ensure non-negative (clip negative R² to 0)
            quantile_scores.append(max(0, r2_quantile))
    
    # Return mean of quantile scores
    return np.mean(quantile_scores) if quantile_scores else 0

def calculate_distribution_based_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None, config: ObjectiveConfig = None) -> float:
    """
    Distribution-based weighted R² that uses inverse density weighting.
    Emphasizes performance on underrepresented concentration ranges.
    
    Args:
        y_true: True target values
        y_pred: Predicted values  
        base_r2: Legacy parameter for interface compatibility (not used)
        config: Configuration object with weighting parameters
    """
    if config is None:
        config = ObjectiveConfig()
        
    try:
        from scipy.stats import gaussian_kde
        # Estimate probability density at each point
        kde = gaussian_kde(y_true)
        densities = kde(y_true)
        
        # Inverse density weighting (smooth)
        weights = 1.0 / (densities + config.kde_epsilon)
        
        # Apply smoothing to prevent extreme weights using config bounds
        weights = np.clip(weights, config.min_sample_weight, config.max_sample_weight)
        
    except ImportError:
        # Fallback: bin-based distribution weighting using config bins
        bins = np.percentile(y_true, config.distribution_bins)
        bin_indices = np.digitize(y_true, bins) - 1
        
        # Calculate inverse frequency weights
        unique_bins, counts = np.unique(bin_indices, return_counts=True)
        total_samples = len(y_true)
        
        weights = np.ones_like(y_true, dtype=float)
        for bin_idx, count in zip(unique_bins, counts):
            mask = bin_indices == bin_idx
            weights[mask] = total_samples / (len(unique_bins) * count)
    
    # Calculate weighted R²
    y_mean = np.average(y_true, weights=weights)
    ss_tot = np.average((y_true - y_mean)**2, weights=weights)
    ss_res = np.average((y_true - y_pred)**2, weights=weights)
    
    return 1 - (ss_res / ss_tot) if ss_tot > 0 else 0

def calculate_hybrid_weighted_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None, config: ObjectiveConfig = None) -> float:
    """
    Hybrid weighted R² that combines distribution-based weighting with domain knowledge.
    Uses data-driven weighting but emphasizes extreme concentration ranges.
    
    Args:
        y_true: True target values
        y_pred: Predicted values  
        base_r2: Legacy parameter for interface compatibility (not used)
        config: Configuration object with weighting parameters
    """
    if config is None:
        config = ObjectiveConfig()
        
    # Step 1: Get distribution-based weights
    try:
        from scipy.stats import gaussian_kde
        kde = gaussian_kde(y_true)
        densities = kde(y_true)
        dist_weights = 1.0 / (densities + config.kde_epsilon)
        dist_weights = np.clip(dist_weights, config.min_sample_weight, config.max_sample_weight)
    except ImportError:
        # Fallback: bin-based distribution weighting using config bins
        bins = np.percentile(y_true, config.distribution_bins)
        bin_indices = np.digitize(y_true, bins) - 1
        unique_bins, counts = np.unique(bin_indices, return_counts=True)
        total_samples = len(y_true)
        
        dist_weights = np.ones_like(y_true, dtype=float)
        for bin_idx, count in zip(unique_bins, counts):
            mask = bin_indices == bin_idx
            dist_weights[mask] = total_samples / (len(unique_bins) * count)
    
    # Step 2: Apply domain knowledge modifiers using config values
    percentiles = np.percentile(y_true, [25, 75])
    domain_modifiers = np.ones_like(y_true, dtype=float)
    
    # Emphasize extreme ranges (domain knowledge) using config modifiers
    domain_modifiers[y_true <= percentiles[0]] *= config.low_range_modifier  # Low concentrations
    domain_modifiers[y_true >= percentiles[1]] *= config.high_range_modifier  # High concentrations
    
    # Step 3: Combine both approaches
    weights = dist_weights * domain_modifiers
    
    # Normalize weights
    weights = weights * len(y_true) / np.sum(weights)
    
    # Calculate weighted R²
    y_mean = np.average(y_true, weights=weights)
    ss_tot = np.average((y_true - y_mean)**2, weights=weights)
    ss_res = np.average((y_true - y_pred)**2, weights=weights)
    
    return 1 - (ss_res / ss_tot) if ss_tot > 0 else 0