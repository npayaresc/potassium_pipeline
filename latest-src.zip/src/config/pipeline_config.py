"""
Centralized Configuration Management for the ML Pipeline.

Uses Pydantic for data validation and clear structure.
"""
from typing import List, Dict, Any, Optional, Literal
from pydantic import BaseModel, DirectoryPath, FilePath, field_validator
import os


class ModelParamsConfig(BaseModel):
    """Default parameters for the standard training models."""
    ridge: Dict[str, Any] = {"alpha": 1.0}
    lasso: Dict[str, Any] = {"alpha": 0.1}
    elastic_net: Dict[str, Any] = {"alpha": 0.1, "l1_ratio": 0.5}
    random_forest: Dict[str, Any] = {"n_estimators": 100}
    gradient_boost: Dict[str, Any] = {"n_estimators": 100}
    xgboost: Dict[str, Any] = {"n_estimators": 100, "learning_rate": 0.1, "max_depth": 6}
    lightgbm: Dict[str, Any] = {"n_estimators": 100, "learning_rate": 0.1, "max_depth": 6}
    catboost: Dict[str, Any] = {"n_estimators": 100, "learning_rate": 0.1, "depth": 6}
    svr: Dict[str, Any] = {"kernel": 'rbf', "C": 1.0, "gamma": 'scale'}
    extratrees: Dict[str, Any] = {"n_estimators": 100}

# Tuner Config
class TunerConfig(BaseModel):
    """Configuration for the Optuna hyperparameter tuner."""
    n_trials: int = 200
    timeout: int = 8600
    n_jobs: int = 4
    #models_to_tune: List[str] = ["random_forest", "xgboost", "lightgbm", "catboost", "svr", "extratrees"]
    models_to_tune: List[str] = ["extratrees"]
    # Use this to select the tuning goal.
    objective_function_name: Literal[
        'r2', 'robust', 'concentration_weighted', 'mape_focused',
        'robust_v2', 'weighted_r2', 'balanced_mae', 'quantile_weighted',
        'distribution_based', 'hybrid_weighted'
    ] = 'distribution_based'



# This placeholder class is needed for Pydantic validation.
# In a real project, it would be imported from src.spectral_extraction.results
class PeakRegion(BaseModel):
    element: str
    lower_wavelength: float
    upper_wavelength: float
    center_wavelengths: List[float]

    @property
    def n_peaks(self) -> int:
        return len(self.center_wavelengths)

class AutoGluonConfig(BaseModel):
    """Configuration specific to the AutoGluon pipeline."""
    # This flag enables all the advanced features from your original code
    use_improved_config: bool = True
    
    # Sample weighting configuration
    weight_method: Literal['legacy', 'improved'] = 'improved'
    
    time_limit: int = 3600
    presets: str = 'best_quality'
    model_subdirectory: str = "autogluon"
    num_trials: int = 50  # Number of trials for AutoGluon hyperparameter optimization
    
    # Advanced training arguments from the original script
    ag_args_fit: Dict[str, Any] = {
        'num_bag_folds': 10,
        'num_bag_sets': 2,
        'num_stack_levels': 2,
        'num_gpus': 1, # Set to 1 to attempt GPU usage
    }
    ag_args_ensemble: Dict[str, Any] = {
        'fold_fitting_strategy': 'sequential_local', # Avoids GPU parallelism issues
    }
    excluded_model_types: List[str] = ['KNN', 'FASTAI']
    
    # The full "enhanced" hyperparameters dictionary from the original script
    hyperparameters: Dict[str, Any] = {
        'GBM': [
            {'num_boost_round': 200, 'learning_rate': 0.05, 'num_leaves': 63, 'feature_fraction': 0.8},
            {'num_boost_round': 300, 'learning_rate': 0.03, 'num_leaves': 127, 'feature_fraction': 0.7},
        ],
        'CAT': [
            {'iterations': 500, 'learning_rate': 0.05, 'depth': 8},
            {'iterations': 700, 'learning_rate': 0.03, 'depth': 10},
        ],
        'XGB': [
            {'n_estimators': 200, 'max_depth': 8, 'learning_rate': 0.05, 'subsample': 0.8},
            {'n_estimators': 300, 'max_depth': 10, 'learning_rate': 0.03, 'subsample': 0.7},
        ],
        'RF': [
            {'n_estimators': 200, 'max_features': 'sqrt', 'max_depth': 20},
            {'n_estimators': 300, 'max_features': 0.7, 'max_depth': None},
        ],
        'XT': [
            {'n_estimators': 200, 'max_features': 'sqrt', 'max_depth': 20},
            {'n_estimators': 300, 'max_features': 0.7, 'max_depth': None},
        ],
        'NN_TORCH': [
            {'num_epochs': 50, 'learning_rate': 0.001, 'dropout_prob': 0.2},
            {'num_epochs': 100, 'learning_rate': 0.0005, 'dropout_prob': 0.3},
        ]
    }

class Config(BaseModel):
    """Main configuration class for the entire pipeline."""
    project_name: str = "NitrogenPrediction"
    run_timestamp: str
    random_state: int = 42
    use_gpu: bool = False  # Global GPU flag

    data_dir: DirectoryPath
    raw_data_dir: DirectoryPath
    processed_data_dir: DirectoryPath
    model_dir: DirectoryPath
    reports_dir: DirectoryPath
    log_dir: DirectoryPath
    bad_files_dir: DirectoryPath
    averaged_files_dir: DirectoryPath  
    cleansed_files_dir: DirectoryPath 
    bad_prediction_files_dir: DirectoryPath 

    reference_data_path: FilePath
    
    # --- Data Management ---
    target_column: str = "Nitrogen %"
    sample_id_column: str = "Sample ID"
    exclude_pot_samples: bool = False
    test_split_size: float = 0.35
    max_samples: Optional[int] = None
    
    # ADDED: Configuration for target value filtering
    target_value_min: Optional[float] = 2.0
    target_value_max: Optional[float] = 7.0
    
    # Custom validation set directory - if provided, will process raw files from this directory for validation
    custom_validation_dir: Optional[str] = "/home/payanico/nitrogen_pipeline/data/raw/combo_6_8"
    #custom_validation_dir: Optional[str] = None

    # Wavelength standardization configuration
    enable_wavelength_standardization: bool = False
    wavelength_interpolation_method: Literal['linear', 'cubic', 'nearest'] = 'linear'
    wavelength_resolution: float = 0.1  # nm resolution for standardized grid

    outlier_method: str = 'SAM'
    outlier_threshold: float = 0.95
    max_outlier_percentage: float = 50.0

    @field_validator('outlier_method')
    @classmethod
    def outlier_method_must_be_valid(cls, v):
        if v.upper() not in ['SAM', 'MAD']:
            raise ValueError("outlier_method must be 'SAM' or 'MAD'")
        return v.upper()

    nitrogen_region: PeakRegion = PeakRegion(
        element="N_I", lower_wavelength=741.0, upper_wavelength=743.0, center_wavelengths=[742.0]
    )
    context_regions: List[PeakRegion] = [
        PeakRegion(element="C_I", lower_wavelength=832.5, upper_wavelength=834.5, center_wavelengths=[833.5]),
        PeakRegion(element="CA_I_help", lower_wavelength=525.1, upper_wavelength=527.1, center_wavelengths=[526.1]),
        PeakRegion(element="N_II_help", lower_wavelength=746.8, upper_wavelength=748.8, center_wavelengths=[747.8]),
        PeakRegion(element="P_I_help", lower_wavelength=653.5, upper_wavelength=656.5, center_wavelengths=[654.5]),
        PeakRegion(element="K_I_help", lower_wavelength=768.79, upper_wavelength=770.79, center_wavelengths=[769.79]),
    ]
    
    # Enhanced spectral regions for crop nitrogen prediction
    # Molecular bands
    molecular_bands: List[PeakRegion] = [
        PeakRegion(element="CN_violet_1", lower_wavelength=385.0, upper_wavelength=390.0, center_wavelengths=[387.5]),
        PeakRegion(element="CN_violet_2", lower_wavelength=415.0, upper_wavelength=425.0, center_wavelengths=[420.0]),
        PeakRegion(element="NH_band", lower_wavelength=335.0, upper_wavelength=338.0, center_wavelengths=[336.5]),
        PeakRegion(element="NO_band", lower_wavelength=226.0, upper_wavelength=248.0, center_wavelengths=[237.0]),
    ]
    
    # Additional macro elements
    macro_elements: List[PeakRegion] = [
        PeakRegion(element="S_I", lower_wavelength=834.5, upper_wavelength=836.5, center_wavelengths=[835.5]),
        PeakRegion(element="S_I_2", lower_wavelength=868.0, upper_wavelength=870.0, center_wavelengths=[869.0]),
        PeakRegion(element="Mg_I", lower_wavelength=515.7, upper_wavelength=517.7, center_wavelengths=[516.7]),
        PeakRegion(element="Mg_II", lower_wavelength=279.0, upper_wavelength=281.0, center_wavelengths=[280.3]),
    ]
    
    # Micro elements
    micro_elements: List[PeakRegion] = [
        PeakRegion(element="Fe_I", lower_wavelength=437.5, upper_wavelength=439.5, center_wavelengths=[438.4]),
        PeakRegion(element="Fe_I_2", lower_wavelength=439.5, upper_wavelength=441.5, center_wavelengths=[440.5]),
        PeakRegion(element="Mn_I", lower_wavelength=402.5, upper_wavelength=404.5, center_wavelengths=[403.4]),
        PeakRegion(element="B_I", lower_wavelength=248.5, upper_wavelength=250.5, center_wavelengths=[249.8]),
        PeakRegion(element="Zn_I", lower_wavelength=480.5, upper_wavelength=482.5, center_wavelengths=[481.1]),
        PeakRegion(element="Cu_I", lower_wavelength=323.5, upper_wavelength=325.5, center_wavelengths=[324.8]),
        PeakRegion(element="Mo_I", lower_wavelength=378.5, upper_wavelength=380.5, center_wavelengths=[379.8]),
    ]
    
    # Oxygen and hydrogen lines
    oxygen_hydrogen: List[PeakRegion] = [
        PeakRegion(element="O_I", lower_wavelength=776.5, upper_wavelength=778.5, center_wavelengths=[777.4]),
        PeakRegion(element="O_I_2", lower_wavelength=843.5, upper_wavelength=845.5, center_wavelengths=[844.6]),
        PeakRegion(element="H_alpha", lower_wavelength=655.5, upper_wavelength=657.5, center_wavelengths=[656.3]),
        PeakRegion(element="H_beta", lower_wavelength=485.0, upper_wavelength=487.0, center_wavelengths=[486.1]),
    ]
    
    # Feature configuration flags
    enable_molecular_bands: bool = False
    enable_macro_elements: bool = False
    enable_micro_elements: bool = False
    enable_oxygen_hydrogen: bool = False
    enable_advanced_ratios: bool = False
    enable_spectral_patterns: bool = False
    enable_interference_correction: bool = False
    enable_plasma_indicators: bool = False

    @property
    def all_regions(self) -> List[PeakRegion]:
        regions = [self.nitrogen_region] + self.context_regions
        
        # Add enabled enhanced regions
        if self.enable_molecular_bands:
            regions.extend(self.molecular_bands)
        if self.enable_macro_elements:
            regions.extend(self.macro_elements)
        if self.enable_micro_elements:
            regions.extend(self.micro_elements)
        if self.enable_oxygen_hydrogen:
            regions.extend(self.oxygen_hydrogen)
            
        return regions

    #feature_strategies: List[str] = ["N_only", "simple_only", "full_context"]
    feature_strategies: List[str] = ["full_context"]
    peak_shapes: List[str] = ['lorentzian']
    fitting_mode: str = 'mean_first'
    baseline_correction: bool = True

    # models_to_train: List[str] = [
    #     "ridge", "lasso", "random_forest", "gradient_boost", "xgboost",
    #     "lightgbm", "catboost", "svr", "extratrees", "ridge_pca", "lasso_pca", "elastic_net_pca", "random_forest_pca", "gradient_boost_pca", "xgboost_pca", "lightgbm_pca", "catboost_pca", "svr_pca", "extratrees_pca"
    # ]
    models_to_train: List[str] = ["extratrees"]
    # Sample weighting configuration for model training
    use_sample_weights: bool = True
    sample_weight_method: Literal['legacy', 'improved', 'weighted_r2', 'distribution_based', 'hybrid'] = 'distribution_based'
    
    model_params: ModelParamsConfig = ModelParamsConfig()
    cv_folds: int = 5

    autogluon: AutoGluonConfig = AutoGluonConfig()

    log_file: str = "pipeline.log"
    log_level: str = "INFO"
    
    # --- Model Tuning ---
    tuner: TunerConfig = TunerConfig()

    class Config:
        validate_assignment = True

config = Config(
    run_timestamp="placeholder", data_dir=".", raw_data_dir=".", processed_data_dir=".",
    model_dir=".", reports_dir=".", log_dir=".", reference_data_path="README.md", bad_files_dir=".", averaged_files_dir=".", cleansed_files_dir=".", bad_prediction_files_dir="."
)