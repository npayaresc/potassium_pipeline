"""
Feature Engineering Module: Defines reusable scikit-learn compatible transformers for
creating features from raw spectral data.
"""
import logging
from typing import List, Dict, Any

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

from src.features.feature_helpers import extract_full_simple_features, generate_high_nitrogen_features
from src.config.pipeline_config import Config, PeakRegion
from src.spectral_extraction.extractor import SpectralFeatureExtractor
from src.utils.helpers import OutlierClipper
from src.features.enhanced_features import EnhancedSpectralFeatures

logger = logging.getLogger(__name__)

class SpectralFeatureGenerator(BaseEstimator, TransformerMixin):
    """Extracts features from spectral data using the SpectralFeatureExtractor."""
    def __init__(self, config: Config, strategy: str = "simple_only"):
        self.config = config
        self.strategy = strategy
        self.extractor = SpectralFeatureExtractor()
        self.feature_names_out: List[str] = []

    """
    Extracts features from spectral data, now perfectly mirroring the
    original script's feature creation for all strategies.
    """
    def __init__(self, config: Config, strategy: str):
        self.config = config
        self.strategy = strategy
        self.extractor = SpectralFeatureExtractor()
        self.feature_names_out_: List[str] = []
        self._all_simple_names = []
        self._high_n_names = []
        # Initialize enhanced features if any are enabled
        self._use_enhanced = any([
            config.enable_molecular_bands, config.enable_advanced_ratios,
            config.enable_spectral_patterns, config.enable_interference_correction,
            config.enable_plasma_indicators
        ])
        if self._use_enhanced:
            self.enhanced_features = EnhancedSpectralFeatures(config)

    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        """Fits the transformer by determining the canonical feature names."""
        self._set_feature_names(X.iloc[0:1]) # Use a sample row to determine dynamic feature names
        logger.info(f"SpectralFeatureGenerator fitted for strategy '{self.strategy}'.")
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transforms raw spectral data into the final feature matrix."""
        base_features_list = [self._extract_base_features(row) for _, row in X.iterrows()]
        base_features_df = pd.DataFrame(base_features_list, index=X.index)

        n_area = base_features_df.get('N_I_peak_0', pd.Series(np.nan, index=base_features_df.index))
        c_area = base_features_df.get('C_I_peak_0', pd.Series(np.nan, index=base_features_df.index))
        
        # Calculate NC_ratio with clipping to prevent extreme values
        nc_ratio_raw = n_area / c_area.replace(0, 1e-6)
        base_features_df['N_C_ratio'] = np.clip(nc_ratio_raw, -50.0, 50.0)
        
        full_features_df, _ = generate_high_nitrogen_features(base_features_df, self._all_simple_names)
        
        final_df = full_features_df.reindex(columns=self.get_feature_names_out(), fill_value=np.nan)
        
        # Ensure the final dataframe maintains the original index
        final_df.index = X.index
        
        logger.info(f"Transformed data into {final_df.shape[1]} features for strategy '{self.strategy}'.")
        return final_df

    def _extract_base_features(self, row: pd.Series) -> Dict[str, Any]:
        """Extracts simple and complex features for a single sample."""
        features = {}
        wavelengths = np.asarray(row['wavelengths'])
        intensities = np.asarray(row['intensities'])
        
        if intensities.size == 0:
            # Return NaN for all expected features instead of empty dict
            logger.warning(f"Empty intensities found for sample, returning NaN features")
            return {}

        for region in self.config.all_regions:
            features.update(extract_full_simple_features(region, wavelengths, intensities))
        
        # Ensure intensities is 2D for the extractor (expects n_wavelengths x n_spectra)
        spectra_2d = intensities.reshape(-1, 1) if intensities.ndim == 1 else intensities
        
        fit_results = self.extractor.extract_features(
            wavelengths=wavelengths, spectra=spectra_2d, regions=self.config.all_regions,
            peak_shapes=self.config.peak_shapes * len(self.config.all_regions)
        )
        for res in fit_results.fitting_results:
            element = res.region_result.region.element
            for i, area in enumerate(res.peak_areas):
                features[f"{element}_peak_{i}"] = area
                
        # Add enhanced features if enabled
        if self._use_enhanced:
            enhanced_feats = self.enhanced_features.transform(features, wavelengths, intensities)
            features.update(enhanced_feats)
            
        return features
    
    def _set_feature_names(self, X_sample):
        """
        Defines the canonical list of feature names for each strategy,
        matching the original script's logic exactly.
        """
        # Define all possible base feature names
        all_complex_names = []
        for region in self.config.all_regions:
            for i in range(region.n_peaks):
                all_complex_names.append(f'{region.element}_peak_{i}')
        
        # This list of 48 features is now correct
        self._all_simple_names = []
        for region in self.config.all_regions:
            prefix = f"{region.element}_simple"
            self._all_simple_names.extend([
                f'{prefix}_peak_area', f'{prefix}_peak_height', f'{prefix}_peak_center_intensity',
                f'{prefix}_baseline_avg', f'{prefix}_signal_range', f'{prefix}_total_intensity',
                f'{prefix}_height_to_baseline', f'{prefix}_normalized_area'
            ])
        
        # Dynamically determine the high_n_names by running a sample
        # This makes it robust to changes in the helper function
        # Temporarily disable enhanced features to avoid recursion
        use_enhanced_temp = self._use_enhanced
        self._use_enhanced = False
        sample_base_df = pd.DataFrame([self._extract_base_features(X_sample.iloc[0])])
        self._use_enhanced = use_enhanced_temp
        
        sample_base_df['N_C_ratio'] = 0.0
        _, self._high_n_names = generate_high_nitrogen_features(sample_base_df, self._all_simple_names)

        # Get enhanced feature names if enabled
        enhanced_names = []
        if self._use_enhanced:
            # Use the sample features we already extracted
            sample_features = sample_base_df.iloc[0].to_dict()
            sample_wavelengths = np.asarray(X_sample.iloc[0]['wavelengths'])
            sample_intensities = np.asarray(X_sample.iloc[0]['intensities'])
            enhanced_sample = self.enhanced_features.transform(sample_features, sample_wavelengths, sample_intensities)
            enhanced_names = list(enhanced_sample.keys())
        
        if self.strategy == "N_only":
            n_complex = [name for name in all_complex_names if name.startswith('N_I_')]
            n_simple = [name for name in self._all_simple_names if name.startswith('N_I_simple')]
            n_enhanced = [name for name in enhanced_names if 'N' in name or 'nitrogen' in name.lower()]
            self.feature_names_out_ = n_complex + n_simple + n_enhanced
        elif self.strategy == "simple_only":
            self.feature_names_out_ = self._all_simple_names + ['N_C_ratio'] + self._high_n_names + enhanced_names
        elif self.strategy == "full_context":
            self.feature_names_out_ = all_complex_names + self._all_simple_names + ['N_C_ratio'] + self._high_n_names + enhanced_names
        else:
            raise ValueError(f"Unknown feature strategy: {self.strategy}")

    def _extract_features_for_sample(self, wavelengths: np.ndarray, intensities: np.ndarray) -> Dict[str, Any]:
        """Core feature extraction logic for a single sample."""
        features = {}
        
        # Ensure intensities is 2D for the extractor (expects n_wavelengths x n_spectra)
        spectra_2d = intensities.reshape(-1, 1) if intensities.ndim == 1 else intensities
        
        fit_results = self.extractor.extract_features(
            wavelengths=wavelengths, spectra=spectra_2d, regions=self.config.all_regions,
            peak_shapes=self.config.peak_shapes * len(self.config.all_regions),
            fitting_mode=self.config.fitting_mode, baseline_correction=self.config.baseline_correction,
        )
        element_to_areas = {res.region_result.region.element: res.peak_areas for res in fit_results.fitting_results}

        for region in self.config.all_regions:
            areas = element_to_areas.get(region.element, [np.nan] * region.n_peaks)
            for i, area in enumerate(areas): features[f"{region.element}_peak_{i}"] = area
            features.update(self._extract_simple_region_features(region, wavelengths, intensities))

        n_area, c_area = features.get('N_I_peak_0', np.nan), features.get('C_I_peak_0', np.nan)
        nc_ratio = n_area / c_area if not np.isnan(n_area) and not np.isnan(c_area) and c_area > 1e-6 else np.nan
        
        # Clip NC_ratio to reasonable bounds to prevent extreme values in derived features
        if not np.isnan(nc_ratio):
            nc_ratio = np.clip(nc_ratio, -50.0, 50.0)
        
        features.update({
            'N_C_ratio': nc_ratio, 'NC_ratio_squared': nc_ratio ** 2 if not np.isnan(nc_ratio) else np.nan,
            'NC_ratio_cubic': nc_ratio ** 3 if not np.isnan(nc_ratio) else np.nan, 
            'NC_ratio_log': np.log1p(np.abs(nc_ratio)) if not np.isnan(nc_ratio) else np.nan
        })
        return features

    

    def get_feature_names_out(self, input_features=None): return self.feature_names_out_
    def _get_empty_features(self) -> Dict[str, Any]: return {name: np.nan for name in self.get_feature_names_out()}
    def _extract_simple_region_features(self, region: PeakRegion, wavelengths: np.ndarray, intensities: np.ndarray) -> Dict[str, float]:
        """Simplified simple feature extractor."""
        prefix = f"{region.element}_simple"
        
        # Ensure arrays are numpy arrays
        wavelengths = np.asarray(wavelengths)
        intensities = np.asarray(intensities)
        
        mask = (wavelengths >= region.lower_wavelength) & (wavelengths <= region.upper_wavelength)
        
        # Handle both 1D (single sample) and 2D (multiple samples) arrays
        if intensities.ndim == 1:
            if not np.any(mask) or intensities.size == 0:
                return {f'{prefix}_peak_area': np.nan, f'{prefix}_peak_height': np.nan, f'{prefix}_height_to_baseline': np.nan}
            avg_spectrum = intensities[mask]
        else:
            if not np.any(mask) or intensities.shape[1] == 0:
                return {f'{prefix}_peak_area': np.nan, f'{prefix}_peak_height': np.nan, f'{prefix}_height_to_baseline': np.nan}
            avg_spectrum = np.mean(intensities[mask, :], axis=1)
        
        peak_height, baseline_avg = np.max(avg_spectrum), (avg_spectrum[0] + avg_spectrum[-1]) / 2
        return {
            f'{prefix}_peak_area': np.trapz(avg_spectrum, wavelengths[mask]),
            f'{prefix}_peak_height': peak_height,
            f'{prefix}_height_to_baseline': peak_height - baseline_avg
        }

def create_feature_pipeline(config: Config, strategy: str, exclude_scaler: bool = False) -> Pipeline:
    """Creates a scikit-learn pipeline for the entire feature engineering process."""
    steps = [
        ('spectral_features', SpectralFeatureGenerator(config=config, strategy=strategy)),
        ('imputer', SimpleImputer(strategy='mean')),
        ('clipper', OutlierClipper())
    ]
    
    # Add StandardScaler unless explicitly excluded (e.g., for AutoGluon)
    if not exclude_scaler:
        steps.append(('scaler', StandardScaler()))
    
    pipeline = Pipeline(steps)
    scaler_info = "without StandardScaler" if exclude_scaler else "with StandardScaler"
    logger.info(f"Created feature engineering pipeline for strategy: '{strategy}' {scaler_info}.")
    return pipeline