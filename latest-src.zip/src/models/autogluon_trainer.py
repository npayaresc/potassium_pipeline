"""
AutoGluon Training Module: Defines the specific training process for the AutoGluon pipeline.
"""
import logging
from pathlib import Path
import pandas as pd
from sklearn.pipeline import Pipeline

from src.config.pipeline_config import Config
from src.features.feature_engineering import create_feature_pipeline
from src.models.custom_autogluon import AutoGluonRegressor
from src.reporting.reporter import Reporter

logger = logging.getLogger(__name__)

class AutoGluonTrainer:
    """Handles the training and saving of an AutoGluon model."""
    def __init__(self, config: Config, strategy: str, reporter: Reporter):
        self.config = config
        self.strategy = strategy
        self.reporter = reporter
        
        self.feature_pipeline = create_feature_pipeline(config, strategy, exclude_scaler=True)
        
        self.autogluon_model_path = (
            Path(self.config.model_dir) / self.config.autogluon.model_subdirectory
            / f"{self.strategy}_{self.config.run_timestamp}"
        )
        self.autogluon_model_path.mkdir(parents=True, exist_ok=True)
        # Save feature pipeline inside the specific AutoGluon model directory
        self.feature_pipeline_path = self.autogluon_model_path / "feature_pipeline.pkl"
        
    def save(self):
        """Saves the trained feature pipeline to disk."""
        import joblib
        
        logger.info(f"Saving feature pipeline to: {self.feature_pipeline_path}")
        joblib.dump(self.feature_pipeline, self.feature_pipeline_path)
        logger.info("Feature pipeline saved successfully")

    def train(self, train_df: pd.DataFrame):
        """Trains the full feature engineering and AutoGluon pipeline."""
        X_train_raw = train_df.drop(columns=[self.config.target_column])
        y_train = train_df[self.config.target_column]
        y_train.name = self.config.target_column
        logger.info(f"Starting AutoGluon pipeline for strategy: {self.strategy}")

        logger.info("Preprocessing data for AutoGluon...")
        # Use train_df directly and let the pipeline handle consistency
        # This ensures X and y always have matching indices
        X_train_features = train_df.drop(columns=[self.config.target_column, self.config.sample_id_column])
        X_train_processed = self.feature_pipeline.fit_transform(X_train_features)
        X_train_processed_df = pd.DataFrame(
            X_train_processed, 
            columns=self.feature_pipeline.get_feature_names_out(),
            index=X_train_features.index  # Preserve original index
        )
        
        # Filter y_train to match the processed features using the same index
        y_train_filtered = train_df.loc[X_train_processed_df.index, self.config.target_column].copy()
        y_train_filtered.name = self.config.target_column
        
        if len(X_train_processed_df) != len(y_train):
            logger.warning(f"Feature pipeline filtered data: {len(y_train)} -> {len(X_train_processed_df)} samples")
        
        # Save the fitted feature pipeline
        self.save()

        # Update AutoGluon config based on global GPU flag
        autogluon_config = self.config.autogluon.model_copy(deep=True)
        if self.config.use_gpu:
            autogluon_config.ag_args_fit['num_gpus'] = 1
            logger.info("GPU enabled for AutoGluon (num_gpus=1)")
        else:
            autogluon_config.ag_args_fit['num_gpus'] = 0
            logger.info("GPU disabled for AutoGluon (num_gpus=0)")
        
        self.autogluon_regressor = AutoGluonRegressor(
            config=autogluon_config, model_path=self.autogluon_model_path
        )
        self.autogluon_regressor.fit(X_train_processed_df, y_train_filtered)
        logger.info(f"AutoGluon training complete. Artifacts in: {self.autogluon_model_path}")
    
    def train_and_evaluate(self, train_df: pd.DataFrame, test_df: pd.DataFrame):
        """Trains AutoGluon model and evaluates on test set, using reporter for results."""
        # Train the model
        self.train(train_df)
        
        # Prepare test data
        X_test_raw = test_df.drop(columns=[self.config.target_column])
        y_test = test_df[self.config.target_column]
        
        # We need sample_id from the test set for detailed prediction saving
        test_sample_ids = X_test_raw[self.config.sample_id_column]
        
        # Transform test data
        X_test_processed = self.feature_pipeline.transform(X_test_raw.drop(columns=[self.config.sample_id_column]))
        X_test_processed_df = pd.DataFrame(X_test_processed, columns=self.feature_pipeline.get_feature_names_out())
        
        # Make predictions
        y_pred = self.autogluon_regressor.predict(X_test_processed_df)
        
        # Calculate metrics
        from src.utils.helpers import calculate_regression_metrics
        metrics = calculate_regression_metrics(y_test, y_pred)
        logger.info(f"AutoGluon evaluation metrics: {metrics}")
        
        # Get AutoGluon model info
        model_name = "autogluon"
        params = {
            "time_limit": self.config.autogluon.time_limit,
            "num_trials": self.config.autogluon.num_trials,
            "presets": self.config.autogluon.presets,
            "num_gpus": self.config.autogluon.ag_args_fit.get('num_gpus', 0),
            "num_stack_levels": self.config.autogluon.ag_args_fit.get('num_stack_levels', 2),
            "num_bag_folds": self.config.autogluon.ag_args_fit.get('num_bag_folds', 10),
            "num_bag_sets": self.config.autogluon.ag_args_fit.get('num_bag_sets', 2),
            "fold_fitting_strategy": self.config.autogluon.ag_args_ensemble.get('fold_fitting_strategy', 'sequential_local')
        }
        
        # Use the reporter to add results
        self.reporter.add_run_results(self.strategy, model_name, metrics, params)
        
        # Use the reporter to save detailed predictions and plots
        predictions_df = self.reporter.save_prediction_results(
            y_test, y_pred, test_sample_ids, self.strategy, model_name
        )
        self.reporter.generate_calibration_plot(predictions_df, self.strategy, model_name)
        
        # Extract and save the best individual model
        self._extract_and_save_best_model()
    
    def _extract_and_save_best_model(self):
        """Extract the best individual model from AutoGluon and save in consistent format."""
        from sklearn.pipeline import Pipeline
        import joblib
        
        logger.info("Extracting best model from AutoGluon ensemble...")
        
        # Log information about available models
        try:
            leaderboard = self.autogluon_regressor.predictor.leaderboard(silent=True)
            logger.info(f"AutoGluon trained {len(leaderboard)} models:")
            for i, row in leaderboard.head(3).iterrows():
                logger.info(f"  {i+1}. {row['model']} (score: {row['score_val']:.4f})")
        except Exception as e:
            logger.debug(f"Could not log leaderboard: {e}")
        
        try:
            # Method 1: Try to get the best model from leaderboard
            leaderboard = self.autogluon_regressor.predictor.leaderboard(silent=True)
            best_model_name = leaderboard.iloc[0]['model']  # First row is best model
            logger.info(f"Best AutoGluon model: {best_model_name} (score: {leaderboard.iloc[0]['score_val']:.4f})")
            
            # Method 2: Try different extraction approaches
            best_model = None
            
            # Approach A: Use get_model_best() if available
            if hasattr(self.autogluon_regressor.predictor, 'get_model_best'):
                try:
                    best_model = self.autogluon_regressor.predictor.get_model_best()
                    logger.info(f"Extracted via get_model_best(): {type(best_model)}")
                except Exception as e:
                    logger.debug(f"get_model_best() failed: {e}")
            
            # Approach B: Use _trainer.load_model() 
            if best_model is None:
                try:
                    best_model = self.autogluon_regressor.predictor._trainer.load_model(best_model_name)
                    logger.info(f"Extracted via _trainer.load_model(): {type(best_model)}")
                except Exception as e:
                    logger.debug(f"_trainer.load_model() failed: {e}")
            
            # Approach C: Use get_model() if available
            if best_model is None and hasattr(self.autogluon_regressor.predictor, 'get_model'):
                try:
                    best_model = self.autogluon_regressor.predictor.get_model(best_model_name)
                    logger.info(f"Extracted via get_model(): {type(best_model)}")
                except Exception as e:
                    logger.debug(f"get_model() failed: {e}")
            
            if best_model is not None:
                # Check if the extracted model is sklearn-compatible
                if hasattr(best_model, 'predict') and hasattr(best_model, 'fit'):
                    # Create a pipeline with the extracted model
                    full_pipeline = Pipeline([
                        ('features', self.feature_pipeline),
                        ('model', best_model)
                    ])
                    
                    # Save as .pkl file
                    filename = f"{self.strategy}_autogluon_best_{self.config.run_timestamp}.pkl"
                    save_path = self.config.model_dir / filename
                    
                    joblib.dump(full_pipeline, save_path)
                    logger.info(f"Successfully saved extracted AutoGluon model to: {save_path}")
                else:
                    logger.warning(f"Extracted model {type(best_model)} is not sklearn-compatible")
                    raise ValueError("Extracted model is not compatible")
            else:
                raise ValueError("Could not extract best model using any method")
            
        except Exception as e:
            logger.error(f"Failed to extract best AutoGluon model: {e}")
            logger.info("Falling back to wrapper approach...")
            self._save_wrapper_pipeline()
    
    def _save_wrapper_pipeline(self):
        """Fallback: Save using the wrapper approach."""
        from sklearn.pipeline import Pipeline
        import joblib
        
        try:
            full_pipeline = Pipeline([
                ('features', self.feature_pipeline),
                ('model', self.autogluon_regressor)
            ])
            
            filename = f"{self.strategy}_autogluon_{self.config.run_timestamp}.pkl"
            save_path = self.config.model_dir / filename
            joblib.dump(full_pipeline, save_path)
            logger.info(f"Saved AutoGluon wrapper pipeline to: {save_path}")
            
        except Exception as e:
            logger.error(f"Failed to save AutoGluon wrapper: {e}")
            logger.info("AutoGluon model is available in directory format only")