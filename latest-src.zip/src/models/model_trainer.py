"""
Model Training Module: Defines the training and evaluation process for standard models.
"""
import logging
from pathlib import Path
import joblib
import pandas as pd
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge, Lasso, ElasticNet
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor

from typing import Optional
from src.config.pipeline_config import Config
from src.features.feature_engineering import create_feature_pipeline
from src.utils.helpers import calculate_regression_metrics
from src.reporting.reporter import Reporter
from src.models.tuner_objectives_improved import calculate_weighted_r2_objective
from src.data_management.data_manager import DataManager

logger = logging.getLogger(__name__)

class ModelTrainer:
    """Handles the training and evaluation of regression models."""
    def __init__(self, config: Config, strategy: str, reporter: Reporter, data_manager: Optional[DataManager] = None):
        self.config = config
        self.strategy = strategy
        self.reporter = reporter
        self.feature_pipeline = create_feature_pipeline(config, strategy)
        self.data_manager = data_manager

    def _get_model(self, model_name: str) -> Pipeline:
        """
        Returns a scikit-learn pipeline for the requested model, using
        parameters defined in the central configuration file.
        """
        base_model_name = model_name.replace("_pca", "")
        
        # Fetch the parameter dictionary from the config
        try:
            params = getattr(self.config.model_params, base_model_name).copy()
        except AttributeError:
            raise ValueError(f"Parameters for model '{base_model_name}' not found in config.")

        # Define the model instance using the fetched parameters
        model_map = {
            "ridge": Ridge, "lasso": Lasso, "elastic_net": ElasticNet,
            "random_forest": RandomForestRegressor, "gradient_boost": GradientBoostingRegressor,
            "xgboost": XGBRegressor, "lightgbm": LGBMRegressor,
            "catboost": CatBoostRegressor, "svr": SVR,
            "extratrees": ExtraTreesRegressor,
            "ridge_pca": Ridge, "lasso_pca": Lasso, "elastic_net_pca": ElasticNet,
            "random_forest_pca": RandomForestRegressor, "gradient_boost_pca": GradientBoostingRegressor,
            "xgboost_pca": XGBRegressor, "lightgbm_pca": LGBMRegressor,
            "catboost_pca": CatBoostRegressor, "svr_pca": SVR,
            "extratrees_pca": ExtraTreesRegressor,
        }
        
        if base_model_name not in model_map:
            raise ValueError(f"Unknown model name: {model_name}")
        
        # Add universal parameters
        if base_model_name not in ["svr"]:
             params['random_state'] = self.config.random_state
        if base_model_name == 'lightgbm': params['verbose'] = -1
        if base_model_name == 'catboost': params['verbose'] = 0
        
        # Add GPU parameters when GPU is enabled
        if self.config.use_gpu:
            if base_model_name == 'xgboost':
                params['tree_method'] = 'hist'
                params['device'] = 'cuda'
                logger.info(f"GPU enabled for XGBoost (device='cuda')")
            elif base_model_name == 'lightgbm':
                params['device'] = 'gpu'
                params['gpu_platform_id'] = 0
                params['gpu_device_id'] = 0
                logger.info(f"GPU enabled for LightGBM (device='gpu')")
            elif base_model_name == 'catboost':
                params['task_type'] = 'GPU'
                params['devices'] = '0'
                logger.info(f"GPU enabled for CatBoost (task_type='GPU')")
        
        # Add parallel processing for tree-based models
        if base_model_name in ['random_forest', 'extratrees']:
            params['n_jobs'] = -1  # Use all available cores
            logger.info(f"Parallel processing enabled for {base_model_name} (n_jobs=-1)")

        regressor = model_map[base_model_name](**params)
        
        # Construct the final model pipeline, adding PCA if requested
        model_steps = [('pca', PCA(n_components=0.95))] if "_pca" in model_name else []
        model_steps.append(('regressor', regressor))
        
        return Pipeline(model_steps)
    
    def _calculate_sample_weights(self, y: pd.Series, method: str = 'weighted_r2') -> np.ndarray:
        """
        Calculate sample weights using the specified method.
        
        Args:
            y: Target concentration values
            method: Weight calculation method ('legacy', 'improved', 'weighted_r2')
            
        Returns:
            Normalized sample weights array
        """
        if method == 'weighted_r2':
            # Use the same logic as the weighted_r2 objective function
            percentiles = np.percentile(y, [25, 75])
            weights = np.ones_like(y, dtype=float)
            # Give more weight to rare/important samples (same as weighted_r2 objective)
            weights[y <= percentiles[0]] = 2.0  # Bottom quartile
            weights[y >= percentiles[1]] = 1.5  # Top quartile
            # Normalize weights
            weights = weights * len(y) / np.sum(weights)
            logger.info(f"Using weighted_r2 sample weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}, Mean: {weights.mean():.2f}")
            return weights
        elif method == 'legacy':
            # Legacy hard-coded concentration ranges
            weights = np.ones_like(y, dtype=float)
            for i, val in enumerate(y):
                if 2.0 <= val < 3.0: weights[i] = 2.5
                elif 6.0 <= val <= 7.0: weights[i] = 1.8
                elif 3.0 <= val < 4.0: weights[i] = 2.5
                elif 5.0 <= val < 6.0: weights[i] = 1.2
                else: weights[i] = 1.0
            # Normalize weights
            weights = weights * len(y) / np.sum(weights)
            logger.info(f"Using legacy sample weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}, Mean: {weights.mean():.2f}")
            return weights
        elif method == 'improved':
            # Data-driven improved weighting
            percentiles = np.percentile(y, [10, 25, 50, 75, 90])
            p10, p25, p50, p75, p90 = percentiles
            weights = np.ones_like(y, dtype=float)
            
            for i, val in enumerate(y):
                if val <= p10: weights[i] = 3.0  # Bottom 10%
                elif val <= p25: weights[i] = 2.2  # 10-25%
                elif val <= p50: weights[i] = 1.8  # 25-50%
                elif val <= p75: weights[i] = 1.0  # 50-75%
                elif val <= p90: weights[i] = 1.5  # 75-90%
                else: weights[i] = 2.5  # Top 10%
            
            # Normalize weights
            weights = weights * len(y) / np.sum(weights)
            logger.info(f"Using improved sample weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}, Mean: {weights.mean():.2f}")
            return weights
        elif method == 'distribution_based':
            # Smooth distribution-based weighting using kernel density estimation
            try:
                from scipy.stats import gaussian_kde
                # Estimate probability density at each point
                kde = gaussian_kde(y.values)
                densities = kde(y.values)
                
                # Inverse density weighting (smooth)
                weights = 1.0 / (densities + 1e-8)  # Add small epsilon to avoid division by zero
                
                # Apply smoothing to prevent extreme weights
                weights = np.clip(weights, 0.2, 5.0)  # Limit weight range
                
                # Normalize weights
                weights = weights * len(y) / np.sum(weights)
                logger.info(f"Using distribution-based sample weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}, Mean: {weights.mean():.2f}")
                return weights
            except ImportError:
                logger.warning("SciPy not available, falling back to bin-based distribution weighting")
                # Fallback: bin-based distribution weighting
                bins = np.percentile(y, [0, 20, 40, 60, 80, 100])
                bin_indices = np.digitize(y, bins) - 1
                
                # Calculate inverse frequency weights
                unique_bins, counts = np.unique(bin_indices, return_counts=True)
                total_samples = len(y)
                
                weights = np.ones_like(y, dtype=float)
                for bin_idx, count in zip(unique_bins, counts):
                    mask = bin_indices == bin_idx
                    # Inverse frequency: weight = total_samples / (n_bins * count)
                    weights[mask] = total_samples / (len(unique_bins) * count)
                
                # Normalize weights
                weights = weights * len(y) / np.sum(weights)
                logger.info(f"Using bin-based distribution weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}, Mean: {weights.mean():.2f}")
                return weights
                
        elif method == 'hybrid':
            # Hybrid approach: combine distribution-based with domain knowledge
            # Step 1: Get distribution-based weights
            dist_weights = self._calculate_sample_weights(y, 'distribution_based')
            
            # Step 2: Apply domain knowledge modifiers
            percentiles = np.percentile(y, [25, 75])
            domain_modifiers = np.ones_like(y, dtype=float)
            
            # Emphasize extreme ranges (domain knowledge)
            domain_modifiers[y <= percentiles[0]] *= 1.3  # Low concentrations
            domain_modifiers[y >= percentiles[1]] *= 1.2  # High concentrations
            
            # Step 3: Combine both approaches
            weights = dist_weights * domain_modifiers
            
            # Normalize weights
            weights = weights * len(y) / np.sum(weights)
            logger.info(f"Using hybrid sample weights - Min: {weights.min():.2f}, Max: {weights.max():.2f}, Mean: {weights.mean():.2f}")
            return weights
        else:
            raise ValueError(f"Unknown weight method: {method}. Use 'legacy', 'improved', 'weighted_r2', 'distribution_based', or 'hybrid'.")
    
    def _model_supports_sample_weight(self, model_name: str) -> bool:
        """
        Check if a model supports sample_weight parameter in fit().
        
        Args:
            model_name: Name of the model
            
        Returns:
            True if model supports sample_weight, False otherwise
        """
        base_model_name = model_name.replace('_pca', '')
        # Most sklearn and tree-based models support sample_weight
        supported_models = {
            'ridge', 'lasso', 'elastic_net', 'random_forest', 'gradient_boost',
            'xgboost', 'lightgbm', 'catboost', 'extratrees'
        }
        # SVR doesn't support sample_weight in sklearn
        unsupported_models = {'svr'}
        
        return base_model_name in supported_models

    def train_and_evaluate(self, train_df: pd.DataFrame, test_df: pd.DataFrame):
        """Trains all specified models and evaluates their performance."""
        X_train_raw = train_df.drop(columns=[self.config.target_column])
        y_train = train_df[self.config.target_column]
        X_test_raw = test_df.drop(columns=[self.config.target_column])
        y_test = test_df[self.config.target_column]
        logger.info(f"Starting training for feature strategy: {self.strategy}")
        
        # We need sample_id from the test set for detailed prediction saving
        test_sample_ids = X_test_raw[self.config.sample_id_column]

        # Fit feature pipeline on data without sample_id
        self.feature_pipeline.fit(X_train_raw.drop(columns=[self.config.sample_id_column]))
        X_train = self.feature_pipeline.transform(X_train_raw.drop(columns=[self.config.sample_id_column]))
        X_test = self.feature_pipeline.transform(X_test_raw.drop(columns=[self.config.sample_id_column]))

        # Calculate sample weights if enabled
        sample_weights = None
        if self.config.use_sample_weights:
            sample_weights = self._calculate_sample_weights(y_train, self.config.sample_weight_method)
            logger.info(f"Sample weights enabled using method: {self.config.sample_weight_method}")
        else:
            logger.info("Sample weights disabled")

        for model_name in self.config.models_to_train:
            logger.info(f"--- Training model: {model_name} ---")
            model_pipeline = self._get_model(model_name)
            
            # Fit model with or without sample weights
            if (self.config.use_sample_weights and 
                sample_weights is not None and 
                self._model_supports_sample_weight(model_name)):
                
                logger.info(f"Training {model_name} with sample weights")
                model_pipeline.fit(X_train, y_train, regressor__sample_weight=sample_weights)
            else:
                if self.config.use_sample_weights and not self._model_supports_sample_weight(model_name):
                    logger.warning(f"Model {model_name} does not support sample weights, training without weights")
                model_pipeline.fit(X_train, y_train)

            y_pred = model_pipeline.predict(X_test)
            metrics = calculate_regression_metrics(y_test, y_pred)
            logger.info(f"Evaluation metrics for {model_name}: {metrics}")
            
            params = model_pipeline.named_steps['regressor'].get_params()
            
            # Use the reporter to add results
            self.reporter.add_run_results(self.strategy, model_name, metrics, params)
            
            # Use the reporter to save detailed predictions and plots
            predictions_df = self.reporter.save_prediction_results(
                y_test, y_pred, test_sample_ids, self.strategy, model_name
            )
            self.reporter.generate_calibration_plot(predictions_df, self.strategy, model_name)
            
            # Combine feature engineering and model into a single deployable pipeline
            full_pipeline = Pipeline([
                ('features', self.feature_pipeline),
                ('model', model_pipeline)
            ])
            self.save_pipeline(full_pipeline, model_name)

    def save_pipeline(self, pipeline: Pipeline, model_name: str):
        """Saves the complete scikit-learn pipeline."""
        filename = f"{self.strategy}_{model_name}_{self.config.run_timestamp}.pkl"
        save_path = Path(self.config.model_dir) / filename
        
        # Save the pipeline
        joblib.dump(pipeline, save_path)
        logger.info(f"Pipeline for {model_name} saved to: {save_path}")
        
        # If wavelength standardization is enabled, save the wavelength range
        if self.config.enable_wavelength_standardization and self.data_manager and self.data_manager._global_wavelength_range:
            # Use the global wavelength range from the training DataManager
            global_range = self.data_manager._global_wavelength_range
            
            # Save wavelength range metadata alongside the model
            metadata_path = save_path.with_suffix('.wavelength_metadata.json')
            import json
            metadata = {
                'wavelength_standardization_enabled': True,
                'global_wavelength_range': {
                    'min': global_range[0],
                    'max': global_range[1]
                },
                'wavelength_resolution': self.config.wavelength_resolution,
                'interpolation_method': self.config.wavelength_interpolation_method
            }
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            logger.info(f"Wavelength metadata saved to: {metadata_path}")