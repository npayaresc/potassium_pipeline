"""
Model Tuning Module

This module defines the ModelTuner class, which uses Optuna to perform
hyperparameter optimization for specified models.
"""
import logging
from catboost import CatBoostRegressor
import joblib
from pathlib import Path

import optuna
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor

from src.config.pipeline_config import Config
from src.features.feature_engineering import SpectralFeatureGenerator, create_feature_pipeline
from src.reporting.reporter import Reporter
from src.utils.custom_exceptions import ModelTrainingError
from src.models.tuner_objectives import (
    calculate_robust_objective,
    calculate_concentration_weighted_objective,
    calculate_mape_focused_objective
)
from src.models.tuner_objectives_improved import (
    calculate_robust_objective_v2,
    calculate_weighted_r2_objective,
    calculate_balanced_mae_objective,
    calculate_quantile_weighted_objective,
    calculate_distribution_based_objective,
    calculate_hybrid_weighted_objective
)
from src.utils.helpers import OutlierClipper

logger = logging.getLogger(__name__)

class ModelTuner:
    """Uses Optuna to find the best hyperparameters for a model."""

    def __init__(self, config: Config, reporter: Reporter, strategy: str):
        self.config = config
        self.reporter = reporter
        self.strategy = strategy
        self.feature_pipeline = create_feature_pipeline(config, strategy)
        self.X_train = None
        self.y_train = None
        self.X_train_features = None  # Pre-computed features
        self.sample_weights = None  # Pre-computed sample weights
    
    
    def _define_search_space(self, trial: optuna.Trial, model_name: str) -> dict:
        """Returns a dictionary of parameters for a given model."""
        if model_name == "random_forest":
            params = {
                'n_estimators': trial.suggest_int('n_estimators', 50, 500),
                'max_depth': trial.suggest_categorical('max_depth', [None, 10, 20, 30]),
                'min_samples_split': trial.suggest_int('min_samples_split', 2, 20),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 10),
                'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', 0.7]),
            }
            if trial.suggest_categorical('bootstrap', [True, False]):
                params['bootstrap'] = True
                params['max_samples'] = trial.suggest_float('max_samples', 0.5, 1.0)
            else:
                params['bootstrap'] = False
            return params

        if model_name == "xgboost":
            return {
                'n_estimators': trial.suggest_int('n_estimators', 100, 800),
                'max_depth': trial.suggest_int('max_depth', 3, 10),
                'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.2),
                'subsample': trial.suggest_float('subsample', 0.6, 1.0),
                'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
                'reg_alpha': trial.suggest_float('reg_alpha', 0.0, 5.0),
                'reg_lambda': trial.suggest_float('reg_lambda', 1.0, 10.0),
            }

        if model_name == "lightgbm":
            return {
                'n_estimators': trial.suggest_int('n_estimators', 100, 1000),
                'learning_rate': trial.suggest_float('learning_rate', 0.005, 0.1, log=True),
                'num_leaves': trial.suggest_int('num_leaves', 31, 255),
                'max_depth': trial.suggest_int('max_depth', 5, 15),
                'min_child_samples': trial.suggest_int('min_child_samples', 5, 50),
                'reg_alpha': trial.suggest_float('reg_alpha', 0.0, 20.0),
                'reg_lambda': trial.suggest_float('reg_lambda', 0.0, 20.0),
                'colsample_bytree': trial.suggest_float('colsample_bytree', 0.7, 1.0),
                'subsample': trial.suggest_float('subsample', 0.7, 1.0),
            }

        if model_name == "catboost":
            return {
                'iterations': trial.suggest_int('iterations', 200, 1200),
                'depth': trial.suggest_int('depth', 4, 10),
                'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.2),
                'l2_leaf_reg': trial.suggest_float('l2_leaf_reg', 1.0, 10.0),
                'random_strength': trial.suggest_float('random_strength', 0.1, 2.0),
            }

        if model_name == "svr":
            return {
                'C': trial.suggest_float("C", 1e-1, 1e3, log=True),
                'gamma': trial.suggest_categorical("gamma", ['scale', 'auto']),
                'epsilon': trial.suggest_float("epsilon", 1e-2, 1e0, log=True),
            }
            
        if model_name == "extratrees":
            params = {
                'n_estimators': trial.suggest_int('n_estimators', 100, 1000),
                'max_depth': trial.suggest_categorical('max_depth', [None, 10, 20, 30, 40, 50]),
                'min_samples_split': trial.suggest_int('min_samples_split', 2, 30),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 20),
                'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', 0.5, 0.7, 0.9]),
                'min_weight_fraction_leaf': trial.suggest_float('min_weight_fraction_leaf', 0.0, 0.1),
                'max_leaf_nodes': trial.suggest_categorical('max_leaf_nodes', [None, 100, 500, 1000]),
            }
            # Add bootstrap configuration
            if trial.suggest_categorical('bootstrap', [True, False]):
                params['bootstrap'] = True
                params['max_samples'] = trial.suggest_float('max_samples', 0.5, 1.0)
            else:
                params['bootstrap'] = False
            return params

        raise ValueError(f"Tuning not configured for model: {model_name}")
    
    def _calculate_sample_weights(self, y: pd.Series, method: str = 'weighted_r2') -> np.ndarray:
        """
        Calculate sample weights using the specified method.
        Same implementation as in ModelTrainer to ensure consistency.
        """
        if method == 'weighted_r2':
            percentiles = np.percentile(y, [25, 75])
            weights = np.ones_like(y, dtype=float)
            weights[y <= percentiles[0]] = 2.0  # Bottom quartile
            weights[y >= percentiles[1]] = 1.5  # Top quartile
            weights = weights * len(y) / np.sum(weights)
            return weights
        elif method == 'legacy':
            weights = np.ones_like(y, dtype=float)
            for i, val in enumerate(y):
                if 0.1 <= val < 0.15: weights[i] = 2.5     # Low range (rare)
                elif 0.15 <= val < 0.20: weights[i] = 2.0  # Low-medium range
                elif 0.20 <= val < 0.30: weights[i] = 1.2  # Medium range (common)
                elif 0.30 <= val < 0.40: weights[i] = 1.5  # Medium-high range
                elif 0.40 <= val <= 0.50: weights[i] = 2.5 # High range (rare)
                else: weights[i] = 1.0  # Outside expected range
            weights = weights * len(y) / np.sum(weights)
            return weights
        elif method == 'improved':
            percentiles = np.percentile(y, [10, 25, 50, 75, 90])
            p10, p25, p50, p75, p90 = percentiles
            weights = np.ones_like(y, dtype=float)
            for i, val in enumerate(y):
                if val <= p10: weights[i] = 3.0
                elif val <= p25: weights[i] = 2.2
                elif val <= p50: weights[i] = 1.8
                elif val <= p75: weights[i] = 1.0
                elif val <= p90: weights[i] = 1.5
                else: weights[i] = 2.5
            weights = weights * len(y) / np.sum(weights)
            return weights
        elif method == 'distribution_based':
            # Same implementation as ModelTrainer for consistency
            try:
                from scipy.stats import gaussian_kde
                kde = gaussian_kde(y.values)
                densities = kde(y.values)
                weights = 1.0 / (densities + 1e-8)
                weights = np.clip(weights, 0.2, 5.0)
                weights = weights * len(y) / np.sum(weights)
                return weights
            except ImportError:
                bins = np.percentile(y, [0, 20, 40, 60, 80, 100])
                bin_indices = np.digitize(y, bins) - 1
                unique_bins, counts = np.unique(bin_indices, return_counts=True)
                total_samples = len(y)
                weights = np.ones_like(y, dtype=float)
                for bin_idx, count in zip(unique_bins, counts):
                    mask = bin_indices == bin_idx
                    weights[mask] = total_samples / (len(unique_bins) * count)
                weights = weights * len(y) / np.sum(weights)
                return weights
                
        elif method == 'hybrid':
            # Same implementation as ModelTrainer for consistency
            dist_weights = self._calculate_sample_weights(y, 'distribution_based')
            percentiles = np.percentile(y, [25, 75])
            domain_modifiers = np.ones_like(y, dtype=float)
            domain_modifiers[y <= percentiles[0]] *= 1.3
            domain_modifiers[y >= percentiles[1]] *= 1.2
            weights = dist_weights * domain_modifiers
            weights = weights * len(y) / np.sum(weights)
            return weights
        else:
            raise ValueError(f"Unknown weight method: {method}. Use 'legacy', 'improved', 'weighted_r2', 'distribution_based', or 'hybrid'.")
    
    def _model_supports_sample_weight(self, model_name: str) -> bool:
        """Check if a model supports sample_weight parameter in fit()."""
        base_model_name = model_name.replace('_pca', '')
        supported_models = {
            'ridge', 'lasso', 'elastic_net', 'random_forest', 'gradient_boost',
            'xgboost', 'lightgbm', 'catboost', 'extratrees'
        }
        return base_model_name in supported_models

    def _get_regressor(self, model_name: str, params: dict):
        """Returns a model instance from a dictionary of parameters."""
        # Extract base model name (remove _pca suffix if present)
        base_model_name = model_name.replace('_pca', '')
        
        model_map = {
            "random_forest": RandomForestRegressor, "xgboost": XGBRegressor,
            "lightgbm": LGBMRegressor, "catboost": CatBoostRegressor,
            "svr": SVR, "extratrees": ExtraTreesRegressor,
        }
        params['random_state'] = self.config.random_state
        if base_model_name == 'lightgbm': params['verbose'] = -1
        if base_model_name == 'catboost': params['verbose'] = 0
        
        # Add GPU parameters when GPU is enabled
        if self.config.use_gpu:
            if base_model_name == 'xgboost':
                params['tree_method'] = 'hist'
                params['device'] = 'cuda'
                # Add memory-efficient settings for single GPU
                params['max_bin'] = 256  # Reduce memory usage
                logger.info(f"GPU enabled for XGBoost tuning (device='cuda', max_bin=256 for memory efficiency)")
            elif base_model_name == 'lightgbm':
                params['device'] = 'gpu'
                params['gpu_platform_id'] = 0
                params['gpu_device_id'] = 0
                # Memory-efficient GPU settings
                params['gpu_use_dp'] = False  # Use float32 instead of float64
                logger.info(f"GPU enabled for LightGBM tuning (device='gpu', using float32)")
            elif base_model_name == 'catboost':
                params['task_type'] = 'GPU'
                params['devices'] = '0'
                # Limit GPU RAM usage to avoid OOM
                params['gpu_ram_part'] = 0.8  # Use max 80% of GPU RAM
                logger.info(f"GPU enabled for CatBoost tuning (task_type='GPU', gpu_ram_part=0.8)")
        
        # Add parallel processing for tree-based models
        if base_model_name in ['random_forest', 'extratrees']:
            # When using parallel trials, limit model-level parallelism to avoid thread explosion
            if self.config.tuner.n_jobs == -1 or self.config.tuner.n_jobs > 4:
                # Limit tree-level parallelism when running multiple trials
                params['n_jobs'] = 4  # Use 4 cores per model to leave room for parallel trials
                logger.info(f"Limited {base_model_name} to n_jobs=4 to allow parallel trials")
            else:
                # Single trial mode - use all cores for the model
                params['n_jobs'] = -1
                logger.info(f"Sequential trials - using all cores for {base_model_name} (n_jobs=-1)")
        
        return model_map[base_model_name](**params)

    def _objective(self, trial: optuna.Trial) -> float:
        """The objective function that Optuna tries to maximize."""
        try:
            # 1. Select a model and its hyperparameters
            model_name = trial.suggest_categorical("model_name", self.config.tuner.models_to_tune)
            
            # 2. Determine if PCA should be used based on model name
            use_pca = model_name.endswith('_pca')
            base_model_name = model_name.replace('_pca', '')
            
            # 3. Get hyperparameters for the base model
            model_params = self._define_search_space(trial, base_model_name)
            regressor = self._get_regressor(model_name, model_params.copy()) # Use a copy

            # 4. Build the pipeline WITHOUT spectral features (already pre-computed)
            steps = [
                ('imputer', SimpleImputer(strategy='mean')),
                ('clipper', OutlierClipper()),
                ('scaler', StandardScaler())
            ]
            if use_pca:
                # Only suggest PCA components if PCA is being used
                pca_components = trial.suggest_float("pca_n_components", 0.85, 0.99)
                steps.append(('pca', PCA(n_components=pca_components)))
            
            steps.append(('regressor', regressor))
            pipeline = Pipeline(steps)

            # 4. Evaluate this pipeline using the configured objective function
            score = self._evaluate_with_custom_objective(pipeline)
            
            # Log trial progress (helpful for debugging parallel execution)
            logger.debug(f"Trial {trial.number}: {model_name} achieved score {score:.4f}")
            
            return score
            
        except Exception as e:
            logger.error(f"Trial {trial.number} failed for {model_name if 'model_name' in locals() else 'unknown'}: {e}")
            # Return a very poor score instead of -1.0 to help Optuna's optimization
            return -10.0
    
    def _evaluate_with_custom_objective(self, pipeline) -> float:
        """Evaluates pipeline using the configured objective function."""
        objective_name = self.config.tuner.objective_function_name
        
        if objective_name == 'r2':
            # Standard R² scoring - limit CV parallelism when running parallel trials
            cv_n_jobs = 1 if (self.config.tuner.n_jobs == -1 or self.config.tuner.n_jobs > 1) else -1
            cv_scores = cross_val_score(
                pipeline, self.X_train_features, self.y_train, n_jobs=cv_n_jobs, cv=3, scoring='r2'
            )
            return np.mean(cv_scores)
        
        elif objective_name == 'concentration_weighted':
            return self._custom_cv_score(pipeline, calculate_concentration_weighted_objective)
        
        elif objective_name == 'robust':
            return self._evaluate_robust_objective(pipeline)
        
        elif objective_name == 'mape_focused':
            return self._custom_cv_score(pipeline, calculate_mape_focused_objective)
        
        # New improved objective functions
        elif objective_name == 'robust_v2':
            return self._evaluate_robust_objective_v2(pipeline)
        
        elif objective_name == 'weighted_r2':
            return self._custom_cv_score(pipeline, calculate_weighted_r2_objective)
        
        elif objective_name == 'balanced_mae':
            return self._custom_cv_score(pipeline, calculate_balanced_mae_objective)
        
        elif objective_name == 'quantile_weighted':
            return self._custom_cv_score(pipeline, calculate_quantile_weighted_objective)
        
        elif objective_name == 'distribution_based':
            return self._custom_cv_score(pipeline, calculate_distribution_based_objective)
        
        elif objective_name == 'hybrid_weighted':
            return self._custom_cv_score(pipeline, calculate_hybrid_weighted_objective)
        
        else:
            raise ValueError(f"Unknown objective function: {objective_name}")
    
    def _custom_cv_score(self, pipeline, objective_func) -> float:
        """Performs manual cross-validation using a custom objective function."""
        from sklearn.model_selection import KFold
        from sklearn.metrics import r2_score
        
        kf = KFold(n_splits=3, shuffle=True, random_state=self.config.random_state)
        scores = []
        
        for train_idx, val_idx in kf.split(self.X_train_features):
            X_train_fold, X_val_fold = self.X_train_features.iloc[train_idx], self.X_train_features.iloc[val_idx]
            y_train_fold, y_val_fold = self.y_train.iloc[train_idx], self.y_train.iloc[val_idx]
            
            # Fit pipeline on training fold with sample weights if configured
            if (self.config.use_sample_weights and 
                self.sample_weights is not None and 
                self._model_supports_sample_weight(pipeline.named_steps['regressor'].__class__.__name__.lower())):
                
                fold_weights = self.sample_weights[train_idx]
                pipeline.fit(X_train_fold, y_train_fold, regressor__sample_weight=fold_weights)
            else:
                pipeline.fit(X_train_fold, y_train_fold)
            
            # Predict on validation fold
            y_pred = pipeline.predict(X_val_fold)
            
            # Calculate custom objective score
            # Pass config to objective functions that support it
            base_r2 = r2_score(y_val_fold.values, y_pred)
            try:
                # Try passing config first (for new configurable functions)
                score = objective_func(y_val_fold.values, y_pred, base_r2, config=self.config.tuner.objectives)
            except TypeError:
                # Fallback for legacy functions that don't accept config
                score = objective_func(y_val_fold.values, y_pred, base_r2)
            scores.append(score)
        
        return np.mean(scores)
    
    def _evaluate_robust_objective(self, pipeline) -> float:
        """Evaluates pipeline using the robust objective function."""
        from sklearn.model_selection import cross_val_score, train_test_split
        from sklearn.metrics import r2_score
        
        # Get cross-validation scores - limit CV parallelism when running parallel trials
        cv_n_jobs = 1 if (self.config.tuner.n_jobs == -1 or self.config.tuner.n_jobs > 1) else -1
        cv_scores = cross_val_score(
            pipeline, self.X_train, self.y_train, n_jobs=cv_n_jobs, cv=3, scoring='r2'
        )
        
        # Split data for train/test evaluation
        X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(
            self.X_train_features, self.y_train, test_size=0.2, random_state=self.config.random_state
        )
        
        # Fit pipeline and get train/test R² with sample weights if configured
        if (self.config.use_sample_weights and 
            self.sample_weights is not None and 
            self._model_supports_sample_weight(pipeline.named_steps['regressor'].__class__.__name__.lower())):
            
            # Get weights for the training split by matching indices
            train_indices = [self.X_train_features.index.get_loc(idx) for idx in X_train_split.index]
            train_split_weights = self.sample_weights[train_indices]
            pipeline.fit(X_train_split, y_train_split, regressor__sample_weight=train_split_weights)
        else:
            pipeline.fit(X_train_split, y_train_split)
            
        train_pred = pipeline.predict(X_train_split)
        test_pred = pipeline.predict(X_test_split)
        
        train_r2 = r2_score(y_train_split, train_pred)
        test_r2 = r2_score(y_test_split, test_pred)
        
        return calculate_robust_objective(cv_scores, train_r2, test_r2, config=self.config.tuner.objectives)
    
    def _evaluate_robust_objective_v2(self, pipeline) -> float:
        """Evaluates pipeline using the improved robust objective function."""
        from sklearn.model_selection import cross_val_score, train_test_split
        from sklearn.metrics import r2_score
        
        # Get cross-validation scores - limit CV parallelism when running parallel trials
        cv_n_jobs = 1 if (self.config.tuner.n_jobs == -1 or self.config.tuner.n_jobs > 1) else -1
        cv_scores = cross_val_score(
            pipeline, self.X_train, self.y_train, n_jobs=cv_n_jobs, cv=3, scoring='r2'
        )
        
        # Split data for train/test evaluation
        X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(
            self.X_train_features, self.y_train, test_size=0.2, random_state=self.config.random_state
        )
        
        # Fit pipeline and get train/test R² with sample weights if configured
        if (self.config.use_sample_weights and 
            self.sample_weights is not None and 
            self._model_supports_sample_weight(pipeline.named_steps['regressor'].__class__.__name__.lower())):
            
            # Get weights for the training split by matching indices
            train_indices = [self.X_train_features.index.get_loc(idx) for idx in X_train_split.index]
            train_split_weights = self.sample_weights[train_indices]
            pipeline.fit(X_train_split, y_train_split, regressor__sample_weight=train_split_weights)
        else:
            pipeline.fit(X_train_split, y_train_split)
            
        train_pred = pipeline.predict(X_train_split)
        test_pred = pipeline.predict(X_test_split)
        
        train_r2 = r2_score(y_train_split, train_pred)
        test_r2 = r2_score(y_test_split, test_pred)
        
        return calculate_robust_objective_v2(cv_scores, train_r2, test_r2, config=self.config.tuner.objectives)
    
    def tune(self, train_df: pd.DataFrame, test_df: pd.DataFrame):
        """
        Runs the full hyperparameter tuning process.

        Args:
            train_df: The training DataFrame.
            test_df: The test DataFrame for validation evaluation.
        """
        logger.info(f"Starting hyperparameter tuning for strategy: {self.strategy}")
        logger.info(f"Models to tune: {self.config.tuner.models_to_tune}")
        logger.info(f"Number of trials: {self.config.tuner.n_trials}")

        # Prepare training data (features are generated inside the objective function)
        self.X_train = train_df.drop(columns=[self.config.target_column])
        self.y_train = train_df[self.config.target_column]
        
        # Prepare test data for validation evaluation
        self.X_test = test_df.drop(columns=[self.config.target_column])
        self.y_test = test_df[self.config.target_column]
        self.test_sample_ids = self.X_test[self.config.sample_id_column]
        
        # Pre-compute spectral features ONCE to speed up trials
        logger.info("Pre-computing spectral features for all trials...")
        feature_gen = SpectralFeatureGenerator(config=self.config, strategy=self.strategy)
        self.X_train_features = feature_gen.fit_transform(self.X_train)
        self.X_train_features = pd.DataFrame(
            self.X_train_features, 
            columns=feature_gen.get_feature_names_out(),
            index=self.X_train.index
        )
        logger.info(f"Pre-computed {len(self.X_train_features.columns)} features for {len(self.X_train_features)} samples")
        
        # Pre-compute sample weights ONCE if enabled
        if self.config.use_sample_weights:
            self.sample_weights = self._calculate_sample_weights(self.y_train, self.config.sample_weight_method)
            logger.info(f"Pre-computed sample weights using method: {self.config.sample_weight_method}")
        else:
            logger.info("Sample weights disabled for tuning")

        # Create and run the Optuna study
        study = optuna.create_study(direction="maximize")
        
        # Configure parallel execution with GPU safety
        # Check if we're tuning GPU models
        gpu_models = {'xgboost', 'lightgbm', 'catboost'}
        has_gpu_models = any(model in gpu_models for model in self.config.tuner.models_to_tune)
        
        if self.config.use_gpu and has_gpu_models:
            # With single GPU, run trials sequentially to avoid conflicts
            n_jobs_optuna = 1
            logger.warning(f"GPU mode enabled with GPU models - running trials sequentially (n_jobs=1) to avoid GPU conflicts")
        else:
            # CPU-only models or GPU disabled - can run in parallel
            n_jobs_optuna = self.config.tuner.n_jobs
            logger.info(f"Running Optuna with n_jobs={n_jobs_optuna}")
            
            # Add validation for n_jobs
            if n_jobs_optuna == -1:
                import multiprocessing
                actual_cores = multiprocessing.cpu_count()
                logger.info(f"n_jobs=-1 detected, will use all {actual_cores} CPU cores")
            elif n_jobs_optuna > 1:
                logger.info(f"Parallel execution enabled with {n_jobs_optuna} jobs")
            else:
                logger.info("Sequential execution (n_jobs=1)")
        
        logger.info(f"Starting optimization with {self.config.tuner.n_trials} trials, timeout={self.config.tuner.timeout}s")
        
        try:
            study.optimize(
                self._objective,
                n_trials=self.config.tuner.n_trials,
                timeout=self.config.tuner.timeout,
                n_jobs=n_jobs_optuna,  # Enable parallel trials
                show_progress_bar=True  # Show progress
            )
        except Exception as e:
            logger.error(f"Optuna optimization failed: {e}")
            # Try fallback to sequential execution
            logger.warning("Falling back to sequential execution (n_jobs=1)")
            study.optimize(
                self._objective,
                n_trials=self.config.tuner.n_trials,
                timeout=self.config.tuner.timeout,
                n_jobs=1,
                show_progress_bar=True
            )
        
        logger.info(f"Tuning finished. Best trial: {study.best_trial.value:.4f}")
        logger.info(f"Best parameters: {study.best_params}")
        
        # Log more interpretable metrics for the best trial
        objective_name = self.config.tuner.objective_function_name
        best_value = study.best_trial.value
        
        if objective_name == 'concentration_weighted':
            # Extract approximate R² from the combined objective
            # Assuming weighted term is typically 0.3-0.7, R² ≈ value - 0.5
            approx_r2 = best_value - 0.5
            logger.info(f"Approximate R² for best trial: {approx_r2:.4f} (from concentration_weighted objective)")
        elif objective_name in ['robust_v2', 'weighted_r2', 'balanced_mae', 'quantile_weighted', 'distribution_based', 'hybrid_weighted']:
            if objective_name == 'robust_v2':
                logger.info(f"Best robust_v2 score: {best_value:.4f} (0-1 scale, combines R², stability, generalization)")
            elif objective_name == 'weighted_r2':
                logger.info(f"Best weighted R² score: {best_value:.4f} (emphasizes extreme concentration ranges)")
            elif objective_name == 'balanced_mae':
                logger.info(f"Best balanced MAE score: {best_value:.4f} (0-1 scale, higher is better)")
            elif objective_name == 'quantile_weighted':
                logger.info(f"Best quantile-weighted score: {best_value:.4f} (ensures performance across all ranges)")
            elif objective_name == 'distribution_based':
                logger.info(f"Best distribution-based R² score: {best_value:.4f} (emphasizes underrepresented concentrations)")
            elif objective_name == 'hybrid_weighted':
                logger.info(f"Best hybrid weighted R² score: {best_value:.4f} (combines distribution + domain knowledge)")
        elif objective_name == 'r2':
            logger.info(f"Best R² score: {best_value:.4f} (standard R² metric)")
        else:
            logger.info(f"Best {objective_name} score: {best_value:.4f}")

        # Save the full study results
        self.reporter.save_tuning_report(study, self.strategy)
        
        # Evaluate best model on validation set before retraining
        self._evaluate_best_model_on_validation(study.best_params)
        
        # Retrain the best model on the full training data and save it
        self._retrain_and_save_best_model(study.best_params)

    def _evaluate_best_model_on_validation(self, best_params: dict):
        """Evaluates the best model on validation set and saves predictions and metrics."""
        logger.info("Evaluating best model on validation set...")
        
        # Create a copy of best_params to avoid modifying the original
        params_copy = best_params.copy()
        
        # Extract model name and determine PCA usage
        model_name = params_copy.pop("model_name")
        use_pca = model_name.endswith('_pca')
        pca_n_components = params_copy.pop("pca_n_components", None) if use_pca else None
        
        # Get the best regressor
        best_regressor = self._get_regressor(model_name, params_copy)
        
        # Reconstruct the best model pipeline
        model_steps = [
            ('imputer', SimpleImputer(strategy='mean')),
            ('clipper', OutlierClipper()),
            ('scaler', StandardScaler())
        ]
        if use_pca and pca_n_components:
            model_steps.append(('pca', PCA(n_components=pca_n_components)))
        
        model_steps.append(('regressor', best_regressor))
        model_pipeline = Pipeline(model_steps)
        
        # Create the full pipeline with feature engineering
        full_pipeline = Pipeline([
            ('features', self.feature_pipeline),
            ('model', model_pipeline)
        ])
        
        # Train on training data with sample weights if configured
        if (self.config.use_sample_weights and 
            self.sample_weights is not None and 
            self._model_supports_sample_weight(model_name)):
            
            logger.info(f"Training validation model {model_name} with sample weights")
            full_pipeline.fit(self.X_train, self.y_train, model__regressor__sample_weight=self.sample_weights)
        else:
            full_pipeline.fit(self.X_train, self.y_train)
        
        # Predict on validation data
        y_pred = full_pipeline.predict(self.X_test)
        
        # Calculate metrics (same as regular training)
        from src.utils.helpers import calculate_regression_metrics
        metrics = calculate_regression_metrics(self.y_test, y_pred)
        
        # Log validation metrics in a formatted way
        logger.info(f"=== Validation Results for Optimized {model_name} ===")
        logger.info(f"R² Score: {metrics.get('r2', 'N/A'):.4f}")
        logger.info(f"RMSE: {metrics.get('rmse', 'N/A'):.4f}")
        logger.info(f"MAE: {metrics.get('mae', 'N/A'):.4f}")
        logger.info(f"MAPE: {metrics.get('mape', 'N/A'):.2f}%")
        logger.info(f"RRMSE: {metrics.get('rrmse', 'N/A'):.2f}%")
        logger.info(f"Within 20.5%: {metrics.get('within_20.5%', 'N/A'):.1f}%")
        logger.info("=" * 50)
        
        # Save validation predictions (same format as regular training)
        predictions_df = self.reporter.save_prediction_results(
            self.y_test, y_pred, self.test_sample_ids, self.strategy, f"optimized_{model_name}"
        )
        
        # Generate calibration plot for validation results
        self.reporter.generate_calibration_plot(predictions_df, self.strategy, f"optimized_{model_name}")
        
        # Save validation results to separate file (not mixed with training results)
        # Get the regressor parameters for logging
        regressor_params = best_regressor.get_params()
        if use_pca and pca_n_components:
            regressor_params['pca_n_components'] = pca_n_components
            
        self.reporter.save_validation_metrics(self.strategy, f"optimized_{model_name}", metrics, regressor_params)
        
        logger.info(f"Validation evaluation completed for optimized {model_name}")

    def _retrain_and_save_best_model(self, best_params: dict):
        """Retrains and saves the best model found by Optuna."""
        logger.info("Retraining best model on the full training data...")
        
        # 1. Extract model name and determine PCA usage
        model_name = best_params.pop("model_name")
        use_pca = model_name.endswith('_pca')
        pca_n_components = best_params.pop("pca_n_components", None) if use_pca else None

        # 2. Get the best regressor
        best_regressor = self._get_regressor(model_name, best_params)

        # 3. Reconstruct the best model pipeline (preprocessing + regressor only)
        model_steps = [
            ('imputer', SimpleImputer(strategy='mean')),
            ('clipper', OutlierClipper()),
            ('scaler', StandardScaler())
        ]
        if use_pca and pca_n_components:
            model_steps.append(('pca', PCA(n_components=pca_n_components)))
            logger.info(f"Using PCA with {pca_n_components} components for {model_name}")
        
        model_steps.append(('regressor', best_regressor))
        model_pipeline = Pipeline(model_steps)
        
        # 4. Create the feature pipeline (same as regular training)
        feature_pipeline = self.feature_pipeline
        
        # 5. Combine into full pipeline (consistent with regular training)
        full_pipeline = Pipeline([
            ('features', feature_pipeline),
            ('model', model_pipeline)
        ])
        
        # 6. Fit on the entire training dataset (using original data, not pre-computed features)
        if (self.config.use_sample_weights and 
            self.sample_weights is not None and 
            self._model_supports_sample_weight(model_name)):
            
            logger.info(f"Training final optimized model {model_name} with sample weights")
            full_pipeline.fit(self.X_train, self.y_train, model__regressor__sample_weight=self.sample_weights)
        else:
            full_pipeline.fit(self.X_train, self.y_train)

        # 7. Save the final pipeline (consistent naming with regular training)
        filename = f"optimized_{self.strategy}_{model_name}_{self.config.run_timestamp}.pkl"
        save_path = self.config.model_dir / filename
        joblib.dump(full_pipeline, save_path)
        logger.info(f"Saved optimized model to: {save_path}")