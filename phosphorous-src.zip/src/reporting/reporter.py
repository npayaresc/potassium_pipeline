"""
Reporting Module

Handles the aggregation, visualization, and saving of model performance
metrics and prediction results.
"""
import logging
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
import optuna
import json

logger = logging.getLogger(__name__)

class Reporter:
    """Aggregates and saves all results from a pipeline run."""

    def __init__(self, config):
        """
        Initializes the Reporter.

        Args:
            config: The pipeline configuration object.
        """
        self.config = config
        self.results = []

    def add_run_results(self, strategy: str, model_name: str, metrics: dict, params: dict):
        """
        Adds the results of a single model training run to the aggregate list.

        Args:
            strategy: The feature strategy used (e.g., 'simple_only').
            model_name: The name of the model trained (e.g., 'random_forest').
            metrics: A dictionary of performance metrics (e.g., {'r2': 0.9, 'rmse': 0.1}).
            params: A dictionary of the model's parameters.
        """
        result_entry = {
            'strategy': strategy,
            'model_name': model_name,
            **metrics,
            'params': params,
        }
        self.results.append(result_entry)
        logger.debug(f"Added results for {strategy}/{model_name}.")

    def save_summary_report(self):
        """
        Saves the aggregated results of all runs to a CSV file and prints a summary.
        """
        if not self.results:
            logger.warning("No results to report. Skipping summary report.")
            return

        results_df = pd.DataFrame(self.results)
        results_df = results_df.sort_values(by='r2', ascending=False).reset_index(drop=True)

        # Save to CSV
        report_path = self.config.reports_dir / f"training_summary_{self.config.run_timestamp}.csv"
        results_df.to_csv(report_path, index=False)
        logger.info(f"Full training summary saved to: {report_path}")

        # Print a formatted summary to the console
        print("\n--- MODEL TRAINING SUMMARY ---")
        display_cols = ['strategy', 'model_name', 'r2', 'rmse', 'mae', 'mape', 'rrmse', 'within_20.5%']
        # Ensure all display columns exist, filling with NaN if not
        for col in display_cols:
            if col not in results_df.columns:
                results_df[col] = np.nan
        
        print(results_df[display_cols].to_string(index=False, float_format="%.4f"))
        print("----------------------------\n")

    def save_prediction_results(
        self, y_true: pd.Series, y_pred: np.ndarray,
        sample_ids: pd.Series, strategy: str, model_name: str
    ):
        """
        Saves detailed prediction results (true vs. predicted) for a specific model.

        Args:
            y_true: Series of true target values.
            y_pred: Array of predicted values.
            sample_ids: Series of sample IDs corresponding to the test set.
            strategy: The feature strategy used.
            model_name: The name of the model.
        """
        predictions_df = pd.DataFrame({
            'sampleId': sample_ids,
            'ElementValue': y_true,
            'PredictedValue': y_pred
        })
        
        filename = f"predictions_{strategy}_{model_name}_{self.config.run_timestamp}.csv"
        save_path = self.config.reports_dir / filename
        predictions_df.to_csv(save_path, index=False)
        logger.info(f"Predictions for {strategy}/{model_name} saved to: {save_path}")
        
        return predictions_df # Return for further analysis

    def generate_calibration_plot(self, predictions_df: pd.DataFrame, strategy: str, model_name: str):
        """
        Generates and saves a calibration plot (predicted vs. actual).

        Args:
            predictions_df: DataFrame with 'ElementValue' and 'PredictedValue'.
            strategy: The feature strategy used.
            model_name: The name of the model.
        """
        y_true = predictions_df['ElementValue']
        y_pred = predictions_df['PredictedValue']
        
        r2 = r2_score(y_true, y_pred)
        
        plt.figure(figsize=(8, 8))
        plt.scatter(y_true, y_pred, alpha=0.6, edgecolors='k', label='Predicted vs. Actual')
        lims = [min(y_true.min(), y_pred.min()), max(y_true.max(), y_pred.max())]
        plt.plot(lims, lims, 'r--', alpha=0.75, lw=2, label='Ideal 1:1 Line')
        
        plt.title(f'Calibration Curve: {strategy} / {model_name}', fontsize=16)
        plt.xlabel('Actual Phosphorous Concentration (%)', fontsize=12)
        plt.ylabel('Predicted Phosphorous Concentration (%)', fontsize=12)
        plt.legend()
        plt.grid(True, linestyle='--', linewidth=0.5)
        
        textstr = f'$R^2 = {r2:.4f}$'
        plt.text(0.05, 0.95, textstr, transform=plt.gca().transAxes, fontsize=12,
                 verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        plot_filename = f"calibration_plot_{strategy}_{model_name}_{self.config.run_timestamp}.png"
        save_path = self.config.reports_dir / plot_filename
        plt.savefig(save_path, dpi=300)
        plt.close()
        logger.info(f"Calibration plot saved to: {save_path}")
        
    def save_tuning_report(self, study: optuna.Study, strategy: str):
        """
        Saves the results of a hyperparameter tuning study to a CSV file.

        Args:
            study: The completed Optuna study object.
            strategy: The feature strategy used for the tuning run.
        """
        results_df = study.trials_dataframe()
        report_path = self.config.reports_dir / f"tuning_report_{strategy}_{self.config.run_timestamp}.csv"
        results_df.to_csv(report_path, index=False)
        logger.info(f"Tuning study report for strategy '{strategy}' saved to: {report_path}")

    def save_validation_metrics(self, strategy: str, model_name: str, metrics: dict, params: dict):
        """
        Saves validation metrics from hyperparameter tuning to a separate CSV file.
        
        Args:
            strategy: The feature strategy used.
            model_name: The name of the model.
            metrics: Dictionary of validation metrics.
            params: Dictionary of model parameters.
        """
        # Create a single row with all the information
        validation_data = {
            'strategy': strategy,
            'model_name': model_name,
            'timestamp': self.config.run_timestamp,
            **metrics,  # Unpack all metrics (r2, rmse, mae, etc.)
            'params': str(params)  # Convert params dict to string
        }
        
        # Convert to DataFrame
        validation_df = pd.DataFrame([validation_data])
        
        # Save to CSV file
        filename = f"validation_metrics_{strategy}_{model_name}_{self.config.run_timestamp}.csv"
        save_path = self.config.reports_dir / filename
        validation_df.to_csv(save_path, index=False)
        
        logger.info(f"Validation metrics for {strategy}/{model_name} saved to: {save_path}")
        
        return save_path

    def save_config(self):
        """
        Saves the pipeline configuration to a JSON file with timestamp.
        
        Returns:
            Path: The path where the config was saved.
        """
        # Convert the config to a dictionary, handling Pydantic serialization
        config_dict = self.config.model_dump()
        
        # Remove non-serializable path objects and convert to strings
        for key, value in config_dict.items():
            if hasattr(value, '__fspath__'):  # Path objects
                config_dict[key] = str(value)
        
        # Create the filename with timestamp
        config_filename = f"pipeline_config_{self.config.run_timestamp}.json"
        save_path = self.config.reports_dir / config_filename
        
        # Save the config as JSON
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(config_dict, f, indent=2, default=str, ensure_ascii=False)
        
        logger.info(f"Pipeline configuration saved to: {save_path}")
        return save_path