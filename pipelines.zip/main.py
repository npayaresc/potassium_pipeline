"""
Main Orchestration Script for the Nitrogen Prediction Pipeline.

This script serves as the entry point to run different stages of the ML pipeline,
including data preparation, standard training, AutoGluon training, hyperparameter
tuning, and prediction.

Usage:
  - python main.py train            (Trains all standard models from the config)
  - python main.py autogluon        (Runs the automated AutoGluon pipeline)
  - python main.py tune             (Runs Optuna hyperparameter optimization)
  - python main.py predict --input-file ... --model-path ... (Makes a prediction)
"""
import argparse
import json
import logging
from datetime import datetime
from pathlib import Path
from autogluon.tabular.predictor.predictor import Optional
import pandas as pd
import shutil

from src.config.pipeline_config import config, Config
from src.data_management.data_manager import DataManager
from src.cleansing.data_cleanser import DataCleanser
from src.models.model_trainer import ModelTrainer
from src.models.autogluon_trainer import AutoGluonTrainer
from src.models.model_tuner import ModelTuner
from src.models.predictor import Predictor
from src.reporting.reporter import Reporter
from src.utils.helpers import calculate_regression_metrics, setup_logging
from src.utils.custom_exceptions import DataValidationError, PipelineError

logger = logging.getLogger(__name__)

def setup_pipeline_config() -> Config:
    """Sets up dynamic configuration values and creates all necessary directories."""
    config.run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    project_root = Path(__file__).resolve().parents[0]
    
    # Define all paths relative to the project root
    data_dir = project_root / "data"
    raw_data_dir = data_dir / "raw" / "data_5278_Phase3"
    processed_data_dir = data_dir / "processed"
    averaged_files_dir = data_dir / "averaged_files_per_sample"
    cleansed_files_dir = data_dir / "cleansed_files_per_sample"
    model_dir = project_root / "models"
    reports_dir = project_root / "reports"
    log_dir = project_root / "logs"
    bad_files_dir = project_root / "bad_files"
    bad_prediction_files_dir = project_root / "bad_prediction_files"
    reference_data_path = project_root / "data" / "reference_data" / "Final_Lab_Data_Nico_New.xlsx"
    
    # Create all directories first, before assigning to config
    for dir_path in [
        processed_data_dir, averaged_files_dir, cleansed_files_dir,
        model_dir, reports_dir, log_dir, bad_files_dir, bad_prediction_files_dir
    ]:
        dir_path.mkdir(parents=True, exist_ok=True)
    
    # Now assign paths to config after directories exist
    config.data_dir = data_dir
    config.raw_data_dir = raw_data_dir
    config.processed_data_dir = processed_data_dir
    config.averaged_files_dir = averaged_files_dir
    config.cleansed_files_dir = cleansed_files_dir
    config.model_dir = model_dir
    config.reports_dir = reports_dir
    config.log_dir = log_dir
    config.bad_files_dir = bad_files_dir
    config.bad_prediction_files_dir = bad_prediction_files_dir
    config.reference_data_path = reference_data_path
    config.sample_id_column = "Sample ID"
    
    setup_logging()
    return config

def run_data_preparation(cfg: Config):
    """Orchestrates the initial data preparation: averaging raw files."""
    data_manager = DataManager(cfg)
    data_manager.average_raw_files()

def load_and_clean_data(cfg: Config) -> pd.DataFrame:
    """Loads averaged data, cleans it, saves the clean version, and moves bad files."""
    data_manager = DataManager(cfg)
    metadata = data_manager.load_and_prepare_metadata()
    training_files = data_manager.get_training_data_paths()
    data_cleanser = DataCleanser(cfg)
    processed_data_for_training = []

    logger.info(f"Cleansing {len(training_files)} averaged files...")
    for file_path in training_files:
        wavelengths, intensities = data_manager.load_spectral_file(file_path)
        
        # Ensure intensity is 2D for the cleanser, as averaged files might have 1D intensity
        if intensities.ndim == 1:
            intensities = intensities.reshape(-1, 1)

        clean_intensities = data_cleanser.clean_spectra(str(file_path), intensities)
        
        if clean_intensities.size > 0:
            # Save the cleansed file for auditing and reuse
            cleansed_path = cfg.cleansed_files_dir / file_path.name
            # Start DataFrame with the Wavelength column
            cleansed_df = pd.DataFrame({'Wavelength': wavelengths})
            
            # Add each remaining intensity column (shot) one by one
            for i in range(clean_intensities.shape[1]):
                cleansed_df[f'Intensity{i+1}'] = clean_intensities[:, i]
                
            cleansed_df.to_csv(cleansed_path, index=False)

            # Prepare the data for in-memory use in the current pipeline run
            sample_id = file_path.name.replace('.csv.txt', '')
            target = metadata.loc[metadata[cfg.sample_id_column] == sample_id, cfg.target_column].values[0]
            processed_data_for_training.append({
                 cfg.sample_id_column: sample_id, "wavelengths": wavelengths,
                "intensities": clean_intensities, cfg.target_column: target
            })
        else:
            # File had too many outliers; move the *averaged* source file to bad_files
            try:
                destination = cfg.bad_files_dir / file_path.name
                shutil.move(str(file_path), str(destination))
                logger.warning(f"Moved bad averaged file {file_path.name} to {cfg.bad_files_dir}")
            except Exception as e:
                logger.error(f"Failed to move bad file {file_path.name}: {e}")
    
    if not processed_data_for_training:
        raise DataValidationError("No data left after cleansing. Aborting pipeline.")
    
    logger.info(f"Data cleaning complete. {len(processed_data_for_training)} files are ready for training.")
    return pd.DataFrame(processed_data_for_training)

def run_training_pipeline():
    """Executes the standard model training pipeline."""
    cfg = setup_pipeline_config()
    logger.info(f"Starting standard training run: {cfg.run_timestamp}")
    
    run_data_preparation(cfg)
    reporter = Reporter(cfg)
    full_dataset = load_and_clean_data(cfg)
    train_df, test_df = DataManager(cfg).create_reproducible_splits(full_dataset)

    for strategy in cfg.feature_strategies:
        model_trainer = ModelTrainer(cfg, strategy=strategy, reporter=reporter)
        model_trainer.train_and_evaluate(train_df, test_df)
    
    reporter.save_summary_report()
    logger.info("Standard training pipeline run completed successfully.")

def run_autogluon_pipeline():
    """Executes the dedicated AutoGluon training pipeline."""
    cfg = setup_pipeline_config()
    logger.info(f"Starting AutoGluon training run: {cfg.run_timestamp}")
    
    #run_data_preparation(cfg)
    full_dataset = load_and_clean_data(cfg)
    
    strategy_for_autogluon = "simple_only" # As per original logic, often best for AutoGluon
    logger.info(f"Using feature strategy '{strategy_for_autogluon}' for AutoGluon.")
    trainer = AutoGluonTrainer(config=cfg, strategy=strategy_for_autogluon)
    trainer.train(full_dataset)
    logger.info("AutoGluon pipeline run completed successfully.")

def run_tuning_pipeline():
    """Executes the hyperparameter tuning pipeline."""
    cfg = setup_pipeline_config()
    logger.info(f"Starting tuning run: {cfg.run_timestamp}")
    
    run_data_preparation(cfg)
    reporter = Reporter(cfg)
    full_dataset = load_and_clean_data(cfg)
    train_df, _ = DataManager(cfg).create_reproducible_splits(full_dataset)
    
    for strategy in cfg.feature_strategies:
        tuner = ModelTuner(cfg, reporter=reporter, strategy=strategy)
        tuner.tune(train_df)
    
    logger.info("Hyperparameter tuning pipeline run completed successfully.")

# --- Prediction Pipeline Functions ---

def run_single_prediction_pipeline(input_file: str, model_path: str):
    """Executes a prediction on a single, non-averaged input file."""
    cfg = setup_pipeline_config()
    logger.info(f"Starting single-file prediction for: {input_file}")

    predictor = Predictor(config=cfg)
    prediction = predictor.make_single_prediction(
        input_file=Path(input_file),
        model_path=Path(model_path)
    )
    
    print("\n--- SINGLE PREDICTION RESULT ---")
    print(f"  Input File: {Path(input_file).name}")
    print(f"  Model Used: {Path(model_path).name}")
    print(f"  Predicted Nitrogen Concentration: {prediction:.4f} %")
    print("--------------------------------\n")

def run_batch_prediction_pipeline(input_dir: str, model_path: str, output_file: str, reference_file: Optional[str] = None):
    """Executes batch predictions on a directory, including the averaging step."""
    cfg = setup_pipeline_config()
    logger.info(f"Starting batch prediction run from dir: {input_dir}")

    predictor = Predictor(config=cfg)
    results_df = predictor.make_batch_predictions(
        input_dir=Path(input_dir),
        model_path=Path(model_path)
    )
    
    output_file_path = cfg.reports_dir / output_file
    results_df.to_csv(output_file_path, index=False)
    
    logger.info(f"Batch prediction complete. Results saved to {output_file_path}")
    print("\n--- BATCH PREDICTION SUMMARY ---")
    print(results_df.to_string())
    print("--------------------------------\n")
    
    if reference_file:
        logger.info(f"Reference file provided. Calculating performance metrics...")
        try:
            ref_df = pd.read_excel(reference_file)
            merged_df = pd.merge(
                results_df, ref_df, left_on='sampleId',
                right_on=cfg.sample_id_column, how='inner'
            )
            merged_df.dropna(subset=['PredictedValue', cfg.target_column], inplace=True)

            if merged_df.empty:
                logger.warning("No matching samples found between predictions and reference file.")
                return

            # --- METRICS CALCULATION FOR FULL DATASET ---
            full_metrics = calculate_regression_metrics(
                merged_df[cfg.target_column].values,
                merged_df['PredictedValue'].values
            )
            print("\n--- PREDICTION METRICS (Full Dataset) ---")
            print(f"  Compared {len(merged_df)} samples against reference file.")
            for name, value in full_metrics.items():
                print(f"  - {name.upper()}: {value:.4f}")
            print("-------------------------------------------\n")

            # --- FILTER DATA TO TRAINING RANGE AND RECALCULATE METRICS ---
            filtered_df = merged_df.copy()
            if cfg.target_value_min is not None:
                filtered_df = filtered_df[filtered_df[cfg.target_column] >= cfg.target_value_min]
            if cfg.target_value_max is not None:
                filtered_df = filtered_df[filtered_df[cfg.target_column] <= cfg.target_value_max]
            
            if filtered_df.empty:
                logger.warning("No samples found within the specified training range for filtered metrics.")
                filtered_metrics = {}
            else:
                filtered_metrics = calculate_regression_metrics(
                    filtered_df[cfg.target_column].values,
                    filtered_df['PredictedValue'].values
                )
                print("\n--- PREDICTION METRICS (Filtered to Training Range) ---")
                print(f"  Compared {len(filtered_df)} samples within range [{cfg.target_value_min}-{cfg.target_value_max}].")
                for name, value in filtered_metrics.items():
                    print(f"  - {name.upper()}: {value:.4f}")
                print("-----------------------------------------------------------\n")

            # --- SAVE METRICS REPORT TO JSON ---
            report_data = {
                'model_path': str(model_path),
                'prediction_file': str(output_file_path),
                'full_dataset_metrics': {
                    'sample_count': len(merged_df),
                    'metrics': full_metrics
                },
                'filtered_dataset_metrics': {
                    'sample_count': len(filtered_df),
                    'metrics': filtered_metrics
                }
            }
            report_path = cfg.reports_dir / f"prediction_metrics_report_{cfg.run_timestamp}.json"
            with open(report_path, 'w') as f:
                json.dump(report_data, f, indent=4)
            logger.info(f"Prediction metrics report saved to: {report_path}")

        except FileNotFoundError:
            logger.error(f"Reference file not found at: {reference_file}")
        except Exception as e:
            logger.error(f"Could not calculate metrics due to an error: {e}", exc_info=True)


def main():
    # """Main entry point for the Nitrogen Prediction ML Pipeline."""
    # parser = argparse.ArgumentParser(description="Nitrogen Prediction ML Pipeline")
    # subparsers = parser.add_subparsers(dest="stage", required=True, help="Pipeline stage to run")

    # subparsers.add_parser("train", help="Run the standard model training pipeline.")
    # subparsers.add_parser("autogluon", help="Run the AutoGluon training pipeline.")
    # subparsers.add_parser("tune", help="Run hyperparameter tuning for standard models.")

    # # Single Prediction subparser
    # parser_predict_single = subparsers.add_parser("predict-single", help="Make a prediction on a single raw file.")
    # parser_predict_single.add_argument("--input-file", type=str, required=True, help="Path to the raw spectral .csv.txt file.")
    # parser_predict_single.add_argument("--model-path", type=str, required=True, help="Path to the trained model (.pkl) or AutoGluon directory.")

    # # Batch Prediction subparser
    # parser_predict_batch = subparsers.add_parser("predict-batch", help="Make batch predictions on a directory of raw files.")
    # parser_predict_batch.add_argument("--input-dir", type=str, required=True, help="Path to the directory with raw spectral files.")
    # parser_predict_batch.add_argument("--model-path", type=str, required=True, help="Path to the trained model (.pkl) or AutoGluon directory.")
    # parser_predict_batch.add_argument("--output-file", type=str, default="batch_predictions.csv", help="Name for the output CSV file in the reports directory.")
    # parser_predict_batch.add_argument("--reference-file", type=str, required=False, help="Optional: Path to an Excel file with true values to calculate metrics.")


    #args = parser.parse_args()
    args = argparse.Namespace()
    time_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    args.stage = "autogluon"
    args.input_dir = "/home/payanico/nitrogen_pipeline/data/raw/data_5278_Phase3"
    args.model_path = "/home/payanico/nitrogen_pipeline/models/full_context_extratrees_20250720_204549.pkl"
    args.output_file = f"batch_predictions_{time_stamp}.csv"
    args.reference_file = "/home/payanico/nitrogen_pipeline/data/reference_data/Final_Lab_Data_Nico_New.xlsx"
    try:
        if args.stage == "train":
            run_training_pipeline()
        elif args.stage == "autogluon":
            run_autogluon_pipeline()
        elif args.stage == "tune":
            run_tuning_pipeline()
        elif args.stage == "predict-single":
            run_single_prediction_pipeline(input_file=args.input_file, model_path=args.model_path)
        elif args.stage == "predict-batch":
            run_batch_prediction_pipeline(input_dir=args.input_dir, model_path=args.model_path, output_file=args.output_file, reference_file=args.reference_file)          
    except (DataValidationError, PipelineError, FileNotFoundError) as e:
        logger.error(f"Pipeline stopped due to a known error: {e}")
    except Exception as e:
        logger.critical(f"An unexpected error occurred in pipeline stage '{args.stage}': {e}", exc_info=True)


if __name__ == "__main__":
    main()