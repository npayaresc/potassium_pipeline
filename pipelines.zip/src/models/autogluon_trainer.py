"""
AutoGluon Training Module: Defines the specific training process for the AutoGluon pipeline.
"""
import logging
from pathlib import Path
import pandas as pd
from sklearn.pipeline import Pipeline

from src.config.pipeline_config import Config
from src.features.feature_engineering import create_feature_pipeline
from src.models.custom_autogluon import AutoGluonRegressor

logger = logging.getLogger(__name__)

class AutoGluonTrainer:
    """Handles the training and saving of an AutoGluon model."""
    def __init__(self, config: Config, strategy: str):
        self.config = config
        self.strategy = strategy
        self.feature_pipeline = create_feature_pipeline(config, strategy)
        self.autogluon_model_path = (
            Path(self.config.model_dir) / self.config.autogluon.model_subdirectory
            / f"{self.strategy}_{self.config.run_timestamp}"
        )
        self.autogluon_model_path.mkdir(parents=True, exist_ok=True)

    def train(self, train_df: pd.DataFrame):
        """Trains the full feature engineering and AutoGluon pipeline."""
        X_train_raw = train_df.drop(columns=[self.config.target_column])
        y_train = train_df[self.config.target_column]
        y_train.name = self.config.target_column
        logger.info(f"Starting AutoGluon pipeline for strategy: {self.strategy}")

        logger.info("Preprocessing data for AutoGluon...")
        X_train_processed = self.feature_pipeline.fit_transform(X_train_raw)
        X_train_processed_df = pd.DataFrame(X_train_processed, columns=self.feature_pipeline.get_feature_names_out())

        autogluon_regressor = AutoGluonRegressor(
            config=self.config.autogluon, model_path=self.autogluon_model_path
        )
        autogluon_regressor.fit(X_train_processed_df, y_train)
        logger.info(f"AutoGluon training complete. Artifacts in: {self.autogluon_model_path}")