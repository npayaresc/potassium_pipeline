"""
Custom scikit-learn compatible wrapper for the AutoGluon TabularPredictor.
This version mirrors the full functionality of the original implementation,
including sample weighting and prediction calibration.
"""
import logging
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin

try:
    from autogluon.tabular import TabularPredictor
    AUTOGLUON_AVAILABLE = True
except ImportError:
    AUTOGLUON_AVAILABLE = False

from src.config.pipeline_config import AutoGluonConfig

logger = logging.getLogger(__name__)

class AutoGluonRegressor(BaseEstimator, RegressorMixin):
    """A scikit-learn compatible wrapper for AutoGluon's TabularPredictor."""
    def __init__(self, config: AutoGluonConfig, model_path: Path):
        if not AUTOGLUON_AVAILABLE:
            raise ImportError("AutoGluon not installed. Run 'pip install autogluon'.")
        self.config = config
        self.model_path = model_path
        self.predictor = None
        self.feature_names_in_ = None

    def _calculate_sample_weights(self, y: pd.Series) -> np.ndarray:
        """
        Calculate sample weights based on concentration ranges.
        This logic is adapted directly from the original script.
        """
        weights = np.ones_like(y, dtype=float)
        for i, val in enumerate(y):
            if 2.0 <= val < 3.0: weights[i] = 2.5
            elif 6.0 <= val <= 7.0: weights[i] = 1.8
            elif 3.0 <= val < 4.0: weights[i] = 2.5
            elif 5.0 <= val < 6.0: weights[i] = 1.2
            else: weights[i] = 1.0
        
        # Normalize weights
        return weights * len(y) / np.sum(weights)

    def fit(self, X: pd.DataFrame, y: pd.Series):
        """Fits the AutoGluon TabularPredictor."""
        self.feature_names_in_ = list(X.columns)
        train_data = pd.concat([X, y], axis=1)
        
        predictor_kwargs = {
            'label': y.name,
            'path': str(self.model_path),
            'eval_metric': 'root_mean_squared_error',
            'verbosity': 2
        }

        # ADDED: Logic for custom sample weighting
        if self.config.use_improved_config:
            logger.info("Using improved config: Applying custom sample weights.")
            sample_weight = self._calculate_sample_weights(y)
            train_data['sample_weight'] = sample_weight
            predictor_kwargs['sample_weight'] = 'sample_weight'

        logger.info(f"Starting AutoGluon training. Models saved to: {self.model_path}")
        logger.info(f"Time limit: {self.config.time_limit} seconds.")

        self.predictor = TabularPredictor(**predictor_kwargs).fit(
            train_data,
            time_limit=self.config.time_limit,
            presets=self.config.presets,
            hyperparameters=self.config.hyperparameters,
            ag_args_fit=self.config.ag_args_fit,
            ag_args_ensemble=self.config.ag_args_ensemble,
            excluded_model_types=self.config.excluded_model_types,
            refit_full=True,
        )
        logger.info("AutoGluon training completed.")
        logger.info(f"AutoGluon Leaderboard:\n{self.predictor.leaderboard(silent=True)}")
        
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Makes predictions, applying calibration if configured."""
        if self.predictor is None:
            raise RuntimeError("The model has not been fitted yet.")
        
        X_reordered = X[self.feature_names_in_]
        base_predictions = self.predictor.predict(X_reordered).values
        
        # ADDED: Post-processing calibration logic
        if self.config.use_improved_config:
            logger.info("Using improved config: Applying post-prediction calibration.")
            calibrated_predictions = np.copy(base_predictions)
            for i, pred in enumerate(base_predictions):
                if pred < 2.5: calibrated_predictions[i] = pred * 0.85
                elif pred > 6.0: calibrated_predictions[i] = pred * 1.08
                elif 2.5 <= pred < 3.0: calibrated_predictions[i] = pred * 0.92
            return calibrated_predictions
        
        return base_predictions