"""
Model Training Module: Defines the training and evaluation process for standard models.
"""
import logging
from pathlib import Path
import joblib
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge, Lasso, ElasticNet
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor

from src.config.pipeline_config import Config
from src.features.feature_engineering import create_feature_pipeline
from src.utils.helpers import calculate_regression_metrics
from src.reporting.reporter import Reporter

logger = logging.getLogger(__name__)

class ModelTrainer:
    """Handles the training and evaluation of regression models."""
    def __init__(self, config: Config, strategy: str, reporter: Reporter):
        self.config = config
        self.strategy = strategy
        self.reporter = reporter
        self.feature_pipeline = create_feature_pipeline(config, strategy)

    def _get_model(self, model_name: str) -> Pipeline:
        """
        Returns a scikit-learn pipeline for the requested model, using
        parameters defined in the central configuration file.
        """
        base_model_name = model_name.replace("_pca", "")
        
        # Fetch the parameter dictionary from the config
        try:
            params = getattr(self.config.model_params, base_model_name).copy()
        except AttributeError:
            raise ValueError(f"Parameters for model '{base_model_name}' not found in config.")

        # Define the model instance using the fetched parameters
        model_map = {
            "ridge": Ridge, "lasso": Lasso, "elastic_net": ElasticNet,
            "random_forest": RandomForestRegressor, "gradient_boost": GradientBoostingRegressor,
            "xgboost": XGBRegressor, "lightgbm": LGBMRegressor,
            "catboost": CatBoostRegressor, "svr": SVR,
            "extratrees": ExtraTreesRegressor,
            "ridge_pca": Ridge, "lasso_pca": Lasso, "elastic_net_pca": ElasticNet,
            "random_forest_pca": RandomForestRegressor, "gradient_boost_pca": GradientBoostingRegressor,
            "xgboost_pca": XGBRegressor, "lightgbm_pca": LGBMRegressor,
            "catboost_pca": CatBoostRegressor, "svr_pca": SVR,
            "extratrees_pca": ExtraTreesRegressor,
        }
        
        if base_model_name not in model_map:
            raise ValueError(f"Unknown model name: {model_name}")
        
        # Add universal parameters
        if base_model_name not in ["svr"]:
             params['random_state'] = self.config.random_state
        if base_model_name == 'lightgbm': params['verbose'] = -1
        if base_model_name == 'catboost': params['verbose'] = 0

        regressor = model_map[base_model_name](**params)
        
        # Construct the final model pipeline, adding PCA if requested
        model_steps = [('pca', PCA(n_components=0.95))] if "_pca" in model_name else []
        model_steps.append(('regressor', regressor))
        
        return Pipeline(model_steps)

    def train_and_evaluate(self, train_df: pd.DataFrame, test_df: pd.DataFrame):
        """Trains all specified models and evaluates their performance."""
        X_train_raw = train_df.drop(columns=[self.config.target_column])
        y_train = train_df[self.config.target_column]
        X_test_raw = test_df.drop(columns=[self.config.target_column])
        y_test = test_df[self.config.target_column]
        logger.info(f"Starting training for feature strategy: {self.strategy}")
        
        # We need sample_id from the test set for detailed prediction saving
        test_sample_ids = X_test_raw[self.config.sample_id_column]

        # Fit feature pipeline on data without sample_id
        self.feature_pipeline.fit(X_train_raw.drop(columns=[self.config.sample_id_column]))
        X_train = self.feature_pipeline.transform(X_train_raw.drop(columns=[self.config.sample_id_column]))
        X_test = self.feature_pipeline.transform(X_test_raw.drop(columns=[self.config.sample_id_column]))

        for model_name in self.config.models_to_train:
            logger.info(f"--- Training model: {model_name} ---")
            model_pipeline = self._get_model(model_name)
            model_pipeline.fit(X_train, y_train)

            y_pred = model_pipeline.predict(X_test)
            metrics = calculate_regression_metrics(y_test, y_pred)
            logger.info(f"Evaluation metrics for {model_name}: {metrics}")
            
            params = model_pipeline.named_steps['regressor'].get_params()
            
            # Use the reporter to add results
            self.reporter.add_run_results(self.strategy, model_name, metrics, params)
            
            # Use the reporter to save detailed predictions and plots
            predictions_df = self.reporter.save_prediction_results(
                y_test, y_pred, test_sample_ids, self.strategy, model_name
            )
            self.reporter.generate_calibration_plot(predictions_df, self.strategy, model_name)
            
            # Combine feature engineering and model into a single deployable pipeline
            full_pipeline = Pipeline([
                ('features', self.feature_pipeline),
                ('model', model_pipeline)
            ])
            self.save_pipeline(full_pipeline, model_name)

    def save_pipeline(self, pipeline: Pipeline, model_name: str):
        """Saves the complete scikit-learn pipeline."""
        filename = f"{self.strategy}_{model_name}_{self.config.run_timestamp}.pkl"
        save_path = Path(self.config.model_dir) / filename
        joblib.dump(pipeline, save_path)
        logger.info(f"Pipeline for {model_name} saved to: {save_path}")