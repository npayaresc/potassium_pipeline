"""
Model Tuning Module

This module defines the ModelTuner class, which uses Optuna to perform
hyperparameter optimization for specified models.
"""
import logging
from catboost import CatBoostRegressor
import joblib
from pathlib import Path

import optuna
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor

from src.config.pipeline_config import Config
from src.features.feature_engineering import SpectralFeatureGenerator, create_feature_pipeline
from src.reporting.reporter import Reporter
from src.utils.custom_exceptions import ModelTrainingError
from src.models.tuner_objectives import (
    calculate_robust_objective,
    calculate_concentration_weighted_objective,
    calculate_mape_focused_objective
)
from src.utils.helpers import OutlierClipper

logger = logging.getLogger(__name__)

class ModelTuner:
    """Uses Optuna to find the best hyperparameters for a model."""

    def __init__(self, config: Config, reporter: Reporter, strategy: str):
        self.config = config
        self.reporter = reporter
        self.strategy = strategy
        self.feature_pipeline = create_feature_pipeline(config, strategy)
        self.X_train = None
        self.y_train = None
    
    
    def _define_search_space(self, trial: optuna.Trial, model_name: str) -> dict:
        """Returns a dictionary of parameters for a given model."""
        if model_name == "random_forest":
            params = {
                'n_estimators': trial.suggest_int('n_estimators', 50, 500),
                'max_depth': trial.suggest_categorical('max_depth', [None, 10, 20, 30]),
                'min_samples_split': trial.suggest_int('min_samples_split', 2, 20),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 10),
                'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', 0.7]),
            }
            if trial.suggest_categorical('bootstrap', [True, False]):
                params['bootstrap'] = True
                params['max_samples'] = trial.suggest_float('max_samples', 0.5, 1.0)
            else:
                params['bootstrap'] = False
            return params

        if model_name == "xgboost":
            return {
                'n_estimators': trial.suggest_int('n_estimators', 100, 800),
                'max_depth': trial.suggest_int('max_depth', 3, 10),
                'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.2),
                'subsample': trial.suggest_float('subsample', 0.6, 1.0),
                'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
                'reg_alpha': trial.suggest_float('reg_alpha', 0.0, 5.0),
                'reg_lambda': trial.suggest_float('reg_lambda', 1.0, 10.0),
            }

        if model_name == "lightgbm":
            return {
                'n_estimators': trial.suggest_int('n_estimators', 100, 1000),
                'learning_rate': trial.suggest_float('learning_rate', 0.005, 0.1, log=True),
                'num_leaves': trial.suggest_int('num_leaves', 31, 255),
                'max_depth': trial.suggest_int('max_depth', 5, 15),
                'min_child_samples': trial.suggest_int('min_child_samples', 5, 50),
                'reg_alpha': trial.suggest_float('reg_alpha', 0.0, 20.0),
                'reg_lambda': trial.suggest_float('reg_lambda', 0.0, 20.0),
                'colsample_bytree': trial.suggest_float('colsample_bytree', 0.7, 1.0),
                'subsample': trial.suggest_float('subsample', 0.7, 1.0),
            }

        if model_name == "catboost":
            return {
                'iterations': trial.suggest_int('iterations', 200, 1200),
                'depth': trial.suggest_int('depth', 4, 10),
                'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.2),
                'l2_leaf_reg': trial.suggest_float('l2_leaf_reg', 1.0, 10.0),
                'random_strength': trial.suggest_float('random_strength', 0.1, 2.0),
            }

        if model_name == "svr":
            return {
                'C': trial.suggest_float("C", 1e-1, 1e3, log=True),
                'gamma': trial.suggest_categorical("gamma", ['scale', 'auto']),
                'epsilon': trial.suggest_float("epsilon", 1e-2, 1e0, log=True),
            }
            
        if model_name == "extratrees":
             return {
                'n_estimators': trial.suggest_int('n_estimators', 100, 600),
                'max_depth': trial.suggest_int('max_depth', 5, 40),
                'min_samples_split': trial.suggest_int('min_samples_split', 2, 30),
                'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 20),
                'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', 0.8]),
             }

        raise ValueError(f"Tuning not configured for model: {model_name}")

    def _get_regressor(self, model_name: str, params: dict):
        """Returns a model instance from a dictionary of parameters."""
        model_map = {
            "random_forest": RandomForestRegressor, "xgboost": XGBRegressor,
            "lightgbm": LGBMRegressor, "catboost": CatBoostRegressor,
            "svr": SVR, "extratrees": ExtraTreesRegressor,
        }
        params['random_state'] = self.config.random_state
        if model_name == 'lightgbm': params['verbose'] = -1
        if model_name == 'catboost': params['verbose'] = 0
        
        return model_map[model_name](**params)
    
    
    def _get_model_search_space(self, trial: optuna.Trial, model_name: str):
        """Defines the hyperparameter search space for a given model."""
        if model_name == "random_forest":
            return RandomForestRegressor(
                n_estimators=trial.suggest_int("n_estimators", 50, 500),
                max_depth=trial.suggest_int("max_depth", 5, 50),
                min_samples_split=trial.suggest_int("min_samples_split", 2, 20),
                min_samples_leaf=trial.suggest_int("min_samples_leaf", 1, 10),
                random_state=self.config.random_state,
            )
        if model_name == "xgboost":
            return XGBRegressor(
                n_estimators=trial.suggest_int("n_estimators", 50, 500),
                max_depth=trial.suggest_int("max_depth", 3, 10),
                learning_rate=trial.suggest_float("learning_rate", 0.01, 0.3),
                subsample=trial.suggest_float("subsample", 0.6, 1.0),
                random_state=self.config.random_state,
            )
        if model_name == "lightgbm":
            return LGBMRegressor(
                n_estimators=trial.suggest_int("n_estimators", 50, 500),
                max_depth=trial.suggest_int("max_depth", 3, 10),
                learning_rate=trial.suggest_float("learning_rate", 0.01, 0.3),
                num_leaves=trial.suggest_int("num_leaves", 20, 300),
                random_state=self.config.random_state,
                verbose=-1,
            )
        if model_name == "catboost":
            return CatBoostRegressor(
                iterations=trial.suggest_int("iterations", 100, 1000),
                depth=trial.suggest_int("depth", 4, 10),
                learning_rate=trial.suggest_float("learning_rate", 0.01, 0.3),
                l2_leaf_reg=trial.suggest_float("l2_leaf_reg", 1.0, 10.0),
                random_state=self.config.random_state,
                verbose=0,
            )
            
        if model_name == "svr":
            return SVR(
                C=trial.suggest_float("C", 1e-2, 1e2, log=True),
                gamma=trial.suggest_categorical("gamma", ['scale', 'auto']),
                epsilon=trial.suggest_float("epsilon", 1e-2, 1e0, log=True),
            )
        raise ValueError(f"Tuning not configured for model: {model_name}")

    def _objective(self, trial: optuna.Trial) -> float:
        """The objective function that Optuna tries to maximize."""
        # 1. Select a model and its hyperparameters
        model_name = trial.suggest_categorical("model_name", self.config.tuner.models_to_tune)
        model_params = self._define_search_space(trial, model_name)
        regressor = self._get_regressor(model_name, model_params.copy()) # Use a copy

        # 2. Select preprocessing steps
        use_pca = trial.suggest_categorical("use_pca", [True, False])
        
        # 3. Build the full pipeline for this specific trial
        steps = [
            ('spectral_features', SpectralFeatureGenerator(config=self.config, strategy=self.strategy)),
            ('imputer', SimpleImputer(strategy='mean')),
            ('clipper', OutlierClipper()),
            ('scaler', StandardScaler())
        ]
        if use_pca:
            steps.append(('pca', PCA(n_components=trial.suggest_float("pca_n_components", 0.85, 0.99))))
        
        steps.append(('regressor', regressor))
        pipeline = Pipeline(steps)

        # 4. Evaluate this pipeline using the configured objective function
        try:
            return self._evaluate_with_custom_objective(pipeline)
        except Exception as e:
            logger.warning(f"Trial failed for {model_name}: {e}")
            return -1.0
    
    def _evaluate_with_custom_objective(self, pipeline) -> float:
        """Evaluates pipeline using the configured objective function."""
        objective_name = self.config.tuner.objective_function_name
        
        if objective_name == 'r2':
            # Standard R² scoring
            cv_scores = cross_val_score(
                pipeline, self.X_train, self.y_train, n_jobs=1, cv=3, scoring='r2'
            )
            return np.mean(cv_scores)
        
        elif objective_name == 'concentration_weighted':
            return self._custom_cv_score(pipeline, calculate_concentration_weighted_objective)
        
        elif objective_name == 'robust':
            return self._custom_cv_score(pipeline, calculate_robust_objective)
        
        elif objective_name == 'mape_focused':
            return self._custom_cv_score(pipeline, calculate_mape_focused_objective)
        
        else:
            raise ValueError(f"Unknown objective function: {objective_name}")
    
    def _custom_cv_score(self, pipeline, objective_func) -> float:
        """Performs manual cross-validation using a custom objective function."""
        from sklearn.model_selection import KFold
        
        kf = KFold(n_splits=3, shuffle=True, random_state=self.config.random_state)
        scores = []
        
        for train_idx, val_idx in kf.split(self.X_train):
            X_train_fold, X_val_fold = self.X_train.iloc[train_idx], self.X_train.iloc[val_idx]
            y_train_fold, y_val_fold = self.y_train.iloc[train_idx], self.y_train.iloc[val_idx]
            
            # Fit pipeline on training fold
            pipeline.fit(X_train_fold, y_train_fold)
            
            # Predict on validation fold
            y_pred = pipeline.predict(X_val_fold)
            
            # Calculate custom objective score
            score = objective_func(y_val_fold.values, y_pred)
            scores.append(score)
        
        return np.mean(scores)
    def tune(self, train_df: pd.DataFrame):
        """
        Runs the full hyperparameter tuning process.

        Args:
            train_df: The training DataFrame.
        """
        logger.info(f"Starting hyperparameter tuning for strategy: {self.strategy}")
        logger.info(f"Models to tune: {self.config.tuner.models_to_tune}")
        logger.info(f"Number of trials: {self.config.tuner.n_trials}")

        # Prepare data (features are generated inside the objective function)
        self.X_train = train_df.drop(columns=[self.config.target_column])
        self.y_train = train_df[self.config.target_column]

        # Create and run the Optuna study
        study = optuna.create_study(direction="maximize")
        study.optimize(
            self._objective,
            n_trials=self.config.tuner.n_trials,
            timeout=self.config.tuner.timeout
        )
        
        logger.info(f"Tuning finished. Best trial: {study.best_trial.value:.4f}")
        logger.info(f"Best parameters: {study.best_params}")

        # Save the full study results
        self.reporter.save_tuning_report(study, self.strategy)
        
        # Retrain the best model on the full training data and save it
        self._retrain_and_save_best_model(study.best_params)

    def _retrain_and_save_best_model(self, best_params: dict):
        """Retrains and saves the best model found by Optuna."""
        logger.info("Retraining best model on the full training data...")
        
        # 1. Pop non-model parameters
        model_name = best_params.pop("model_name")
        use_pca = best_params.pop("use_pca")
        pca_n_components = best_params.pop("pca_n_components", None)

        # 2. Get the best regressor
        best_regressor = self._get_regressor(model_name, best_params)

        # 3. Reconstruct the best pipeline
        steps = [
            ('spectral_features', SpectralFeatureGenerator(config=self.config, strategy=self.strategy)),
            ('imputer', SimpleImputer(strategy='mean')),
            ('clipper', OutlierClipper()),
            ('scaler', StandardScaler())
        ]
        if use_pca and pca_n_components:
            steps.append(('pca', PCA(n_components=pca_n_components)))
        
        steps.append(('regressor', best_regressor))
        optimized_pipeline = Pipeline(steps)
        
        # 4. Fit on the entire training dataset
        optimized_pipeline.fit(self.X_train, self.y_train)

        # 5. Save the final pipeline
        filename = f"optimized_{self.strategy}_{model_name}_{self.config.run_timestamp}.pkl"
        save_path = self.config.model_dir / filename
        joblib.dump(optimized_pipeline, save_path)
        logger.info(f"Saved optimized model to: {save_path}")