"""
Prediction Module

This module defines the Predictor class, which handles loading a trained model
and making predictions on new, unseen spectral data.
"""
from collections import defaultdict
import logging
from pathlib import Path
import shutil
import joblib
import pandas as pd
import numpy as np

from src.config.pipeline_config import Config
from src.data_management.data_manager import DataManager
from src.cleansing.data_cleanser import DataCleanser
from src.utils.custom_exceptions import PipelineError

# Conditionally import AutoGluon to avoid errors if it's not installed
try:
    from autogluon.tabular import TabularPredictor
    AUTOGLUON_AVAILABLE = True
except ImportError:
    AUTOGLUON_AVAILABLE = False

logger = logging.getLogger(__name__)

class Predictor:
    """Handles loading models and making predictions on new data."""

    def __init__(self, config: Config):
        """
        Initializes the Predictor.

        Args:
            config: The pipeline configuration object.
        """
        self.config = config
        self.data_cleanser = DataCleanser(config)
        # Use the same data manager methods for consistency
        self.data_manager = DataManager(config)

    def _load_model(self, model_path: Path) -> any:
        """
        Loads a model, handling both standard .pkl and AutoGluon models.

        Args:
            model_path: Path to the model file or directory.

        Returns:
            A loaded model object (scikit-learn pipeline or AutoGluon TabularPredictor).
        """
        if model_path.is_dir():
            # This is an AutoGluon model directory
            if not AUTOGLUON_AVAILABLE:
                raise ImportError("AutoGluon is not installed, but trying to load an AutoGluon model.")
            logger.info(f"Loading AutoGluon model from directory: {model_path}")
            return TabularPredictor.load(str(model_path))
        elif model_path.suffix == '.pkl':
            # This is a standard scikit-learn pipeline
            logger.info(f"Loading scikit-learn pipeline from file: {model_path}")
            return joblib.load(model_path)
        else:
            raise PipelineError(f"Invalid model path: {model_path}. Must be a .pkl file or a directory.")

    def make_prediction(self, input_file: Path, model_path: Path) -> float:
        """
        Makes a nitrogen prediction for a single raw spectral file.

        This method encapsulates the full prediction process:
        1. Loads the specified trained model.
        2. Loads and cleans the raw spectral data.
        3. Formats the data into the structure expected by the model.
        4. Returns a single prediction value.

        Args:
            input_file: Path to the raw spectral data file (.csv.txt).
            model_path: Path to the trained model (.pkl file or AutoGluon directory).

        Returns:
            The predicted nitrogen concentration as a float.
        
        Raises:
            FileNotFoundError: If the input file does not exist.
            PipelineError: If the data cannot be processed or prediction fails.
        """
        if not input_file.exists():
            raise FileNotFoundError(f"Input file not found: {input_file}")

        # 1. Load the model
        model = self._load_model(model_path)

        # 2. Load and clean the input data
        logger.info(f"Processing input file: {input_file.name}")
        wavelengths, intensities = DataManager.load_spectral_file(input_file)
        clean_intensities = self.data_cleanser.clean_spectra(str(input_file), intensities)

        if clean_intensities.size == 0:
            raise PipelineError(f"No data remaining for {input_file.name} after cleansing. Cannot predict.")

        # 3. Format data into a DataFrame for the pipeline
        # The trained pipeline expects a DataFrame with specific columns
        input_data = pd.DataFrame([{
            #"sample_id": input_file.stem,
            "wavelengths": wavelengths,
            "intensities": clean_intensities
        }])

        # 4. Make prediction
        logger.info("Generating prediction...")
        prediction_result = model.predict(input_data)
        
        # Extract the single float value from the prediction output
        predicted_value = prediction_result[0] if isinstance(prediction_result, (np.ndarray, pd.Series)) else prediction_result
        
        logger.info(f"Predicted Nitrogen %%: {predicted_value:.4f}")
        return float(predicted_value)

    
    def make_batch_predictions(self, input_dir: Path, model_path: Path) -> pd.DataFrame:
        """
        Processes a directory of raw files, averages them by sample ID, cleans them,
        and makes predictions on the valid samples.
        """
        logger.info(f"Starting batch prediction from directory: {input_dir}")
        model = self._load_model(model_path)

        # 1. Group raw files by sample ID
        files_by_sample = defaultdict(list)
        for file_path in input_dir.glob('*.csv.txt'):
            prefix = self.data_manager._extract_file_prefix(file_path.name)
            files_by_sample[prefix].append(file_path)
        logger.info(f"Found {len(files_by_sample)} unique sample IDs to process.")

        prediction_results = []
        for sample_id, file_paths in files_by_sample.items():
            try:
                # 2. Average the files for this sample ID using the centralized DataManager method
                wavelengths, averaged_intensities = self.data_manager.average_files_in_memory(file_paths)

                if averaged_intensities is None:
                    raise ValueError("Averaging failed, no data returned.")

                # 3. Clean the averaged sample
                clean_intensities = self.data_cleanser.clean_spectra(sample_id, averaged_intensities)

                if clean_intensities.size > 0:
                    # 4a. Predict on the clean sample
                    # input_data = pd.DataFrame([{
                    #     "sample_id": sample_id,
                    #     "wavelengths": wavelengths,
                    #     "intensities": clean_intensities
                    # }])
                    input_data = pd.DataFrame([{
                        "wavelengths": wavelengths,
                        "intensities": clean_intensities
                    }])
                    prediction = model.predict(input_data)[0]
                    prediction_results.append({'sampleId': sample_id, 'PredictedValue': prediction, 'Status': 'Success'})
                else:
                    # 4b. Handle bad files
                    logger.warning(f"Sample {sample_id} flagged as outlier; copying source files.")
                    for raw_file in file_paths:
                        shutil.copy(raw_file, self.config.bad_prediction_files_dir)
                    prediction_results.append({'sampleId': sample_id, 'PredictedValue': np.nan, 'Status': 'Failed - Outlier'})
            
            except Exception as e:
                logger.error(f"Failed to process sample {sample_id}: {e}")
                prediction_results.append({'sampleId': sample_id, 'PredictedValue': np.nan, 'Status': f'Failed - {e}'})
        
        return pd.DataFrame(prediction_results)