"""
AutoGluon Training Module: Defines the specific training process for the AutoGluon pipeline.
"""
import logging
from pathlib import Path
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.decomposition import PCA
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import cross_val_predict
import joblib
import numpy as np

from src.config.pipeline_config import Config
from src.features.dimension_reduction import DimensionReductionFactory
from src.features.feature_engineering import create_feature_pipeline
from src.features.concentration_features import create_enhanced_feature_pipeline_with_concentration
from src.models.custom_autogluon import AutoGluonRegressor
from src.reporting.reporter import Reporter
from src.models.base_optimizer import BaseOptimizer

logger = logging.getLogger(__name__)


class CalibratedModelWrapper:
    """Wrapper that applies calibration to model predictions."""
    
    def __init__(self, model, calibrator):
        self.model = model
        self.calibrator = calibrator
    
    def fit(self, X, y):
        """Fit the underlying model."""
        return self.model.fit(X, y)
    
    def predict(self, X):
        """Make predictions and apply calibration."""
        raw_predictions = self.model.predict(X)
        return self.calibrator.transform(raw_predictions)
    
    def __getattr__(self, name):
        """Delegate other attributes to the underlying model."""
        return getattr(self.model, name)

class AutoGluonTrainer(BaseOptimizer):
    """Handles the training and saving of an AutoGluon model."""
    def __init__(self, config: Config, strategy: str, reporter: Reporter, use_concentration_features: bool = True, use_parallel_features: bool = False, feature_n_jobs: int = -1):
        super().__init__(config)  # Initialize base optimizer
        self.strategy = strategy
        self.reporter = reporter
        self.use_concentration_features = use_concentration_features
        self.use_parallel_features = use_parallel_features
        self.feature_n_jobs = feature_n_jobs
        
        # Calibration for when sample weights are used
        self.calibrator = None
        self.use_calibration = False
        
        # IMPORTANT: Include scaler for AutoGluon - tree models + linear models need consistent scaling
        exclude_scaler = False
        
        # Choose feature pipeline based on concentration features setting
        if self.use_concentration_features:
            logger.info("Using enhanced feature pipeline with concentration-aware features")
            self.feature_pipeline = create_enhanced_feature_pipeline_with_concentration(
                config, strategy, exclude_scaler=exclude_scaler, use_parallel=use_parallel_features, n_jobs=feature_n_jobs
            )
        else:
            logger.info(f"Using standard feature pipeline (parallel={use_parallel_features}, feature_n_jobs={feature_n_jobs})")
            self.feature_pipeline = create_feature_pipeline(config, strategy, exclude_scaler=exclude_scaler, use_parallel=use_parallel_features, n_jobs=feature_n_jobs)
        
        # Store dimension reduction configuration for later use - DON'T add to feature pipeline
        self.use_dimension_reduction = config.use_dimension_reduction
        self.dimension_reduction_config = config.dimension_reduction
        self.dimension_reducer = None
        
        if self.use_dimension_reduction:
            logger.info(f"Dimension reduction ({self.dimension_reduction_config.method}) will be applied after feature engineering")
        
        # Use display strategy name that includes 'raw-spectral' when appropriate
        from main import get_display_strategy_name
        display_strategy = get_display_strategy_name(self.strategy, getattr(self.config, 'use_raw_spectral_data', False))
        
        self.autogluon_model_path = (
            Path(self.config.model_dir) / self.config.autogluon.model_subdirectory
            / f"{display_strategy}_{self.config.run_timestamp}"
        )
        self.autogluon_model_path.mkdir(parents=True, exist_ok=True)
        # Save feature pipeline inside the specific AutoGluon model directory
        self.feature_pipeline_path = self.autogluon_model_path / "feature_pipeline.pkl"
        
    def save(self):
        """Saves the trained feature pipeline and PCA transformer to disk."""
        import joblib
        
        logger.info(f"Saving feature pipeline to: {self.feature_pipeline_path}")
        joblib.dump(self.feature_pipeline, self.feature_pipeline_path)
        
        # Save dimension reducer if used
        if self.use_dimension_reduction and self.dimension_reducer is not None:
            reducer_path = self.autogluon_model_path / "dimension_reducer.pkl"
            self.dimension_reducer.save(str(reducer_path))
            logger.info(f"Dimension reducer saved to: {reducer_path}")
            
        logger.info("Feature pipeline saved successfully")

    def train(self, train_df: pd.DataFrame):
        """Trains the full feature engineering and AutoGluon pipeline."""
        X_train_raw = train_df.drop(columns=[self.config.target_column])
        y_train = train_df[self.config.target_column]
        y_train.name = self.config.target_column
        logger.info(f"Starting AutoGluon pipeline for strategy: {self.strategy}")

        logger.info("Preprocessing data for AutoGluon...")
        # Extract raw spectral data (should contain wavelengths and intensities columns)
        X_train_raw = train_df.drop(columns=[self.config.target_column])
        X_train_features = X_train_raw.drop(columns=[self.config.sample_id_column])
        
        # Log original feature count (should be 2 for raw data: wavelengths and intensities)
        original_features = X_train_features.shape[1]
        logger.info(f"Raw spectral data columns: {original_features} (expecting 2: wavelengths, intensities)")
        
        if original_features != 2:
            logger.warning(f"Expected 2 columns (wavelengths, intensities) but got {original_features}. "
                          f"Columns: {list(X_train_features.columns)}")
        
        # Apply feature engineering pipeline (this converts raw spectra -> engineered features)
        # Pass target values to pipeline for concentration features
        if self.config.use_raw_spectral_data:
            # For raw spectral mode, pass target values to enable concentration features
            X_train_processed = self._fit_transform_with_targets(self.feature_pipeline, X_train_features, y_train)
        else:
            X_train_processed = self.feature_pipeline.fit_transform(X_train_features)
        
        # Log feature count after engineering
        engineered_features = X_train_processed.shape[1]
        logger.info(f"Features after engineering: {engineered_features}")
        
        # Apply dimension reduction if enabled
        if self.use_dimension_reduction:
            logger.info(f"Applying {self.dimension_reduction_config.method} dimension reduction")
            
            # Create dimension reducer
            self.dimension_reducer = DimensionReductionFactory.create_reducer(
                method=self.dimension_reduction_config.method,
                params=self.dimension_reduction_config.get_params()
            )
            
            # Special handling for PLS which requires y values
            if self.dimension_reduction_config.method == 'pls':
                logger.info("Fitting PLS with target values")
                # Get y values that match the processed features
                y_for_pls = train_df.loc[X_train_features.index, self.config.target_column]
                X_train_processed = self.dimension_reducer.fit_transform(X_train_processed, y_for_pls)
            else:
                X_train_processed = self.dimension_reducer.fit_transform(X_train_processed)
            
            # Log reduction results
            reduced_features = X_train_processed.shape[1]
            
            # Get variance info if available (for PCA)
            if hasattr(self.dimension_reducer, 'pca') and hasattr(self.dimension_reducer.pca, 'explained_variance_ratio_'):
                variance_retained = self.dimension_reducer.pca.explained_variance_ratio_.sum()
                logger.info(f"{self.dimension_reduction_config.method.upper()} applied: {engineered_features} → {reduced_features} components (retained {variance_retained:.1%} variance)")
            else:
                logger.info(f"{self.dimension_reduction_config.method.upper()} applied: {engineered_features} → {reduced_features} components")
                
            logger.info(f"Features going into AutoGluon model: {reduced_features}")
        else:
            self.dimension_reducer = None
            logger.info(f"No dimension reduction applied - using all {engineered_features} features")
            logger.info(f"Features going into AutoGluon model: {engineered_features}")
        
        logger.info(f"Training samples: {X_train_processed.shape[0]}")
        
        # Create DataFrame with appropriate column names
        if self.use_dimension_reduction:
            feature_columns = [f"{self.dimension_reduction_config.method}_component_{i}" for i in range(X_train_processed.shape[1])]
        else:
            # Try multiple methods to get feature names from the pipeline
            feature_columns = None
            expected_feature_count = X_train_processed.shape[1]
            
            # Debug: Log all pipeline steps to understand the transformation
            logger.debug(f"Pipeline steps: {list(self.feature_pipeline.named_steps.keys())}")
            
            # Method 1: Try get_feature_names_out() with input feature names
            try:
                feature_columns = self.feature_pipeline.get_feature_names_out(X_train_features.columns)
                if feature_columns is not None:
                    if len(feature_columns) != expected_feature_count:
                        logger.warning(f"Method 1: Feature count mismatch - got {len(feature_columns)} names for {expected_feature_count} features")
                        # If there's a small mismatch, try to fix it by padding/truncating
                        if abs(len(feature_columns) - expected_feature_count) <= 5:
                            if len(feature_columns) < expected_feature_count:
                                # Pad with generic names
                                additional_names = [f"additional_feature_{i}" for i in range(len(feature_columns), expected_feature_count)]
                                feature_columns = list(feature_columns) + additional_names
                                logger.info(f"Method 1: Padded feature names to match expected count")
                            else:
                                # Truncate extra names
                                feature_columns = feature_columns[:expected_feature_count]
                                logger.info(f"Method 1: Truncated feature names to match expected count")
                        else:
                            feature_columns = None
                    else:
                        logger.debug(f"Method 1: Successfully got {len(feature_columns)} feature names from pipeline")
                else:
                    logger.debug(f"Method 1: Pipeline returned None for feature names")
            except (ValueError, AttributeError) as e:
                logger.debug(f"Method 1 failed: {e}")
            
            # Method 2: Try get_feature_names_out() without input (for transformers that don't need input)
            if feature_columns is None:
                try:
                    feature_columns = self.feature_pipeline.get_feature_names_out()
                    if len(feature_columns) != expected_feature_count:
                        logger.warning(f"Method 2: Feature count mismatch - got {len(feature_columns)} names for {expected_feature_count} features")
                        feature_columns = None
                    else:
                        logger.debug(f"Method 2: Successfully got {len(feature_columns)} feature names from pipeline")
                except (ValueError, AttributeError) as e:
                    logger.debug(f"Method 2 failed: {e}")
            
            # Method 3: Try to get from the SpectralFeatureGenerator directly (but account for subsequent steps)
            if feature_columns is None:
                try:
                    spectral_generator = self.feature_pipeline.named_steps.get('spectral_features')
                    if spectral_generator and hasattr(spectral_generator, 'get_feature_names_out'):
                        spectral_feature_names = spectral_generator.get_feature_names_out()
                        logger.debug(f"Method 3: SpectralFeatureGenerator produces {len(spectral_feature_names)} features")
                        
                        # Check for subsequent steps that add features
                        # Try minimal_concentration (for raw spectral mode)
                        concentration_step = self.feature_pipeline.named_steps.get('minimal_concentration')
                        if concentration_step and hasattr(concentration_step, 'get_feature_names_out'):
                            # Use the proper method to get feature names including input features
                            feature_columns = concentration_step.get_feature_names_out(spectral_feature_names)
                            logger.debug(f"Method 3: Got {len(feature_columns)} total features from minimal_concentration step")
                        else:
                            # Try concentration_features (for feature engineering mode)
                            concentration_step = self.feature_pipeline.named_steps.get('concentration_features')
                            if concentration_step and hasattr(concentration_step, 'get_feature_names_out'):
                                feature_columns = concentration_step.get_feature_names_out(spectral_feature_names)
                                logger.debug(f"Method 3: Got {len(feature_columns)} total features from concentration_features step")
                            else:
                                feature_columns = spectral_feature_names
                        
                        if len(feature_columns) != expected_feature_count:
                            logger.warning(f"Method 3: Feature count mismatch - got {len(feature_columns)} names for {expected_feature_count} features")
                            feature_columns = None
                        else:
                            logger.debug(f"Method 3: Successfully got {len(feature_columns)} feature names from SpectralFeatureGenerator + subsequent steps")
                except (ValueError, AttributeError) as e:
                    logger.debug(f"Method 3 failed: {e}")
            
            # Method 4: Build feature names by combining all transformers that add features
            if feature_columns is None:
                try:
                    feature_columns = self._build_feature_names_from_pipeline(X_train_features.columns, expected_feature_count)
                    if feature_columns is not None and len(feature_columns) == expected_feature_count:
                        logger.debug(f"Method 4: Successfully built {len(feature_columns)} feature names from pipeline steps")
                    else:
                        feature_columns = None
                except Exception as e:
                    logger.debug(f"Method 4 failed: {e}")
            
            # Fallback: create generic feature names that match the actual feature count
            if feature_columns is None:
                feature_columns = [f"feature_{i}" for i in range(expected_feature_count)]
                logger.info(f"Using generic feature names: {len(feature_columns)} features")
            
            # Final safety check
            if len(feature_columns) != expected_feature_count:
                logger.error(f"Feature name count mismatch: {len(feature_columns)} names vs {expected_feature_count} features")
                feature_columns = [f"feature_{i}" for i in range(expected_feature_count)]
                logger.info(f"Forced to use generic feature names: {len(feature_columns)} features")
            
        X_train_processed_df = pd.DataFrame(
            X_train_processed, 
            columns=feature_columns,
            index=X_train_features.index  # Preserve original index
        )
        
        # Filter y_train to match the processed features using the same index
        y_train_filtered = train_df.loc[X_train_processed_df.index, self.config.target_column].copy()
        y_train_filtered.name = self.config.target_column
        
        if len(X_train_processed_df) != len(y_train):
            logger.warning(f"Feature pipeline filtered data: {len(y_train)} -> {len(X_train_processed_df)} samples")
        
        # Save the fitted feature pipeline
        self.save()

        # Update AutoGluon config based on global GPU flag with GPU-safe configurations
        autogluon_config = self.config.autogluon.model_copy(deep=True)
        if self.config.use_gpu:
            autogluon_config.ag_args_fit['num_gpus'] = 1
            
            # Use GPU-safe preset and hyperparameters to avoid CatBoost/LightGBM exceptions
            logger.info("GPU enabled - applying GPU-safe configurations")
            autogluon_config.presets = autogluon_config.gpu_safe_preset  # Use extreme_quality or other safe preset
            
            # Use GPU-safe hyperparameters if available, OR add GPU settings to existing hyperparameters
            if hasattr(autogluon_config, 'gpu_safe_hyperparameters'):
                logger.info("Using GPU-safe hyperparameters with explicit GPU device settings")
                autogluon_config.hyperparameters = autogluon_config.gpu_safe_hyperparameters
            else:
                # Fallback: automatically add GPU settings to existing hyperparameters
                logger.info("Adding GPU device settings to existing hyperparameters")
                autogluon_config.hyperparameters = self._add_gpu_settings_to_hyperparameters(autogluon_config.hyperparameters)
            
            # Add any problematic models to exclusion list when using GPU
            if hasattr(autogluon_config, 'gpu_excluded_models') and autogluon_config.gpu_excluded_models:
                autogluon_config.excluded_model_types.extend(autogluon_config.gpu_excluded_models)
                logger.info(f"GPU mode: excluding additional models {autogluon_config.gpu_excluded_models}")
            
            logger.info(f"GPU enabled for AutoGluon with preset '{autogluon_config.presets}' (num_gpus=1)")
        else:
            autogluon_config.ag_args_fit['num_gpus'] = 0
            
            # For CPU mode, ensure XGBoost uses CPU device to avoid device mismatch warnings
            if hasattr(autogluon_config, 'hyperparameters') and 'XGB' in autogluon_config.hyperparameters:
                # Update XGBoost hyperparameters to use CPU device
                for i, xgb_config in enumerate(autogluon_config.hyperparameters['XGB']):
                    if isinstance(xgb_config, dict):
                        xgb_config = xgb_config.copy()
                        xgb_config['device'] = 'cpu'
                        xgb_config['tree_method'] = 'hist'
                        autogluon_config.hyperparameters['XGB'][i] = xgb_config
                logger.info("CPU mode: XGBoost configured to use CPU device to avoid CUDA warnings")
            
            logger.info("GPU disabled for AutoGluon (num_gpus=0)")
        
        self.autogluon_regressor = AutoGluonRegressor(
            config=autogluon_config, model_path=self.autogluon_model_path
        )
        self.autogluon_regressor.fit(X_train_processed_df, y_train_filtered)
        logger.info(f"AutoGluon training complete. Artifacts in: {self.autogluon_model_path}")
        
        # Check if calibration should be applied (only when sample weights are used)
        self._setup_calibration_if_needed(X_train_processed_df, y_train_filtered)
    
    def train_and_evaluate(self, train_df: pd.DataFrame, test_df: pd.DataFrame):
        """Trains AutoGluon model and evaluates on test set, using reporter for results."""
        # Train the model
        self.train(train_df)
        
        # Prepare test data
        X_test_raw = test_df.drop(columns=[self.config.target_column])
        y_test = test_df[self.config.target_column]
        
        # We need sample_id from the test set for detailed prediction saving
        test_sample_ids = X_test_raw[self.config.sample_id_column]
        
        # Transform test data (same process as training: raw spectral -> engineered features -> PCA if enabled)
        X_test_features = X_test_raw.drop(columns=[self.config.sample_id_column])
        X_test_processed = self.feature_pipeline.transform(X_test_features)
        
        engineered_features = X_test_processed.shape[1]
        logger.info(f"Test data after feature engineering: {engineered_features} features")
        
        # Apply dimension reduction if it was used during training
        if self.use_dimension_reduction and self.dimension_reducer is not None:
            X_test_processed = self.dimension_reducer.transform(X_test_processed)
            reduced_features = X_test_processed.shape[1]
            logger.info(f"Test data after {self.dimension_reduction_config.method}: {engineered_features} → {reduced_features} features")
            feature_columns = [f"{self.dimension_reduction_config.method}_component_{i}" for i in range(X_test_processed.shape[1])]
        else:
            logger.info(f"No dimension reduction applied to test data - using all {engineered_features} features")
            # Try multiple methods to get feature names from the pipeline (same as training)
            feature_columns = None
            expected_feature_count = X_test_processed.shape[1]
            
            # Method 1: Try get_feature_names_out() with input feature names
            try:
                feature_columns = self.feature_pipeline.get_feature_names_out(X_test_features.columns)
                if len(feature_columns) != expected_feature_count:
                    logger.warning(f"Test Method 1: Feature count mismatch - got {len(feature_columns)} names for {expected_feature_count} features")
                    feature_columns = None
                else:
                    logger.debug(f"Test Method 1: Successfully got {len(feature_columns)} feature names from pipeline")
            except (ValueError, AttributeError) as e:
                logger.debug(f"Test Method 1 failed: {e}")
            
            # Method 2: Try get_feature_names_out() without input
            if feature_columns is None:
                try:
                    feature_columns = self.feature_pipeline.get_feature_names_out()
                    if len(feature_columns) != expected_feature_count:
                        logger.warning(f"Test Method 2: Feature count mismatch - got {len(feature_columns)} names for {expected_feature_count} features")
                        feature_columns = None
                    else:
                        logger.debug(f"Test Method 2: Successfully got {len(feature_columns)} feature names from pipeline")
                except (ValueError, AttributeError) as e:
                    logger.debug(f"Test Method 2 failed: {e}")
            
            # Method 3: Try to get from the SpectralFeatureGenerator directly (but account for subsequent steps)
            if feature_columns is None:
                try:
                    spectral_generator = self.feature_pipeline.named_steps.get('spectral_features')
                    if spectral_generator and hasattr(spectral_generator, 'get_feature_names_out'):
                        spectral_feature_names = spectral_generator.get_feature_names_out()
                        logger.debug(f"Test Method 3: SpectralFeatureGenerator produces {len(spectral_feature_names)} features")
                        
                        # Check for subsequent steps that add features
                        feature_columns = list(spectral_feature_names)
                        
                        # Try minimal_concentration (for raw spectral mode)
                        concentration_step = self.feature_pipeline.named_steps.get('minimal_concentration')
                        if concentration_step and hasattr(concentration_step, 'get_feature_names_out'):
                            try:
                                # Use the proper method to get feature names including input features
                                feature_columns = concentration_step.get_feature_names_out(spectral_feature_names)
                                logger.debug(f"Test Method 3: Got {len(feature_columns)} total features from minimal_concentration step")
                            except Exception as e:
                                logger.debug(f"Test Method 3: minimal_concentration get_feature_names_out failed: {e}")
                                # Fallback: manually combine names
                                if hasattr(concentration_step, 'feature_names_out_') and concentration_step.feature_names_out_:
                                    feature_columns = list(spectral_feature_names) + list(concentration_step.feature_names_out_)
                                    logger.debug(f"Test Method 3: Manually combined {len(spectral_feature_names)} + {len(concentration_step.feature_names_out_)} = {len(feature_columns)} features")
                        else:
                            # Try concentration_features (for feature engineering mode)
                            concentration_step = self.feature_pipeline.named_steps.get('concentration_features')
                            if concentration_step and hasattr(concentration_step, 'get_feature_names_out'):
                                try:
                                    feature_columns = concentration_step.get_feature_names_out(spectral_feature_names)
                                    logger.debug(f"Test Method 3: Got {len(feature_columns)} total features from concentration_features step")
                                except Exception as e:
                                    logger.debug(f"Test Method 3: concentration_features get_feature_names_out failed: {e}")
                                    # Fallback: manually combine names
                                    if hasattr(concentration_step, 'feature_names_out_') and concentration_step.feature_names_out_:
                                        feature_columns = list(spectral_feature_names) + list(concentration_step.feature_names_out_)
                                        logger.debug(f"Test Method 3: Manually combined {len(spectral_feature_names)} + {len(concentration_step.feature_names_out_)} = {len(feature_columns)} features")
                        
                        if len(feature_columns) != expected_feature_count:
                            logger.warning(f"Test Method 3: Feature count mismatch - got {len(feature_columns)} names for {expected_feature_count} features")
                            feature_columns = None
                        else:
                            logger.debug(f"Test Method 3: Successfully got {len(feature_columns)} feature names from SpectralFeatureGenerator + subsequent steps")
                except (ValueError, AttributeError) as e:
                    logger.debug(f"Test Method 3 failed: {e}")
            
            # Method 4: Build feature names by combining all transformers that add features
            if feature_columns is None:
                try:
                    feature_columns = self._build_feature_names_from_pipeline(X_test_features.columns, expected_feature_count)
                    if feature_columns is not None and len(feature_columns) == expected_feature_count:
                        logger.debug(f"Test Method 4: Successfully built {len(feature_columns)} feature names from pipeline steps")
                    else:
                        feature_columns = None
                except Exception as e:
                    logger.debug(f"Test Method 4 failed: {e}")
            
            # Fallback: create generic feature names that match the actual feature count
            if feature_columns is None:
                feature_columns = [f"feature_{i}" for i in range(expected_feature_count)]
                logger.info(f"Using generic test feature names: {len(feature_columns)} features")
            
            # Final safety check
            if len(feature_columns) != expected_feature_count:
                logger.error(f"Test feature name count mismatch: {len(feature_columns)} names vs {expected_feature_count} features")
                feature_columns = [f"feature_{i}" for i in range(expected_feature_count)]
                logger.info(f"Forced to use generic test feature names: {len(feature_columns)} features")
            
        X_test_processed_df = pd.DataFrame(X_test_processed, columns=feature_columns)
        logger.info(f"Final test data shape for AutoGluon: {X_test_processed_df.shape}")
        
        # Make predictions for both train and test
        y_train_pred_raw = self.autogluon_regressor.predict(X_train_processed_df)
        y_test_pred_raw = self.autogluon_regressor.predict(X_test_processed_df)
        
        # Apply calibration if available
        y_train_pred = self._apply_calibration(y_train_pred_raw)
        y_test_pred = self._apply_calibration(y_test_pred_raw)
        
        # Apply post-processing calibration from base class
        y_train_pred, y_pred = self.apply_post_calibration(
            y_train, y_train_pred, y_test, y_test_pred, model_name="AUTOGLUON"
        )
        
        # Calculate metrics
        from src.utils.helpers import calculate_regression_metrics
        metrics = calculate_regression_metrics(y_test, y_pred)
        logger.info(f"AutoGluon evaluation metrics: {metrics}")
        
        # Get AutoGluon model info
        model_name = "autogluon"
        params = {
            "time_limit": self.config.autogluon.time_limit,
            "num_trials": self.config.autogluon.num_trials,
            "presets": self.config.autogluon.presets,
            "num_gpus": self.config.autogluon.ag_args_fit.get('num_gpus', 0),
            "num_stack_levels": self.config.autogluon.ag_args_fit.get('num_stack_levels', 2),
            "num_bag_folds": self.config.autogluon.ag_args_fit.get('num_bag_folds', 10),
            "num_bag_sets": self.config.autogluon.ag_args_fit.get('num_bag_sets', 2),
            "fold_fitting_strategy": self.config.autogluon.ag_args_ensemble.get('fold_fitting_strategy', 'sequential_local')
        }
        
        # Use the reporter to add results
        self.reporter.add_run_results(self.strategy, model_name, metrics, params)
        
        # Use the reporter to save detailed predictions and plots
        predictions_df = self.reporter.save_prediction_results(
            y_test, y_pred, test_sample_ids, self.strategy, model_name
        )
        self.reporter.generate_calibration_plot(predictions_df, self.strategy, model_name)
        
        # Extract and save the best individual model
        self._extract_and_save_best_model()
    
    def _extract_and_save_best_model(self):
        """Extract the best individual model from AutoGluon and save in consistent format."""
        from sklearn.pipeline import Pipeline
        import joblib
        
        logger.info("Extracting best model from AutoGluon ensemble...")
        
        # Log information about available models
        try:
            leaderboard = self.autogluon_regressor.predictor.leaderboard(silent=True)
            logger.info(f"AutoGluon trained {len(leaderboard)} models:")
            for i, row in leaderboard.head(3).iterrows():
                logger.info(f"  {i+1}. {row['model']} (score: {row['score_val']:.4f})")
        except Exception as e:
            logger.debug(f"Could not log leaderboard: {e}")
        
        try:
            # Method 1: Try to get the best model from leaderboard
            leaderboard = self.autogluon_regressor.predictor.leaderboard(silent=True)
            best_model_name = leaderboard.iloc[0]['model']  # First row is best model
            logger.info(f"Best AutoGluon model: {best_model_name} (score: {leaderboard.iloc[0]['score_val']:.4f})")
            
            # Method 2: Try different extraction approaches
            best_model = None
            
            # Approach A: Use get_model_best() if available
            if hasattr(self.autogluon_regressor.predictor, 'get_model_best'):
                try:
                    best_model = self.autogluon_regressor.predictor.get_model_best()
                    logger.info(f"Extracted via get_model_best(): {type(best_model)}")
                except Exception as e:
                    logger.debug(f"get_model_best() failed: {e}")
            
            # Approach B: Use _trainer.load_model() 
            if best_model is None:
                try:
                    best_model = self.autogluon_regressor.predictor._trainer.load_model(best_model_name)
                    logger.info(f"Extracted via _trainer.load_model(): {type(best_model)}")
                except Exception as e:
                    logger.debug(f"_trainer.load_model() failed: {e}")
            
            # Approach C: Use get_model() if available
            if best_model is None and hasattr(self.autogluon_regressor.predictor, 'get_model'):
                try:
                    best_model = self.autogluon_regressor.predictor.get_model(best_model_name)
                    logger.info(f"Extracted via get_model(): {type(best_model)}")
                except Exception as e:
                    logger.debug(f"get_model() failed: {e}")
            
            if best_model is not None:
                # Check if the extracted model is sklearn-compatible
                if hasattr(best_model, 'predict') and hasattr(best_model, 'fit'):
                    # Create a pipeline with the extracted model and optional calibration
                    if self.use_calibration and self.calibrator is not None:
                        from sklearn.pipeline import Pipeline
                        
                        # Create a calibrated model wrapper
                        calibrated_model = CalibratedModelWrapper(best_model, self.calibrator)
                        full_pipeline = Pipeline([
                            ('features', self.feature_pipeline),
                            ('model', calibrated_model)
                        ])
                        logger.info("Included calibration in saved pipeline")
                    else:
                        full_pipeline = Pipeline([
                            ('features', self.feature_pipeline),
                            ('model', best_model)
                        ])
                    
                    # Save as .pkl file - use display strategy name for consistency
                    from main import get_display_strategy_name
                    display_strategy = get_display_strategy_name(self.strategy, getattr(self.config, 'use_raw_spectral_data', False))
                    filename = f"{display_strategy}_autogluon_best_{self.config.run_timestamp}.pkl"
                    save_path = self.config.model_dir / filename
                    
                    joblib.dump(full_pipeline, save_path)
                    logger.info(f"Successfully saved extracted AutoGluon model to: {save_path}")
                else:
                    logger.warning(f"Extracted model {type(best_model)} is not sklearn-compatible")
                    raise ValueError("Extracted model is not compatible")
            else:
                raise ValueError("Could not extract best model using any method")
            
        except Exception as e:
            logger.error(f"Failed to extract best AutoGluon model: {e}")
            logger.info("Falling back to wrapper approach...")
            self._save_wrapper_pipeline()
    
    def _save_wrapper_pipeline(self):
        """Fallback: Save using the wrapper approach."""
        from sklearn.pipeline import Pipeline
        import joblib
        
        try:
            # Create pipeline with optional calibration
            if self.use_calibration and self.calibrator is not None:
                calibrated_model = CalibratedModelWrapper(self.autogluon_regressor, self.calibrator)
                full_pipeline = Pipeline([
                    ('features', self.feature_pipeline),
                    ('model', calibrated_model)
                ])
                logger.info("Included calibration in wrapper pipeline")
            else:
                full_pipeline = Pipeline([
                    ('features', self.feature_pipeline),
                    ('model', self.autogluon_regressor)
                ])
            
            # Use display strategy name for consistency
            from main import get_display_strategy_name
            display_strategy = get_display_strategy_name(self.strategy, getattr(self.config, 'use_raw_spectral_data', False))
            filename = f"{display_strategy}_autogluon_{self.config.run_timestamp}.pkl"
            save_path = self.config.model_dir / filename
            joblib.dump(full_pipeline, save_path)
            logger.info(f"Saved AutoGluon wrapper pipeline to: {save_path}")
            
        except Exception as e:
            logger.error(f"Failed to save AutoGluon wrapper: {e}")
            logger.info("AutoGluon model is available in directory format only")
    
    def _build_feature_names_from_pipeline(self, input_feature_names, expected_count):
        """
        Build feature names by manually combining outputs from each pipeline step.
        This is needed because sklearn's Pipeline.get_feature_names_out() doesn't
        always work correctly with custom transformers.
        """
        try:
            current_names = list(input_feature_names)
            
            # Handle different pipeline types
            if 'raw_spectral' in self.feature_pipeline.named_steps:
                # Raw spectral pipeline
                raw_step = self.feature_pipeline.named_steps.get('raw_spectral')
                if raw_step and hasattr(raw_step, 'get_feature_names_out'):
                    current_names = list(raw_step.get_feature_names_out())
                    logger.debug(f"After raw_spectral: {len(current_names)} features")
                
                # MinimalConcentrationFeatures adds concentration-aware features
                concentration_step = self.feature_pipeline.named_steps.get('minimal_concentration')
                if concentration_step:
                    if hasattr(concentration_step, 'get_feature_names_out'):
                        concentration_names = concentration_step.get_feature_names_out(current_names)
                        current_names = list(concentration_names)
                        logger.debug(f"After minimal_concentration: {len(current_names)} features")
                    elif hasattr(concentration_step, 'feature_names_out_'):
                        # Fallback: manually combine names if get_feature_names_out doesn't work
                        concentration_feature_names = concentration_step.feature_names_out_
                        current_names = current_names + concentration_feature_names
                        logger.debug(f"After minimal_concentration (manual): {len(current_names)} features")
            else:
                # Traditional feature engineering pipeline
                spectral_step = self.feature_pipeline.named_steps.get('spectral_features')
                if spectral_step and hasattr(spectral_step, 'get_feature_names_out'):
                    current_names = list(spectral_step.get_feature_names_out())
                    logger.debug(f"After spectral_features: {len(current_names)} features")
                
                # ConcentrationRangeFeatures adds concentration features in feature engineering mode
                concentration_step = self.feature_pipeline.named_steps.get('concentration_features')
                if concentration_step:
                    if hasattr(concentration_step, 'get_feature_names_out'):
                        concentration_names = concentration_step.get_feature_names_out(current_names)
                        current_names = list(concentration_names)
                        logger.debug(f"After concentration_features: {len(current_names)} features")
                    elif hasattr(concentration_step, 'feature_names_out_'):
                        # Fallback: manually combine names if get_feature_names_out doesn't work
                        concentration_feature_names = concentration_step.feature_names_out_
                        current_names = current_names + concentration_feature_names
                        logger.debug(f"After concentration_features (manual): {len(current_names)} features")
            
            # Steps like Imputer, Clipper, Scaler don't change feature names, just pass through
            # These steps don't modify feature names, they just transform the data
            
            # Additional check for any other feature-generating steps we might have missed
            for step_name, transformer in self.feature_pipeline.steps:
                if step_name not in ['raw_spectral', 'spectral_features', 'minimal_concentration', 'concentration_features']:
                    if hasattr(transformer, 'get_feature_names_out'):
                        try:
                            step_names = transformer.get_feature_names_out(current_names)
                            if step_names is not None and len(step_names) != len(current_names):
                                logger.debug(f"Step '{step_name}' changed feature count: {len(current_names)} -> {len(step_names)}")
                                current_names = list(step_names)
                        except Exception as e:
                            logger.debug(f"Step '{step_name}' get_feature_names_out failed: {e}")
            
            # Verify we have the expected number of features
            if len(current_names) == expected_count:
                return current_names
            else:
                logger.warning(f"Pipeline feature name building: expected {expected_count}, got {len(current_names)}")
                logger.debug(f"Current names length: {len(current_names)}, Expected: {expected_count}")
                return None
                
        except Exception as e:
            logger.debug(f"Failed to build feature names from pipeline: {e}")
            return None
    
    def _fit_transform_with_targets(self, pipeline, X, y):
        """
        Fit and transform a pipeline while passing target values to steps that need them.
        
        This is specifically for raw spectral mode where MinimalConcentrationFeatures
        needs target values to learn distribution statistics.
        """
        X_current = X.copy()
        
        for step_name, transformer in pipeline.steps:
            if step_name == 'minimal_concentration':
                # This step needs target values
                transformer.fit(X_current, y)
                X_current = transformer.transform(X_current)
                logger.debug(f"Step '{step_name}': fitted with targets, shape {X_current.shape}")
            else:
                # Regular fit/transform without targets
                transformer.fit(X_current)
                X_current = transformer.transform(X_current)
                logger.debug(f"Step '{step_name}': fitted without targets, shape {X_current.shape}")
                
        return X_current
    
    def _add_gpu_settings_to_hyperparameters(self, hyperparameters):
        """
        Automatically add GPU device settings to existing hyperparameters.
        
        This ensures that when AutoGluon is run with GPU support, the individual models
        get the proper GPU configuration that matches direct model training.
        """
        import copy
        gpu_hyperparameters = copy.deepcopy(hyperparameters)
        
        # Add GPU settings to LightGBM configurations
        if 'GBM' in gpu_hyperparameters:
            for i, config in enumerate(gpu_hyperparameters['GBM']):
                if isinstance(config, dict):
                    config = config.copy()
                    config['device'] = 'gpu'
                    config['gpu_platform_id'] = 0
                    config['gpu_device_id'] = 0
                    gpu_hyperparameters['GBM'][i] = config
            logger.debug(f"Added GPU settings to {len(gpu_hyperparameters['GBM'])} LightGBM configurations")
        
        # Add GPU settings to CatBoost configurations  
        if 'CAT' in gpu_hyperparameters:
            for i, config in enumerate(gpu_hyperparameters['CAT']):
                if isinstance(config, dict):
                    config = config.copy()
                    config['task_type'] = 'GPU'
                    config['devices'] = '0'
                    gpu_hyperparameters['CAT'][i] = config
            logger.debug(f"Added GPU settings to {len(gpu_hyperparameters['CAT'])} CatBoost configurations")
        
        # Update XGBoost to use CUDA (if it's using CPU)
        if 'XGB' in gpu_hyperparameters:
            for i, config in enumerate(gpu_hyperparameters['XGB']):
                if isinstance(config, dict):
                    config = config.copy()
                    config['device'] = 'cuda'
                    config['tree_method'] = 'hist'  # Required for GPU
                    gpu_hyperparameters['XGB'][i] = config
            logger.debug(f"Updated XGBoost to use CUDA in {len(gpu_hyperparameters['XGB'])} configurations")
        
        return gpu_hyperparameters
    
    def _setup_calibration_if_needed(self, X_train: pd.DataFrame, y_train: pd.Series):
        """
        Setup calibration if sample weights are being used.
        Uses cross-validation to avoid overfitting the calibrator.
        """
        # Check if sample weights are enabled in AutoGluon config
        use_sample_weights = getattr(self.config.autogluon, 'improved_config', False)
        
        if use_sample_weights:
            logger.info("Sample weights detected - setting up prediction calibration")
            
            try:
                # Use cross-validation predictions to train calibrator (avoids overfitting)
                logger.info("Generating cross-validation predictions for calibration...")
                cv_predictions = cross_val_predict(self.autogluon_regressor, X_train, y_train, cv=5)
                
                # Fit isotonic regression calibrator
                self.calibrator = IsotonicRegression(out_of_bounds='clip')
                self.calibrator.fit(cv_predictions, y_train)
                self.use_calibration = True
                
                # Log calibration diagnostics
                calibrated_cv_preds = self.calibrator.transform(cv_predictions)
                original_bias = np.mean(cv_predictions - y_train)
                calibrated_bias = np.mean(calibrated_cv_preds - y_train)
                
                logger.info(f"Calibration setup complete:")
                logger.info(f"  Original bias: {original_bias:.4f}")
                logger.info(f"  Calibrated bias: {calibrated_bias:.4f}")
                logger.info(f"  Bias improvement: {abs(original_bias) - abs(calibrated_bias):+.4f}")
                
            except Exception as e:
                logger.warning(f"Failed to setup calibration: {e}")
                logger.info("Continuing without calibration")
                self.use_calibration = False
                self.calibrator = None
        else:
            logger.debug("No sample weights detected - skipping calibration")
            self.use_calibration = False
            self.calibrator = None
    
    def _apply_calibration(self, predictions: np.ndarray) -> np.ndarray:
        """Apply calibration to predictions if calibrator is available."""
        if self.use_calibration and self.calibrator is not None:
            logger.debug("Applying calibration to predictions")
            return self.calibrator.transform(predictions)
        return predictions