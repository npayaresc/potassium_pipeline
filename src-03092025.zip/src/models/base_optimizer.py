"""Base optimizer class with post-processing calibration support."""

import numpy as np
import logging
from typing import Tuple, Optional
from src.models.calibration_utils import PrecisionCalibrator
from src.utils.helpers import calculate_regression_metrics

logger = logging.getLogger(__name__)


class BaseOptimizer:
    """Base class for model optimizers with post-calibration support."""
    
    def __init__(self, config):
        """Initialize base optimizer."""
        self.config = config
        self.post_calibrator = None
        self.post_calibration_config = None
        
    def apply_post_calibration(self, y_train, train_pred, y_test, test_pred, 
                              model_name: str = "model") -> Tuple[np.ndarray, np.ndarray]:
        """
        Apply post-processing calibration if enabled in config.
        
        Args:
            y_train: Training targets
            train_pred: Training predictions
            y_test: Test targets  
            test_pred: Test predictions
            model_name: Name of the model for logging
            
        Returns:
            Tuple of (calibrated_train_pred, calibrated_test_pred)
        """
        # Check if post-calibration is enabled
        use_post_calibration = getattr(self.config, 'use_post_calibration', False)
        
        if not use_post_calibration:
            logger.info(f"[{model_name.upper()}] Post-processing calibration is DISABLED")
            return train_pred, test_pred
            
        # Get calibration settings
        calibration_method = getattr(self.config, 'post_calibration_method', 'isotonic')
        target_metric = getattr(self.config, 'post_calibration_target', 'within_20.5')
        
        # Store config for later use
        self.post_calibration_config = {
            'enabled': True,
            'method': calibration_method,
            'target': target_metric
        }
        
        logger.info("=" * 60)
        logger.info(f"[{model_name.upper()}] POST-PROCESSING CALIBRATION ACTIVATED")
        logger.info(f"Method: {calibration_method}")
        logger.info(f"Target metric: {target_metric}")
        logger.info(f"Training samples: {len(y_train)}")
        logger.info(f"Test samples: {len(y_test)}")
        logger.info("=" * 60)
        
        try:
            # Create sample weights based on target metric
            if target_metric == 'within_20.5':
                # Focus on middle range for within_20.5% improvement
                weights = np.ones_like(y_train)
                p25, p75 = np.percentile(y_train, [25, 75])
                mask = (y_train >= p25) & (y_train <= p75)
                weights[mask] = 2.0
                weights = weights / weights.mean()
                logger.info(f"[{model_name.upper()}] Using middle-range weighting (25th-75th percentile)")
                
            elif target_metric == 'mape':
                # Inverse weighting for MAPE improvement
                weights = 1.0 / (y_train + 0.01)
                weights = weights / weights.mean()
                logger.info(f"[{model_name.upper()}] Using inverse-value weighting for MAPE")
                
            else:
                weights = None
                logger.info(f"[{model_name.upper()}] Using uniform weights")
            
            # Fit calibrator on training data
            self.post_calibrator = PrecisionCalibrator(method=calibration_method)
            self.post_calibrator.fit(y_train, train_pred, sample_weight=weights)
            
            # Apply calibration
            train_pred_cal = self.post_calibrator.transform(train_pred)
            test_pred_cal = self.post_calibrator.transform(test_pred)
            
            # Clip to reasonable bounds
            train_pred_cal = np.clip(train_pred_cal, 0, max(y_train.max() * 1.2, 1.0))
            test_pred_cal = np.clip(test_pred_cal, 0, max(y_test.max() * 1.2, 1.0))
            
            # Calculate and log improvements
            original_train_metrics = calculate_regression_metrics(y_train, train_pred)
            original_test_metrics = calculate_regression_metrics(y_test, test_pred)
            calibrated_train_metrics = calculate_regression_metrics(y_train, train_pred_cal)
            calibrated_test_metrics = calculate_regression_metrics(y_test, test_pred_cal)
            
            logger.info(f"[{model_name.upper()}] POST-CALIBRATION RESULTS:")
            logger.info("-" * 50)
            logger.info("TEST SET - Before Post-Cal → After Post-Cal:")
            logger.info(f"  R²: {original_test_metrics['r2']:.4f} → {calibrated_test_metrics['r2']:.4f} "
                       f"({'↑' if calibrated_test_metrics['r2'] > original_test_metrics['r2'] else '↓'} "
                       f"{abs(calibrated_test_metrics['r2'] - original_test_metrics['r2']):.4f})")
            logger.info(f"  RMSE: {original_test_metrics['rmse']:.4f} → {calibrated_test_metrics['rmse']:.4f} "
                       f"({'↓' if calibrated_test_metrics['rmse'] < original_test_metrics['rmse'] else '↑'} "
                       f"{abs(calibrated_test_metrics['rmse'] - original_test_metrics['rmse']):.4f})")
            logger.info(f"  Within 20.5%: {original_test_metrics['within_20.5%']:.2f}% → "
                       f"{calibrated_test_metrics['within_20.5%']:.2f}% "
                       f"({'↑' if calibrated_test_metrics['within_20.5%'] > original_test_metrics['within_20.5%'] else '↓'} "
                       f"{abs(calibrated_test_metrics['within_20.5%'] - original_test_metrics['within_20.5%']):.2f}%)")
            logger.info(f"  MAPE: {original_test_metrics['mape']:.2f}% → {calibrated_test_metrics['mape']:.2f}% "
                       f"({'↓' if calibrated_test_metrics['mape'] < original_test_metrics['mape'] else '↑'} "
                       f"{abs(calibrated_test_metrics['mape'] - original_test_metrics['mape']):.2f}%)")
            
            logger.info("-" * 50)
            logger.info("TRAINING SET - Before Post-Cal → After Post-Cal:")
            logger.info(f"  R²: {original_train_metrics['r2']:.4f} → {calibrated_train_metrics['r2']:.4f}")
            logger.info(f"  RMSE: {original_train_metrics['rmse']:.4f} → {calibrated_train_metrics['rmse']:.4f}")
            logger.info(f"  Within 20.5%: {original_train_metrics['within_20.5%']:.2f}% → "
                       f"{calibrated_train_metrics['within_20.5%']:.2f}%")
            logger.info(f"  MAPE: {original_train_metrics['mape']:.2f}% → {calibrated_train_metrics['mape']:.2f}%")
            logger.info("=" * 60)
            
            return train_pred_cal, test_pred_cal
            
        except Exception as e:
            logger.error(f"[{model_name.upper()}] Post-calibration failed: {e}")
            logger.info(f"[{model_name.upper()}] Continuing without calibration")
            return train_pred, test_pred