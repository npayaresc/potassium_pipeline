"""
Custom scikit-learn compatible wrapper for the AutoGluon TabularPredictor.
This version mirrors the full functionality of the original implementation,
including sample weighting and prediction calibration.
"""
import logging
from pathlib import Path
from typing import Optional, Tuple, Dict, Any

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.base import BaseEstimator, RegressorMixin

try:
    from autogluon.tabular import TabularPredictor
    AUTOGLUON_AVAILABLE = True
except ImportError:
    AUTOGLUON_AVAILABLE = False

from src.config.pipeline_config import AutoGluonConfig
from src.utils.helpers import calculate_regression_metrics
from src.data_management.data_manager import DataManager

logger = logging.getLogger(__name__)

class AutoGluonRegressor(BaseEstimator, RegressorMixin):
    """A scikit-learn compatible wrapper for AutoGluon's TabularPredictor."""
    def __init__(self, config: AutoGluonConfig, model_path: Path, pipeline_config=None):
        if not AUTOGLUON_AVAILABLE:
            raise ImportError("AutoGluon not installed. Run 'pip install autogluon'.")
        self.config = config
        self.model_path = Path(model_path)  # Ensure it's a Path object
        self.predictor = None
        self.feature_names_in_ = None
        self.pipeline_config = pipeline_config
        self._data_manager = None
        if pipeline_config:
            self._data_manager = DataManager(pipeline_config)
    
    def __getstate__(self):
        """Custom pickling - exclude the TabularPredictor object."""
        state = self.__dict__.copy()
        # Remove the unpicklable TabularPredictor
        state['predictor'] = None
        return state
    
    def __setstate__(self, state):
        """Custom unpickling - restore the TabularPredictor object."""
        self.__dict__.update(state)
        # Reload the TabularPredictor from disk
        if self.model_path and self.model_path.exists():
            logger.info(f"Restoring AutoGluon predictor from: {self.model_path}")
            self.predictor = TabularPredictor.load(str(self.model_path))
        else:
            logger.warning(f"AutoGluon model path not found: {self.model_path}")
    
    def _ensure_predictor_loaded(self):
        """Ensure the TabularPredictor is loaded."""
        if self.predictor is None:
            if self.model_path and self.model_path.exists():
                logger.info(f"Loading AutoGluon predictor from: {self.model_path}")
                self.predictor = TabularPredictor.load(str(self.model_path))
            else:
                raise RuntimeError(f"AutoGluon model not found at: {self.model_path}")

    def _calculate_sample_weights_legacy(self, y: pd.Series) -> np.ndarray:
        """
        Legacy sample weights based on fixed concentration ranges.
        Adapted for magnesium concentration ranges (0.1-0.5%).
        """
        weights = np.ones_like(y, dtype=float)
        for i, val in enumerate(y):
            if 0.1 <= val < 0.15: weights[i] = 2.5     # Low range (rare)
            elif 0.15 <= val < 0.20: weights[i] = 2.0  # Low-medium range
            elif 0.20 <= val < 0.30: weights[i] = 1.2  # Medium range (common)
            elif 0.30 <= val < 0.40: weights[i] = 1.5  # Medium-high range
            elif 0.40 <= val <= 0.50: weights[i] = 2.5 # High range (rare)
            else: weights[i] = 1.0  # Outside expected range
        
        # Normalize weights
        return weights * len(y) / np.sum(weights)
    
    def _calculate_sample_weights_improved(self, y: pd.Series) -> np.ndarray:
        """
        Improved sample weights based on data distribution and ML best practices.
        
        Features:
        1. Automatic distribution analysis 
        2. Inverse frequency weighting for rare samples
        3. Smooth weighting curves to avoid discontinuities
        4. Data-driven thresholds instead of hard-coded ranges
        """
        y_values = y.values
        
        # 1. Calculate data distribution percentiles
        percentiles = np.percentile(y_values, [10, 25, 50, 75, 90])
        p10, p25, p50, p75, p90 = percentiles
        
        # 2. Calculate inverse frequency weights based on quantiles
        weights = np.ones_like(y_values, dtype=float)
        
        for i, val in enumerate(y_values):
            # Bottom 10% (rare low concentrations) - highest weight
            if val <= p10:
                weights[i] = 3.0
            # 10-25% percentile (low-medium concentrations)
            elif val <= p25:
                # Smooth transition using linear interpolation
                weight_factor = 3.0 - 0.8 * (val - p10) / (p25 - p10)
                weights[i] = max(2.2, weight_factor)
            # 25-50% percentile (medium-low concentrations)
            elif val <= p50:
                weights[i] = 1.8
            # 50-75% percentile (medium-high concentrations) - normal weight
            elif val <= p75:
                weights[i] = 1.0
            # 75-90% percentile (high concentrations)
            elif val <= p90:
                weights[i] = 1.5
            # Top 10% (rare high concentrations) - high weight
            else:
                weights[i] = 2.5
        
        # 3. Apply additional weighting for extreme values (beyond typical range)
        q05, q95 = np.percentile(y_values, [5, 95])
        extreme_mask = (y_values <= q05) | (y_values >= q95)
        weights[extreme_mask] *= 1.2  # Extra boost for very rare samples
        
        # 4. Smooth weights using local averaging to reduce noise
        if len(weights) > 10:  # Only smooth if we have enough samples
            try:
                from scipy.ndimage import gaussian_filter1d
                # Sort by concentration for smooth filtering
                sort_idx = np.argsort(y_values)
                weights_sorted = weights[sort_idx]
                # Apply mild smoothing (sigma=1.0)
                weights_smoothed = gaussian_filter1d(weights_sorted, sigma=1.0, mode='nearest')
                # Restore original order
                weights[sort_idx] = weights_smoothed
                logger.debug("Applied Gaussian smoothing to sample weights")
            except ImportError:
                logger.warning("SciPy not available - skipping weight smoothing")
                # Fallback: simple moving average smoothing
                if len(weights) > 20:
                    sort_idx = np.argsort(y_values)
                    weights_sorted = weights[sort_idx]
                    # Simple 3-point moving average
                    for i in range(1, len(weights_sorted) - 1):
                        weights_sorted[i] = (weights_sorted[i-1] + weights_sorted[i] + weights_sorted[i+1]) / 3
                    weights[sort_idx] = weights_sorted
                    logger.debug("Applied simple moving average smoothing to sample weights")
        
        # 5. Normalize weights to maintain total sample count
        weights = weights * len(y) / np.sum(weights)
        
        # 6. Log weight distribution for analysis
        logger.info(f"Weight distribution - Min: {weights.min():.2f}, Max: {weights.max():.2f}, Mean: {weights.mean():.2f}")
        logger.info(f"Data percentiles - P10: {p10:.2f}, P25: {p25:.2f}, P50: {p50:.2f}, P75: {p75:.2f}, P90: {p90:.2f}")
        
        return weights
    
    def _calculate_sample_weights(self, y: pd.Series, method: str = 'improved') -> np.ndarray:
        """
        Calculate sample weights using specified method.
        
        Args:
            y: Target concentration values
            method: 'legacy' (original hard-coded ranges) or 'improved' (data-driven)
            
        Returns:
            Normalized sample weights array
        """
        if method == 'legacy':
            logger.info("Using legacy weight calculation (hard-coded concentration ranges)")
            return self._calculate_sample_weights_legacy(y)
        elif method == 'improved':
            logger.info("Using improved weight calculation (data-driven distribution analysis)")
            return self._calculate_sample_weights_improved(y)
        else:
            raise ValueError(f"Unknown weight calculation method: {method}. Use 'legacy' or 'improved'.")

    def fit(self, X: pd.DataFrame, y: pd.Series):
        """Fits the AutoGluon TabularPredictor."""
        self.feature_names_in_ = list(X.columns)
        train_data = pd.concat([X, y], axis=1)
        
        predictor_kwargs = {
            'label': y.name,
            'path': str(self.model_path),
            'eval_metric': 'root_mean_squared_error',
            'verbosity': 2
        }

        # ENABLED: Testing sample weighting for extreme concentration ranges
        if self.config.use_improved_config:
            logger.info("Improved config enabled - applying sample weighting for concentration-aware training")
            weight_method = getattr(self.config, 'weight_method', 'improved')
            sample_weight = self._calculate_sample_weights(y, method=weight_method)
            train_data['sample_weight'] = sample_weight
            predictor_kwargs['sample_weight'] = 'sample_weight'
            predictor_kwargs['weight_evaluation'] = True  # Enable weight-based evaluation
            logger.info(f"Sample weights applied using '{weight_method}' method")
            logger.info(f"Sample weight range: Min={sample_weight.min():.3f}, Max={sample_weight.max():.3f}, Mean={sample_weight.mean():.3f}")
            logger.info("Weight-based evaluation enabled for AutoGluon")

        logger.info(f"Starting AutoGluon training. Models saved to: {self.model_path}")
        logger.info(f"Time limit: {self.config.time_limit} seconds.")

        # Check if preset uses dynamic hyperparameters (which conflicts with explicit hyperparameters)
        dynamic_hyperparams_presets = ['extreme_quality', 'high_quality', 'best_quality']
        use_explicit_hyperparams = self.config.presets not in dynamic_hyperparams_presets
        
        fit_kwargs = {
            'time_limit': self.config.time_limit,
            'presets': self.config.presets,
            'ag_args_fit': self.config.ag_args_fit,
            'ag_args_ensemble': self.config.ag_args_ensemble,
            'excluded_model_types': self.config.excluded_model_types,
            'refit_full': True,
        }
        
        # Only add hyperparameters if not using dynamic presets
        if use_explicit_hyperparams:
            fit_kwargs['hyperparameters'] = self.config.hyperparameters
            logger.info(f"Using explicit hyperparameters with preset '{self.config.presets}'")
        else:
            logger.info(f"Skipping explicit hyperparameters due to dynamic preset '{self.config.presets}'")

        self.predictor = TabularPredictor(**predictor_kwargs).fit(train_data, **fit_kwargs)
        logger.info("AutoGluon training completed.")
        logger.info(f"AutoGluon Leaderboard:\n{self.predictor.leaderboard(silent=True)}")
        
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Makes predictions, applying calibration if configured."""
        # Ensure predictor is loaded (handles post-pickling scenarios)
        self._ensure_predictor_loaded()
        
        # Ensure X is a DataFrame and reorder columns if needed
        if isinstance(X, pd.DataFrame):
            if self.feature_names_in_ is not None and list(X.columns) != self.feature_names_in_:
                # Reorder columns to match training feature order
                X_reordered = X[self.feature_names_in_]
            else:
                X_reordered = X
        else:
            # Convert numpy array to DataFrame with correct column names
            if self.feature_names_in_ is not None:
                X_reordered = pd.DataFrame(X, columns=self.feature_names_in_)
            else:
                X_reordered = pd.DataFrame(X)
        
        base_predictions = self.predictor.predict(X_reordered).values
        
        # DISABLED: Post-prediction calibration hurts performance
        # if self.config.use_improved_config:
        #     logger.debug("Improved config enabled - applying prediction calibration")
        #     weight_method = getattr(self.config, 'weight_method', 'improved')
        #     calibrated_predictions = self._apply_prediction_calibration(base_predictions, method=weight_method)
        #     return calibrated_predictions
        
        return base_predictions
    
    def _apply_prediction_calibration_legacy(self, predictions: np.ndarray) -> np.ndarray:
        """
        Legacy calibration based on fixed concentration ranges.
        """
        calibrated_predictions = np.copy(predictions)
        for i, pred in enumerate(predictions):
            if pred < 2.5: 
                calibrated_predictions[i] = pred * 0.85
            elif pred > 6.0: 
                calibrated_predictions[i] = pred * 1.08
            elif 2.5 <= pred < 3.0: 
                calibrated_predictions[i] = pred * 0.92
        return calibrated_predictions
    
    def _apply_prediction_calibration_improved(self, predictions: np.ndarray) -> np.ndarray:
        """
        Improved calibration based on statistical analysis and ML best practices.
        
        Features:
        1. Smooth calibration curves based on prediction distribution
        2. Adaptive scaling factors based on prediction confidence 
        3. Range-based calibration with gradual transitions
        4. Statistical outlier protection
        """
        calibrated_predictions = np.copy(predictions)
        
        # Calculate prediction distribution statistics
        pred_median = np.median(predictions)
        pred_std = np.std(predictions)
        q25, q75 = np.percentile(predictions, [25, 75])
        
        # Define calibration regions based on prediction distribution
        for i, pred in enumerate(predictions):
            # Very low predictions (bottom 10%)
            if pred <= np.percentile(predictions, 10):
                # Conservative downward adjustment with smooth transition
                adjustment_factor = 0.88 - 0.03 * min(1.0, (pred_median - pred) / pred_std)
                calibrated_predictions[i] = pred * max(0.82, adjustment_factor)
            
            # Low predictions (10-25%)
            elif pred <= q25:
                # Mild downward adjustment
                calibrated_predictions[i] = pred * 0.91
            
            # Medium-low predictions (25-50%)
            elif pred <= pred_median:
                # Minimal adjustment
                calibrated_predictions[i] = pred * 0.96
            
            # Medium-high predictions (50-75%)
            elif pred <= q75:
                # Slight upward adjustment
                calibrated_predictions[i] = pred * 1.02
            
            # High predictions (75-90%)
            elif pred <= np.percentile(predictions, 90):
                # Moderate upward adjustment
                calibrated_predictions[i] = pred * 1.05
            
            # Very high predictions (top 10%)
            else:
                # Strong upward adjustment with protection against extreme values
                adjustment_factor = 1.08 + 0.02 * min(1.0, (pred - pred_median) / pred_std)
                calibrated_predictions[i] = pred * min(1.12, adjustment_factor)
        
        # Apply additional refinement based on residual analysis (if available)
        # This would require training set predictions, which we don't have here
        # But could be added in future improvements
        
        # Log calibration statistics
        avg_adjustment = np.mean(calibrated_predictions / predictions)
        logger.debug(f"Calibration applied - Average adjustment factor: {avg_adjustment:.3f}")
        logger.debug(f"Calibration range - Min factor: {np.min(calibrated_predictions / predictions):.3f}, "
                    f"Max factor: {np.max(calibrated_predictions / predictions):.3f}")
        
        return calibrated_predictions
    
    def _apply_prediction_calibration(self, predictions: np.ndarray, method: str = 'improved') -> np.ndarray:
        """
        Apply prediction calibration using specified method.
        
        Args:
            predictions: Raw model predictions
            method: 'legacy' (hard-coded ranges) or 'improved' (adaptive)
            
        Returns:
            Calibrated predictions
        """
        if method == 'legacy':
            logger.debug("Applying legacy calibration (hard-coded factors)")
            return self._apply_prediction_calibration_legacy(predictions)
        elif method == 'improved':
            logger.debug("Applying improved calibration (adaptive factors)")
            return self._apply_prediction_calibration_improved(predictions)
        else:
            raise ValueError(f"Unknown calibration method: {method}. Use 'legacy' or 'improved'.")

    def load_reference_data(self) -> Optional[pd.DataFrame]:
        """
        Loads reference data for evaluation if pipeline config is available.
        
        Returns:
            DataFrame with reference data or None if not available.
        """
        if not self.pipeline_config:
            logger.warning("No pipeline config available. Cannot load reference data.")
            return None
            
        try:
            if not self._data_manager:
                self._data_manager = DataManager(self.pipeline_config)
            return self._data_manager.load_and_prepare_metadata()
        except Exception as e:
            logger.error(f"Failed to load reference data: {e}")
            return None

    def evaluate_predictions(self, predictions_df: pd.DataFrame, 
                           reference_df: Optional[pd.DataFrame] = None) -> Optional[Dict[str, Any]]:
        """
        Evaluates predictions against reference data and calculates metrics.
        
        Args:
            predictions_df: DataFrame with columns ['sampleId', 'PredictedValue', 'Status']
            reference_df: Optional reference DataFrame. If None, will attempt to load it.
            
        Returns:
            Dictionary containing metrics and evaluation results, or None if evaluation fails.
        """
        if reference_df is None:
            reference_df = self.load_reference_data()
            
        if reference_df is None:
            logger.warning("No reference data available for evaluation.")
            return None
            
        # Filter successful predictions only
        successful_predictions = predictions_df[predictions_df['Status'] == 'Success'].copy()
        if successful_predictions.empty:
            logger.warning("No successful predictions to evaluate.")
            return None
            
        # Extract sample ID prefixes for matching
        if not self._data_manager:
            logger.error("Data manager not available for sample ID extraction.")
            return None
            
        successful_predictions['sample_prefix'] = successful_predictions['sampleId'].apply(
            lambda x: self._data_manager._extract_file_prefix(x + "_dummy")
        )
        
        # Merge with reference data
        sample_id_col = self.pipeline_config.sample_id_column if self.pipeline_config else 'SampleID'
        target_col = self.pipeline_config.target_column if self.pipeline_config else 'ElementValue'
        
        merged_df = successful_predictions.merge(
            reference_df[[sample_id_col, target_col]], 
            left_on='sample_prefix', 
            right_on=sample_id_col, 
            how='inner'
        )
        
        if merged_df.empty:
            logger.warning("No matches found between predictions and reference data.")
            return None
            
        logger.info(f"Matched {len(merged_df)} predictions with reference data out of {len(successful_predictions)} successful predictions.")
        
        # Calculate metrics
        y_true = merged_df[target_col].values
        y_pred = merged_df['PredictedValue'].values
        
        metrics = calculate_regression_metrics(y_true, y_pred)
        
        evaluation_results = {
            'metrics': metrics,
            'matched_data': merged_df,
            'n_total_predictions': len(predictions_df),
            'n_successful_predictions': len(successful_predictions),
            'n_matched_with_reference': len(merged_df),
            'success_rate': len(successful_predictions) / len(predictions_df) * 100,
            'reference_match_rate': len(merged_df) / len(successful_predictions) * 100 if len(successful_predictions) > 0 else 0
        }
        
        # Log results
        logger.info("=== AUTOGLUON PREDICTION EVALUATION ===")
        logger.info(f"Total predictions: {evaluation_results['n_total_predictions']}")
        logger.info(f"Successful predictions: {evaluation_results['n_successful_predictions']} ({evaluation_results['success_rate']:.1f}%)")
        logger.info(f"Matched with reference: {evaluation_results['n_matched_with_reference']} ({evaluation_results['reference_match_rate']:.1f}%)")
        logger.info("=== PERFORMANCE METRICS ===")
        for metric, value in metrics.items():
            logger.info(f"{metric.upper()}: {value:.4f}")
        logger.info("=" * 40)
        
        return evaluation_results

    def generate_calibration_plot(self, evaluation_results: Dict[str, Any], 
                                save_path: Optional[Path] = None) -> Optional[Path]:
        """
        Generates a calibration plot from evaluation results.
        
        Args:
            evaluation_results: Results from evaluate_predictions method
            save_path: Optional path to save the plot. If None, uses default naming.
            
        Returns:
            Path to saved plot or None if generation fails.
        """
        try:
            matched_data = evaluation_results['matched_data']
            metrics = evaluation_results['metrics']
            
            target_col = self.pipeline_config.target_column if self.pipeline_config else 'ElementValue'
            y_true = matched_data[target_col].values
            y_pred = matched_data['PredictedValue'].values
            
            plt.figure(figsize=(8, 8))
            plt.scatter(y_true, y_pred, alpha=0.6, edgecolors='k', label='Predicted vs. Actual')
            
            # Plot ideal 1:1 line
            lims = [min(y_true.min(), y_pred.min()), max(y_true.max(), y_pred.max())]
            plt.plot(lims, lims, 'r--', alpha=0.75, lw=2, label='Ideal 1:1 Line')
            
            plt.title('AutoGluon Model Calibration Curve', fontsize=16)
            plt.xlabel('Actual Magnesium Concentration (%)', fontsize=12)
            plt.ylabel('Predicted Magnesium Concentration (%)', fontsize=12)
            plt.legend()
            plt.grid(True, linestyle='--', linewidth=0.5)
            
            # Add metrics text
            textstr = f'$R^2 = {metrics["r2"]:.4f}$\n'
            textstr += f'RMSE = {metrics["rmse"]:.4f}\n'
            textstr += f'MAE = {metrics["mae"]:.4f}\n'
            textstr += f'n = {len(matched_data)}'
            
            plt.text(0.05, 0.95, textstr, transform=plt.gca().transAxes, fontsize=11,
                     verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
            
            # Determine save path
            if save_path is None:
                if self.pipeline_config and hasattr(self.pipeline_config, 'reports_dir'):
                    timestamp = getattr(self.pipeline_config, 'run_timestamp', 'autogluon')
                    filename = f"calibration_plot_autogluon_{timestamp}.png"
                    save_path = Path(self.pipeline_config.reports_dir) / filename
                else:
                    save_path = Path("calibration_plot_autogluon.png")
            
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"Calibration plot saved to: {save_path}")
            return save_path
            
        except Exception as e:
            logger.error(f"Failed to generate calibration plot: {e}")
            return None

    def save_evaluation_results(self, evaluation_results: Dict[str, Any], 
                              save_path: Optional[Path] = None) -> Optional[Path]:
        """
        Saves detailed evaluation results to CSV.
        
        Args:
            evaluation_results: Results from evaluate_predictions method
            save_path: Optional path to save results. If None, uses default naming.
            
        Returns:
            Path to saved file or None if saving fails.
        """
        try:
            matched_data = evaluation_results['matched_data']
            
            # Determine save path
            if save_path is None:
                if self.pipeline_config and hasattr(self.pipeline_config, 'reports_dir'):
                    timestamp = getattr(self.pipeline_config, 'run_timestamp', 'autogluon')
                    filename = f"autogluon_evaluation_results_{timestamp}.csv"
                    save_path = Path(self.pipeline_config.reports_dir) / filename
                else:
                    save_path = Path("autogluon_evaluation_results.csv")
            
            # Prepare data for saving
            target_col = self.pipeline_config.target_column if self.pipeline_config else 'ElementValue'
            results_df = matched_data[['sampleId', 'PredictedValue', target_col]].copy()
            results_df = results_df.rename(columns={target_col: 'ActualValue'})
            results_df['AbsoluteError'] = np.abs(results_df['ActualValue'] - results_df['PredictedValue'])
            results_df['RelativeError'] = results_df['AbsoluteError'] / results_df['ActualValue'] * 100
            
            results_df.to_csv(save_path, index=False)
            logger.info(f"Evaluation results saved to: {save_path}")
            return save_path
            
        except Exception as e:
            logger.error(f"Failed to save evaluation results: {e}")
            return None