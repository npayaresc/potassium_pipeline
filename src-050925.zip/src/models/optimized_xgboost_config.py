"""
Optimized XGBoost Configuration for Improved R²

This configuration focuses on addressing common issues that lead to low R² scores:
1. Overfitting prevention
2. Better feature interaction capture
3. Improved regularization
4. Enhanced learning dynamics
"""

# Enhanced XGBoost parameters for better R²
OPTIMIZED_XGBOOST_PARAMS = {
    # Core learning parameters
    'n_estimators': 500,           # Increased from 100 - more trees for complex patterns
    'learning_rate': 0.03,         # Lower for more stable learning
    'max_depth': 6,                # Increased from 4 - capture more interactions
    
    # Regularization parameters
    'reg_alpha': 0.1,              # L1 regularization
    'reg_lambda': 1.0,             # L2 regularization  
    'gamma': 0.1,                  # Minimum split loss
    'min_child_weight': 1,         # Reduced for small dataset
    
    # Sampling parameters
    'subsample': 0.9,              # Row sampling
    'colsample_bytree': 0.9,       # Column sampling per tree
    'colsample_bylevel': 0.9,      # Column sampling per level
    'colsample_bynode': 0.9,       # Column sampling per node
    
    # Advanced parameters for spectral data
    'max_delta_step': 1,           # Helps with imbalanced data
    'scale_pos_weight': 1,         # For handling class imbalance
    'validate_parameters': True,
    'random_state': 42
}

# Tuning search space for Optuna optimization
XGBOOST_TUNING_SPACE = {
    'n_estimators': (200, 1000),
    'learning_rate': (0.01, 0.15),
    'max_depth': (4, 10),
    'reg_alpha': (0.0, 2.0),
    'reg_lambda': (0.5, 5.0),
    'gamma': (0.0, 1.0),
    'min_child_weight': (1, 10),
    'subsample': (0.7, 1.0),
    'colsample_bytree': (0.7, 1.0),
    'colsample_bylevel': (0.7, 1.0),
    'colsample_bynode': (0.7, 1.0)
}

# Feature engineering specific for XGBoost
XGBOOST_FEATURE_ENGINEERING = {
    'polynomial_features': True,
    'interaction_features': True,
    'feature_selection': True,
    'variance_threshold': 0.01,
    'correlation_threshold': 0.95
}