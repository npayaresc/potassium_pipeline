"""
Main Orchestration Script for the Nitrogen Prediction Pipeline.

This script serves as the entry point to run different stages of the ML pipeline,
including data preparation, standard training, AutoGluon training, hyperparameter
tuning, and prediction.

Usage:
  - python main.py train            (Trains all standard models from the config)
  - python main.py autogluon        (Runs the automated AutoGluon pipeline)
  - python main.py tune             (Runs Optuna hyperparameter optimization)
  - python main.py predict --input-file ... --model-path ... (Makes a prediction)
"""
import argparse
import json
import logging
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Optional
import pandas as pd
import shutil

from src.config.pipeline_config import config, Config
from src.data_management.data_manager import DataManager
from src.cleansing.data_cleanser import DataCleanser
from src.models.model_trainer import ModelTrainer
from src.models.autogluon_trainer import AutoGluonTrainer
from src.models.model_tuner import ModelTuner
from src.models.predictor import Predictor
from src.reporting.reporter import Reporter
from src.utils.helpers import calculate_regression_metrics, setup_logging
from src.utils.custom_exceptions import DataValidationError, PipelineError

logger = logging.getLogger(__name__)

def setup_pipeline_config(use_gpu: bool = False, validation_dir: Optional[str] = None) -> Config:
    """Sets up dynamic configuration values and creates all necessary directories."""
    config.run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    config.use_gpu = use_gpu
    # Only override config.custom_validation_dir if a value is explicitly provided
    if validation_dir is not None:
        config.custom_validation_dir = validation_dir
    
    if use_gpu:
        logger.info("GPU mode enabled - models will use CUDA acceleration where available")
    else:
        logger.info("GPU mode disabled - models will use CPU only")
    
    if config.custom_validation_dir:
        logger.info(f"Custom validation directory configured: {config.custom_validation_dir}")
    project_root = Path(__file__).resolve().parents[0]
    
    # Define all paths relative to the project root
    data_dir = project_root / "data"
    raw_data_dir = data_dir / "raw" / "data_5278_Phase3"
    processed_data_dir = data_dir / "processed"
    averaged_files_dir = data_dir / "averaged_files_per_sample"
    cleansed_files_dir = data_dir / "cleansed_files_per_sample"
    model_dir = project_root / "models"
    reports_dir = project_root / "reports"
    log_dir = project_root / "logs"
    bad_files_dir = project_root / "bad_files"
    bad_prediction_files_dir = project_root / "bad_prediction_files"
    reference_data_path = project_root / "data" / "reference_data" / "Final_Lab_Data_Nico_New.xlsx"
    
    # Create all directories first, before assigning to config
    for dir_path in [
        processed_data_dir, averaged_files_dir, cleansed_files_dir,
        model_dir, reports_dir, log_dir, bad_files_dir, bad_prediction_files_dir
    ]:
        dir_path.mkdir(parents=True, exist_ok=True)
    
    # Now assign paths to config after directories exist
    config.data_dir = data_dir
    config.raw_data_dir = raw_data_dir
    config.processed_data_dir = processed_data_dir
    config.averaged_files_dir = averaged_files_dir
    config.cleansed_files_dir = cleansed_files_dir
    config.model_dir = model_dir
    config.reports_dir = reports_dir
    config.log_dir = log_dir
    config.bad_files_dir = bad_files_dir
    config.bad_prediction_files_dir = bad_prediction_files_dir
    config.reference_data_path = reference_data_path
    config.sample_id_column = "Sample ID"
    
    setup_logging()
    return config

def run_data_preparation(cfg: Config):
    """Orchestrates the initial data preparation: averaging raw files."""
    data_manager = DataManager(cfg)
    data_manager.average_raw_files()

def load_and_clean_data(cfg: Config) -> pd.DataFrame:
    """Loads averaged data, cleans it, saves the clean version, and moves bad files."""
    data_manager = DataManager(cfg)
    metadata = data_manager.load_and_prepare_metadata()
    training_files = data_manager.get_training_data_paths()
    data_cleanser = DataCleanser(cfg)
    processed_data_for_training = []

    logger.info(f"Cleansing {len(training_files)} averaged files...")
    for file_path in training_files:
        wavelengths, intensities = data_manager.load_spectral_file(file_path)
        
        # Ensure intensity is 2D for the cleanser, as averaged files might have 1D intensity
        if intensities.ndim == 1:
            intensities = intensities.reshape(-1, 1)

        clean_intensities = data_cleanser.clean_spectra(str(file_path), intensities)
        
        if clean_intensities.size > 0:
            # Save the cleansed file for auditing and reuse
            cleansed_path = cfg.cleansed_files_dir / file_path.name
            # Start DataFrame with the Wavelength column
            cleansed_df = pd.DataFrame({'Wavelength': wavelengths})
            
            # Add each remaining intensity column (shot) one by one
            for i in range(clean_intensities.shape[1]):
                cleansed_df[f'Intensity{i+1}'] = clean_intensities[:, i]
                
            cleansed_df.to_csv(cleansed_path, index=False)

            # Prepare the data for in-memory use in the current pipeline run
            sample_id = file_path.name.replace('.csv.txt', '')
            target = metadata.loc[metadata[cfg.sample_id_column] == sample_id, cfg.target_column].values[0]
            processed_data_for_training.append({
                 cfg.sample_id_column: sample_id, "wavelengths": wavelengths,
                "intensities": clean_intensities, cfg.target_column: target
            })
        else:
            # File had too many outliers; move the *averaged* source file to bad_files
            try:
                destination = cfg.bad_files_dir / file_path.name
                shutil.move(str(file_path), str(destination))
                logger.warning(f"Moved bad averaged file {file_path.name} to {cfg.bad_files_dir}")
            except Exception as e:
                logger.error(f"Failed to move bad file {file_path.name}: {e}")
    
    if not processed_data_for_training:
        raise DataValidationError("No data left after cleansing. Aborting pipeline.")
    
    logger.info(f"Data cleaning complete. {len(processed_data_for_training)} files are ready for training.")
    return pd.DataFrame(processed_data_for_training)

def process_validation_data(cfg: Config, validation_dir: Path) -> pd.DataFrame:
    """Process raw validation files through averaging and cleansing."""
    logger.info(f"Processing validation data from: {validation_dir}")
    
    # Create temporary directories for validation data processing
    val_averaged_dir = cfg.data_dir / f"validation_averaged_{cfg.run_timestamp}"
    val_cleansed_dir = cfg.data_dir / f"validation_cleansed_{cfg.run_timestamp}"
    val_averaged_dir.mkdir(parents=True, exist_ok=True)
    val_cleansed_dir.mkdir(parents=True, exist_ok=True)
    
    data_manager = DataManager(cfg)
    data_cleanser = DataCleanser(cfg)
    metadata = data_manager.load_and_prepare_metadata()
    
    # Step 1: Average validation files
    logger.info("Averaging validation files...")
    file_groups = defaultdict(list)
    for file_path in validation_dir.glob('*.csv.txt'):
        prefix = data_manager._extract_file_prefix(file_path.name)
        file_groups[prefix].append(file_path)
    
    for prefix, file_paths in file_groups.items():
        logger.info(f"Processing validation group: {prefix} ({len(file_paths)} files)")
        wavelengths, averaged_data = data_manager.average_files_in_memory(file_paths)
        
        if wavelengths is not None and averaged_data is not None:
            output_path = val_averaged_dir / f"{prefix}.csv.txt"
            output_df = pd.DataFrame()
            output_df['Wavelength'] = wavelengths
            for i in range(averaged_data.shape[1]):
                output_df[f'Intensity{i+1}'] = averaged_data[:, i]
            output_df.to_csv(output_path, index=False)
    
    # Step 2: Clean averaged validation files and prepare dataset
    logger.info("Cleaning validation files...")
    processed_validation_data = []
    
    for file_path in val_averaged_dir.glob("*.csv.txt"):
        wavelengths, intensities = data_manager.load_spectral_file(file_path)
        
        if intensities.ndim == 1:
            intensities = intensities.reshape(-1, 1)
        
        clean_intensities = data_cleanser.clean_spectra(str(file_path), intensities)
        
        if clean_intensities.size > 0:
            sample_id = file_path.name.replace('.csv.txt', '')
            
            # Check if this sample exists in metadata
            if sample_id in metadata[cfg.sample_id_column].values:
                target = metadata.loc[metadata[cfg.sample_id_column] == sample_id, cfg.target_column].values[0]
                processed_validation_data.append({
                    cfg.sample_id_column: sample_id,
                    "wavelengths": wavelengths,
                    "intensities": clean_intensities,
                    cfg.target_column: target
                })
            else:
                logger.warning(f"Validation sample {sample_id} not found in metadata, skipping...")
    
    if not processed_validation_data:
        raise DataValidationError("No valid validation data found after processing.")
    
    logger.info(f"Validation data processing complete. {len(processed_validation_data)} files ready.")
    
    # Clean up temporary directories
    shutil.rmtree(val_averaged_dir, ignore_errors=True)
    shutil.rmtree(val_cleansed_dir, ignore_errors=True)
    
    return pd.DataFrame(processed_validation_data)

def run_training_pipeline(use_gpu: bool = False, validation_dir: Optional[str] = None):
    """Executes the standard model training pipeline."""
    cfg = setup_pipeline_config(use_gpu, validation_dir)
    logger.info(f"Starting standard training run: {cfg.run_timestamp}")
    
    run_data_preparation(cfg)
    reporter = Reporter(cfg)
    full_dataset = load_and_clean_data(cfg)
    
    # Use either the passed validation_dir or the one from config
    validation_directory = validation_dir or cfg.custom_validation_dir
    
    if validation_directory:
        # Process validation data separately
        val_path = Path(validation_directory)
        if not val_path.exists():
            raise DataValidationError(f"Validation directory not found: {val_path}")
        
        validation_dataset = process_validation_data(cfg, val_path)
        
        # Extract sample IDs from validation dataset
        val_sample_ids = set(validation_dataset[cfg.sample_id_column])
        
        # Split data based on validation sample IDs
        test_df = full_dataset[full_dataset[cfg.sample_id_column].isin(val_sample_ids)]
        train_df = full_dataset[~full_dataset[cfg.sample_id_column].isin(val_sample_ids)]
        
        # If some validation samples weren't in the main dataset, add them
        missing_val_samples = val_sample_ids - set(test_df[cfg.sample_id_column])
        if missing_val_samples:
            missing_df = validation_dataset[validation_dataset[cfg.sample_id_column].isin(missing_val_samples)]
            test_df = pd.concat([test_df, missing_df], ignore_index=True)
        
        logger.info(f"Using custom validation split: {len(train_df)} training, {len(test_df)} validation samples")
    else:
        # Use standard random split
        train_df, test_df = DataManager(cfg).create_reproducible_splits(full_dataset)

    for strategy in cfg.feature_strategies:
        model_trainer = ModelTrainer(cfg, strategy=strategy, reporter=reporter)
        model_trainer.train_and_evaluate(train_df, test_df)
    
    reporter.save_summary_report()
    logger.info("Standard training pipeline run completed successfully.")

def run_autogluon_pipeline(use_gpu: bool = False, validation_dir: Optional[str] = None):
    """Executes the dedicated AutoGluon training pipeline."""
    cfg = setup_pipeline_config(use_gpu, validation_dir)
    logger.info(f"Starting AutoGluon training run: {cfg.run_timestamp}")
    reporter = Reporter(cfg)
    run_data_preparation(cfg)
    full_dataset = load_and_clean_data(cfg)
    
    # Use either the passed validation_dir or the one from config
    validation_directory = validation_dir or cfg.custom_validation_dir
    
    if validation_directory:
        # Process validation data separately
        val_path = Path(validation_directory)
        if not val_path.exists():
            raise DataValidationError(f"Validation directory not found: {val_path}")
        
        validation_dataset = process_validation_data(cfg, val_path)
        
        # Extract sample IDs from validation dataset
        val_sample_ids = set(validation_dataset[cfg.sample_id_column])
        
        # Split data based on validation sample IDs
        test_df = full_dataset[full_dataset[cfg.sample_id_column].isin(val_sample_ids)]
        train_df = full_dataset[~full_dataset[cfg.sample_id_column].isin(val_sample_ids)]
        
        # If some validation samples weren't in the main dataset, add them
        missing_val_samples = val_sample_ids - set(test_df[cfg.sample_id_column])
        if missing_val_samples:
            missing_df = validation_dataset[validation_dataset[cfg.sample_id_column].isin(missing_val_samples)]
            test_df = pd.concat([test_df, missing_df], ignore_index=True)
        
        logger.info(f"Using custom validation split: {len(train_df)} training, {len(test_df)} validation samples")
    else:
        # Create train/test splits like the standard pipeline
        train_df, test_df = DataManager(cfg).create_reproducible_splits(full_dataset)
    
    strategy_for_autogluon = "simple_only" # As per original logic, often best for AutoGluon
    logger.info(f"Using feature strategy '{strategy_for_autogluon}' for AutoGluon.")
    trainer = AutoGluonTrainer(config=cfg, strategy=strategy_for_autogluon, reporter=reporter)
    trainer.train_and_evaluate(train_df, test_df)
    
    reporter.save_summary_report()
    
    logger.info("AutoGluon pipeline run completed successfully.")

def run_tuning_pipeline(use_gpu: bool = False, validation_dir: Optional[str] = None):
    """Executes the hyperparameter tuning pipeline."""
    cfg = setup_pipeline_config(use_gpu, validation_dir)
    logger.info(f"Starting tuning run: {cfg.run_timestamp}")
    
    run_data_preparation(cfg)
    reporter = Reporter(cfg)
    full_dataset = load_and_clean_data(cfg)
    
    # Use either the passed validation_dir or the one from config
    validation_directory = validation_dir or cfg.custom_validation_dir
    
    if validation_directory:
        # Process validation data separately
        val_path = Path(validation_directory)
        if not val_path.exists():
            raise DataValidationError(f"Validation directory not found: {val_path}")
        
        validation_dataset = process_validation_data(cfg, val_path)
        
        # Extract sample IDs from validation dataset
        val_sample_ids = set(validation_dataset[cfg.sample_id_column])
        
        # Split data based on validation sample IDs
        test_df = full_dataset[full_dataset[cfg.sample_id_column].isin(val_sample_ids)]
        train_df = full_dataset[~full_dataset[cfg.sample_id_column].isin(val_sample_ids)]
        
        # If some validation samples weren't in the main dataset, add them
        missing_val_samples = val_sample_ids - set(test_df[cfg.sample_id_column])
        if missing_val_samples:
            missing_df = validation_dataset[validation_dataset[cfg.sample_id_column].isin(missing_val_samples)]
            test_df = pd.concat([test_df, missing_df], ignore_index=True)
        
        logger.info(f"Using custom validation split: {len(train_df)} training, {len(test_df)} validation samples")
    else:
        train_df, test_df = DataManager(cfg).create_reproducible_splits(full_dataset)
    
    for strategy in cfg.feature_strategies:
        tuner = ModelTuner(cfg, reporter=reporter, strategy=strategy)
        tuner.tune(train_df, test_df)
    
    logger.info("Hyperparameter tuning pipeline run completed successfully.")

# --- Prediction Pipeline Functions ---

def run_single_prediction_pipeline(input_file: str, model_path: str):
    """Executes a prediction on a single, non-averaged input file."""
    cfg = setup_pipeline_config()
    logger.info(f"Starting single-file prediction for: {input_file}")

    predictor = Predictor(config=cfg)
    prediction = predictor.make_prediction(
        input_file=Path(input_file),
        model_path=Path(model_path)
    )
    
    print("\n--- SINGLE PREDICTION RESULT ---")
    print(f"  Input File: {Path(input_file).name}")
    print(f"  Model Used: {Path(model_path).name}")
    print(f"  Predicted Nitrogen Concentration: {prediction:.4f} %")
    print("--------------------------------\n")

def run_batch_prediction_pipeline(input_dir: str, model_path: str, output_file: str, reference_file: Optional[str] = None):
    """Executes batch predictions on a directory, including the averaging step."""
    cfg = setup_pipeline_config()
    logger.info(f"Starting batch prediction run from dir: {input_dir}")

    predictor = Predictor(config=cfg)
    results_df = predictor.make_batch_predictions(
        input_dir=Path(input_dir),
        model_path=Path(model_path)
    )
    
    # Handle output file path - check if it's already a full path or relative to reports_dir
    output_path = Path(output_file)
    if output_path.is_absolute():
        output_file_path = output_path
    elif str(output_path).startswith('reports/'):
        # Remove the reports prefix and use reports_dir
        relative_path = Path(str(output_path)[8:])  # Remove 'reports/' prefix
        output_file_path = cfg.reports_dir / relative_path
    else:
        # Assume it's relative to reports_dir
        output_file_path = cfg.reports_dir / output_file
    
    # Ensure the parent directory exists
    output_file_path.parent.mkdir(parents=True, exist_ok=True)
    results_df.to_csv(output_file_path, index=False)
    
    logger.info(f"Batch prediction complete. Results saved to {output_file_path}")
    print("\n--- BATCH PREDICTION SUMMARY ---")
    print(results_df.to_string())
    print("--------------------------------\n")
    
    if reference_file:
        logger.info(f"Reference file provided. Calculating performance metrics...")
        try:
            ref_df = pd.read_excel(reference_file)
            merged_df = pd.merge(
                results_df, ref_df, left_on='sampleId',
                right_on=cfg.sample_id_column, how='inner'
            )
            merged_df.dropna(subset=['PredictedValue', cfg.target_column], inplace=True)

            if merged_df.empty:
                logger.warning("No matching samples found between predictions and reference file.")
                return

            # --- METRICS CALCULATION FOR FULL DATASET ---
            full_metrics = calculate_regression_metrics(
                merged_df[cfg.target_column].values,
                merged_df['PredictedValue'].values
            )
            print("\n--- PREDICTION METRICS (Full Dataset) ---")
            print(f"  Compared {len(merged_df)} samples against reference file.")
            for name, value in full_metrics.items():
                print(f"  - {name.upper()}: {value:.4f}")
            print("-------------------------------------------\n")

            # --- FILTER DATA TO TRAINING RANGE AND RECALCULATE METRICS ---
            filtered_df = merged_df.copy()
            if cfg.target_value_min is not None:
                filtered_df = filtered_df[filtered_df[cfg.target_column] >= cfg.target_value_min]
            if cfg.target_value_max is not None:
                filtered_df = filtered_df[filtered_df[cfg.target_column] <= cfg.target_value_max]
            
            if filtered_df.empty:
                logger.warning("No samples found within the specified training range for filtered metrics.")
                filtered_metrics = {}
            else:
                filtered_metrics = calculate_regression_metrics(
                    filtered_df[cfg.target_column].values,
                    filtered_df['PredictedValue'].values
                )
                print("\n--- PREDICTION METRICS (Filtered to Training Range) ---")
                print(f"  Compared {len(filtered_df)} samples within range [{cfg.target_value_min}-{cfg.target_value_max}].")
                for name, value in filtered_metrics.items():
                    print(f"  - {name.upper()}: {value:.4f}")
                print("-----------------------------------------------------------\n")

            # --- SAVE METRICS REPORT TO JSON ---
            report_data = {
                'model_path': str(model_path),
                'prediction_file': str(output_file_path),
                'full_dataset_metrics': {
                    'sample_count': len(merged_df),
                    'metrics': full_metrics
                },
                'filtered_dataset_metrics': {
                    'sample_count': len(filtered_df),
                    'metrics': filtered_metrics
                }
            }
            report_path = cfg.reports_dir / f"prediction_metrics_report_{cfg.run_timestamp}.json"
            with open(report_path, 'w') as f:
                json.dump(report_data, f, indent=4)
            logger.info(f"Prediction metrics report saved to: {report_path}")

        except FileNotFoundError:
            logger.error(f"Reference file not found at: {reference_file}")
        except Exception as e:
            logger.error(f"Could not calculate metrics due to an error: {e}", exc_info=True)


def main():
    """Main entry point for the Nitrogen Prediction ML Pipeline."""
    parser = argparse.ArgumentParser(description="Nitrogen Prediction ML Pipeline")
    subparsers = parser.add_subparsers(dest="stage", required=True, help="Pipeline stage to run")

    # Add global GPU option to all subcommands
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument("--gpu", action="store_true", help="Enable GPU acceleration for training (requires CUDA)")
    parent_parser.add_argument("--validation-dir", type=str, help="Path to directory containing raw validation spectral files (.csv.txt)")

    subparsers.add_parser("train", parents=[parent_parser], help="Run the standard model training pipeline.")
    subparsers.add_parser("autogluon", parents=[parent_parser], help="Run the AutoGluon training pipeline.")
    subparsers.add_parser("tune", parents=[parent_parser], help="Run hyperparameter tuning for standard models.")

    # Single Prediction subparser
    parser_predict_single = subparsers.add_parser("predict-single", help="Make a prediction on a single raw file.")
    parser_predict_single.add_argument("--input-file", type=str, required=True, help="Path to the raw spectral .csv.txt file.")
    parser_predict_single.add_argument("--model-path", type=str, required=True, help="Path to the trained model (.pkl) or AutoGluon directory.")

    # Batch Prediction subparser
    parser_predict_batch = subparsers.add_parser("predict-batch", help="Make batch predictions on a directory of raw files.")
    parser_predict_batch.add_argument("--input-dir", type=str, required=True, help="Path to the directory with raw spectral files.")
    parser_predict_batch.add_argument("--model-path", type=str, required=True, help="Path to the trained model (.pkl) or AutoGluon directory.")
    parser_predict_batch.add_argument("--output-file", type=str, default="batch_predictions.csv", help="Name for the output CSV file in the reports directory.")
    parser_predict_batch.add_argument("--reference-file", type=str, required=False, help="Optional: Path to an Excel file with true values to calculate metrics.")

    args = parser.parse_args()
    
    # # For now, keep the hardcoded fallback for testing
    # args = argparse.Namespace()
    # time_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # args.stage = "train"
    # args.gpu = True  # Set to True to test GPU mode
    # #args.input_dir = "/home/payanico/nitrogen_pipeline/data/raw/data_5278_Phase3"
    # args.input_dir = "/home/payanico/nitrogen_pipeline/data/raw/combo_6_8"
    # args.model_path = "/home/payanico/nitrogen_pipeline/models/optimized_simple_only_xgboost_20250724_003832.pkl"
    # args.output_file = f"batch_predictions_{time_stamp}.csv"
    # args.reference_file = "/home/payanico/nitrogen_pipeline/data/reference_data/Final_Lab_Data_Nico_New.xlsx"
    
    try:
        use_gpu = getattr(args, 'gpu', False)
        validation_dir = getattr(args, 'validation_dir', None)
        if args.stage == "train":
            run_training_pipeline(use_gpu=use_gpu, validation_dir=validation_dir)
        elif args.stage == "autogluon":
            run_autogluon_pipeline(use_gpu=use_gpu, validation_dir=validation_dir)
        elif args.stage == "tune":
            run_tuning_pipeline(use_gpu=use_gpu, validation_dir=validation_dir)
        elif args.stage == "predict-single":
            run_single_prediction_pipeline(input_file=args.input_file, model_path=args.model_path)
        elif args.stage == "predict-batch":
            run_batch_prediction_pipeline(input_dir=args.input_dir, model_path=args.model_path, output_file=args.output_file, reference_file=args.reference_file)          
    except (DataValidationError, PipelineError, FileNotFoundError) as e:
        logger.error(f"Pipeline stopped due to a known error: {e}")
    except Exception as e:
        logger.critical(f"An unexpected error occurred in pipeline stage '{args.stage}': {e}", exc_info=True)


if __name__ == "__main__":
    main()