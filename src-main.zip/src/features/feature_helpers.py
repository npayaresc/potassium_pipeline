"""
Feature Engineering Helper Functions

This module contains the detailed logic for creating specific features,
ported directly from the original nitrogen_regression_model.py script.
"""
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple

# This is a placeholder class to allow the function to run standalone.
# In the pipeline, the real class from the config is used.
class PeakRegion:
    def __init__(self, element, lower, upper, centers):
        self.element = element
        self.lower_wavelength = lower
        self.upper_wavelength = upper

logger = logging.getLogger(__name__)

def extract_full_simple_features(
    region: PeakRegion, wavelengths: np.ndarray, intensities: np.ndarray
) -> Dict[str, float]:
    """
    Extracts the full set of 8 simple features from a given peak region.
    This logic is identical to the original _extract_simple_region_features.
    """
    prefix = f"{region.element}_simple"
    nan_features = {
        f'{prefix}_peak_area': np.nan, f'{prefix}_peak_height': np.nan,
        f'{prefix}_peak_center_intensity': np.nan, f'{prefix}_baseline_avg': np.nan,
        f'{prefix}_signal_range': np.nan, f'{prefix}_total_intensity': np.nan,
        f'{prefix}_height_to_baseline': np.nan, f'{prefix}_normalized_area': np.nan
    }

    # Ensure arrays are numpy arrays
    wavelengths = np.asarray(wavelengths)
    intensities = np.asarray(intensities)
    
    mask = (wavelengths >= region.lower_wavelength) & (wavelengths <= region.upper_wavelength)
    
    # Handle both 1D (single sample) and 2D (multiple samples) arrays
    if intensities.ndim == 1:
        if not np.any(mask) or intensities.size == 0 or len(wavelengths[mask]) < 2:
            return nan_features
        avg_spectrum = intensities[mask]
    else:
        if not np.any(mask) or intensities.shape[1] == 0 or len(wavelengths[mask]) < 2:
            return nan_features
        avg_spectrum = np.mean(intensities[mask, :], axis=1)
    
    peak_area = np.trapz(avg_spectrum, wavelengths[mask])
    total_intensity = np.sum(avg_spectrum)
    
    features = {
        f'{prefix}_peak_area': peak_area,
        f'{prefix}_peak_height': np.max(avg_spectrum),
        f'{prefix}_peak_center_intensity': avg_spectrum[len(avg_spectrum)//2],
        f'{prefix}_baseline_avg': (avg_spectrum[0] + avg_spectrum[-1]) / 2,
        f'{prefix}_signal_range': np.max(avg_spectrum) - np.min(avg_spectrum),
        f'{prefix}_total_intensity': total_intensity
    }
    features[f'{prefix}_height_to_baseline'] = features[f'{prefix}_peak_height'] - features[f'{prefix}_baseline_avg']
    features[f'{prefix}_normalized_area'] = peak_area / total_intensity if total_intensity > 0 else 0
    
    return features

def generate_high_nitrogen_features(df: pd.DataFrame, simple_feature_names: List[str]) -> Tuple[pd.DataFrame, List[str]]:
    """
    Generates the full set of enhanced features for high nitrogen detection.
    This logic is identical to the original _generate_high_nitrogen_features.
    """
    df_out = df.copy()
    enhanced_features = pd.DataFrame(index=df_out.index)
    enhanced_feature_names = []
    
    # Apply reasonable bounds to NC_ratio to prevent extreme values
    nc_ratio_safe = df_out['N_C_ratio'].fillna(0.0)
    # Clip NC_ratio to reasonable bounds (e.g., -50 to 50) to prevent corruption
    nc_ratio_clipped = np.clip(nc_ratio_safe, -50.0, 50.0)
    
    enhanced_features['NC_ratio_squared'] = nc_ratio_clipped ** 2
    enhanced_feature_names.append('NC_ratio_squared')
    enhanced_features['NC_ratio_cubic'] = nc_ratio_clipped ** 3
    enhanced_feature_names.append('NC_ratio_cubic')
    enhanced_features['NC_ratio_log'] = np.log1p(np.abs(nc_ratio_clipped))
    enhanced_feature_names.append('NC_ratio_log')
    
    n_height_col, c_height_col = 'N_I_simple_peak_height', 'C_I_simple_peak_height'
    if n_height_col in df_out.columns and c_height_col in df_out.columns:
        c_heights_safe = df_out[c_height_col].replace(0, 1e-6).fillna(1e-6)
        height_ratio = df_out[n_height_col].fillna(0) / c_heights_safe
        enhanced_features['NC_height_ratio'] = height_ratio
        enhanced_feature_names.append('NC_height_ratio')
        enhanced_features['NC_height_ratio_squared'] = height_ratio ** 2
        enhanced_feature_names.append('NC_height_ratio_squared')

    n_base_col, n_total_col = 'N_I_simple_baseline_avg', 'N_I_simple_total_intensity'
    if n_base_col in df_out.columns and n_total_col in df_out.columns:
        base_safe = df_out[n_base_col].replace(0, 1e-6).fillna(1e-6)
        sbr = df_out[n_total_col].fillna(0) / base_safe
        enhanced_features['N_signal_baseline_ratio'] = sbr
        enhanced_feature_names.append('N_signal_baseline_ratio')
        enhanced_features['N_signal_baseline_log'] = np.log1p(np.abs(sbr))
        enhanced_feature_names.append('N_signal_baseline_log')

    n_area_col = 'N_I_simple_peak_area'
    if n_area_col in df_out.columns:
        n_area_safe = df_out[n_area_col].fillna(0)
        n_75th = np.percentile(n_area_safe[n_area_safe > 0], 75) if np.any(n_area_safe > 0) else 0
        n_90th = np.percentile(n_area_safe[n_area_safe > 0], 90) if np.any(n_area_safe > 0) else 0
        
        enhanced_features['high_N_indicator'] = 1 / (1 + np.exp(-(n_area_safe - n_75th) / (n_75th + 1e-6)))
        enhanced_feature_names.append('high_N_indicator')
        enhanced_features['very_high_N_indicator'] = 1 / (1 + np.exp(-(n_area_safe - n_90th) / (n_90th + 1e-6)))
        enhanced_feature_names.append('very_high_N_indicator')
        
    other_elements = set(name.split('_simple')[0] for name in simple_feature_names if '_simple_' in name and 'N_I' not in name and 'C_I' not in name)
    for element in list(other_elements)[:2]:
        element_area_col = f'{element}_simple_peak_area'
        if element_area_col in df_out.columns and n_area_col in df_out.columns:
            element_safe = df_out[element_area_col].replace(0, 1e-6).fillna(1e-6)
            ratio = df_out[n_area_col].fillna(0) / element_safe
            enhanced_features[f'N_{element}_ratio'] = ratio
            enhanced_feature_names.append(f'N_{element}_ratio')

    logger.info(f"Generated {len(enhanced_feature_names)} high-nitrogen features.")
    return pd.concat([df_out, enhanced_features], axis=1), enhanced_feature_names