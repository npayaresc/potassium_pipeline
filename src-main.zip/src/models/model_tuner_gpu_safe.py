"""
GPU-Safe Model Tuner Configuration

This module provides safe configurations for running hyperparameter tuning
with GPU models on single-GPU systems.
"""

def get_safe_n_jobs(config, models_to_tune):
    """
    Determines safe n_jobs value based on GPU usage and models being tuned.
    
    Returns:
        int: Safe number of parallel jobs
    """
    gpu_models = {'xgboost', 'lightgbm', 'catboost'}
    cpu_only_models = {'random_forest', 'extratrees', 'svr', 'ridge', 'lasso'}
    
    # Check if any GPU models are being tuned
    has_gpu_models = any(model in gpu_models for model in models_to_tune)
    
    if config.use_gpu and has_gpu_models:
        # With single GPU, run trials sequentially to avoid conflicts
        return 1
    else:
        # CPU-only models can run in parallel
        return config.tuner.n_jobs

def get_gpu_config_for_parallel(trial_id, total_trials):
    """
    Returns GPU configuration for parallel trials (if multi-GPU available).
    
    For single GPU systems, this should not be used - run sequentially instead.
    """
    # Example for multi-GPU systems (not applicable for single GPU)
    gpu_count = 1  # You mentioned having only 1 GPU
    
    if gpu_count == 1:
        # Single GPU - should use sequential execution
        return {
            'gpu_device_id': 0,
            'gpu_memory_fraction': 0.8  # Leave some memory for system
        }
    else:
        # Multi-GPU - distribute trials across GPUs
        gpu_id = trial_id % gpu_count
        return {
            'gpu_device_id': gpu_id,
            'gpu_memory_fraction': 0.8 / (total_trials / gpu_count)
        }

def configure_gpu_model_safely(model_name, params, config):
    """
    Configures GPU models with memory limits and safety settings.
    """
    if model_name == 'xgboost':
        params['tree_method'] = 'hist'
        params['device'] = 'cuda:0'
        # Limit GPU memory growth
        params['max_bin'] = 256  # Reduce memory usage
        
    elif model_name == 'lightgbm':
        params['device'] = 'gpu'
        params['gpu_device_id'] = 0
        params['gpu_platform_id'] = 0
        # Reduce GPU memory usage
        params['gpu_use_dp'] = False  # Use float32 instead of float64
        params['max_bin'] = 255  # Default is 255, keep it reasonable
        
    elif model_name == 'catboost':
        params['task_type'] = 'GPU'
        params['devices'] = '0'
        # CatBoost GPU memory settings
        params['gpu_ram_part'] = 0.8  # Use max 80% of GPU RAM
        
    return params