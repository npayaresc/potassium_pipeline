"""
Improved Tuner Objective Functions

Following ML best practices for objective functions:
1. Consistent scaling (0-1 range preferred)
2. Single metric focus or weighted average with normalized components
3. Data-driven thresholds
4. Avoid arbitrary constants
"""
import numpy as np
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

def calculate_robust_objective_v2(cv_scores: np.ndarray, train_r2: float, test_r2: float) -> float:
    """
    Improved robust objective focusing on generalization.
    Returns value in [0, 1] range.
    """
    cv_mean = np.mean(cv_scores)
    cv_std = np.std(cv_scores)
    
    # Normalize CV stability to [0, 1] - lower std is better
    stability_score = 1 - min(cv_std, 0.2) / 0.2  # Cap std at 0.2
    
    # Generalization score - penalize overfitting
    generalization_gap = max(0, train_r2 - test_r2)
    generalization_score = 1 - min(generalization_gap, 0.2) / 0.2  # Cap gap at 0.2
    
    # Weighted combination
    return 0.7 * cv_mean + 0.15 * stability_score + 0.15 * generalization_score

def calculate_weighted_r2_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None) -> float:
    """
    Weighted R² that emphasizes accuracy on specific concentration ranges.
    Returns standard R² value in [-inf, 1] range.
    
    Args:
        y_true: True target values
        y_pred: Predicted values  
        base_r2: Legacy parameter for interface compatibility (not used)
    """
    # Calculate sample weights based on concentration
    # Use inverse frequency weighting or domain knowledge
    percentiles = np.percentile(y_true, [25, 75])
    
    weights = np.ones_like(y_true, dtype=float)
    # Give more weight to rare/important samples
    weights[y_true <= percentiles[0]] = 2.0  # Bottom quartile
    weights[y_true >= percentiles[1]] = 1.5  # Top quartile
    
    # Calculate weighted R²
    y_mean = np.average(y_true, weights=weights)
    ss_tot = np.average((y_true - y_mean)**2, weights=weights)
    ss_res = np.average((y_true - y_pred)**2, weights=weights)
    
    return 1 - (ss_res / ss_tot) if ss_tot > 0 else 0

def calculate_balanced_mae_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None) -> float:
    """
    Balanced MAE that normalizes errors by concentration range.
    Returns value in [0, 1] range where higher is better.
    
    Args:
        y_true: True target values
        y_pred: Predicted values
        base_r2: Legacy parameter for interface compatibility (not used)
    """
    # Calculate MAE for different concentration bins
    bins = np.percentile(y_true, [0, 33, 66, 100])
    mae_scores = []
    
    for i in range(len(bins)-1):
        mask = (y_true >= bins[i]) & (y_true < bins[i+1])
        if np.any(mask):
            mae = mean_absolute_error(y_true[mask], y_pred[mask])
            # Normalize by range to make errors comparable
            range_size = bins[i+1] - bins[i]
            normalized_mae = mae / range_size if range_size > 0 else mae
            mae_scores.append(normalized_mae)
    
    # Convert to maximization objective (lower MAE is better)
    avg_normalized_mae = np.mean(mae_scores) if mae_scores else 1.0
    return 1 / (1 + avg_normalized_mae)

def calculate_quantile_weighted_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None) -> float:
    """
    Objective that weights performance by quantiles of the target distribution.
    Ensures good performance across the entire range.
    
    Args:
        y_true: True target values
        y_pred: Predicted values
        base_r2: Legacy parameter for interface compatibility (not used)
    """
    # Split into quantiles
    n_quantiles = 5
    quantiles = np.linspace(0, 100, n_quantiles + 1)
    bounds = np.percentile(y_true, quantiles)
    
    quantile_scores = []
    for i in range(n_quantiles):
        mask = (y_true >= bounds[i]) & (y_true <= bounds[i+1])
        if np.sum(mask) > 1:  # Need at least 2 points
            # Calculate R² for this quantile
            r2_quantile = r2_score(y_true[mask], y_pred[mask])
            # Ensure non-negative (clip negative R² to 0)
            quantile_scores.append(max(0, r2_quantile))
    
    # Return mean of quantile scores
    return np.mean(quantile_scores) if quantile_scores else 0

def calculate_distribution_based_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None) -> float:
    """
    Distribution-based weighted R² that uses inverse density weighting.
    Emphasizes performance on underrepresented concentration ranges.
    
    Args:
        y_true: True target values
        y_pred: Predicted values  
        base_r2: Legacy parameter for interface compatibility (not used)
    """
    try:
        from scipy.stats import gaussian_kde
        # Estimate probability density at each point
        kde = gaussian_kde(y_true)
        densities = kde(y_true)
        
        # Inverse density weighting (smooth)
        weights = 1.0 / (densities + 1e-8)
        
        # Apply smoothing to prevent extreme weights
        weights = np.clip(weights, 0.2, 5.0)
        
    except ImportError:
        # Fallback: bin-based distribution weighting
        bins = np.percentile(y_true, [0, 20, 40, 60, 80, 100])
        bin_indices = np.digitize(y_true, bins) - 1
        
        # Calculate inverse frequency weights
        unique_bins, counts = np.unique(bin_indices, return_counts=True)
        total_samples = len(y_true)
        
        weights = np.ones_like(y_true, dtype=float)
        for bin_idx, count in zip(unique_bins, counts):
            mask = bin_indices == bin_idx
            weights[mask] = total_samples / (len(unique_bins) * count)
    
    # Calculate weighted R²
    y_mean = np.average(y_true, weights=weights)
    ss_tot = np.average((y_true - y_mean)**2, weights=weights)
    ss_res = np.average((y_true - y_pred)**2, weights=weights)
    
    return 1 - (ss_res / ss_tot) if ss_tot > 0 else 0

def calculate_hybrid_weighted_objective(y_true: np.ndarray, y_pred: np.ndarray, base_r2: float = None) -> float:
    """
    Hybrid weighted R² that combines distribution-based weighting with domain knowledge.
    Uses data-driven weighting but emphasizes extreme concentration ranges.
    
    Args:
        y_true: True target values
        y_pred: Predicted values  
        base_r2: Legacy parameter for interface compatibility (not used)
    """
    # Step 1: Get distribution-based weights
    try:
        from scipy.stats import gaussian_kde
        kde = gaussian_kde(y_true)
        densities = kde(y_true)
        dist_weights = 1.0 / (densities + 1e-8)
        dist_weights = np.clip(dist_weights, 0.2, 5.0)
    except ImportError:
        # Fallback: bin-based distribution weighting
        bins = np.percentile(y_true, [0, 20, 40, 60, 80, 100])
        bin_indices = np.digitize(y_true, bins) - 1
        unique_bins, counts = np.unique(bin_indices, return_counts=True)
        total_samples = len(y_true)
        
        dist_weights = np.ones_like(y_true, dtype=float)
        for bin_idx, count in zip(unique_bins, counts):
            mask = bin_indices == bin_idx
            dist_weights[mask] = total_samples / (len(unique_bins) * count)
    
    # Step 2: Apply domain knowledge modifiers
    percentiles = np.percentile(y_true, [25, 75])
    domain_modifiers = np.ones_like(y_true, dtype=float)
    
    # Emphasize extreme ranges (domain knowledge)
    domain_modifiers[y_true <= percentiles[0]] *= 1.3  # Low concentrations
    domain_modifiers[y_true >= percentiles[1]] *= 1.2  # High concentrations
    
    # Step 3: Combine both approaches
    weights = dist_weights * domain_modifiers
    
    # Normalize weights
    weights = weights * len(y_true) / np.sum(weights)
    
    # Calculate weighted R²
    y_mean = np.average(y_true, weights=weights)
    ss_tot = np.average((y_true - y_mean)**2, weights=weights)
    ss_res = np.average((y_true - y_pred)**2, weights=weights)
    
    return 1 - (ss_res / ss_tot) if ss_tot > 0 else 0