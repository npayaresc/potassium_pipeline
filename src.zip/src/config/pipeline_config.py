"""
Centralized Configuration Management for the ML Pipeline.

Uses Pydantic for data validation and clear structure.
"""
from typing import List, Dict, Any, Optional, Literal
from pydantic import BaseModel, DirectoryPath, FilePath, field_validator
import os


class ModelParamsConfig(BaseModel):
    """Default parameters for the standard training models."""
    ridge: Dict[str, Any] = {"alpha": 1.0}
    lasso: Dict[str, Any] = {"alpha": 0.1}
    elastic_net: Dict[str, Any] = {"alpha": 0.1, "l1_ratio": 0.5}
    random_forest: Dict[str, Any] = {"n_estimators": 100}
    gradient_boost: Dict[str, Any] = {"n_estimators": 100}
    xgboost: Dict[str, Any] = {"n_estimators": 100, "learning_rate": 0.1, "max_depth": 6}
    lightgbm: Dict[str, Any] = {"n_estimators": 100, "learning_rate": 0.1, "max_depth": 6}
    catboost: Dict[str, Any] = {"n_estimators": 100, "learning_rate": 0.1, "depth": 6}
    svr: Dict[str, Any] = {"kernel": 'rbf', "C": 1.0, "gamma": 'scale'}
    extratrees: Dict[str, Any] = {"n_estimators": 100}

# Tuner Config
class TunerConfig(BaseModel):
    """Configuration for the Optuna hyperparameter tuner."""
    n_trials: int = 200
    timeout: int = 8600
    n_jobs: int = 4
    #models_to_tune: List[str] = ["random_forest", "xgboost", "lightgbm", "catboost", "svr", "extratrees"]
    models_to_tune: List[str] = ["xgboost"]
    # Use this to select the tuning goal.
    objective_function_name: Literal[
        'r2', 'robust', 'concentration_weighted', 'mape_focused',
        'robust_v2', 'weighted_r2', 'balanced_mae', 'quantile_weighted',
        'distribution_based', 'hybrid_weighted'
    ] = 'weighted_r2'



# This placeholder class is needed for Pydantic validation.
# In a real project, it would be imported from src.spectral_extraction.results
class PeakRegion(BaseModel):
    element: str
    lower_wavelength: float
    upper_wavelength: float
    center_wavelengths: List[float]

    @property
    def n_peaks(self) -> int:
        return len(self.center_wavelengths)

class AutoGluonConfig(BaseModel):
    """Configuration specific to the AutoGluon pipeline."""
    # This flag enables all the advanced features from your original code
    use_improved_config: bool = True
    
    # Sample weighting configuration
    weight_method: Literal['legacy', 'improved'] = 'improved'
    
    time_limit: int = 3600
    presets: str = 'best_quality'
    model_subdirectory: str = "autogluon"
    num_trials: int = 50  # Number of trials for AutoGluon hyperparameter optimization
    
    # Advanced training arguments from the original script
    ag_args_fit: Dict[str, Any] = {
        'num_bag_folds': 10,
        'num_bag_sets': 2,
        'num_stack_levels': 2,
        'num_gpus': 1, # Set to 1 to attempt GPU usage
    }
    ag_args_ensemble: Dict[str, Any] = {
        'fold_fitting_strategy': 'sequential_local', # Avoids GPU parallelism issues
    }
    excluded_model_types: List[str] = ['KNN', 'FASTAI']
    
    # The full "enhanced" hyperparameters dictionary from your original script
    hyperparameters: Dict[str, Any] = {
        'GBM': [
            {'num_boost_round': 200, 'learning_rate': 0.05, 'num_leaves': 63, 'feature_fraction': 0.8},
            {'num_boost_round': 300, 'learning_rate': 0.03, 'num_leaves': 127, 'feature_fraction': 0.7},
        ],
        'CAT': [
            {'iterations': 500, 'learning_rate': 0.05, 'depth': 8},
            {'iterations': 700, 'learning_rate': 0.03, 'depth': 10},
        ],
        'XGB': [
            {'n_estimators': 200, 'max_depth': 8, 'learning_rate': 0.05, 'subsample': 0.8},
            {'n_estimators': 300, 'max_depth': 10, 'learning_rate': 0.03, 'subsample': 0.7},
        ],
        'RF': [
            {'n_estimators': 200, 'max_features': 'sqrt', 'max_depth': 20},
            {'n_estimators': 300, 'max_features': 0.7, 'max_depth': None},
        ],
        'XT': [
            {'n_estimators': 200, 'max_features': 'sqrt', 'max_depth': 20},
            {'n_estimators': 300, 'max_features': 0.7, 'max_depth': None},
        ],
        'NN_TORCH': [
            {'num_epochs': 50, 'learning_rate': 0.001, 'dropout_prob': 0.2},
            {'num_epochs': 100, 'learning_rate': 0.0005, 'dropout_prob': 0.3},
        ]
    }

class Config(BaseModel):
    """Main configuration class for the entire pipeline."""
    project_name: str = "NitrogenPrediction"
    run_timestamp: str
    random_state: int = 42
    use_gpu: bool = False  # Global GPU flag

    data_dir: DirectoryPath
    raw_data_dir: DirectoryPath
    processed_data_dir: DirectoryPath
    model_dir: DirectoryPath
    reports_dir: DirectoryPath
    log_dir: DirectoryPath
    bad_files_dir: DirectoryPath
    averaged_files_dir: DirectoryPath  
    cleansed_files_dir: DirectoryPath 
    bad_prediction_files_dir: DirectoryPath 

    reference_data_path: FilePath
    
    # --- Data Management ---
    target_column: str = "Nitrogen %"
    sample_id_column: str = "Sample ID"
    exclude_pot_samples: bool = True
    test_split_size: float = 0.2
    max_samples: Optional[int] = None
    
    # ADDED: Configuration for target value filtering
    target_value_min: Optional[float] = 2.0
    target_value_max: Optional[float] = 7.0

    outlier_method: str = 'SAM'
    outlier_threshold: float = 0.95
    max_outlier_percentage: float = 50.0

    @field_validator('outlier_method')
    @classmethod
    def outlier_method_must_be_valid(cls, v):
        if v.upper() not in ['SAM', 'MAD']:
            raise ValueError("outlier_method must be 'SAM' or 'MAD'")
        return v.upper()

    nitrogen_region: PeakRegion = PeakRegion(
        element="N_I", lower_wavelength=741.0, upper_wavelength=743.0, center_wavelengths=[742.0]
    )
    context_regions: List[PeakRegion] = [
        PeakRegion(element="C_I", lower_wavelength=832.5, upper_wavelength=834.5, center_wavelengths=[833.5]),
        PeakRegion(element="CA_I_help", lower_wavelength=525.0, upper_wavelength=527.0, center_wavelengths=[526.0]),
        PeakRegion(element="N_II_help", lower_wavelength=746.8, upper_wavelength=748.8, center_wavelengths=[747.8]),
        PeakRegion(element="P_I_help", lower_wavelength=653.5, upper_wavelength=656.5, center_wavelengths=[654.5]),
        PeakRegion(element="K_I_help", lower_wavelength=768.69, upper_wavelength=770.69, center_wavelengths=[769.69]),
    ]

    @property
    def all_regions(self) -> List[PeakRegion]:
        return [self.nitrogen_region] + self.context_regions

    #feature_strategies: List[str] = ["N_only", "simple_only", "full_context"]
    feature_strategies: List[str] = ["simple_only"]
    peak_shapes: List[str] = ['lorentzian']
    fitting_mode: str = 'mean_first'
    baseline_correction: bool = True

    # models_to_train: List[str] = [
    #     "ridge", "lasso", "random_forest", "gradient_boost", "xgboost",
    #     "lightgbm", "catboost", "svr", "extratrees", "ridge_pca", "lasso_pca", "elastic_net_pca", "random_forest_pca", "gradient_boost_pca", "xgboost_pca", "lightgbm_pca", "catboost_pca", "svr_pca", "extratrees_pca"
    # ]
    models_to_train: List[str] = ["random_forest"]
    # Sample weighting configuration for model training
    use_sample_weights: bool = True
    sample_weight_method: Literal['legacy', 'improved', 'weighted_r2', 'distribution_based', 'hybrid'] = 'weighted_r2'
    
    model_params: ModelParamsConfig = ModelParamsConfig()
    cv_folds: int = 5

    autogluon: AutoGluonConfig = AutoGluonConfig()

    log_file: str = "pipeline.log"
    log_level: str = "INFO"
    
    # --- Model Tuning ---
    tuner: TunerConfig = TunerConfig()

    class Config:
        validate_assignment = True

config = Config(
    run_timestamp="placeholder", data_dir=".", raw_data_dir=".", processed_data_dir=".",
    model_dir=".", reports_dir=".", log_dir=".", reference_data_path="README.md", bad_files_dir=".", averaged_files_dir=".", cleansed_files_dir=".", bad_prediction_files_dir="."
)