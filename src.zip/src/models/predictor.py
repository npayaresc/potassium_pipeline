"""
Prediction Module

This module defines the Predictor class, which handles loading a trained model
and making predictions on new, unseen spectral data.
"""
from collections import defaultdict
import logging
from pathlib import Path
import shutil
import joblib
import pandas as pd
import numpy as np

from src.features.feature_engineering import create_feature_pipeline
from src.config.pipeline_config import Config
from src.data_management.data_manager import DataManager
from src.cleansing.data_cleanser import DataCleanser
from src.utils.custom_exceptions import PipelineError

# Conditionally import AutoGluon to avoid errors if it's not installed
try:
    from autogluon.tabular import TabularPredictor
    AUTOGLUON_AVAILABLE = True
except ImportError:
    AUTOGLUON_AVAILABLE = False

from src.models.custom_autogluon import AutoGluonRegressor

logger = logging.getLogger(__name__)

class Predictor:
    """Handles loading models and making predictions on new data."""

    def __init__(self, config: Config):
        """
        Initializes the Predictor.

        Args:
            config: The pipeline configuration object.
        """
        self.config = config
        self.data_cleanser = DataCleanser(config)
        # Use the same data manager methods for consistency
        self.data_manager = DataManager(config)

    def _load_model(self, model_path: Path) -> tuple:
        """
        Loads a model, handling both standard .pkl and AutoGluon models.

        Args:
            model_path: Path to the model file or directory.

        Returns:
            A tuple of (model, needs_manual_features) where needs_manual_features 
            indicates if manual feature transformation is required.
        """
        if model_path.is_dir():
            # This is an AutoGluon model directory (legacy format)
            if not AUTOGLUON_AVAILABLE:
                raise ImportError("AutoGluon is not installed, but trying to load an AutoGluon model.")
            logger.info(f"Loading legacy AutoGluon model from directory: {model_path}")
            logger.warning("Loading legacy AutoGluon format. Consider re-training to get consistent pipeline format.")
            self.feature_pipeline = joblib.load(model_path / "feature_pipeline.pkl")
            # Use AutoGluonRegressor wrapper to include calibration logic
            autogluon_regressor = AutoGluonRegressor(
                config=self.config.autogluon, 
                model_path=model_path,
                pipeline_config=self.config
            )
            autogluon_regressor.predictor = TabularPredictor.load(str(model_path))
            autogluon_regressor.feature_names_in_ = self.feature_pipeline.get_feature_names_out().tolist()
            return autogluon_regressor, True  # True = needs manual feature transformation
            
        elif model_path.suffix == '.pkl':
            # This is a standard scikit-learn pipeline (regular, fine-tuned, or new AutoGluon format)
            logger.info(f"Loading scikit-learn pipeline from file: {model_path}")
            pipeline = joblib.load(model_path)
            
            # Detect what type of pipeline this is for logging
            if hasattr(pipeline, 'named_steps') and 'model' in pipeline.named_steps:
                model_step = pipeline.named_steps['model']
                model_type = str(type(model_step))
                
                if 'AutoGluon' in model_type:
                    logger.info("Detected AutoGluon wrapper in consistent pipeline format")
                elif any(lib in model_type for lib in ['XGBoost', 'LightGBM', 'CatBoost', 'RandomForest', 'ExtraTrees']):
                    logger.info(f"Detected extracted AutoGluon or standard model: {type(model_step).__name__}")
                else:
                    logger.info(f"Detected standard pipeline model: {type(model_step).__name__}")
            
            return pipeline, False  # False = standard pipeline format (handles features internally)
        else:
            raise PipelineError(f"Invalid model path: {model_path}. Must be a .pkl file or a directory.")

    def make_prediction(self, input_file: Path, model_path: Path) -> float:
        """
        Makes a nitrogen prediction for a single raw spectral file.

        This method encapsulates the full prediction process:
        1. Loads the specified trained model.
        2. Loads and cleans the raw spectral data.
        3. Formats the data into the structure expected by the model.
        4. Returns a single prediction value.

        Args:
            input_file: Path to the raw spectral data file (.csv.txt).
            model_path: Path to the trained model (.pkl file or AutoGluon directory).

        Returns:
            The predicted nitrogen concentration as a float.
        
        Raises:
            FileNotFoundError: If the input file does not exist.
            PipelineError: If the data cannot be processed or prediction fails.
        """
        if not input_file.exists():
            raise FileNotFoundError(f"Input file not found: {input_file}")

        # 1. Load the model
        model, needs_manual_features = self._load_model(model_path)

        # 2. Load and clean the input data
        logger.info(f"Processing input file: {input_file.name}")
        # For raw files, we need to use the data manager instance method
        df = self.data_manager._read_raw_intensity_data(input_file)
        wavelengths = df['Wavelength'].values
        intensity_cols = [col for col in df.columns if col != 'Wavelength']
        intensities = df[intensity_cols].values
        
        # Ensure intensities is 2D for consistency with training
        if intensities.ndim == 1:
            intensities = intensities.reshape(-1, 1)
            
        clean_intensities = self.data_cleanser.clean_spectra(str(input_file), intensities)

        if clean_intensities.size == 0:
            raise PipelineError(f"No data remaining for {input_file.name} after cleansing. Cannot predict.")

        # 3. Format data into a DataFrame for the pipeline
        # The trained pipeline expects a DataFrame with specific columns
        input_data = pd.DataFrame([{
            #"sample_id": input_file.stem,
            "wavelengths": wavelengths,
            "intensities": clean_intensities
        }])
        
        # Apply manual feature transformation for legacy AutoGluon format
        if needs_manual_features:
            input_data = self.feature_pipeline.transform(input_data)
            logger.debug("Applied manual feature transformation for legacy format")
        
        # 4. Make prediction
        logger.info("Generating prediction...")
        prediction_result = model.predict(input_data)
        
        # Extract the single float value from the prediction output
        predicted_value = prediction_result[0] if isinstance(prediction_result, (np.ndarray, pd.Series)) else prediction_result
        
        logger.info(f"Predicted Nitrogen %%: {predicted_value:.4f}")
        return float(predicted_value)

    
    def make_batch_predictions(self, input_dir: Path, model_path: Path) -> pd.DataFrame:
        """
        Processes a directory of raw files, averages them by sample ID, cleans them,
        and makes predictions on the valid samples.
        """
        logger.info(f"Starting batch prediction from directory: {input_dir}")
        model, needs_manual_features = self._load_model(model_path)

        # 1. Group raw files by sample ID
        files_by_sample = defaultdict(list)
        for file_path in input_dir.glob('*.csv.txt'):
            prefix = self.data_manager._extract_file_prefix(file_path.name)
            files_by_sample[prefix].append(file_path)
        logger.info(f"Found {len(files_by_sample)} unique sample IDs to process.")

        prediction_results = []
        for sample_id, file_paths in files_by_sample.items():
            try:
                # 2. Average the files for this sample ID using the centralized DataManager method
                wavelengths, averaged_intensities = self.data_manager.average_files_in_memory(file_paths)

                if averaged_intensities is None:
                    raise ValueError("Averaging failed, no data returned.")

                # 3. Clean the averaged sample
                clean_intensities = self.data_cleanser.clean_spectra(sample_id, averaged_intensities)
                
                # Keep intensities as 2D to match training format
                # The feature extractor expects 2D intensities (n_wavelengths x n_shots)
                
                if clean_intensities.size > 0:
                    # 4a. Predict on the clean sample
                    # input_data = pd.DataFrame([{
                    #     "sample_id": sample_id,
                    #     "wavelengths": wavelengths,
                    #     "intensities": clean_intensities
                    # }])
                    input_data = pd.DataFrame([{
                        "wavelengths": wavelengths,
                        "intensities": clean_intensities
                    }])
                    
                    # Apply manual feature transformation for legacy AutoGluon format
                    if needs_manual_features:
                        input_data = self.feature_pipeline.transform(input_data)
                    
                    prediction = model.predict(input_data)[0]
                    prediction_results.append({'sampleId': sample_id, 'PredictedValue': prediction, 'Status': 'Success'})
                else:
                    # 4b. Handle bad files
                    logger.warning(f"Sample {sample_id} flagged as outlier; copying source files.")
                    for raw_file in file_paths:
                        shutil.copy(raw_file, self.config.bad_prediction_files_dir)
                    prediction_results.append({'sampleId': sample_id, 'PredictedValue': np.nan, 'Status': 'Failed - Outlier'})
            
            except Exception as e:
                logger.error(f"Failed to process sample {sample_id}: {e}")
                import traceback
                logger.debug(f"Traceback for {sample_id}:\n{traceback.format_exc()}")
                prediction_results.append({'sampleId': sample_id, 'PredictedValue': np.nan, 'Status': f'Failed - {e}'})
        
        results_df = pd.DataFrame(prediction_results)
        
        # If using legacy AutoGluon model, perform evaluation with reference data
        if needs_manual_features and hasattr(model, 'evaluate_predictions'):
            logger.info("AutoGluon model detected. Performing evaluation with reference data...")
            try:
                evaluation_results = model.evaluate_predictions(results_df)
                if evaluation_results:
                    # Generate calibration plot
                    plot_path = model.generate_calibration_plot(evaluation_results)
                    if plot_path:
                        logger.info(f"Calibration plot generated: {plot_path}")
                    
                    # Save detailed evaluation results
                    eval_path = model.save_evaluation_results(evaluation_results)
                    if eval_path:
                        logger.info(f"Detailed evaluation results saved: {eval_path}")
                        
            except Exception as e:
                logger.warning(f"Evaluation failed: {e}")
        
        return results_df