"""
Tuner Objective Functions

This module contains various objective functions that can be used by Optuna
to guide the hyperparameter search towards different goals (e.g., robustness,
performance on specific data slices).
"""
import numpy as np
from sklearn.metrics import r2_score, mean_absolute_error

def calculate_robust_objective(cv_scores: np.ndarray, train_r2: float, test_r2: float) -> float:
    """Calculates a robust objective that balances performance and overfitting."""
    cv_mean = np.mean(cv_scores)
    cv_std = np.std(cv_scores)
    
    stability_penalty = cv_std * 0.3
    overfitting_penalty = max(0, train_r2 - cv_mean) * 0.4
    
    return cv_mean - stability_penalty - overfitting_penalty

def calculate_concentration_weighted_objective(
    y_true: np.ndarray, y_pred: np.ndarray, base_r2: float
) -> float:
    """Calculates an objective with higher weights for low concentrations."""
    weights = np.ones_like(y_true, dtype=float)
    weights[y_true <= 3.0] = 3.0  # High weight for low concentrations
    weights[(y_true > 3.0) & (y_true <= 6.0)] = 1.5
    
    weighted_mse = np.average((y_true - y_pred) ** 2, weights=weights)
    weighted_rmse = np.sqrt(weighted_mse)
    
    # Combine with R² to balance overall fit and weighted performance
    # Lower weighted_rmse is better, so we invert it.
    return base_r2 + (1 / (1 + weighted_rmse))

def calculate_mape_focused_objective(
    y_true: np.ndarray, y_pred: np.ndarray, base_r2: float
) -> float:
    """Calculates an objective focused on minimizing MAPE, especially for low concentrations."""
    # Create masks for different concentration ranges
    low_mask = (y_true >= 1.0) & (y_true < 3.0)
    med_mask = (y_true >= 3.0) & (y_true < 5.0)

    def get_mape(mask):
        if not np.any(mask): return 100.0 # High penalty if no samples
        y_true_slice = y_true[mask]
        y_pred_slice = y_pred[mask]
        return np.mean(np.abs((y_true_slice - y_pred_slice) / y_true_slice)) * 100

    low_mape = get_mape(low_mask)
    med_mape = get_mape(med_mask)
    
    # Lower MAPE is better. We create an objective where higher is better.
    # Give high priority to low_mape.
    mape_score = (1 / (1 + low_mape)) * 0.7 + (1 / (1 + med_mape)) * 0.3
    
    return base_r2 * 0.5 + mape_score * 0.5